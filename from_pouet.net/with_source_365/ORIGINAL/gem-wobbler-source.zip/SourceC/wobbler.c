// This is the c source code of the 4kb intro called Wobbler.
// (c) 2000-2002 by Gergely Kutenics, gem@mailbox.hu
//
// I developed the code in c (this file), then I manually converted the final c code to
// NASM syntax assembly and I finally size optimized the assembly version.
//
// This code is very different from the final intro. This misses the final intro sequencing
// (which was done only in assembly). Several additional effects and other code parts are
// included here which were left out from the final intro.
//
// This code was tested to compile with the following compilers:
// - Microsoft Visual C version 6 - C compiler
// - Microsoft Visual C version 6 - C++ compiler
// - LCC
// - OpenWatcom version 1
//
// LCC compilation notes:
// The opengl32.lib supplied with LCC-Win32 is bad, the wglUseFontOutlines()
// function declaration is missing. You have to make a good opengl32.lib:
// - add the function name to buildlibs\opengl32.exp (take it from opengl.exp)
// - force LCC to generate the lib: "bin\buildlib.exe buildlibs\opengl32.exp"
// - move the lib to the directory "lib\"
//
// Visual C optimizations are turned on with #define TINY 1 (which is set
// in the project settings for configuration 'Win32 Tiny')

#define FULLSCREEN 1
#define FLASHES 0
#define SOUND 1
#define SOUND_SAVE 0 // save music to a WAV file
#define SOUND_303 1 // choose between the TB-303 and the sample generator
#define SOUND_SUBWOOFER 0 // enable this to make the TB303 sound like a sub bass line
#define SOUND_TUNE 0 // enable/disable the tune knob of the TB303

#if TINY
#define SOUND_303 1 // only the TB-303 compiles in Tiny mode
#define SOUND_SAVE 0 // can't save music in tiny mode
#endif



#include "windows.h"
#include "gl\gl.h"
#include "gl\glu.h"
#include "mmsystem.h"
#if TINY==0
#include "math.h"
#if SOUND_SAVE
#include "stdio.h"
#endif
#endif



// types
typedef long dword;
typedef short int word;
typedef unsigned char byte;
#ifndef __WATCOMC__
#ifndef __cplusplus
typedef byte bool;
#endif
#endif



// Visual C specific code
#ifdef _MSC_VER

// silence the double-to-float warning
#pragma warning( once : 4305)
#pragma warning( once : 4244)

#if TINY

#ifdef __cplusplus
extern "C" {
#endif

// signal to Visual C that we use floating point values
int _fltused;

// HACK: Visual C 6 discards __cdecl and passes fvar on st(0) instead of the stack,
// that is why the fld has to be commented
int __cdecl _ftol(float fvar)
{
	int lvar;
	__asm {
//		fld dword ptr fvar
		fistp dword ptr lvar
	}
	return lvar;
}

// y=sin(x)
__inline float __cdecl sin(float x)
{
	float y;
	__asm {
		fld dword ptr x
		fsin
		fstp dword ptr y
	}
	return y;
}

// y=cos(x)
__inline float __cdecl cos(float x)
{
	float y;
	__asm {
		fld dword ptr x
		fcos
		fstp dword ptr y
	}
	return y;
}

// y=square_root(x)
__inline float __cdecl sqrt(float x)
{
	float y;
	__asm {
		fld dword ptr x
		fsqrt
		fstp dword ptr y
	}
	return y;
}

// y=2^f
__inline float __cdecl pow2(float x)
{
	float y;
	__asm {
		fld dword ptr x
		fld st(0)
		frndint
		fxch st(1)
		fsub st(0),st(1)
		f2xm1
		fld1
		faddp st(1),st(0)
		fscale
		fstp st(1)
		fstp dword ptr y
	}
	return y;
}

__inline void* __cdecl memcpy(void *dst,const void *src,size_t len)
{
	__asm {
		pushad
		mov esi,src
		mov edi,dst
		mov ecx,len
		rep movsb
		popad
	}
	return dst;
}

#if SOUND
// uninitialized data
extern byte wavbuffer[];
#endif

#ifdef __cplusplus
}
#endif

#endif

#endif



LRESULT CALLBACK Window(HWND hwnd, UINT uMsg, WPARAM wParam, LPARAM lParam);
float fn_closeup(float fx,float fy);
float fn_waveout(float fx,float fy);
float fn_wobbler(float fx,float fy);
float fn_column(float fx,float fy);



//
// data
//

typedef struct { float x,y,z; } vect;
//typedef struct { float x,y,z,w; } quat;
//#define members(xx) sizeof(xx)/sizeof(xx[0])
#ifndef PI
#define PI 3.1415926535897932384626
#endif
#define color(colr,colg,colb) {(float)colr/(float)255,(float)colg/(float)255,(float)colb/(float)255}

char Name[]="wobbler";
char FontName[]="arial";

WNDCLASS wc={
	CS_OWNDC,
	Window,
	0,
	0,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	Name,
};

PIXELFORMATDESCRIPTOR pixel={
	sizeof(PIXELFORMATDESCRIPTOR),
	1,
	PFD_DRAW_TO_WINDOW + PFD_SUPPORT_OPENGL + PFD_DOUBLEBUFFER,
	PFD_TYPE_RGBA,
	0,0,0,0,0,0,
	0,0,
	0,0,0,0,0,
	16,
	0,0,
	PFD_MAIN_PLANE,
	0,
	0,0,0,
};


HFONT hFnt;
HWND hWnd;
HDC hDC;
HGLRC hGLRC;
MSG msg;
DEVMODE VideoMode;
int FontList; // base ID of the OpenGL display list of the font



typedef struct {
	int nx,ny;
	float fn_delta;
	byte flat,linex,liney,fill;
	vect *col;
	float col_far;
	float col_len;
	float rot; // speed of rotation
} Object;

typedef struct {
	vect *bkcol; // background color
	int nobj; // number of objects
	int obj0; // ID of first object

	// common object properties
	vect pos;
	float (*fn)(float fx,float fy);
	float h,w;
	struct {
		float centre,deviance,speed;
	} rot[2];
} Scene;

typedef struct {
	int Scene;
	float Len;
	float Time0;
	float Speed; // PartTime = Speed*Time + Time0
} Part;


#define WS 64 // maximal resolution of object tesselation (in other words: array size ;)
vect Verts[WS*WS];
Scene *ActScene;
Object *ActObject;
float StartTime,Time;


vect col_black = color(0,0,0);
vect col_white = color(255,255,255);
vect col_grayblue = color(144,140,182);
vect col_brightgray = color(164,160,172);
vect col_darkgray = color(59,59,59);
vect col_darkgreen = color(13,72,47);
vect col_sun = color(255,179,26);
//vect col_orange = color(255,179, 0);
//vect col_darkred = color(90,4,2);
//vect col_red = color(192,20,26);
//vect col_brightred = color(252,3,14);
//vect col_green = color(20,90,0);
//vect col_palegreen = color(20,133,90);
//vect col_yellow = color(204,128,26);
//vect col_paleblue = color(7,89,133);
//vect col_darkblue = color(68,85,98);
//vect col_skyblue = color(125,158,255);
//vect col_brightblue = color(140,165,214);
//vect col_purple = color(140,82,148);
//vect col_pink = color(247,198,214);


Object Objects[]={

// lines
{
	60,30,
	0,
	0,1,0,0,
	&col_brightgray,
	-150,-300,
	0.4,
},

{
	60,11,
	0,
	0,1,0,0,
	&col_white,
	500,250,
	0.4,
},

{
	60,19,
	0,
	0,1,0,0,
	&col_grayblue,
	400,250,
	0.4,
},

// snake
{
	8,24,
	0,
	1,0,0,1,
	&col_grayblue,
	1050,400,
	0,
},

{
	8,12,
	0.05,
	0,1,0,0,
	&col_black,0,0,
	0,
},

{
	4,7,
	0.7,
	0,1,0,0,
	&col_white,800,200,
	-1,
},

// column
{
	40,62,
	0,
	0,0,0,1,
	&col_grayblue,
	280,110,
	0,
},

{
	10,62,
	0.1,
	0,0,1,0,
	&col_black,
	0,0,
	0,
},

// wobbler
{
	60,60,
	0,
	0,0,0,1,
	&col_black,
	550,200,
	0.2,
},

{
	60,60,
	0.03,
	0,0,0,1,
	&col_grayblue,
	450,150,
	-0.2,
},

{
	10,30,
	0.04,
	0,0,1,0,
	&col_black,
	0,0,
	-0.2,
},

{
	10,30,
	0.01,
	0,0,1,0,
	&col_white,
	550,200,
	0.2,
},

// sun
{
	30,30,
	0,
	0,0,0,1,
	&col_sun,
	395,130,
	0,
},

{
	30,30,
	0.08,
	0,1,1,0,
	&col_white,
	400,150,
	0,
},

};


Scene Scenes[]={

// lines
{
	&col_darkgreen,
	3,
	0,

	{0,0,-50},
	&fn_wobbler,
	450,160,
	{{0.2,0,0},{1.35,0,0}},
},

// snake
{
	&col_darkgreen,
	3,
	3,

	{0,0,700},
	&fn_waveout,
	600,180,
	{{3.6,0,0},{0.6,0,0}},
},

// column
{
	&col_black,//darkgray,
	2,
	6,

	{0,0,200},
	&fn_column,
	250,50,
	{{0,0,0},{-0.15,0,0}},
},

// wobbler
{
	&col_darkgreen,
	4,
	8,

	{0,0,400},
	&fn_wobbler,
	350,120,
	{{1.5,0.5,1},{1.8,0.5,2}},
},

// sun
{
	&col_darkgray,
	2,
	12,

	{0,0,350},
	&fn_wobbler,
	230,80,
	{{0,0.2,1.2},{1.6,0.2,1.3}},
},

// green background
{
	&col_darkgreen,
	0,
	0,

	{0,0,0},
	NULL,
	0,0,
	{{0,0,0},{0,0,0}},
},

// black background
{
	&col_darkgray,
	0,
	0,

	{0,0,0},
	NULL,
	0,0,
	{{0,0,0},{0,0,0}},
},

};

#define WLEN 25.6
#define WREP 0.4

Part Parts[]={
	{6,6.4,0,4},
	{2,0.4,2,-2},
	{2,0.4,0,+2},
	{2,0.8,2,-2},
	{2,11.2,0,1},
	{1,12.8,0,0.6},
	{0,12.8,0,0.5},
	{5,12.8,0,1},
	{3,12.8,0.5,1},
	{4,WLEN,0,1},
	{2,WREP,0,+2},
	{4,WREP,WLEN+WREP,1},
	{2,WREP,0,-2},
	{4,WREP,WLEN+WREP*3,1},
	{1,WREP,0,1},
	{4,WREP,WLEN+WREP*5,1},
	{2,WREP,0,1},
	{4,WREP,WLEN+WREP*7,1},
	{6,WREP,5,+4},
	{4,WREP,WLEN+WREP*9,1},
	{5,WREP,20,1},
	{4,WREP,WLEN+WREP*11,1},
	{2,WREP,0,+2},
	{4,WREP,WLEN+WREP*13,1},
	{0,WREP,0,1},
	{4,WREP,WLEN+WREP*15,1},
	{6,4.8,5,-4},
	{-1,0,0,0},
};

#if FLASHES
float Flashes[]={ // relative times in seconds; negative value signals end of table
	6.4,
	0.4,
	0.4,
	0.8,
	-1,
};
#endif



//
// random
//

dword randseed=0x12341234;

// random [0;255]
int RandomI()
{
  randseed=(randseed+1)*31415621;
  return (randseed&0xFF);
}

// random [0;+1]
// return (float)rand() * ((float)1/(float)RAND_MAX);
float RandomF()
{
  randseed=(randseed+1)*31415621;
  return ((float)(randseed&0xFFFF)-0x8000)/32768;
}

// random [-1;+1]
// return (float)rand() * ((float)2/(float)RAND_MAX) - 1;
float RandomS()
{
  randseed=(randseed+1)*31415621;
  return ((float)(randseed&0xFFFF)-0x8000)/32768;
}



//
// sound code
//

#if SOUND

#define PI 3.1415926535897932384626

#define GKA_SAMPLE 2 // 1=8bit, 2=16bit
#define GKA_CHANNELS 1 // 1=mono, 2=stereo
#define GKA_FREQ 44100 // frequency (samples/second)

// number of samples
#if SOUND_303
#define GKA_SIZE (4410*16*76)
#else
#define GKA_SIZE (0x4000)
#endif

// ; wav header
struct {
	char Riff[4];
	dword Size;
	char Wave[4];
	char Fmt[4];
	dword Num;
	word Format;
	word Channels;
	dword Freq;
	dword ABPS;
	word BlockAlign;
	word BitDepth;
	char Data[4];
	dword DataSize;
} gkaWavhead={
	{'R','I','F','F'}, // {"RIFF"}, // Watcom does not accept the simpler syntax
	36+GKA_SAMPLE*GKA_CHANNELS*GKA_SIZE,
	{'W','A','V','E'}, // {"WAVE"},
	{'f','m','t',' '}, // {"fmt "},
	0x10,
	1,
	GKA_CHANNELS,
	GKA_FREQ,
	GKA_SAMPLE*GKA_CHANNELS*GKA_FREQ,
	GKA_SAMPLE*GKA_CHANNELS,
	GKA_SAMPLE*8,
	{'d','a','t','a'}, // {"data"},
	GKA_SAMPLE*GKA_CHANNELS*GKA_SIZE,
};

byte *gkaWav;
byte *gkaSamples;
byte gkaSmp[0x4000*GKA_SAMPLE];

#define GKA_VOLUME 1.0f

// clip: return value in range [-1;+1]
float gkaClip(float f)
{
	if (f>1.0f) f=1.0f;
	if (f<-1.0f) f=-1.0f;
	return f;
}

// store sample
void gkaStore(byte *s,float f)
{
	int i;
	signed char sb;
	signed int sw;
	f=gkaClip(f) * GKA_VOLUME;

	for (i=0;i<GKA_CHANNELS;i++) {
		if (GKA_SAMPLE==1) {
			sb=(signed char)(f*127.0f);
			*s++=sb+128;
		} else {
			sw=(signed short int)(f*32767.0f);
			*s++=(sw)&0xFF;
			*s++=(sw)>>8;
		}
	}
}

#if 0
// store 8 bit mono sample
void gkaStore(byte *s,float f)
{
	signed char sb;
	f=gkaClip(f);
	sb=(signed char)(f*127.0f);
	*s=sb;
}
#endif

// store sample to final music
#define gkaS(n,f) gkaStore(gkaSamples+GKA_SAMPLE*GKA_CHANNELS*n,f)


#if SOUND_303

//
// 303
//
// emulator of Roland TB-303 analogue sound synthethiser
// main sources of information: Noisetrakker by Arguru, Rebirth by Propellerheads

enum {
	TB303_SPS = 44100, // samples/second = 44100
	TB303_TPM = 600, // ticks/minute
	TB303_SPT = 4410, // samples/tick

	TBFLAG_SLIDE = 0x10,
	TBFLAG_ACCENT = 0x20,
	TBFLAG_TRANSPOSE_UP = 0x40,
	TBFLAG_TRANSPOSE_DOWN = 0x80,
	TBFLAG_NOTE = (TBFLAG_TRANSPOSE_UP+TBFLAG_TRANSPOSE_DOWN),
};

typedef struct {
	union {
		struct { // knob's value is in range [0;127]
			byte tune;
			byte cutoff;
			byte resonance;
			byte envmod;
			byte decay;
			byte accent;
		};
		byte knobs[6];
	};
	byte notes[16];
} para303;


void tbInit();
void tbReset();
float tbGetSample();
float tbFilter(float input,float f,float q);

byte tbKnobs[6*4]={
	64,4,12,41,44,44,
	64,8,12,41,44,44,
	64,2,12,41,4,44,
	64,2,12,41,4,44,
};

// tone: 0=C, 1=C#, 2=D, etc, 12=high C
// slide: 1=on
// accent: 1=on
// modifiers: pause=0,up=1,down=2,regular note(no transpose)=3
#define TBNOTE(tone,slide,accent,mod) ((tone&0x0F)+(slide?0x10:0)+(accent?0x20:0)+(mod%4)*0x40)
// Limitation of this setup: a paused note can't have a transpose up or down flag, this
// makes a difference if the previous note is not paused and this note has the slide flag on

para303 tbPara={
	64,9,126,64,127,64, // these initial values are overridden by tbStep()
	{   // --- note S A M
		TBNOTE(0x00,1,1,1),
		TBNOTE(0x00,1,1,2),
		TBNOTE(0x00,1,0,1),
		TBNOTE(0x00,0,0,3),
		TBNOTE(0x00,0,1,3),
		TBNOTE(0x00,1,0,1),
		TBNOTE(0x00,1,1,2),
		TBNOTE(0x00,1,1,2),
		TBNOTE(0x00,1,1,1),
		TBNOTE(0x00,0,1,3),
		TBNOTE(0x03,1,1,1),
		TBNOTE(0x00,1,1,2),
		TBNOTE(0x00,1,0,1),
		TBNOTE(0x00,0,1,3),
		TBNOTE(0x00,1,1,1),
		TBNOTE(0x00,0,0,2),
	}
};

byte tbPattern; // 0 to 3
byte tbLine; // 0 to 15
float tbBuf0;
float tbBuf1;
float tbVolume;


// constants
float f1o128=0.0078125f;
float f1o64=0.015625f;
float f1o8192=0.000122f;
float f_tune=0.1889763f; // =63.5/12 => tune [0;127] => -1 octave to +1 octave
float f_accent=0.0001765f;
float f_cutoff=0.0026041f; // 1/128/3 => puts cutoff in range [0;1/3]
float f_envmod=0.0009531f;

// 303 Parameters
float tbCutoff;
float tbResonance;
float tbEnvmod;
float tbDecay;
float tbSample;
float tbRealCutoff;
float tbRealVolume;
float tbTargetVolume;
float tbCurrentVolume;
float tbSlideTime;
float tbOscPosition;
float tbOscSpeed;
float tbOscSpeedDelta;
float tbOscPrevSpeed;
bool tbPrevSlide;

// 303 initialization
void tbInit()
{
	tbLine=0;
	tbVolume=0.1f;
	tbRealCutoff=0.5f;
	tbCutoff=0.5f;
	tbResonance=0.5f;
	tbEnvmod=0.5f;
	tbDecay=0.5f;

	tbBuf0=0.0f;
	tbBuf1=0.0f;

	tbRealVolume=0.0f;
	tbCurrentVolume=0.0f;
	tbSlideTime=0.0f;
	tbOscPosition=0.0f;
	tbOscSpeed=0.0f;
	tbPrevSlide=0;
}

// calculate one sample
float tbGetSample()
{
	float a,b;
	float f,q;

	// get volume
	if (tbCurrentVolume+f1o128<tbTargetVolume) tbCurrentVolume+=f1o128;
	else if (tbCurrentVolume-f1o128>tbTargetVolume) tbCurrentVolume-=f1o128;

	// get oscillator value
	tbSample=tbOscPosition*tbCurrentVolume;

	// run oscillator
	tbOscPosition+=tbOscSpeed;
	if(tbSlideTime>0) {
		tbSlideTime--;
		tbOscSpeed+=tbOscSpeedDelta;
	}
	if(tbOscPosition>=16384) tbOscPosition-=32768;


	// lowpass filter
	// this is a simple 12dB/octave 2-pole filter, the real TB-303 has a sharper 3-pole filter

	tbRealCutoff=tbCutoff+tbEnvmod;
	tbEnvmod-=tbDecay*tbRealCutoff*f1o64;
	if(tbRealCutoff<tbCutoff) tbRealCutoff=tbCutoff;

#if SOUND_SUBWOOFER
	q=0.98f; f=0.01f; // subwoofer
#else
	q=tbResonance;
	if (q>0.98f) q=0.98f;
	if (q<0.01f) q=0.01f;
	f=tbRealCutoff;
	if (f>0.999f) f=0.999f;
	if (f<0.005f) f=0.005f;
#endif

	a= (float)(1.0 - f);
	b= (float)(q * (1.0 + (1.0/a)));
	tbBuf0= a * tbBuf0 + f * (tbSample + b * (tbBuf0 - tbBuf1));
	tbBuf1= a * tbBuf1 + f * tbBuf0;
	
	return tbBuf1; // return filtered sample
}

// step the sequencer one note forward
void tbStep()
{
	int i;
	float a,b;
	float note;
	bool tbSlide;

	// set knobs
	for (i=0;i<6;i++) {
		tbPara.knobs[i]=tbKnobs[tbPattern*6+i];
	}

	tbOscPrevSpeed=tbOscSpeed;
	tbSlide=tbPara.notes[tbLine]&TBFLAG_SLIDE;
	note=(float)(tbPara.notes[tbLine]&0x0F)-17+84;
	if (tbPara.notes[tbLine]&TBFLAG_TRANSPOSE_UP) note+=12;
	if (tbPara.notes[tbLine]&TBFLAG_TRANSPOSE_DOWN) note-=12;
#if SOUND_TUNE
	note+=(float)tbPara.tune*f_tune-12.0f;
#endif
#if TINY
	tbOscSpeed=(float)pow2(note/12.0f); // frequency
#else
	tbOscSpeed=(float)pow(2.0,note/12.0f); // frequency
#endif
	tbOscSpeedDelta=0;

	if (tbPrevSlide) {
		a=tbOscPrevSpeed;
		b=tbOscSpeed;
		tbSlideTime=TB303_SPT*0.5f;
		tbOscSpeedDelta=(b-a)/tbSlideTime;
		tbOscSpeed=a;
	}

	if (tbPara.notes[tbLine]&TBFLAG_NOTE) {
		tbCutoff=(float)(tbPara.cutoff+1)*f_cutoff;
		tbEnvmod=(tbCutoff*2)+(float)tbPara.envmod*f_envmod;
		tbResonance=(float)tbPara.resonance*f1o128;
		tbDecay=(128.0f-(float)tbPara.decay)*f1o8192;
		tbRealVolume=tbVolume;
	}

	if (tbSlide) tbDecay=0.0f;

	if (tbPara.notes[tbLine]&TBFLAG_ACCENT) {
		a=(float)tbPara.accent*f_accent;
		tbResonance+=a;
		tbCutoff+=a;
		tbRealVolume*=((a*64.0f)+1.0f);
	}

	if ((!tbSlide) && !(tbPara.notes[tbLine]&TBFLAG_NOTE)) tbRealVolume=0;

	tbTargetVolume=tbRealVolume;
	tbPrevSlide=tbSlide;

	// step the sequencer
	tbLine++;
	if (tbLine==16) {
		tbLine=0;
		tbPattern++;
		if (tbPattern==4) tbPattern=0;
	}
}

void gkaGen()
{
	int i,j;

	tbInit();

	j=0;
	tbLine=0;
	tbPattern=0;
	for (i=0;i<GKA_SIZE;i++) {
		j--;
		if (j<=0) {
			j=TB303_SPT;
			tbStep(); // step the sequencer
		}
		gkaS(i,tbGetSample()/32768.0f);
	}
}


#else


//
// sample generator
//

enum {
	// waveforms
	GKAO_SILENCE=0,
	GKAO_SINE,
	GKAO_PULSE,
	GKAO_PULSE2,
	GKAO_TRIANGLE,
	GKAO_SAWTOOTH,
	GKAO_SAWTOOTH2,
	GKAO_NOISE,
	GKAO_RANDOM,
};

// normalize: convert from range [-1;+1] to [0;+1]
float gkaNorm(float f)
{
	return f*0.5f+0.5f;
}

// lowpass filter
// i=input sample
// c=cutoff frequency
float gkafLowpass(float i,float c)
{
	float o;
	static float pi=0,po=0;
	static float a,b;

	b=atan(PI*c/44100.0f);
	b=-(b-1.0f)/(1.0f+b);
	a=0.5f*(1.0f-b);

	o=a*i+a*pi+b*po;
	pi=i;
	po=o;
	return o;
}

// oscillator
float gkaOsc(int waveform,float t)
{
	float o;
	static float wrpos=0;
	static float wrn1,wrn2;

	switch (waveform) {
	default:
	case GKAO_SILENCE:
		o=0;
		break;
	case GKAO_SINE:
		o=sin(t);
		break;
	case GKAO_PULSE:
		o=fmod(t,2*PI);
		if (o<PI) o=-1; else o=+1;
		break;
	case GKAO_PULSE2: // half phase displacement
		o=fmod(t,2*PI);
		if (o>PI) o=-1; else o=+1;
		break;
	case GKAO_TRIANGLE:
		o=fmod(t+1.5*PI,2*PI)/PI;
		if (o>1) o=2-o;
		o=2*o-1;
		break;
	case GKAO_SAWTOOTH:
		o=(fmod(t,2*PI)/PI)-1;
		break;
	case GKAO_SAWTOOTH2:
		o=1-(fmod(t,2*PI)/PI);
		break;
	case GKAO_NOISE:
		if (wrpos==0) {
			wrn1=RandomS();
			wrn2=RandomS();
			wrpos=t;
		}
		while (t>=wrpos+2*PI) {
			wrpos+=2*PI;
			wrn1=wrn2;
			wrn2=RandomS();
		}
		o=(t-wrpos)*wrn2+(2*PI+wrpos-t)*wrn1;
		break;
	case GKAO_RANDOM: // noise without any control over frequency
		o=RandomS();
		break;
	}
	return o;
}

#define gkaOscF(waveform,t) ((gkaOsc(waveform,t)+1)*0.5f)

void gkaGenSynth()
{
	int i;
	float e,f,t;

	for (i=0;i<0x4000;i++) {
		t=(float)i;
		f=gkaOsc(GKAO_SINE,t*6/44100*2*PI);
		f=gkaOsc(GKAO_PULSE,(t*500+f*40000)/44100*2*PI);
		f=f*gkaNorm(gkaOsc(GKAO_SAWTOOTH2,0.00025f*t));
		e=550.0f+(t/(4*44100))*5.0f;
		f=gkafLowpass(f,e);
		gkaStore(gkaSmp+GKA_SAMPLE*i,f);
	}
}

void gkaGenTechdrum()
{
	int i;
	float f,amp,osc;

	osc=0;
	for (i=0;i<0x4000;i++) {
		float p=(float)i/(float)0x4000;
		amp=(0.22f/(p+0.05f))-0.23f;
		if (amp<0) amp=0;
		f=amp*sin(osc);
		gkaStore(gkaSmp+GKA_SAMPLE*i,f);
		osc+=(22.0f/(p+0.05f))*2*PI/44100.0f;
	}
}

void gkaGenHihat()
{
	int i;
	float f,p,t;
	for (i=0;i<0x4000;i++) {
		t=(float)i/(float)44100*2*PI;
		p=1-(float)i/(float)0x4000;
		f=gkaOsc(GKAO_SAWTOOTH,t*5000)*(p*p*p*p);
		gkaStore(gkaSmp+GKA_SAMPLE*i,f);
	}
}

void gkaGenHit()
{
	int i;
	float p=0.0001f,d=0.002f,f;
	for (i=0;i<0x4000;i++) {
		f=gkaOsc(GKAO_NOISE,100*p)/p;
		gkaStore(gkaSmp+GKA_SAMPLE*i,f);
		p+=d;
	}
}

void gkaFill()
{
	int i,j;
	for (i=0;i<GKA_SIZE*GKA_SAMPLE;i++) {
		j=i%(0x4000*GKA_SAMPLE);
		gkaSamples[i]=gkaSmp[j];
	}
}

void gkaGen()
{
//	gkaGenSynth();
	gkaGenTechdrum();
//	gkaGenHihat();
//	gkaGenHit();
	gkaFill();
}

#endif

#endif



//
// graphics code
//

// send a vertex to GL
void sendvert(vect *v)
{
	float f;
	if (ActObject->col_len==0) f=0;
	else f=(float)( (ActObject->col_far-v->z)/ActObject->col_len - 1 ); // depth attenuation
	glColor3f(f+ActObject->col->x,f+ActObject->col->y,f+ActObject->col->z);
	glVertex3f(v->x,v->y,-v->z);
}

// rotate about one axis, swap axes
// input -> output:
//  yAngle x z y  ->  y z x
//  xAngle z y x  ->  x z y
//  zAngle y x z  ->  z y x
// operation (for y axis):
//  x= x*cos(ya) - z*sin(ya);
//  z= z*cos(ya) + x*sin(ya);
void rotate(float a,vect *v)
{
	vect t=*v;
	v->x=t.y; // y
	v->y=t.z*(float)cos(a) + t.x*(float)sin(a); // z
	v->z=t.x*(float)cos(a) - t.z*(float)sin(a); // x
}


// draw a 3d object
// parameters: ActScene, ActObject, Time
void DrawObject()
{
	int i,j,k;
	float fx,fy;
	int j0;
	vect *v;

	// calculate vertices
	for (i=0;i<=ActObject->ny;i++) {
		for (j=0;j<ActObject->nx;j++) {
			fx=(float)j/(float)ActObject->nx;
			fy=(float)i/(float)ActObject->ny;

			v=&Verts[WS*i+j];
			v->y=(float)(ActScene->h*(fy-.5));
			v->x=0;
			v->z=ActScene->w*(ActScene->fn(fx,fy)+ActObject->fn_delta);

			if (ActScene==&Scenes[2]) fx+=(float)(0.4f*sin(fy*1.8f+Time*0.9f)); // hack (column)
			else if (ActScene==&Scenes[3]) fx+=(float)(0.2f*sin(fy+Time*0.8f)); // hack (wobbler)

			rotate( (float)(fx*2*PI + ActObject->rot*Time), v ); // create cylindrical object
			for (k=0;k<2;k++) { // rotate object
				rotate((float)(ActScene->rot[k].centre+ActScene->rot[k].deviance*
				sin(Time*ActScene->rot[k].speed)),v);
			}

			v->x+=ActScene->pos.x;
			v->y+=ActScene->pos.y;
			v->z+=ActScene->pos.z;
		}
	}

	// render object
	glShadeModel( ActObject->flat ? GL_FLAT : GL_SMOOTH );
	if (ActObject->fill) glBegin(GL_QUADS);
	else glBegin(GL_LINES);
	for (i=0;i<=ActObject->ny;i++) {
		for (j=0;j<ActObject->nx;j++) {
			j0=j-1;
			if (j0<0) j0=ActObject->nx-1;

			if (i<ActObject->ny) {
				if (ActObject->fill) {
					sendvert(&Verts[WS*i    +j ]);
					sendvert(&Verts[WS*i    +j0]);
					sendvert(&Verts[WS*(i+1)+j0]);
					sendvert(&Verts[WS*(i+1)+j ]);
				}
				if (ActObject->liney) {
					sendvert(&Verts[WS*i    +j ]);
					sendvert(&Verts[WS*(i+1)+j ]);
				}
			}

			if (ActObject->linex) {
				sendvert(&Verts[WS*i    +j ]);
				sendvert(&Verts[WS*i    +j0]);
			}
		}
	}
	glEnd();
}


#if TINY

// This function had to be hand converted to ASM to avoid a compiler quirk.
//
// Details:
// - Standard sin,cos,sqrt routines from math.h use 'double'
// - These are replaced with smaller ones which use 'float' (less precision)
// - sqrt(sin(x)) => the compiler [superfluously] stores the intermediate value after sin() and
// before sqrt() into a float in memory, thus some precision is lost,
// - This turns sin(1.000*3.141) to -0.001 and sqrt() fails with the negative value
float fn_closeup(float fx,float fy)
{
	float f;
	__asm {
		fldpi
		fmul dword ptr fy
		fsin
		fsqrt
		fstp dword ptr f;
	}
	return f;
}

#else

float fn_closeup(float fx,float fy)
{
	return (float)sqrt(sin(fy*PI));
}

#endif


float fn_waveout(float fx,float fy)
{
	return (float)(fn_closeup(fx,fy)*(0.7+0.6
		*sin((fx+Time*0.2)*2*PI) // circular humps & rotation
		*sin(fy*12+Time*2.7) // longitudinal humps & "moving" down
	));
}

float fn_wobbler(float fx,float fy)
{
	return (float)(fn_closeup(fx,fy)*(1.0+
		(1+sin((fx+Time*0.2)*2*PI))* // size of humps
		(0.15*sin(fx*8*PI) // ribbing
		+0.25*sin(fy*12+Time*2.7) // waving
	)));
}

float fn_column(float fx,float fy)
{
	fy+=(float)(0.1+0.3*sin(Time*0.8));
	return (float)(1.0
			+0.38*sin(fy*6+sin(fx*4*PI))
			+0.09*sin(fx*32*PI)
			+0.06*sin(fy*38));
}


// intro text

#define nIt 3

struct {
	int n;
	float f;
	char *s;
	float x,y;
} It[nIt]={
	{7,40,Name,-65,15},
	{7,20,"preview",-10,5},
	{14,10,"gem@mailbox.hu",-65,-25},
};

void fx_introtext()
{
	int i;

	for (i=0;i<nIt;i++) {
		glLoadIdentity();
		glTranslatef(It[i].x,It[i].y,Time-100);
		glScalef(It[i].f,It[i].f,It[i].f);
		glRotatef(-20,1,0,0);
		glCallLists(It[i].n,GL_UNSIGNED_BYTE,It[i].s);
	}
}


// question mark object

void fx_question()
{
	int i,j;
	float f[3];
	float g;
	char s='?';

	// draw 6 objects
	for (i=0;i<6;i++) {

		// put them far from the screen
		glLoadIdentity();
		glRotatef(16,0,1,0);
		glTranslatef(0,-28,-80.0f+30.0f*(float)sin(Time));

		// make them rotate around a bit
		for (j=0;j<3;j++) {
			f[0]=f[1]=f[2]=0;
			f[j]=1;
			glRotatef(140*Time,f[0],f[1],f[2]); // rotation is in angles not radians!
		}

		g=90;

		// rotate to given axis x,y,z
		if (i==1 || i==4) glRotatef(g,0,1,0);
		else if (i==2 || i==5) glRotatef(g,0,0,1);

		// turn the pairs away
		glRotatef( (i<3 ? g : -g) ,0,0,1);

		// set the size of the objects
		glScalef(55,55,55);

		// centre of rotation: the middle of the dot in the question mark
		glTranslatef(-0.272f,-0.05f,+0.1f);

		// draw
		glCallLists(1,GL_UNSIGNED_BYTE,&s);
	}
}


// dollar signs

void fx_roto()
{
	int i,j;
	float g;
	char s='$';

//	glLightfv(GL_LIGHT0,GL_DIFFUSE,&col_palegreen.x);
	glLoadIdentity();

	// 9x4 objects
	for (i=0;i<9;i++) {
		for (j=0;j<4;j++) {

			// put them far from the screen
			glPushMatrix();
			glTranslatef((i-4)*20,5+(j-2)*20,-130);

			// make them rotate around a bit
			g=20+40*Time+16*sin(j+Time)+15*cos(i+1.5*Time);
//			if (Time<1) g=0; else if (Time<5) g*=(Time-1)*0.25f;
			glRotatef(g,1,0,0);
			glRotatef(g,0,1,0);
			glRotatef(g,0,0,1);

			// set the size of the objects
			g=28+8*sin(g*0.08f);
			glScalef(g,g,g);

			glCallLists(1,GL_UNSIGNED_BYTE,&s);
			glPopMatrix();
		}
	}
}


// text effect

#define TX_NMAX 10000
#define TX_NKID 3
#define TX_NLEV 3

typedef struct _tx_char {
	float size;
	float ra,rb,rc;
#if ((defined __WATCOM_C__)||(defined __cplusplus))
	_tx_char *child,*next; // OpenWatcom and VisualC++ accepts '_tx_char' only
#else
	void *child,*next; // LCC and VisualC accepts 'void' only
#endif
} tx_char;

// pool of characters
int txn=0;
tx_char txpool[TX_NMAX];

int txid[20];
char txstrn=7;
#define txstr Name // char Name[]="wobbler" (defined above)
char txc;
int txlev=0;
float txsize=60;

tx_char *txInitChar()
{
	int i;
	tx_char *tc,*tt;

	if (txlev>=TX_NLEV) return NULL;
	tc=&txpool[txn++];

	// generate values
	tc->ra=RandomS();
	tc->rb=RandomS();
	tc->rc=RandomS();
	tc->size=0.6+0.3*RandomF();

	// add children
	txlev++;
	for (i=0;i<TX_NKID;i++) {
		tt=txInitChar();
		if (tt) tt->next=tc->child;
		tc->child=tt;
	}
	txlev--;

	return tc;
}

void txInit()
{
	int i;

	txn=0;

	for (i=0;i<txstrn;i++) {
		txid[i]=txn;
		txInitChar();
	}
}

void txDrawChar(tx_char *tc)
{
	int i;
	tx_char *tt;
	float f;
	float bksize;

	if (txlev>=TX_NLEV) return;

	glPushMatrix();

	if (Time<2) f=0;
	else f=(Time-2)*0.2f;
	if (f>1) f=1;
	glRotatef((180*tc->ra+14*Time)*f,1,0,0);
	glRotatef((180*tc->rb+14*Time)*f,0,1,0);
	glRotatef((180*tc->rc+14*Time)*f,0,0,1);
	txsize*=(1-f)+f*tc->size;
	bksize=txsize;
	glTranslatef(0,0.5f*f*bksize,0);

	// draw children
	txlev++;
	tt=tc->child;
	if (tt)
	for (i=0;i<TX_NKID;i++) {
		txsize=bksize;
		txDrawChar(tt);
		tt=tt->next;
	}
	txlev--;

	glTranslatef(0,-0.5f*f*bksize,0);
	glScalef(bksize,bksize,bksize);
	glCallLists(1,GL_UNSIGNED_BYTE,&txc);

	glPopMatrix();
}

void txDraw()
{
	char *c;
	int i;

	glLoadIdentity();
	glTranslatef(-60,-35,sin(0.5f*Time)-80);

	c=txstr;
	for (i=0;i<txstrn;i++) {
		txc=*c++;
		txDrawChar(&txpool[txid[i]]);
		txsize=40;
		glTranslatef(18,0,0);
	}
}



//
// system code + the demo sequencer
//

void Quit()
{
	KillTimer(hWnd,0);
	PostQuitMessage(0);
}

LRESULT CALLBACK Window(HWND hwnd, UINT uMsg, WPARAM wParam, LPARAM lParam)
{
	float Time1;
#if FLASHES
	float *FT;
	float f;
#endif
	int i;
	Part *P;

	if (uMsg==WM_CREATE) {
		SetTimer(hwnd,0,10,NULL);
	} else if (uMsg==WM_TIMER) {

		// draw

		Time1=Time=((float)GetTickCount()-StartTime)*0.001f;

		P=Parts;

		// get the actual part
		for (P=Parts;;P++) {
			if (P->Scene<0) { // end of demo - quit
				Quit();
				return 0;
			}
			if (Time<=P->Len) break; // actual part - draw
			Time-=P->Len;
		}

		Time=P->Speed*Time+P->Time0;
		ActScene=&Scenes[P->Scene];

		// draw background and flashes
#if FLASHES
		f=0;
		for (FT=Flashes;*FT>=0;FT++) {
			Time1-=*FT;
			if (Time1>0.2) continue;
			if (Time1<0) break;
			if (Time1<0.1) f=1;
			else f=2-10*Time1;
			break;
		}
		glClearColor(f+ActScene->bkcol->x,f+ActScene->bkcol->y,f+ActScene->bkcol->z,0);
#else
		glClearColor(ActScene->bkcol->x,ActScene->bkcol->y,ActScene->bkcol->z,0);
#endif
		glClear(GL_COLOR_BUFFER_BIT|GL_DEPTH_BUFFER_BIT);

		// draw scene
		ActObject=&Objects[ActScene->obj0];
		for (i=0;i<ActScene->nobj;i++) {
			glLoadIdentity();
			glPushMatrix();
			DrawObject();
			glPopMatrix();
			ActObject++;
		}

		// draw effects
//		glClear(GL_DEPTH_BUFFER_BIT);
		glEnable(GL_LIGHT0);
		glEnable(GL_LIGHTING);
		glEnable(GL_COLOR_MATERIAL);
		glColor3f(0.6f,0.6f,0.6f);
		glEnable(GL_NORMALIZE);
//		glLightfv(GL_LIGHT1,GL_DIFFUSE,thelight);
//		glLightfv(GL_LIGHT1,GL_POSITION,thelightpos);
//		glEnable(GL_LIGHT1);
		if (P->Scene==0) fx_question();
		if (P->Scene==4) txDraw();
		if (P->Scene==5) fx_roto();
		if (P->Scene==6) fx_introtext();
		glDisable(GL_LIGHTING);

		// show
		SwapBuffers(hDC);

	} else if ( (uMsg==WM_DESTROY) || // ALT+F4 pressed
		((uMsg==WM_KEYDOWN)&&(wParam==VK_ESCAPE))) { // ESC is pressed
		Quit();
	} else {
		return DefWindowProc(hwnd,uMsg,wParam,lParam);
	}
	return 0;
}

// only one instance of this program can run at a time,
// but this is not verified (size optimization)
#if TINY
void WinMainCRTStartup()
#else
int WINAPI WinMain(HINSTANCE hInstance, HINSTANCE hPrevInstance, LPSTR lpCmdLine, int nCmdShow)
#endif
{
#if SOUND_SAVE
	FILE *O;
#endif

	// create window
	RegisterClass(&wc);
	hWnd=CreateWindowEx(
		WS_EX_TOPMOST,
		Name,Name,
#if FULLSCREEN
		WS_VISIBLE + WS_POPUPWINDOW,
#else
		WS_VISIBLE + WS_CAPTION + WS_SYSMENU + WS_MINIMIZEBOX,
#endif
		0,0,640,480,
		NULL,NULL,NULL,NULL);

#if FULLSCREEN
	// set display mode
	VideoMode.dmSize=sizeof(DEVMODE);
	VideoMode.dmDriverExtra=0;
	VideoMode.dmFields=DM_BITSPERPEL+DM_PELSWIDTH+DM_PELSHEIGHT;
	VideoMode.dmPelsWidth=640;
	VideoMode.dmPelsHeight=480;
	VideoMode.dmBitsPerPel=16;
	ChangeDisplaySettings(&VideoMode,CDS_FULLSCREEN);
	// hide mouse cursor
	ShowCursor(0);
#endif

	// initialize window for OpenGL rendering
	hDC=GetDC(hWnd); // get device context
	SetPixelFormat(hDC,ChoosePixelFormat(hDC,&pixel),&pixel); // set properties
	hGLRC=wglCreateContext(hDC); // create OpenGL rendering context
	wglMakeCurrent(hDC,hGLRC); // actualize it

	// set up OpenGL font
	hFnt=CreateFont(
		0,
		0,0,0,
		800,
		0,0,0,
		ANSI_CHARSET,
		OUT_TT_PRECIS,
		0,0,0,
		FontName
	);
	SelectObject(hDC, hFnt);
	FontList=glGenLists(255);
	wglUseFontOutlines(hDC, 0, 255, FontList, 0.004f, 0.2f, WGL_FONT_POLYGONS, NULL);
	glListBase(FontList);

	// initialize viewport and matrices (only once)
	// uncomment identity setups if this code is executed more than once
//	glViewport(0,0,640,480);
//	glScissor(0,120,320,240);
	glMatrixMode(GL_PROJECTION);
//	glLoadIdentity();
	gluPerspective(60,640.0/480.0,10,1000);
	glMatrixMode(GL_MODELVIEW);
//	glLoadIdentity();
//	gluLookAt(0,0,0, 0,0,1, 0,1,0);
	glEnable(GL_DEPTH_TEST);
	glClearDepth(1000);

	txInit(); // initialize the text effect

#if SOUND
#if TINY
	gkaWav=wavbuffer;
#else
	gkaWav=(byte*)malloc(sizeof(gkaWavhead)+GKA_SAMPLE*GKA_CHANNELS*GKA_SIZE);
#endif
	gkaSamples=gkaWav+sizeof(gkaWavhead);
	memcpy(gkaWav,&gkaWavhead,sizeof(gkaWavhead));
	gkaGen();
#if SOUND_SAVE
	O=fopen("a.wav","wb");
	fwrite(gkaWav,1,sizeof(gkaWavhead)+GKA_SAMPLE*GKA_CHANNELS*GKA_SIZE,O);
	fclose(O);
#endif
	sndPlaySound((char*)gkaWav,SND_NODEFAULT+SND_ASYNC+SND_MEMORY);
#endif

	StartTime=(float)GetTickCount();

	// message loop
	while (GetMessage(&msg,0,0,0)!=0) DispatchMessage(&msg);

#if SOUND
	sndPlaySound(0,0);
#endif

	// reset desktop videomode
	ChangeDisplaySettings(NULL,0);

#if TINY
	ExitProcess(1); // it is vital to terminate this way if sndPlaySound is used
#else
	return 0; // ExitProcess is in the Visual C closing code in the default libs
#endif
}


#if TINY&&SOUND
// uninitialized data
byte wavbuffer[sizeof(gkaWavhead)+GKA_SAMPLE*GKA_CHANNELS*GKA_SIZE];
#endif
