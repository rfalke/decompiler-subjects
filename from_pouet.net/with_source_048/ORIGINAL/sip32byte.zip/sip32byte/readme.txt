Interestingly the size of the source file is 666 bytes...
All 32 bytes intros are demonic? It was a pure co-incidence.

Perhaps..

They are pretty pointless but I just wanted to see if I could get
something that passed for an effect into 32b.

Sorry that there was no space to have an esc exit, you'll have to use ALT+ENTER

Check out these sites;

www.dbfinteractive.com
www.intro-inferno.com
http://surprise.intro-inferno.com/

Some personal greetings from Shockwave.

0X4E71 - ADIGUN POLACK - ALPHA ONE - AM FM - AMPLI - AULD - BAD MR.BOX - BENNY - BLITZ AMATEUR
BULL - CAN - CHAOS - CHENMY1 - CLANKY - CLYDE - CODEMAN - CORE - DAXX - DAZZABOY - DA FATSTUFF - DECIPHER 
DELETER - DEVILS CHILD - DEXTRO - DIC4B - DRAGONSPIRIT - DREWPEE - DRUID - DR.V - EKOLI - EMIL HALIM - ENERGY - ENZYMER 
EVILWIZARD - FERRIS - GHANDY - GHOST - GRAHAMK - GRIMREAPER - GUARDIAN - HOTSHOT 
HOUSEY - INCOGNITO - IROKOS - JANER - JIHAD - JIM - JOEP - JOJO - KRUZE - MADMAX - MANDRIXX 
MAXX - MIKE G  - MIND - MR.P - MUSASHI9 - NAWITUS - NAUSEA - NEUMANIX - NINOGENIO 
NOISEMAKER - NUKE - OPTIMUS - P01 - PARAPETE - PEACEMAKER - PHOENIX - PIRX - PIXEL OUTLAW - POHAR - PRITCHARD 
RAIN STORM - RAS - RBRAZ - RDC - RELSOFT - SAIDA - SAREK - SHADOWMAKER - SINGER - SIR MUD 
SLEDGE - SLINKS - SLIPPY - SNARTY - SOLDIERBOY - STATIC GERBIL - STEVE ELLIOT - STINGRAY - STONEMONKEY 
STORMBRINGER - STROBE - STU1 - TETRA - TEIS - TMB - VOLTAGE - WAL - WIDOWMAKER - XERNOBYL - YALOOPY - ZAWRAN - ZPARTICLE

Sorry if I missed you.

Last note, I guess I need to thank Pirx, your enthusiasm for these little things must be rubbing off on me.
Stonemonkey, you got the ball rolling :-)
Rbraz, I saw your 32 byte xor texture and then I guess I thought that just maybe I could make a scrolling one!
        