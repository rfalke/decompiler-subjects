indian summer 256b intro - final version

if it's running too slowly on your pc, try using dosbox 
<http://www.dosbox.com/>. it usually speeds up execution 
considerably.

about the intro:
it's pretty simple, it first sets up the palette, then
it enters the main loop, in which first some lines are
drawn and then blur is applied.
i decided to release it because i was satisfied with its
looks. (i assembled about 25 variants of the code until
it finally became something i liked.)
some other people enjoyed the party version as well, so
i came to the conclusion that it was worth making it.
the final version has slightly different visuals and i
like them even more than the old ones.

if you have any questions, feel free to contact me. you
can find contact details at my homepage:

http://www.hugi.scene.org/adok/
