 ______ ______  ______  ______  __  ______  ______  ______ ______
/\  ___/\  __ \/\  == \/\  == \/\ \/\  ___\/\  __ \/\__  _/\  ___\
\ \  __\ \  __ \ \  __<\ \  __<\ \ \ \ \___\ \  __ \/_/\ \\ \  __\
 \ \_\  \ \_\ \_\ \_____\ \_\ \_\ \_\ \_____\ \_\ \_\ \ \_\\ \_____\
  \/_/   \/_/\/_/\/_____/\/_/ /_/\/_/\/_____/\/_/\/_/  \/_/ \/_____/

 ...AKA "Hackalicious" :P

 :.a 256-byte tiny-intro by
  youth uprising.:

 :.code
  ferris.:

 :.thanks & inspiration
  gargaj
  rrrola
  mentor
  baze.:

 :.coded in 5 days and compiled
  with NASM...also about a week
  late :P.:

 :.greets
  meh...this prod is just too
  insignificant for those
  things.:

 :.(C) 2009 youth uprising.: