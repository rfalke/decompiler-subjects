prod:    faberge
type:    71 byte DOS intro
author:  orbitaldecay
date:    04-04-2010

For my boss, who fucking called me into work on easter sunday.  Happy Holidays
to those who seek them.

faberge.asm (Original 103 byte version)
faberge.com

faberge-1-1.asm (Updated 71 byte version)
faberge-1-1.com

http://www.orbitaldecay.com
