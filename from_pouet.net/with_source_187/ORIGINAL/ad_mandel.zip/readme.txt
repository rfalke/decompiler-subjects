original.asm is the Mandelbrot program from FASM (examples directory).

mandel126.asm and madenl134.asm are my modified versions. mandel126.asm fits into the 128 bytes limit, mandel134.asm is a bit too large, but looks interesting.

-Adok