//  hell  (89 bayt demo)   //
/                           /
///// coded in assembly  ////
/                           /
// Coded by �brahim inci //// 
/                           / 
///////  DEVREC�  ///////////
/                           /
/// web: www.devreci.tk /////
/                           / 
/ email: devreci@yahoo.com  /
/                           /
///     DOS platform      ///
