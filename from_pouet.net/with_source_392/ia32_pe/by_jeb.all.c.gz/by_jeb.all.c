
int sub_91D12F(int param0, short param1) {
    int v0;
    char* ptr0;
    unsigned int v1;
    int v2 = v0;
    if(v1 < 0xf3f20201) {
        (unsigned short)v3 = outsb(param1, *ptr0);
        retf();
    }
    jump v2;
}
