prod:    matisse
type:    32 byte DOS intro
author:  orbitaldecay
date:    03-13-2010

Greetz go out to my cat, Artemis.

http://www.orbitaldecay.com
