Oh Shade! 255b

This is the first Clash product. We are now officially built with this little piece of code. There is also a 128b bonus. Source codes are included.

Code & Idea : Skate/Clash & Ragnor/Clash

Clash Member Status
-------------------
Emotion          : Graphics, Music
Lockman Hackim   : Graphics
Ragnor           : Code
Skate            : Code
