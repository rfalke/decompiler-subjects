
                       __ __________________________ __
                     :_)__ _                      _ __(_:
                     |._)                            (_.|
                     <>\              ()              /<>
                     ||            T  ||  L            ||
                     ||         S     ::     L         ||
                     |�              _____             �|
                     :              /    /\             :
               _______    ___.     /____/  \   ___       ___
      ___    _/   _   \ _/   |__   \    \  / _/   \    _/   \        ___
     /\  \  \\    |____\\_  ___/___\\____\/-\\    |   \\    |       /  /\
    /  \__\  |______   |     |     |        |     /____|    /____  /__/  \
    \  /  /  :    |/   _     |     _        _          _       _// \  \  /
     \/__/  _|    /    \_          \_       \_         \_       |_  \__\/
            \\_________//__________//       |/_________//_______//
           - ----------------------/        |-�d----------------- -
                     :            /         |           :
                     |.          /          :          .|
                     ||                                ||
                     ||                                ||
                     || ._ .__ __  __ __ .__ _._    __ ||
                     || |_)| ((_/__) (_/_|  ) |__)__)  ||
                     || |                              ||
                     ||                                ||
                     <>                                <> 

                               F R A C T A L I Z    
                            T R A N S M I S S I O N 
                                P L A S T I C E
     
                                      A T
                    T O K Y O - D E M O - F E S T  2 0 1 1
 
>> About
	
        The first one called "fractaliz" is a normal mandelbrot with a slightly
        changed rendering technique which produces very interesting results.	

        The second one called "transmission" is a mix of two formulas: 
        the mandelbox in 2d and the mandelbrot it produces sort of
        weird patterns if it runs long enough. 

        The third called "plastice" is another mandelbrot/mandelbox mix with 
        some sort of flying (over the 2d-scape) added.

        mad^still >> 2011

>> 1k
    
        Since it's 1k import by ordinals is used.
        thanx to Franck "hitchhikr" Charlet / Neural for 1kpack.

>> Suggestions

        Please disable virus software in order to run this,
        Make sure you have a resolution of 1280x720 established. 
        D3DX9_30.DLL should be installed.

        Windows XP32, yet.. 

>> A demonstration brought to you by

        MAD ^ STILL >> stDOTmaderATgmxDOTde >> coding stuff
        dMG ^ divine stylers >> ascii-logo-template cheers..
        Decca ^ Bauknecht & Lego >> video editing & encoding

        Feel free to contact us.

        Meet us at next Breakpoint, Assembly, Evoke, TUM

>> Greetings to:

        Bonzaj ^ plastic
        Sire ^ Bauknecht & Lego & Still
        Stingray ^ scarab
        Krill ^ Plush
        Dalezy ^ Mad Wizards
        Helge ^ Helgejobb
        Cynic ^ Still
        Pirx ^ Still
        Mr.Pet ^ Einklang
        Fiver2, Ryg, Gizmo, Chaos, kb, wayfinder, cp ^ Farbrausch
        Sharon, Digisnap ^ Matrix
        Unreal ^ Sunflower
        Gargaj ^ Conspiracy
        Admiral ^ Elyssis
        Alien ^ bitfellas
        Tim ^ bitfilmfestival
        Madstop ^ Ethic
        Rames ^ Remedy
        Sniper & Ray ^ Scarab
        Hunta, Eric ^ Brainstorm
        Muhmac ^ Speckdrumm
        Minas ^ Calodox
        XXX ^ Haujobb
        Slack ^ Necrostudios
        Gopher ^ Alctraz
        Degauss ^ TEK
        Sudio,Rackler,Jester,Eliptic ^ Ideology
        Graham,Yazoo,Axis,Dante ^ Oxyron
        Decca ^ Bauknecht & Lego
        IQ ^ RGBA
        Mentor ^ TBC
        Blueberry ^ Loonies
        Navis ^ ASD
        Nero,Pixtur ^ Still
        2crazy ^ VCF

>> Respect to:

        Kewlers / MFX
        The Black Lotus
        Plastic
        Conspiracy
        Ephidrena
        Moppi Productions
        Sunflower
        Tpolm
        Stravaganza
        Nesnausk
        Adromeda Software Development
        Cocoon
        Mad Wizards
        Portal Process
        A.N.D.
        Hellcore
        Exceed
        Bypass
        Adapt
        Traction
        Matt Current
        Visualice
        The Electronic Knights
        Oxyron
        Resource
        Camelot
        Ideology
        Andromeda
        RGBA
        Loonies
        TBC
        Quite
        

<< Suggested hardware:

        a fast gfx card is recommended.


>> Tested on:

       no humans where harmed during the developement