An attempt to get some fake colors in 256b. 
I wrote original version of this intro in 1999.
Back then, on true DOS the 320x400 version worked fine,
but it seems neither DOSBox nor Windows XP can emulate VGA card correctly.
So I have made a 320x200 (ehh, ugly...) version and added something instead of 320x400 mode initialization & handling.