
                       __ __________________________ __
                     :_)__ _                      _ __(_:
                     |._)                            (_.|
                     <>\              ()              /<>
                     ||            T  ||  L            ||
                     ||         S     ::     L         ||
                     |�              _____             �|
                     :              /    /\             :
               _______    ___.     /____/  \   ___       ___
      ___    _/   _   \ _/   |__   \    \  / _/   \    _/   \        ___
     /\  \  \\    |____\\_  ___/___\\____\/-\\    |   \\    |       /  /\
    /  \__\  |______   |     |     |        |     /____|    /____  /__/  \
    \  /  /  :    |/   _     |     _        _          _       _// \  \  /
     \/__/  _|    /    \_          \_       \_         \_       |_  \__\/
            \\_________//__________//       |/_________//_______//
           - ----------------------/        |-�d----------------- -
                     :            /         |           :
                     |.          /          :          .|
                     ||                                ||
                     ||                                ||
                     || ._ .__ __  __ __ .__ _._    __ ||
                     || |_)| ((_/__) (_/_|  ) |__)__)  ||
                     || |                              ||
                     ||                                ||
                     <>                                <>

                                F U T U R I S M
                                 E S A - C 0 3

>> About
        Eyebex^Rab showed me at breakpoint2010 a new fractal formula which looked
        so awesome, that i felt in love at first sight.. for me it looks quite
        cooler than the mandelbulb stuff and is also pretty simple.. so I want
        to make atleast another demo with this formula.. but for a start this
        1k, it's my first 1k and next one will for sure have musics..

        google Tglad or read his posts at fractalforums to understand how this
        fractal was invented..        

>> Suggestions

        You need d3dx9_30.dll. the screenmode is 640x480 which should be present.
        it uses import by ordinals by which it would be preselected by most
        parties (atleast except ours..


>> A demonstration brought to you by

        MAD ^ STILL >> stDOTmaderATgmxDOTde >> coding stuff
        dMG ^ divine stylers >> ascii-logo-template, cheers..
        Franck "hitchhikr" Charlet ^ Neural >> packer + asm template
	Tglad, Knighty and Buddhi ^ FractalForum >> thanks a lot for algo desc
        Decca ^ Lego ^ Bauknecht >> videoencoding

        Feel free to contact us.

        Meet us at next Breakpoint, Assembly, Evoke, TUM

>> Greetings to:

        Bonzaj ^ plastic
        Sire ^ Bauknecht & Lego & Still
        Stingray ^ scarab
        Krill ^ Plush
        Dalezy ^ Mad Wizards
        Helge ^ Helgejobb
        Cynic ^ Still
        Pirx ^ Still
        Mr.Pet ^ Einklang
        Fiver2, Ryg, Gizmo, Chaos, kb, wayfinder, cp ^ Farbrausch
        Sharon, Digisnap ^ Matrix
        Unreal ^ Sunflower
        Gargaj ^ Conspiracy
        Admiral ^ Elyssis
        Alien ^ bitfellas
        Tim ^ bitfilmfestival
        Madstop ^ Ethic
        Rames ^ Remedy
        Sniper & Ray ^ Scarab
        Hunta, Eric ^ Brainstorm
        Muhmac ^ Speckdrumm
        Minas ^ Calodox
        XXX ^ Haujobb
        Slack ^ Necrostudios
        Gopher ^ Alctraz
        Degauss ^ TEK
        Sudio,Rackler,Jester,Eliptic ^ Ideology
        Graham,Yazoo,Axis,Dante ^ Oxyron
        Decca ^ Bauknecht & Lego
        IQ ^ RGBA
        Mentor ^ TBC
        Blueberry ^ Loonies
        Navis ^ ASD
        Nero,Pixtur ^ Still
        2crazy ^ VCF

>> Respect to:

        Kewlers / MFX
        The Black Lotus
        Plastic
        Conspiracy
        Ephidrena
        Moppi Productions
        Sunflower
        Tpolm
        Stravaganza
        Nesnausk
        Adromeda Software Development
        Cocoon
        Mad Wizards
        Portal Process
        A.N.D.
        Hellcore
        Exceed
        Bypass
        Adapt
        Traction
        Matt Current
        Visualice
        The Electronic Knights
        Oxyron
        Resource
        Camelot
        Ideology
        Andromeda
        RGBA
        Loonies
        TBC
        Quite
        

<< Suggested hardware:

        hardware


>> Tested on:

       no humans were harmed during the developement