//  kure1  (477 bayt demo) //
//  kure2  (249 bayt demo) //
/                           /
///// coded in assembly  ////
/                           /
// Coded by �brahim inci //// 
/                           / 
///////  DEVREC�  ///////////
/                           /
/// web: www.devreci.tk /////
/                           / 
/ email: devreci@yahoo.com  /
/                           /
///    DOS platform        //
