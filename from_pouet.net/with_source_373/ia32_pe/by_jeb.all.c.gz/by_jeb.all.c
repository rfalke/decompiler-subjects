
void sub_41D3EC() {
    while(1) {
    }
}
