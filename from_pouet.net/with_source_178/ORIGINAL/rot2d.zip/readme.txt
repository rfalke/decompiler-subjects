
128byte rotozoomer with parallax: contribution to EFNet #asm coders' compo #3

by Mikael Kalms <mikael@kalms.org>, 20 Feb 2000

Two versions provided: one (143 bytes) which is exitable, another (128 bytes)
which is not. The rules didn't require the program to be exitable... :)
