
int FontInit(unsigned int param0) {
    →XLoadQueryFont();
    return →XSetFont();
}

int MikmodInit() {
    →MikMod_RegisterAllDrivers();
    →MikMod_RegisterAllLoaders();
    int v0 = →MikMod_Init();
    if(v0) {
        int v1 = →MikMod_strerror();
        →fprintf(stderr, "MikMod: %s\n", v1);
        /*NO_RETURN*/ →exit(1);
    }
    int v2 = →Player_Load();
    if(!v2) {
        int v3 = →MikMod_strerror();
        →printf("MikMod Error: %s\n", v3);
        /*NO_RETURN*/ →exit(1);
    }
    return →Player_Start();
}

int XPrint(int param0, int param1, int param2, int param3, char* __s) {
    short v0;
    int v1 = param0;
    int v2 = param1;
    int v3 = param2;
    int v4 = param3;
    size_t v5 = →strlen(__s);
    short v0 = fnstcw();
    fldcw((unsigned short)(unsigned char)v0 | ((unsigned short)12 << 8));
    fldcw(v0);
    fldcw((unsigned short)(unsigned char)v0 | ((unsigned short)12 << 8));
    fldcw(v0);
    return →XDrawString();
}

int __do_global_ctors_aux(int param0, int param1) {
    int v0;
    int v1 = v0;
    int v2 = param1;
    unsigned int v3 = *(int*)&__CTOR_LIST__;
    unsigned int* ptr0 = (unsigned int*)&__CTOR_LIST__;
    while(v3 != -1) {
        --ptr0;
        v3();
        v3 = *ptr0;
    }
    return param1;
}

int* __do_global_dtors_aux() {
    int* result;
    return result;
}

int _start(int param0, int param1) {
    int v0;
    char v1;
    void* ptr0;
    int v2;
    int v3 = 0;
    char v4 = 1;
    char v5 = 0;
    char v6 = 1;
    char v7 = 0;
    char v8 = 0;
    int v9 = v0;
    int* ptr1 = &v1;
    char v10 = &v0 ? 0: 1;
    char v11 = (int)&v0 < 0;
    char v12 = __parity__((unsigned char)&v0);
    char v13 = 0;
    char v14 = 0;
    int v15 = v2;
    int* ptr2 = &v15;
    int* ptr3 = &v15;
    int v16 = param1;
    int v17 = &finalizer_0;
    int v18 = &initializer_0;
    int* ptr4 = &v1;
    int v19 = &main;
    int* ptr5 = &ptr0;
    int v20 = →__libc_start_main();
    hlt();
}

void* call_gmon_start() {
    void* result = __gmon_start__;
    if(result) {
        result = (void*)result();
    }
    return result;
}

int* finalizer_0() {
    return __do_global_dtors_aux();
}

unsigned char frame_dummy() {
    return 0;
}

int init(int param0, int param1) {
    int v0 = →XOpenDisplay();
    dis = v0;
    int v1 = →XCreateSimpleWindow();
    win = v1;
    →XMapWindow();
    colormap = *(unsigned int*)(*(int*)(dis + 140) + 48);
    int v2 = →XCreateGC();
    green_gc = v2;
    →XParseColor();
    →XAllocColor();
    return →XSetForeground();
}

int initializer_0() {
    int v0;
    int v1;
    call_gmon_start();
    frame_dummy();
    return __do_global_ctors_aux(v0, v1);
}

void main() {
    int v0;
    __SyntheticTypeUnknown v1;
    int v2;
    int v3;
    char v4;
    __SyntheticTypeUnknownF v5;
    init(300, 100);
    void* ptr0 = (void*)&loc_8048CED;
    FontInit("12x24");
    MikmodInit();
    while(1) {
        char* __s = (char*)&dude;
        *(long long*)&v0 = rut / 300.0;
        v1[v4] = →sin(*(double*)&v0);
        *(long long*)&v2 = v5 * 20.0 + 60.0;
        *(long long*)&v0 = (float)(400.0 - rut / 2.0);
        int v6 = XPrint(v0, v3, v2, (int)ptr0, __s);
        rut += 0.1;
        tim += 1.0;
        fucompp(50.0, tim);
        fnstsw((unsigned short)v6);
        if(!((unsigned char)(v6 >>> 8) & 0x45)) {
            unsigned int v7 = win;
            ptr0 = (void*)&loc_8048DAA;
            →XClearWindow();
            tim = 0;
        }
        →MikMod_Update();
    }
}

int sub_804881A() {
    return gvar_804A460();
}

int →MikMod_Init() {
    return →MikMod_Init();
}

int →MikMod_RegisterAllDrivers() {
    return →MikMod_RegisterAllDrivers();
}

int →MikMod_RegisterAllLoaders() {
    return →MikMod_RegisterAllLoaders();
}

int →MikMod_Update() {
    return →MikMod_Update();
}

int →MikMod_strerror() {
    return →MikMod_strerror();
}

int →Player_Load() {
    return →Player_Load();
}

int →Player_Start() {
    return →Player_Start();
}

int →XAllocColor() {
    return →XAllocColor();
}

int →XClearWindow() {
    return →XClearWindow();
}

int →XCreateGC() {
    return →XCreateGC();
}

int →XCreateSimpleWindow() {
    return →XCreateSimpleWindow();
}

int →XDrawString() {
    return →XDrawString();
}

int →XLoadQueryFont() {
    return →XLoadQueryFont();
}

int →XMapWindow() {
    return →XMapWindow();
}

int →XOpenDisplay() {
    return →XOpenDisplay();
}

int →XParseColor() {
    return →XParseColor();
}

int →XSetFont() {
    return →XSetFont();
}

int →XSetForeground() {
    return →XSetForeground();
}

int →__libc_start_main() {
    return →__libc_start_main();
}

void →exit(int __status) {
    /*NO_RETURN*/ →exit(__status);
}

int →fprintf(FILE* __stream, char* __format, ...) {
    return →fprintf(__stream, __format);
}

int →printf(char* __format, ...) {
    return →printf(__format);
}

double →sin(double __x) {
    __SyntheticTypeUnknown v0;
    char v1;
    v0[v1] = →sin(__x);
    return result;
}

size_t →strlen(char* __s) {
    return →strlen(__s);
}
