
Fit + Bandwagon present  : Yellow Rose of Texas
                           4k Linux intro for Assembly'03
                           pure C version for portability purposes
                           This is a new fixed version!

Marq/Fit                 : soft synth + system-level programming, C version
NF/Bandwagon             : music + visuals

Some 4k tips             : GCC 3.3 parameter tuning
                           stripping enough
                           gzip unpacker stub
                           SDL
                           dynamical GL loading
                           static arrays
                           use the source!

Connect                  : http://www.kameli.net/fit/
                           http://bandwagon.doesntexist.com/
                           http://unixscene.kameli.net/

