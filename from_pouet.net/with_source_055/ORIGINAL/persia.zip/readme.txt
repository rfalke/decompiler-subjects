prod:    persia
type:    32 byte DOS intro
author:  orbitaldecay
date:    02-10-2010

Thanks Rrrola, t$, IND and pouet.net for the inspiring prods.

http://www.orbitaldecay.com