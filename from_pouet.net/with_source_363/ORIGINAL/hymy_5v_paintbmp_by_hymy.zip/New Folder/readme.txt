this is my first extreme graphics entry
compiled with nasm
aspect ratio 16:10
for windows xp