#include "cfont.h"
#include "sprite.h"

extern void renderSetFont(int nr, font *fnt);
extern sprite *renderTextBuffer(char *txt, int width, int height);
