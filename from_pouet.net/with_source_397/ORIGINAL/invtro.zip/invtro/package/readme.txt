
                      WITCHCRAFT - CUBIC & $EEN
                         SMASH DESIGNS - LEGO
                            present to you

         the official Mekka & Symposium 2000 Invitation Intro
               (Ambience 2000 64K intro compo release)

----------------------------  THE PARTY ------------------------------

For in-depth information, read the text in the intro or look up
our web site, here's just a short summary:

Date: April 21st 2000, 12:00 CET till April 24th 2000, 12:00 CET
Location: Heidmarkhalle, Fallingbostel, Germany
Platforms: PC, Amiga, C64, PSX (any other may compete in the Wild compo)
WWW site: http://ms.demo.org

Please note that we also included maps how to come to MS2000 in this
archive. They're NOT necessary to run the intro, of course.

no gamers - friendly+competent organizers - enough power - stable network



----------------------------  THE INTRO ------------------------------

Required:
- Pentium with MMX or above
- enough RAM (32 for Win95, 64 for Win98/2000 or a big swap file)
- DirectX 5 or higher
- Graphics card capable of doing 640x480 in 32 and 8bpp
- DirectSound capable Sound card


Credits:
- Fabian "ryg/witchcraft" Giesen: main code / intro part / responsibility
- Nils "torus/cubic&$een" Pipenbrinck: 3d engine
- Tammo "kb/smash designs" Hinrichs: player / synth / music / final linking
- Michael "raw style/lego" Krause: texts / design


Known Bugs (will be fixed later, hopefully):
- in rare cases, the intro may crash, pressing ctrl-alt-del will
  fix this, of course
- under Win2000, the font at the beginning may not appear (who messed
  up the GDI?)


Contact:
- for bug reports, questions, submission of if you found the
  hidden part, e-mail to: kb@ms.demo.org



----------------------------  THE STUFF ------------------------------

What you're looking at (when running the intro, that is) is the result
of about two weeks of more or less hard work. No, there isn't much design
or the likes in it, doing that kinda stuff is in fact up to YOU for the
MS2000 demo/intro compos :)

Additional credits have to go to Chaos/FEB/Ex-Sanity for providing the
original Amiga fonts, to the UAE makers for giving us a possibility
to look up the original, to Niklas Beisert for MXMPlay (which our player
is based on), to Markus F.X.J. Oberhumer and Laszlo Molnar for UPX and
various people from the Scala Family and IRCNet's #kotraum for testing
and helping out with ideas.

The intro contains about 512k of graphics, 3MB of pre-synthesized music
(with additional realtime effects) and 30K of text. The code consists
of about 12000 lines hand-crafted ASM plus about 1300 lines C, as we were
too lazy :). All this stuffed in a neat 46K EXE file. So much for "Windows
programs have to be big and bloated".

Anyway, we hope that you all will come to us and have a great time visiting
the Mekka & Symposium 2000. We're looking forward to you.

    KB / The Obsessed Maniacs / PuRGE / Smash Designs
    (MS2000 organizer for audio/liveacts/compos)

