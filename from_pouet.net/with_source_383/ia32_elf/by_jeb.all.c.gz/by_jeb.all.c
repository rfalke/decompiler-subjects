
int start() {
    void* ptr0;
    void* ptr1;
    int v0;
    char v1;
    int result;
    char v2;
    char v3;
    char v4;
    int* ptr2;
    void* ptr3;
    void* ptr4;
    int v5;
    int v6;
    unsigned char v7;
    char v8;
    char v9;
    char v10;
    char v11;
    int v12 = v0;
    int* ptr5 = &v12;
    char v13 = &ptr1 == 332;
    char v14 = (int)&ptr2 < 0;
    char v15 = __parity__((unsigned char)&ptr1 - 76);
    char v16 = (int*)((int)(int*)((int)(int*)((int)(int*)((int)&v12 ^ 0x13c) ^ (int)&ptr2) >>> 4) & 0x1);
    char v17 = (unsigned int)&v12 < 316;
    char v18 = (int)(int*)((int)(int*)((int)&v12 ^ (int)&ptr2) & (int)(int*)((int)&v12 ^ 0x13c)) < 0;
    →SDL_SetVideoMode();
    →SDL_ShowCursor();
    →glShadeModel();
    *(int*)&v7 = 0x3f4ccccd;
    →glClearColor();
    char* ptr6 = &v7;
    char v19 = &ptr1 == 340;
    char v20 = (int)&ptr4 < 0;
    char v21 = __parity__((unsigned char)&ptr1 - 84);
    char v22 = (int*)((int)(int*)((int)(int*)((int)(int*)((int)&v7 ^ 0x18) ^ (int)&ptr4) >>> 4) & 0x1);
    char v23 = (unsigned int)&v7 >= 0xffffffe8;
    char v24 = (int)(int*)((int)(int*)((int)&ptr4 ^ (int)&v7) & (int*)~(int)(int*)((int)&v7 ^ 0x18)) < 0;
    →glClearDepth();
    →glEnable();
    →glDepthFunc();
    int v25 = 515;
    int v26 = 0x3ff00000;
    →glHint();
    *(int*)&v7 = 0;
    →glViewport();
    char* ptr7 = &v7;
    char v27 = &ptr1 == 344;
    char v28 = (int)&v5 < 0;
    char v29 = __parity__((unsigned char)&ptr1 - 88);
    char v30 = (int*)((int)(int*)((int)(int*)((int)(int*)((int)&v7 ^ 0x14) ^ (int)&v5) >>> 4) & 0x1);
    char v31 = (unsigned int)&v7 >= 0xffffffec;
    char v32 = (int)(int*)((int)(int*)((int)&v5 ^ (int)&v7) & (int*)~(int)(int*)((int)&v7 ^ 0x14)) < 0;
    →glMatrixMode();
    →glLoadIdentity();
    *(int*)&v7 = 0;
    int v33 = 0;
    int v34 = 0xbff00000;
    int v35 = 0;
    int v36 = 1073039278;
    int v37 = 343597384;
    int v38 = -1074444370;
    int v39 = 343597384;
    →glFrustum();
    int* ptr8 = &v39;
    char v40 = &ptr1 == 344;
    char v41 = (int)&v5 < 0;
    char v42 = __parity__((unsigned char)&ptr1 - 88);
    char v43 = (int*)((int)(int*)((int)(int*)((int)(int*)((int)&v39 ^ 0x34) ^ (int)&v5) >>> 4) & 0x1);
    char v44 = (unsigned int)&v39 >= 0xffffffcc;
    char v45 = (int)(int*)((int)(int*)((int)&v5 ^ (int)&v39) & (int*)~(int)(int*)((int)&v39 ^ 0x34)) < 0;
    →glMatrixMode();
    →glLoadIdentity();
    int v46 = 0x4100;
    →glClear();
    →glLoadIdentity();
    int v47 = 0x4100;
    int v48 = 0x1102;
    unsigned int v49 = 0;
    char v50 = 1;
    char v51 = 0;
    char v52 = 1;
    char v53 = 0;
    char v54 = 0;
    *(int*)&v7 = 0;
    →glTranslated();
    char* ptr9 = &v7;
    char v55 = &ptr1 == 332;
    char v56 = (int)&ptr2 < 0;
    char v57 = __parity__((unsigned char)&ptr1 - 76);
    char v58 = (int*)((int)(int*)((int)(int*)((int)(int*)((int)&v7 ^ 0x20) ^ (int)&ptr2) >>> 4) & 0x1);
    char v59 = (unsigned int)&v7 >= 0xffffffe0;
    char v60 = (int)(int*)((int)(int*)((int)&v7 ^ (int)&ptr2) & (int*)~(int)(int*)((int)&v7 ^ 0x20)) < 0;
    v5 = 0x3f800000;
    →glRotatef();
    unsigned int v61 = 0x3f800000;
    int v62 = 0;
    *(int*)&v7 = 0x42700000;
    →glRotatef();
    char* ptr10 = &v7;
    char v63 = &ptr1 == 332;
    char v64 = (int)&ptr2 < 0;
    char v65 = __parity__((unsigned char)&ptr1 - 76);
    char v66 = (int*)((int)(int*)((int)(int*)((int)(int*)((int)&v7 ^ 0x20) ^ (int)&ptr2) >>> 4) & 0x1);
    char v67 = (unsigned int)&v7 >= 0xffffffe0;
    char v68 = (int)(int*)((int)(int*)((int)&v7 ^ (int)&ptr2) & (int*)~(int)(int*)((int)&v7 ^ 0x20)) < 0;
    int v69 = sub_8049394();
    int* ptr11 = &ptr2;
    char v70 = &ptr1 == 344;
    char v71 = (int)&v5 < 0;
    char v72 = __parity__((unsigned char)&ptr1 - 88);
    char v73 = (int*)((int)(int*)((int)(int*)((int)(int*)((int)&ptr2 ^ 0xc) ^ (int)&v5) >>> 4) & 0x1);
    char v74 = (unsigned int)&ptr2 < 12;
    char v75 = (int)(int*)((int)(int*)((int)&v5 ^ (int)&ptr2) & (int)(int*)((int)&ptr2 ^ 0xc)) < 0;
    int v76 = v69;
    →srand(100000000);
    int v77 = 0;
    int* ptr12 = &v46;
    char v78 = &ptr1 == 332;
    char v79 = (int)&ptr2 < 0;
    char v80 = __parity__((unsigned char)&ptr1 - 76);
    char v81 = (int*)((int)(int*)((int)(int*)((int)(int*)((int)&v46 ^ 0x10) ^ (int)&ptr2) >>> 4) & 0x1);
    char v82 = (unsigned int)&v46 >= 0xfffffff0;
    char v83 = (int)(int*)((int)(int*)((int)&v46 ^ (int)&ptr2) & (int*)~(int)(int*)((int)&v46 ^ 0x10)) < 0;
    int* ptr13 = &v8;
    int* ptr14 = &v8;
    do {
        int* ptr15 = &ptr2;
        char v84 = &ptr1 == 364;
        char v85 = (int)&v7 < 0;
        char v86 = __parity__((unsigned char)&ptr1 - 108);
        char v87 = (int*)((int)(int*)((int)(int*)((int)(int*)((int)&ptr2 ^ 0x20) ^ (int)&v7) >>> 4) & 0x1);
        char v88 = (unsigned int)&ptr2 < 32;
        char v89 = (int)(int*)((int)(int*)((int)&v7 ^ (int)&ptr2) & (int)(int*)((int)&ptr2 ^ 0x20)) < 0;
        int v90 = 5;
        int* ptr16 = ptr14;
        char* ptr17 = &v7;
        while(v90 != 0) {
            *(int*)ptr17 = *ptr16;
            ++ptr16;
            ptr17 += 4;
            --v90;
        }
        int v91 = sub_8049330(v7, v62, v61);
        char* ptr18 = &v7;
        char v92 = &ptr1 == 332;
        char v93 = (int)&ptr2 < 0;
        char v94 = __parity__((unsigned char)&ptr1 - 76);
        char v95 = (int*)((int)(int*)((int)(int*)((int)(int*)((int)&v7 ^ 0x20) ^ (int)&ptr2) >>> 4) & 0x1);
        char v96 = (unsigned int)&v7 >= 0xffffffe0;
        char v97 = (int)(int*)((int)(int*)((int)&v7 ^ (int)&ptr2) & (int*)~(int)(int*)((int)&v7 ^ 0x20)) < 0;
        int v98 = v91;
        int v99 = v91 - 1;
        char v100 = v99 ? 0: 1;
        char v101 = v99 < 0;
        char v102 = __parity__((unsigned char)v99);
        char v103 = ((~v99 ^ ~v98) >>> 4) & 0x1;
        char v104 = ((v99 ^ v98) & v98) < 0;
        if(v100) {
            →SDL_Quit();
            return result;
        }
        →rand();
        int v105 = 3;
        int v106 = result < 0 ? -1: 0;
        int v107 = (unsigned int)((unsigned long long)result | ((unsigned long long)v106 << 32)) % 3;
        int v108 = (unsigned int)((unsigned long long)result | ((unsigned long long)v106 << 32)) / 3;
        int v109 = v107;
        int v110 = v109 + 1;
        →rand();
        char v111 = v110 == v77;
        char v112 = v110 > v77;
        char v113 = __parity__((unsigned char)v77 - (unsigned char)v110);
        char v114 = (unsigned int)v110 > (unsigned int)v77;
        char v115 = (((v77 - v110) ^ v77) & (v110 ^ v77)) < 0;
        char v116 = (((v77 - v110) ^ (v110 ^ v77)) >>> 4) & 0x1;
        if(v111) {
            unsigned int v117 = v49;
            --v49;
            char v118 = v49 ? 0: 1;
            char v119 = v49 >= 0x80000000;
            char v120 = __parity__((unsigned char)v49);
            char v121 = ((~v49 ^ ~v117) >>> 4) & 0x1;
            char v122 = (int)((v49 ^ v117) & v117) < 0;
        }
        else {
            ptr0 = ptr3;
            ptr4 = ptr3;
            int v123 = result < 0 ? -1: 0;
            int v124 = (unsigned int)((unsigned long long)result | ((unsigned long long)v123 << 32)) % 3;
            int v125 = (unsigned int)((unsigned long long)result | ((unsigned long long)v123 << 32)) / 3;
            int v126 = v124;
            int v127 = sub_8049363(v110, v126);
            *(int*)(v49 * 4 + (int)&v6) = v127;
            int* ptr19 = &v46;
            char v128 = &ptr1 == 336;
            char v129 = (int)&ptr0 < 0;
            char v130 = __parity__((unsigned char)&ptr1 - 80);
            char v131 = (int*)((int)(int*)((int)(int*)((int)(int*)((int)&v46 ^ 0xc) ^ (int)&ptr0) >>> 4) & 0x1);
            char v132 = (unsigned int)&v46 >= 0xfffffff4;
            char v133 = (int)(int*)((int)(int*)((int)&ptr0 ^ (int)&v46) & (int*)~(int)(int*)((int)&v46 ^ 0xc)) < 0;
            int v134 = sub_80492D1(v76, v127, 90);
            v77 = v110;
            int* ptr20 = &v46;
            char v135 = &ptr1 == 332;
            char v136 = (int)&ptr2 < 0;
            char v137 = __parity__((unsigned char)&ptr1 - 76);
            char v138 = (int*)((int)(int*)((int)(int*)((int)(int*)((int)&v46 ^ 0x10) ^ (int)&ptr2) >>> 4) & 0x1);
            char v139 = (unsigned int)&v46 >= 0xfffffff0;
            char v140 = (int)(int*)((int)(int*)((int)&v46 ^ (int)&ptr2) & (int*)~(int)(int*)((int)&v46 ^ 0x10)) < 0;
        }
        ++v49;
        v3 = v49 == 59;
        v2 = (int)v49 < 59;
        char v141 = __parity__((unsigned char)v49 - 59);
        char v142 = v49 < 59;
        v4 = (((v49 - 59) ^ v49) & (v49 ^ 0x3b)) < 0;
        char v143 = (((v49 - 59) ^ (v49 ^ 0x3b)) >>> 4) & 0x1;
    }
    while(v3 || v2 != v4);
    unsigned int v144 = 0;
    char v145 = 1;
    char v146 = 0;
    char v147 = 1;
    char v148 = 0;
    char v149 = 0;
    int v150 = sub_804993D(v76);
    →SDL_GL_SwapBuffers();
    int* ptr21 = &v46;
    char v151 = &ptr1 == 332;
    char v152 = (int)&ptr2 < 0;
    char v153 = __parity__((unsigned char)&ptr1 - 76);
    char v154 = (int*)((int)(int*)((int)(int*)((int)(int*)((int)&v46 ^ 0x10) ^ (int)&ptr2) >>> 4) & 0x1);
    char v155 = (unsigned int)&v46 >= 0xfffffff0;
    char v156 = (int)(int*)((int)(int*)((int)&v46 ^ (int)&ptr2) & (int*)~(int)(int*)((int)&v46 ^ 0x10)) < 0;
    int* ptr22 = &v8;
    int* ptr23 = &v8;
    do {
        int* ptr24 = &ptr2;
        char v157 = &ptr1 == 364;
        char v158 = (int)&v7 < 0;
        char v159 = __parity__((unsigned char)&ptr1 - 108);
        char v160 = (int*)((int)(int*)((int)(int*)((int)(int*)((int)&ptr2 ^ 0x20) ^ (int)&v7) >>> 4) & 0x1);
        char v161 = (unsigned int)&ptr2 < 32;
        char v162 = (int)(int*)((int)(int*)((int)&v7 ^ (int)&ptr2) & (int)(int*)((int)&ptr2 ^ 0x20)) < 0;
        int v163 = 5;
        int* ptr25 = ptr23;
        char* ptr26 = &v7;
        while(v163 != 0) {
            *(int*)ptr26 = *ptr25;
            ++ptr25;
            ptr26 += 4;
            --v163;
        }
        int v164 = sub_8049330(v7, v62, v61);
        char* ptr27 = &v7;
        char v165 = &ptr1 == 332;
        char v166 = (int)&ptr2 < 0;
        char v167 = __parity__((unsigned char)&ptr1 - 76);
        char v168 = (int*)((int)(int*)((int)(int*)((int)(int*)((int)&v7 ^ 0x20) ^ (int)&ptr2) >>> 4) & 0x1);
        char v169 = (unsigned int)&v7 >= 0xffffffe0;
        char v170 = (int)(int*)((int)(int*)((int)&v7 ^ (int)&ptr2) & (int*)~(int)(int*)((int)&v7 ^ 0x20)) < 0;
        int v171 = v164;
        int v172 = v164 - 1;
        char v173 = v172 ? 0: 1;
        char v174 = v172 < 0;
        char v175 = __parity__((unsigned char)v172);
        char v176 = ((~v172 ^ ~v171) >>> 4) & 0x1;
        char v177 = ((v172 ^ v171) & v171) < 0;
        if(v173) {
            →SDL_Quit();
            return result;
        }
        unsigned int v178 = v144;
        ++v144;
        char v179 = v144 ? 0: 1;
        char v180 = v144 >= 0x80000000;
        char v181 = __parity__((unsigned char)v144);
        char v182 = (((v178 ^ 0x1) ^ v144) >>> 4) & 0x1;
        char v183 = (int)((v144 ^ v178) & ~(v178 ^ 0x1)) < 0;
        v5 = 0;
        →glRotatef();
        →glClear();
        →glFlush();
        int v184 = sub_804993D(v76);
        →SDL_GL_SwapBuffers();
        v46 = 20;
        →SDL_Delay();
        v1 = v144 == 200;
        char v185 = (int)v144 < 200;
        char v186 = __parity__((unsigned char)v144 - 200);
        char v187 = v144 < 200;
        char v188 = (((v144 - 200) ^ v144) & (v144 ^ 0xc8)) < 0;
        char v189 = (((v144 - 200) ^ (v144 ^ 0xc8)) >>> 4) & 0x1;
    }
    while(!v1);
    int* ptr28 = &v8;
    v144 = (unsigned int)59 | ((unsigned int)((v144 >>> 8) & 0xffffff) << 8);
    int* ptr29 = &v8;
    do {
        v77 = 0;
        do {
            int* ptr30 = &ptr2;
            char v190 = &ptr1 == 364;
            char v191 = (int)&v7 < 0;
            char v192 = __parity__((unsigned char)&ptr1 - 108);
            char v193 = (int*)((int)(int*)((int)(int*)((int)(int*)((int)&ptr2 ^ 0x20) ^ (int)&v7) >>> 4) & 0x1);
            char v194 = (unsigned int)&ptr2 < 32;
            char v195 = (int)(int*)((int)(int*)((int)&v7 ^ (int)&ptr2) & (int)(int*)((int)&ptr2 ^ 0x20)) < 0;
            int v196 = 5;
            int* ptr31 = ptr29;
            char* ptr32 = &v7;
            while(v196 != 0) {
                *(int*)ptr32 = *ptr31;
                ++ptr31;
                ptr32 += 4;
                --v196;
            }
            int v197 = sub_8049330(v7, v62, v61);
            char* ptr33 = &v7;
            char v198 = &ptr1 == 332;
            char v199 = (int)&ptr2 < 0;
            char v200 = __parity__((unsigned char)&ptr1 - 76);
            char v201 = (int*)((int)(int*)((int)(int*)((int)(int*)((int)&v7 ^ 0x20) ^ (int)&ptr2) >>> 4) & 0x1);
            char v202 = (unsigned int)&v7 >= 0xffffffe0;
            char v203 = (int)(int*)((int)(int*)((int)&v7 ^ (int)&ptr2) & (int*)~(int)(int*)((int)&v7 ^ 0x20)) < 0;
            int v204 = v197;
            int v205 = v197 - 1;
            char v206 = v205 ? 0: 1;
            char v207 = v205 < 0;
            char v208 = __parity__((unsigned char)v205);
            char v209 = ((~v205 ^ ~v204) >>> 4) & 0x1;
            char v210 = ((v205 ^ v204) & v204) < 0;
            if(v206) {
                →SDL_Quit();
                return result;
            }
            v5 = 0;
            v46 = 0x40000000;
            →glRotatef();
            int* ptr34 = &v46;
            char v211 = &ptr1 == 336;
            char v212 = (int)&ptr0 < 0;
            char v213 = __parity__((unsigned char)&ptr1 - 80);
            char v214 = (int*)((int)(int*)((int)(int*)((int)(int*)((int)&v46 ^ 0xc) ^ (int)&ptr0) >>> 4) & 0x1);
            char v215 = (unsigned int)&v46 >= 0xfffffff4;
            char v216 = (int)(int*)((int)(int*)((int)&ptr0 ^ (int)&v46) & (int*)~(int)(int*)((int)&v46 ^ 0xc)) < 0;
            int v217 = *(int*)(v144 * 4 + (int)&v6);
            int v218 = sub_80492D1(v76, v217, -5);
            →glClear();
            →glFlush();
            int v219 = sub_804993D(v76);
            →SDL_GL_SwapBuffers();
            v46 = 20;
            →SDL_Delay();
            ++v77;
            v10 = v77 == 18;
            char v220 = v77 < 18;
            char v221 = __parity__((unsigned char)v77 - 18);
            char v222 = (unsigned int)v77 < 18;
            char v223 = (((v77 - 18) ^ v77) & (v77 ^ 0x12)) < 0;
            char v224 = (((v77 - 18) ^ (v77 ^ 0x12)) >>> 4) & 0x1;
        }
        while(!v10);
        --v144;
        v11 = v144 == -1;
        char v225 = (int)v144 < -1;
        char v226 = __parity__((unsigned char)v144 - 0xff);
        char v227 = v144 < 0xffffffff;
        char v228 = (((v144 + 1) ^ v144) & ~v144) < 0;
        char v229 = (((v144 + 1) ^ ~v144) >>> 4) & 0x1;
    }
    while(v11);
    int* ptr35 = &v8;
    int* ptr36 = NULL;
    char v230 = 1;
    char v231 = 0;
    char v232 = 1;
    char v233 = 0;
    char v234 = 0;
    ptr2 = &v8;
    do {
        int* ptr37 = &ptr2;
        char v235 = &ptr1 == 364;
        char v236 = (int)&v7 < 0;
        char v237 = __parity__((unsigned char)&ptr1 - 108);
        char v238 = (int*)((int)(int*)((int)(int*)((int)(int*)((int)&ptr2 ^ 0x20) ^ (int)&v7) >>> 4) & 0x1);
        char v239 = (unsigned int)&ptr2 < 32;
        char v240 = (int)(int*)((int)(int*)((int)&v7 ^ (int)&ptr2) & (int)(int*)((int)&ptr2 ^ 0x20)) < 0;
        int v241 = 5;
        int* ptr38 = ptr2;
        char* ptr39 = &v7;
        while(v241 != 0) {
            *(int*)ptr39 = *ptr38;
            ++ptr38;
            ptr39 += 4;
            --v241;
        }
        int v242 = sub_8049330(v7, v62, v61);
        char* ptr40 = &v7;
        char v243 = &ptr1 == 332;
        char v244 = (int)&ptr2 < 0;
        char v245 = __parity__((unsigned char)&ptr1 - 76);
        char v246 = (int*)((int)(int*)((int)(int*)((int)(int*)((int)&v7 ^ 0x20) ^ (int)&ptr2) >>> 4) & 0x1);
        char v247 = (unsigned int)&v7 >= 0xffffffe0;
        char v248 = (int)(int*)((int)(int*)((int)&v7 ^ (int)&ptr2) & (int*)~(int)(int*)((int)&v7 ^ 0x20)) < 0;
        int v249 = v242;
        int v250 = v242 - 1;
        char v251 = v250 ? 0: 1;
        char v252 = v250 < 0;
        char v253 = __parity__((unsigned char)v250);
        char v254 = ((~v250 ^ ~v249) >>> 4) & 0x1;
        char v255 = ((v250 ^ v249) & v249) < 0;
        if(v251) {
            →SDL_Quit();
            return result;
        }
        int* ptr41 = ptr36;
        ptr36 = (int*)((char*)ptr36 + 1);
        char v256 = ptr36 ? 0: 1;
        char v257 = (int)ptr36 < 0;
        char v258 = __parity__((unsigned char)ptr36);
        char v259 = (int*)((int)(int*)((int)(int*)((int)(int*)((int)ptr41 ^ 0x1) ^ (int)ptr36) >>> 4) & 0x1);
        char v260 = (int)(int*)((int)(int*)((int)ptr36 ^ (int)ptr41) & (int*)~(int)(int*)((int)ptr41 ^ 0x1)) < 0;
        v5 = 0;
        →glRotatef();
        →glClear();
        →glFlush();
        int v261 = sub_804993D(v76);
        →SDL_GL_SwapBuffers();
        v46 = 20;
        →SDL_Delay();
        v9 = ptr36 == 350;
        char v262 = (int)ptr36 < 350;
        char v263 = __parity__((unsigned char)ptr36 - 94);
        char v264 = (unsigned int)ptr36 < 350;
        char v265 = (int)(int*)((int)(int*)((int)(int*)((char*)ptr36 - 350) ^ (int)ptr36) & (int)(int*)((int)ptr36 ^ 0x15e)) < 0;
        char v266 = (int*)((int)(int*)((int)(int*)((int)(int*)((char*)ptr36 - 350) ^ (int)(int*)((int)ptr36 ^ 0x15e)) >>> 4) & 0x1);
    }
    while(!v9);
    int* ptr42 = &ptr0;
    →SDL_Quit();
    result = 1;
    int v267 = 0;
    char v268 = 1;
    char v269 = 0;
    char v270 = 1;
    char v271 = 0;
    char v272 = 0;
    interrupt(128);
    →SDL_Quit();
    return result;
}

int sub_80486F2() {
    return gvar_804A0C0();
}

int sub_8048903(int param0, int param1, int param2) {
    unsigned int v0;
    int result = param0;
    int v1 = param1;
    switch(param2) {
        case 1: {
            v0 = (unsigned int)(v1 * 12 + result);
            *(int*)(v0 + 8) = 0x3f800000;
            goto loc_8048993;
        }
        case 2: {
            v0 = (unsigned int)(v1 * 12 + result);
            *(int*)(v0 + 8) = 0;
            *(int*)(v1 * 12 + result + 12) = 0;
            *(int*)(v0 + 16) = 0x3f800000;
            return result;
        }
        case 3: {
            v0 = (unsigned int)(v1 * 12 + result);
            *(int*)(v0 + 8) = 0x3f800000;
            *(int*)(v1 * 12 + result + 12) = 0;
            break;
        }
        case 4: {
            v0 = (unsigned int)(v1 * 12 + result);
            *(int*)(v0 + 8) = 0x3f800000;
            *(int*)(v1 * 12 + result + 12) = 0x3f000000;
            break;
        }
        case 5: {
            v0 = (unsigned int)(v1 * 12 + result);
            *(int*)(v0 + 8) = 0;
        loc_8048993:
            *(int*)(v1 * 12 + result + 12) = 0x3f800000;
            break;
        }
        case 6: {
            v0 = (unsigned int)(v1 * 12 + result);
            *(int*)(v0 + 8) = 0x3f800000;
            *(int*)(v1 * 12 + result + 12) = 0x3f800000;
            *(int*)(v0 + 16) = 0x3f800000;
        }
        default: {
            return result;
        }
    }
    *(int*)(v0 + 16) = 0;
    return result;
}

// Stale decompilation - Refresh this view to re-decompile this code
int sub_80489C3(int param0, char param1, unsigned int param2, unsigned int param3, int param4) {
    unsigned int v0;
    int v1;
    int result = param0;
    unsigned int v2 = param2;
    unsigned int v3 = param3;
    switch(param1) {
        case 66: {
            int v4 = v2 - 2;
            v3 = (unsigned int)((v3 - 2) ^ (unsigned int)((v3 - 2) >> 31)) - (unsigned int)((v3 - 2) >> 31);
            v2 = 0;
            v0 = ((unsigned int)(v4 >> 31) ^ v4) - (unsigned int)(v4 >> 31);
            v1 = 3;
            break;
        }
        case 68: {
            v0 = 0;
            v2 = (unsigned int)((v2 - 2) ^ (unsigned int)((v2 - 2) >> 31)) - (unsigned int)((v2 - 2) >> 31);
            v1 = 4;
            break;
        }
        case 70: {
            int v5 = v2 - 2;
            v2 = 2;
            v0 = ((unsigned int)(v5 >> 31) ^ v5) - (unsigned int)(v5 >> 31);
            v1 = 2;
            break;
        }
        case 76: {
            int v6 = v2 - 2;
            v2 = v3;
            v0 = ((unsigned int)(v6 >> 31) ^ v6) - (unsigned int)(v6 >> 31);
            v1 = 5;
        loc_8048A5E:
            v3 = 0;
            break;
        }
        case 82: {
            int v7 = v3 - 2;
            v0 = (unsigned int)((v2 - 2) ^ (unsigned int)((v2 - 2) >> 31)) - (unsigned int)((v2 - 2) >> 31);
            v3 = 2;
            v2 = (unsigned int)(((v7 >> 31) ^ v7) - (v7 >> 31));
            v1 = 0;
            break;
        }
        case 84: {
            v1 = 1;
            v0 = 2;
            break;
        }
        default: {
            v1 = 0;
            v2 = 0;
            v0 = 0;
            goto loc_8048A5E;
        }
    }
    int v8 = param4;
    int v9 = v0 * 3 + v3 * 9 + (v2 + 12);
    int v10 = sub_8048903(*(int*)(v9 * 4 + result + 4), v1, param4);
    *(int*)(v9 * 4 + result + 4) = v10;
    return result;
}

int sub_8048AA8(int param0) {
    unsigned int v0;
    unsigned int v1;
    unsigned int v2;
    char v3;
    unsigned int v4 = 0;
    int result = param0;
    do {
        unsigned int v5 = 0;
        unsigned int v6 = v4 * 36;
        do {
            v2 = 0;
            v1 = (unsigned int)(v5 * 12 + result + (v6 + 4) + 48);
            do {
                int v7 = *(int*)v1;
                v0 = 0;
                do {
                    *(int*)(v0 + v7 + 16) = 0x3e800000;
                    *(int*)(v0 + v7 + 12) = 0x3e800000;
                    *(int*)(v0 + v7 + 8) = 0x3e800000;
                    v0 += 12;
                }
                while(v0 != 72);
                ++v2;
                v1 += 4;
            }
            while(v2 != 3);
            ++v5;
        }
        while(v5 == 3);
        ++v4;
    }
    while(v4 != 3);
    int v8 = 1;
    v0 = 84;
loc_8048B38:
    while(1) {
        v2 = 0;
        do {
            v1 = 0;
            do {
                unsigned int v9 = v1;
                ++v1;
                *(int*)&v3 = (int)(unsigned char)v0;
                result = sub_80489C3(result, v3, v2, v9, v8);
            }
            while(v1 != 3);
            ++v2;
        }
        while(v2 == 3);
        ++v8;
        if(v8 == 7) {
            return result;
        }
        v0 = (unsigned int)84 | ((unsigned int)((v0 >>> 8) & 0xffffff) << 8);
        switch((unsigned int)(v8 - 2)) {
            case 0: {
                break;
            }
            case 1: {
                goto loc_8048B2A;
            }
            case 2: {
                v0 = (unsigned int)76 | ((unsigned int)((v0 >>> 8) & 0xffffff) << 8);
                continue loc_8048B38;
            }
            case 3: {
                v0 = (unsigned int)66 | ((unsigned int)((v0 >>> 8) & 0xffffff) << 8);
                continue loc_8048B38;
            }
            case 4: {
                v0 = (unsigned int)68 | ((unsigned int)((v0 >>> 8) & 0xffffff) << 8);
            }
            default: {
                continue loc_8048B38;
            }
        }
        v0 = (unsigned int)70 | ((unsigned int)((v0 >>> 8) & 0xffffff) << 8);
        continue;
    loc_8048B2A:
        v0 = (unsigned int)82 | ((unsigned int)((v0 >>> 8) & 0xffffff) << 8);
    }
}

int sub_8048B68(int param0, int param1, int param2, int param3, int param4) {
    int result = param0;
    int* ptr0 = (int*)(param1 * 12 + result + 8);
    int v0 = *ptr0;
    int v1 = *(ptr0 + 1);
    int v2 = *(ptr0 + 2);
    int* ptr1 = (int*)(param2 * 12 + result + 8);
    *ptr0 = *ptr1;
    *(ptr0 + 1) = *(ptr1 + 1);
    *(ptr0 + 2) = *(ptr1 + 2);
    int* ptr2 = (int*)(param3 * 12 + result + 8);
    *ptr1 = *ptr2;
    *(ptr1 + 1) = *(ptr2 + 1);
    *(ptr1 + 2) = *(ptr2 + 2);
    int* ptr3 = (int*)(param4 * 12 + result + 8);
    *ptr2 = *ptr3;
    *(ptr2 + 1) = *(ptr3 + 1);
    *(ptr2 + 2) = *(ptr3 + 2);
    *ptr3 = v0;
    *(ptr3 + 1) = v1;
    *(ptr3 + 2) = v2;
    return result;
}

int sub_8048BE1(int param0, unsigned int param1) {
    int v0;
    int v1;
    int v2;
    int v3;
    int result = param0;
    if(param1 != 2) {
        if(param1 == 3) {
            result = sub_8048B68(result, 1, 5, 4, 0);
        }
        else if(!(param1 - 1)) {
            v3 = 3;
            v2 = 4;
            v1 = 2;
            v0 = 1;
            result = sub_8048B68(result, v0, v1, v2, v3);
        }
        return result;
    }
    v3 = 0;
    v2 = 2;
    v1 = 5;
    v0 = 3;
    return sub_8048B68(result, v0, v1, v2, v3);
}

int sub_8048C24(int param0, unsigned int param1) {
    int v0;
    int v1;
    int v2;
    int v3;
    int result = param0;
    if(param1 != 2) {
        if(param1 == 3) {
            result = sub_8048B68(result, 0, 4, 5, 1);
        }
        else if(!(param1 - 1)) {
            v3 = 1;
            v2 = 2;
            v1 = 4;
            v0 = 3;
            result = sub_8048B68(result, v0, v1, v2, v3);
        }
        return result;
    }
    v3 = 3;
    v2 = 5;
    v1 = 2;
    v0 = 0;
    return sub_8048B68(result, v0, v1, v2, v3);
}

int sub_8048C67(int param0, int param1, int param2) {
    int v0;
    int v1;
    int v2;
    int v3 = param2;
    int v4 = param1;
    int result = param0;
    int v5 = v3;
    __SyntheticTypeUnknownF v6 = (double)v5 + *(float*)((v4 + 8) * 4 + result + 8);
    *(int*)((v4 + 8) * 4 + result + 8) = v6;
    if(v3 < 0) {
        fucompp(-90.0, v6);
        fnstsw((unsigned short)v3);
        if(((v3 >>> 14) & 0x1) && !((v3 >>> 10) & 0x1)) {
            *(int*)((v4 + 8) * 4 + result + 8) = 0;
            int v7 = *(int*)((v4 + 12) * 4 + result + 4);
            *(int*)((v4 + 12) * 4 + result + 4) = *(int*)((v4 + 30) * 4 + result + 4);
            *(int*)((v4 + 30) * 4 + result + 4) = *(int*)((v4 + 36) * 4 + result + 4);
            *(int*)((v4 + 36) * 4 + result + 4) = *(int*)((v4 + 18) * 4 + result + 4);
            *(int*)((v4 + 18) * 4 + result + 4) = v7;
            int v8 = *(int*)((v4 + 21) * 4 + result + 4);
            *(int*)((v4 + 21) * 4 + result + 4) = *(int*)((v4 + 33) * 4 + result + 4);
            *(int*)((v4 + 33) * 4 + result + 4) = *(int*)((v4 + 27) * 4 + result + 4);
            *(int*)((v4 + 27) * 4 + result + 4) = *(int*)((v4 + 15) * 4 + result + 4);
            int* ptr0 = (int*)((v4 + 12) * 4 + result + 4);
            *(int*)((v4 + 15) * 4 + result + 4) = v8;
            unsigned int v9 = 0;
            do {
                v2 = 3;
                ++v9;
                int v10 = sub_8048BE1(ptr0[0], 3);
                ptr0[0] = v10;
                v1 = 3;
                int v11 = sub_8048BE1(ptr0[3], 3);
                ptr0[3] = v11;
                v0 = 3;
                v3 = sub_8048BE1(ptr0[6], 3);
                ptr0[6] = v3;
                ptr0 += 9;
            }
            while(v9 != 3);
        }
    }
    else if(v3) {
        fucompp(90.0, v6);
        fnstsw((unsigned short)v3);
        if(((v3 >>> 14) & 0x1) && !((v3 >>> 10) & 0x1)) {
            int v12 = *(int*)((v4 + 36) * 4 + result + 4);
            *(int*)((v4 + 8) * 4 + result + 8) = 0;
            int v13 = *(int*)((v4 + 18) * 4 + result + 4);
            *(int*)((v4 + 18) * 4 + result + 4) = v12;
            *(int*)((v4 + 36) * 4 + result + 4) = *(int*)((v4 + 30) * 4 + result + 4);
            *(int*)((v4 + 30) * 4 + result + 4) = *(int*)((v4 + 12) * 4 + result + 4);
            *(int*)((v4 + 12) * 4 + result + 4) = v13;
            int v14 = *(int*)((v4 + 15) * 4 + result + 4);
            *(int*)((v4 + 15) * 4 + result + 4) = *(int*)((v4 + 27) * 4 + result + 4);
            *(int*)((v4 + 27) * 4 + result + 4) = *(int*)((v4 + 33) * 4 + result + 4);
            *(int*)((v4 + 33) * 4 + result + 4) = *(int*)((v4 + 21) * 4 + result + 4);
            int* ptr1 = (int*)((v4 + 12) * 4 + result + 4);
            *(int*)((v4 + 21) * 4 + result + 4) = v14;
            unsigned int v15 = 0;
            do {
                v2 = 3;
                ++v15;
                int v16 = sub_8048C24(ptr1[0], 3);
                ptr1[0] = v16;
                v1 = 3;
                int v17 = sub_8048C24(ptr1[3], 3);
                ptr1[3] = v17;
                v0 = 3;
                v3 = sub_8048C24(ptr1[6], 3);
                ptr1[6] = v3;
                ptr1 += 9;
            }
            while(v15 != 3);
        }
    }
    fucom(*(float*)(result + 44), st7);
    fnstsw((unsigned short)v3);
    if(((v3 >>> 10) & 0x1) || !((v3 >>> 14) & 0x1)) {
        st4 = (void)(__SyntheticTypeUnknownF)(st7 - st5);
        fucom(st4, st6);
        fnstsw((unsigned short)v3);
        st6 = st4;
        if(((v3 >>> 10) & 0x1) || !((v3 >>> 14) & 0x1)) {
            st5 = (void)(__SyntheticTypeUnknownF)(st5 + st7);
            fucom(st5, st6);
            fnstsw((unsigned short)v3);
            st6 = st5;
            if(!((v3 >>> 14) & 0x1) || ((v3 >>> 10) & 0x1)) {
                return result;
            }
        }
        goto loc_8048E41;
    }
    else {
    loc_8048E41:
        st5 = (void)*(float*)(result + 48);
        fucom(st5, st7);
        fnstsw((unsigned short)v3);
        if(((v3 >>> 10) & 0x1) || !((v3 >>> 14) & 0x1)) {
            st3 = (void)(__SyntheticTypeUnknownF)(st7 - st4);
            fucom(st3, st5);
            fnstsw((unsigned short)v3);
            if(((v3 >>> 10) & 0x1) || !((v3 >>> 14) & 0x1)) {
                fucomp(st3, (__SyntheticTypeUnknownF)(st7 + st4) + st4);
                fnstsw((unsigned short)v3);
                st7 = st6;
                if(((v3 >>> 14) & 0x1) && !((v3 >>> 10) & 0x1)) {
                    st7 = (void)(__SyntheticTypeUnknownF)(st7 + *(float*)(result + 12));
                    *(int*)(result + 48) = 0;
                    *(int*)(result + 44) = 0;
                    *(int*)(result + 40) = 0;
                    *(int*)(result + 12) = (float)st7;
                    return result;
                }
            }
            else {
                st7 = st6;
                st7 = (void)(__SyntheticTypeUnknownF)(st7 + *(float*)(result + 12));
                *(int*)(result + 48) = 0;
                *(int*)(result + 44) = 0;
                *(int*)(result + 40) = 0;
                *(int*)(result + 12) = (float)st7;
                return result;
            }
        }
        else {
            st7 = st6;
            st7 = (void)(__SyntheticTypeUnknownF)(st7 + *(float*)(result + 12));
            *(int*)(result + 48) = 0;
            *(int*)(result + 44) = 0;
            *(int*)(result + 40) = 0;
            *(int*)(result + 12) = (float)st7;
        }
    }
    return result;
}

int sub_8048EB5(int param0, int param1, int param2) {
    int v0;
    int v1;
    int v2;
    int v3 = param2;
    int v4 = param1;
    int result = param0;
    int v5 = v3;
    __SyntheticTypeUnknownF v6 = (double)v5 + *(float*)((v4 + 4) * 4 + result + 12);
    *(int*)((v4 + 4) * 4 + result + 12) = v6;
    if(v3 < 0) {
        fucompp(-90.0, v6);
        fnstsw((unsigned short)v3);
        if(((v3 >>> 14) & 0x1) && !((v3 >>> 10) & 0x1)) {
            unsigned int v7 = 0;
            *(int*)((v4 + 4) * 4 + result + 12) = 0;
            int v8 = v4 * 12 + result;
            int v9 = *(int*)(v8 + 60);
            *(int*)(v8 + 60) = *(int*)(v8 + 132);
            *(int*)(v8 + 132) = *(int*)(v8 + 124);
            int v10 = *(int*)(v8 + 52);
            *(int*)(v8 + 52) = v9;
            int v11 = *(int*)(v8 + 56);
            *(int*)(v8 + 124) = v10;
            *(int*)(v8 + 56) = *(int*)(v8 + 96);
            *(int*)(v8 + 96) = *(int*)(v8 + 128);
            int v12 = *(int*)(v8 + 88);
            *(int*)(v8 + 88) = v11;
            *(int*)(v8 + 128) = v12;
            int* ptr0 = (int*)(v4 * 12 + result + 52);
            do {
                v2 = 2;
                ++v7;
                int v13 = sub_8048BE1(ptr0[0], 2);
                ptr0[0] = v13;
                v1 = 2;
                int v14 = sub_8048BE1(ptr0[1], 2);
                ptr0[1] = v14;
                v0 = 2;
                v3 = sub_8048BE1(ptr0[2], 2);
                ptr0[2] = v3;
                ptr0 += 9;
            }
            while(v7 != 3);
        }
    }
    else if(v3) {
        fucompp(90.0, v6);
        fnstsw((unsigned short)v3);
        if(((v3 >>> 14) & 0x1) && !((v3 >>> 10) & 0x1)) {
            unsigned int v15 = 0;
            *(int*)((v4 + 4) * 4 + result + 12) = 0;
            int v16 = v4 * 12 + result;
            int v17 = *(int*)(v16 + 52);
            *(int*)(v16 + 52) = *(int*)(v16 + 124);
            *(int*)(v16 + 124) = *(int*)(v16 + 132);
            int v18 = *(int*)(v16 + 60);
            *(int*)(v16 + 60) = v17;
            int v19 = *(int*)(v16 + 88);
            *(int*)(v16 + 132) = v18;
            *(int*)(v16 + 88) = *(int*)(v16 + 128);
            *(int*)(v16 + 128) = *(int*)(v16 + 96);
            int v20 = *(int*)(v16 + 56);
            *(int*)(v16 + 56) = v19;
            *(int*)(v16 + 96) = v20;
            int* ptr1 = (int*)(v4 * 12 + result + 52);
            do {
                v2 = 2;
                ++v15;
                int v21 = sub_8048C24(ptr1[0], 2);
                ptr1[0] = v21;
                v1 = 2;
                int v22 = sub_8048C24(ptr1[1], 2);
                ptr1[1] = v22;
                v0 = 2;
                v3 = sub_8048C24(ptr1[2], 2);
                ptr1[2] = v3;
                ptr1 += 9;
            }
            while(v15 != 3);
        }
    }
    fucom(*(float*)(result + 32), st7);
    fnstsw((unsigned short)v3);
    if(((v3 >>> 10) & 0x1) || !((v3 >>> 14) & 0x1)) {
        st4 = (void)(__SyntheticTypeUnknownF)(st7 - st5);
        fucom(st4, st6);
        fnstsw((unsigned short)v3);
        st6 = st4;
        if(((v3 >>> 10) & 0x1) || !((v3 >>> 14) & 0x1)) {
            st5 = (void)(__SyntheticTypeUnknownF)(st5 + st7);
            fucom(st5, st6);
            fnstsw((unsigned short)v3);
            st6 = st5;
            if(!((v3 >>> 14) & 0x1) || ((v3 >>> 10) & 0x1)) {
                return result;
            }
        }
        goto loc_8049062;
    }
    else {
    loc_8049062:
        st5 = (void)*(float*)(result + 36);
        fucom(st5, st7);
        fnstsw((unsigned short)v3);
        if(((v3 >>> 10) & 0x1) || !((v3 >>> 14) & 0x1)) {
            st3 = (void)(__SyntheticTypeUnknownF)(st7 - st4);
            fucom(st3, st5);
            fnstsw((unsigned short)v3);
            if(((v3 >>> 10) & 0x1) || !((v3 >>> 14) & 0x1)) {
                fucomp(st3, (__SyntheticTypeUnknownF)(st7 + st4) + st4);
                fnstsw((unsigned short)v3);
                st7 = st6;
                if(((v3 >>> 14) & 0x1) && !((v3 >>> 10) & 0x1)) {
                    st7 = (void)(__SyntheticTypeUnknownF)(st7 + *(float*)(result + 8));
                    *(int*)(result + 36) = 0;
                    *(int*)(result + 32) = 0;
                    *(int*)(result + 28) = 0;
                    *(int*)(result + 8) = (float)st7;
                    return result;
                }
            }
            else {
                st7 = st6;
                st7 = (void)(__SyntheticTypeUnknownF)(st7 + *(float*)(result + 8));
                *(int*)(result + 36) = 0;
                *(int*)(result + 32) = 0;
                *(int*)(result + 28) = 0;
                *(int*)(result + 8) = (float)st7;
                return result;
            }
        }
        else {
            st7 = st6;
            st7 = (void)(__SyntheticTypeUnknownF)(st7 + *(float*)(result + 8));
            *(int*)(result + 36) = 0;
            *(int*)(result + 32) = 0;
            *(int*)(result + 28) = 0;
            *(int*)(result + 8) = (float)st7;
        }
    }
    return result;
}

int sub_80490D5(int param0, int param1, int param2) {
    int v0;
    int v1;
    int v2;
    int v3 = param2;
    int v4 = param1;
    int result = param0;
    int v5 = v3;
    __SyntheticTypeUnknownF v6 = (double)v5 + *(float*)((v4 + 4) * 4 + result);
    *(int*)((v4 + 4) * 4 + result) = v6;
    if(v3 < 0) {
        fucompp(-90.0, v6);
        fnstsw((unsigned short)v3);
        if(((v3 >>> 14) & 0x1) && !((v3 >>> 10) & 0x1)) {
            unsigned int v7 = 0;
            *(int*)((v4 + 4) * 4 + result) = 0;
            int v8 = v4 * 36 + result;
            int v9 = *(int*)(v8 + 52);
            *(int*)(v8 + 52) = *(int*)(v8 + 76);
            *(int*)(v8 + 76) = *(int*)(v8 + 84);
            int v10 = *(int*)(v8 + 60);
            *(int*)(v8 + 60) = v9;
            int v11 = *(int*)(v8 + 64);
            *(int*)(v8 + 84) = v10;
            *(int*)(v8 + 64) = *(int*)(v8 + 80);
            *(int*)(v8 + 80) = *(int*)(v8 + 72);
            int v12 = *(int*)(v8 + 56);
            *(int*)(v8 + 56) = v11;
            *(int*)(v8 + 72) = v12;
            int* ptr0 = (int*)(v4 * 36 + result + 52);
            do {
                v2 = 1;
                ++v7;
                int v13 = sub_8048BE1(ptr0[0], 1);
                ptr0[0] = v13;
                v1 = 1;
                int v14 = sub_8048BE1(ptr0[1], 1);
                ptr0[1] = v14;
                v0 = 1;
                v3 = sub_8048BE1(ptr0[2], 1);
                ptr0[2] = v3;
                ptr0 += 3;
            }
            while(v7 != 3);
        }
    }
    else if(v3) {
        fucompp(90.0, v6);
        fnstsw((unsigned short)v3);
        if(((v3 >>> 14) & 0x1) && !((v3 >>> 10) & 0x1)) {
            unsigned int v15 = 0;
            *(int*)((v4 + 4) * 4 + result) = 0;
            int v16 = v4 * 36 + result;
            int v17 = *(int*)(v16 + 60);
            *(int*)(v16 + 60) = *(int*)(v16 + 84);
            *(int*)(v16 + 84) = *(int*)(v16 + 76);
            int v18 = *(int*)(v16 + 52);
            *(int*)(v16 + 52) = v17;
            int v19 = *(int*)(v16 + 56);
            *(int*)(v16 + 76) = v18;
            *(int*)(v16 + 56) = *(int*)(v16 + 72);
            *(int*)(v16 + 72) = *(int*)(v16 + 80);
            int v20 = *(int*)(v16 + 64);
            *(int*)(v16 + 64) = v19;
            *(int*)(v16 + 80) = v20;
            int* ptr1 = (int*)(v4 * 36 + result + 52);
            do {
                v2 = 1;
                ++v15;
                int v21 = sub_8048C24(ptr1[0], 1);
                ptr1[0] = v21;
                v1 = 1;
                int v22 = sub_8048C24(ptr1[1], 1);
                ptr1[1] = v22;
                v0 = 1;
                v3 = sub_8048C24(ptr1[2], 1);
                ptr1[2] = v3;
                ptr1 += 3;
            }
            while(v15 != 3);
        }
    }
    fucom(*(float*)(result + 20), st7);
    fnstsw((unsigned short)v3);
    if(((v3 >>> 10) & 0x1) || !((v3 >>> 14) & 0x1)) {
        st4 = (void)(__SyntheticTypeUnknownF)(st7 - st5);
        fucom(st4, st6);
        fnstsw((unsigned short)v3);
        st6 = st4;
        if(((v3 >>> 10) & 0x1) || !((v3 >>> 14) & 0x1)) {
            st5 = (void)(__SyntheticTypeUnknownF)(st5 + st7);
            fucom(st5, st6);
            fnstsw((unsigned short)v3);
            st6 = st5;
            if(!((v3 >>> 14) & 0x1) || ((v3 >>> 10) & 0x1)) {
                return result;
            }
        }
        goto loc_804925E;
    }
    else {
    loc_804925E:
        st5 = (void)*(float*)(result + 24);
        fucom(st5, st7);
        fnstsw((unsigned short)v3);
        if(((v3 >>> 10) & 0x1) || !((v3 >>> 14) & 0x1)) {
            st3 = (void)(__SyntheticTypeUnknownF)(st7 - st4);
            fucom(st3, st5);
            fnstsw((unsigned short)v3);
            if(((v3 >>> 10) & 0x1) || !((v3 >>> 14) & 0x1)) {
                fucomp(st3, (__SyntheticTypeUnknownF)(st7 + st4) + st4);
                fnstsw((unsigned short)v3);
                st7 = st6;
                if(((v3 >>> 14) & 0x1) && !((v3 >>> 10) & 0x1)) {
                    st7 = (void)(__SyntheticTypeUnknownF)(st7 + *(float*)(result + 4));
                    *(int*)(result + 24) = 0;
                    *(int*)(result + 20) = 0;
                    *(int*)(result + 16) = 0;
                    *(int*)(result + 4) = (float)st7;
                    return result;
                }
            }
            else {
                st7 = st6;
                st7 = (void)(__SyntheticTypeUnknownF)(st7 + *(float*)(result + 4));
                *(int*)(result + 24) = 0;
                *(int*)(result + 20) = 0;
                *(int*)(result + 16) = 0;
                *(int*)(result + 4) = (float)st7;
                return result;
            }
        }
        else {
            st7 = st6;
            st7 = (void)(__SyntheticTypeUnknownF)(st7 + *(float*)(result + 4));
            *(int*)(result + 24) = 0;
            *(int*)(result + 20) = 0;
            *(int*)(result + 16) = 0;
            *(int*)(result + 4) = (float)st7;
        }
    }
    return result;
}

int sub_80492D1(int param0, int param1, int param2) {
    int v0;
    unsigned int v1 = *(unsigned int*)(param1 + 4);
    if(v1 == 2) {
        v0 = param2;
        sub_8048EB5(param0, *(int*)(param1 + 8), param2);
    }
    else if(v1 == 3) {
        v0 = param2;
        sub_8048C67(param0, *(int*)(param1 + 8), param2);
    }
    else if(!(v1 - 1)) {
        v0 = param2;
        sub_80490D5(param0, *(int*)(param1 + 8), param2);
    }
    return param0;
}

int sub_8049330(unsigned char param0, int param1, unsigned int param2) {
    int v0;
    do {
        →SDL_PollEvent();
    }
    while(v0 && param0 == 2 && param2 == 27);
    return 1;
}

int sub_8049363(int param0, int param1) {
    int result;
    →malloc(12);
    *(int*)(result + 4) = param0;
    *(int*)(result + 8) = param1;
    return result;
}

int sub_804937F() {
    int result;
    →malloc(80);
    *(int*)(result + 4) = 0x3f4ccccd;
    return result;
}

int sub_8049394() {
    int v0;
    unsigned int v1 = 0;
    →malloc(160);
    *(int*)(v0 + 4) = 0;
    *(int*)(v0 + 8) = 0;
    *(int*)(v0 + 12) = 0;
    *(int*)(v0 + 16) = 0;
    *(int*)(v0 + 28) = 0;
    *(int*)(v0 + 40) = 0;
    *(int*)(v0 + 20) = 0;
    *(int*)(v0 + 32) = 0;
    *(int*)(v0 + 44) = 0;
    *(int*)(v0 + 24) = 0;
    *(int*)(v0 + 36) = 0;
    *(int*)(v0 + 48) = 0;
    do {
        unsigned int v2 = 0;
        int* ptr0 = (int*)(v1 * 36 + v0 + 52);
        do {
            int v3 = sub_804937F();
            ++v2;
            *ptr0 = v3;
            int v4 = sub_804937F();
            *(ptr0 + 1) = v4;
            int v5 = sub_804937F();
            *(ptr0 + 2) = v5;
            ptr0 += 3;
        }
        while(v2 != 3);
        ++v1;
    }
    while(v1 == 3);
    return sub_8048AA8(v0);
}

int sub_8049444(int param0) {
    __SyntheticTypeUnknownF v0;
    __SyntheticTypeUnknownF v1;
    __SyntheticTypeUnknownF v2;
    __SyntheticTypeUnknownF v3;
    __SyntheticTypeUnknownF v4;
    __SyntheticTypeUnknownF v5;
    __SyntheticTypeUnknownF v6;
    __SyntheticTypeUnknownF v7;
    __SyntheticTypeUnknownF v8;
    __SyntheticTypeUnknownF v9;
    __SyntheticTypeUnknownF v10;
    __SyntheticTypeUnknownF v11;
    __SyntheticTypeUnknownF v12;
    __SyntheticTypeUnknownF v13;
    __SyntheticTypeUnknownF v14;
    __SyntheticTypeUnknownF v15;
    __SyntheticTypeUnknownF v16;
    __SyntheticTypeUnknownF v17;
    __SyntheticTypeUnknownF v18;
    __SyntheticTypeUnknownF v19;
    __SyntheticTypeUnknownF v20;
    __SyntheticTypeUnknownF v21;
    __SyntheticTypeUnknownF v22;
    __SyntheticTypeUnknownF v23;
    __SyntheticTypeUnknownF v24;
    __SyntheticTypeUnknownF v25;
    __SyntheticTypeUnknownF v26;
    __SyntheticTypeUnknownF v27;
    __SyntheticTypeUnknownF v28;
    __SyntheticTypeUnknownF v29;
    __SyntheticTypeUnknownF v30;
    __SyntheticTypeUnknownF v31;
    int result;
    →glPushMatrix();
    →glBegin();
    int v32 = param0 + 8;
    →glColor3fv();
    float v33 = *(float*)(param0 + 4) / 1.8;
    int v34 = v33;
    int v35 = v33;
    v32 = v33;
    →glVertex3f();
    v42[v43] = fchs(*(float*)(param0 + 4) / 1.8);
    v33 = v7 / 1.8;
    v34 = v7 / 1.8;
    v35 = v13;
    v32 = v13;
    →glVertex3f();
    v42[v43] = fchs(*(float*)(param0 + 4));
    v34 = 0x3fe66666;
    v35 = 0x3fe66666;
    v33 = v17 / (v19 / 1.8);
    v32 = v17 / (v19 / 1.8);
    →glVertex3f();
    __SyntheticTypeUnknownF v36 = *(float*)(param0 + 4) / 1.8;
    v34 = v36;
    v42[v43] = fchs(v36);
    v33 = v4 / 1.8;
    v35 = v4 / 1.8;
    →glVertex3f();
    v32 = param0 + 20;
    →glColor3fv();
    v42[v43] = fchs(*(float*)(param0 + 4));
    v34 = 0x3fe66666;
    v33 = 1.7999999523162842 / (v11 / 1.8);
    v35 = 1.7999999523162842 / (v11 / 1.8);
    v32 = v28;
    →glVertex3f();
    __SyntheticTypeUnknownF v37 = *(float*)(param0 + 4);
    v34 = v37 / 1.8;
    v35 = v37 / 1.8;
    v42[v43] = fchs(v37);
    v33 = v30 / 1.8;
    v32 = v30 / 1.8;
    →glVertex3f();
    v33 = *(float*)(param0 + 4) / 1.8;
    v34 = v33;
    v35 = v33;
    v32 = v33;
    →glVertex3f();
    v42[v43] = fchs(*(float*)(param0 + 4) / 1.8);
    v33 = v20 / 1.8;
    v34 = v20 / 1.8;
    v35 = v5;
    →glVertex3f();
    v32 = param0 + 32;
    →glColor3fv();
    v33 = *(float*)(param0 + 4) / 1.8;
    v34 = v33;
    v35 = v33;
    v32 = v33;
    →glVertex3f();
    __SyntheticTypeUnknownF v38 = *(float*)(param0 + 4);
    v34 = v38 / 1.8;
    v35 = v38 / 1.8;
    v42[v43] = fchs(v38);
    v33 = v21 / 1.8;
    v32 = v21 / 1.8;
    →glVertex3f();
    v42[v43] = fchs(*(float*)(param0 + 4));
    v33 = 1.7999999523162842 / (v14 / 1.8);
    v34 = 1.7999999523162842 / (v14 / 1.8);
    v35 = v2;
    v32 = v2;
    →glVertex3f();
    __SyntheticTypeUnknownF v39 = *(float*)(param0 + 4) / 1.8;
    v34 = v39;
    v42[v43] = fchs(v39);
    v33 = v23 / 1.8;
    v35 = v23 / 1.8;
    →glVertex3f();
    v32 = param0 + 44;
    →glColor3fv();
    v42[v43] = fchs(*(float*)(param0 + 4) / 1.8);
    v33 = v8 / 1.8;
    v34 = v8 / 1.8;
    v35 = v15;
    v32 = v15;
    →glVertex3f();
    v42[v43] = fchs(*(float*)(param0 + 4));
    v34 = 0x3fe66666;
    v33 = 1.7999999523162842 / (v10 / 1.8);
    v35 = 1.7999999523162842 / (v10 / 1.8);
    v32 = v26;
    →glVertex3f();
    v42[v43] = fchs(*(float*)(param0 + 4));
    v33 = v29 / 1.8;
    v34 = v29 / 1.8;
    v35 = v29 / 1.8;
    v32 = v29 / 1.8;
    →glVertex3f();
    v42[v43] = fchs(*(float*)(param0 + 4));
    v34 = 0x3fe66666;
    v35 = 0x3fe66666;
    v33 = v6 / (v25 / 1.8);
    →glVertex3f();
    v32 = param0 + 56;
    →glColor3fv();
    v42[v43] = fchs(*(float*)(param0 + 4));
    v33 = v31 / 1.8;
    v34 = v31 / 1.8;
    v35 = v31 / 1.8;
    v32 = v31 / 1.8;
    →glVertex3f();
    v42[v43] = fchs(*(float*)(param0 + 4));
    v33 = 1.7999999523162842 / (v1 / 1.8);
    v34 = 1.7999999523162842 / (v1 / 1.8);
    v35 = v18;
    v32 = v18;
    →glVertex3f();
    __SyntheticTypeUnknownF v40 = *(float*)(param0 + 4) / 1.8;
    v34 = v40;
    v42[v43] = fchs(v40);
    v33 = v27 / 1.8;
    v35 = v27 / 1.8;
    v32 = v12;
    →glVertex3f();
    v42[v43] = fchs(*(float*)(param0 + 4));
    v34 = 0x3fe66666;
    v35 = 0x3fe66666;
    v33 = v24 / (v3 / 1.8);
    →glVertex3f();
    v32 = param0 + 68;
    →glColor3fv();
    __SyntheticTypeUnknownF v41 = *(float*)(param0 + 4);
    v34 = v41 / 1.8;
    v35 = v41 / 1.8;
    v42[v43] = fchs(v41);
    v33 = v9 / 1.8;
    v32 = v9 / 1.8;
    →glVertex3f();
    v42[v43] = fchs(*(float*)(param0 + 4));
    v34 = 0x3fe66666;
    v33 = 1.7999999523162842 / (v16 / 1.8);
    v35 = 1.7999999523162842 / (v16 / 1.8);
    v32 = v22;
    →glVertex3f();
    v42[v43] = fchs(*(float*)(param0 + 4));
    v33 = v0 / 1.8;
    v34 = v0 / 1.8;
    v35 = v0 / 1.8;
    v32 = v0 / 1.8;
    →glVertex3f();
    v42[v43] = fchs(*(float*)(param0 + 4));
    →glVertex3f();
    →glEnd();
    →glPopMatrix();
    return result;
}

int sub_804993D(int param0) {
    __SyntheticTypeUnknownF v0;
    __SyntheticTypeUnknownF v1;
    __SyntheticTypeUnknownF v2;
    int result;
    __SyntheticTypeUnknownF v3;
    __SyntheticTypeUnknownF v4;
    unsigned int v5 = 0;
    int v6 = 0;
    int v7 = 0;
    int v8 = 0x3f800000;
    int v9 = *(int*)(param0 + 4);
    →glRotatef();
    int v10 = 0x3f800000;
    int v11 = 0;
    int v12 = *(int*)(param0 + 8);
    →glRotatef();
    →glRotatef();
    int v13 = param0;
    do {
        unsigned int v14 = 0;
        →glRotatef();
        int v15 = v13;
        do {
            unsigned int v16 = 0;
            →glRotatef();
            do {
                v6 = 0x3f800000;
                →glRotatef();
                unsigned int v17 = v5;
                v7 = (double)v16 - 1.0;
                v8 = (double)v14 - 1.0;
                v9 = (double)v17 - 1.0;
                float v18 = (float)v17;
                float v19 = (float)v14;
                float v20 = (float)v16;
                →glTranslatef();
                sub_8049444(*(int*)(v16 * 4 + v15 + 52));
                v7 = 0x3f800000;
                v8 = 1.0 - v20 - v19;
                v9 = 1.0 - v20 - v18;
                →glTranslatef();
                v10 = 0;
                v11 = 0;
                __int128 v21 = *(float*)(v16 * 4 + param0 + 40);
                ++v16;
                v24[v25] = fchs(v21);
                v12 = v4;
                →glRotatef();
            }
            while(v16 != 3);
            v6 = 0;
            v7 = 0x3f800000;
            v8 = 0;
            __int128 v22 = *(float*)(v14 * 4 + param0 + 28);
            ++v14;
            v24[v25] = fchs(v22);
            v9 = v1;
            →glRotatef();
            v15 += 12;
        }
        while(v14 != 3);
        v6 = 0;
        v7 = 0;
        v8 = 0x3f800000;
        __int128 v23 = *(float*)(v5 * 4 + param0 + 16);
        ++v5;
        v24[v25] = fchs(v23);
        v9 = v3;
        →glRotatef();
        v13 += 36;
    }
    while(v5 != 3);
    v6 = 0x3f800000;
    v7 = 0;
    v8 = 0;
    v24[v25] = fchs(*(float*)(param0 + 12));
    v9 = v2;
    →glRotatef();
    v10 = 0x3f800000;
    v11 = 0;
    v24[v25] = fchs(*(float*)(param0 + 8));
    v12 = v0;
    →glRotatef();
    v6 = 0;
    v7 = 0;
    v8 = 0x3f800000;
    v24[v25] = fchs(*(float*)(param0 + 4));
    →glRotatef();
    return result;
}

void →SDL_Delay() {
    while(1) {
        /*BAD_CALL!*/ SDL_Delay();
        unsigned int* ptr0 = ptr0 - 1;
        *ptr0 = 200;
        --ptr0;
        *ptr0 = gvar_804A0BC;
    }
}

void →SDL_GL_SwapBuffers() {
    while(1) {
        /*BAD_CALL!*/ SDL_GL_SwapBuffers();
        unsigned int* ptr0 = ptr0 - 1;
        *ptr0 = 80;
        --ptr0;
        *ptr0 = gvar_804A0BC;
    }
}

void →SDL_PollEvent() {
    while(1) {
        /*BAD_CALL!*/ SDL_PollEvent();
        unsigned int* ptr0 = ptr0 - 1;
        *ptr0 = 72;
        --ptr0;
        *ptr0 = gvar_804A0BC;
    }
}

void →SDL_Quit() {
    while(1) {
        /*BAD_CALL!*/ SDL_Quit();
        unsigned int* ptr0 = ptr0 - 1;
        *ptr0 = 208;
        --ptr0;
        *ptr0 = gvar_804A0BC;
    }
}

void →SDL_SetVideoMode() {
    while(1) {
        /*BAD_CALL!*/ SDL_SetVideoMode();
        unsigned int* ptr0 = ptr0 - 1;
        *ptr0 = 104;
        --ptr0;
        *ptr0 = gvar_804A0BC;
    }
}

void →SDL_ShowCursor() {
    while(1) {
        /*BAD_CALL!*/ SDL_ShowCursor();
        unsigned int* ptr0 = ptr0 - 1;
        *ptr0 = 64;
        --ptr0;
        *ptr0 = gvar_804A0BC;
    }
}

void →glBegin() {
    while(1) {
        /*BAD_CALL!*/ glBegin();
        unsigned int* ptr0 = ptr0 - 1;
        *ptr0 = 168;
        --ptr0;
        *ptr0 = gvar_804A0BC;
    }
}

void →glClear() {
    while(1) {
        /*BAD_CALL!*/ glClear();
        unsigned int* ptr0 = ptr0 - 1;
        *ptr0 = 56;
        --ptr0;
        *ptr0 = gvar_804A0BC;
    }
}

void →glClearColor() {
    while(1) {
        /*BAD_CALL!*/ glClearColor();
        unsigned int* ptr0 = ptr0 - 1;
        *ptr0 = 96;
        --ptr0;
        *ptr0 = gvar_804A0BC;
    }
}

void →glClearDepth() {
    while(1) {
        /*BAD_CALL!*/ glClearDepth();
        unsigned int* ptr0 = ptr0 - 1;
        *ptr0 = 160;
        --ptr0;
        *ptr0 = gvar_804A0BC;
    }
}

void →glColor3fv() {
    while(1) {
        /*BAD_CALL!*/ glColor3fv();
        unsigned int* ptr0 = ptr0 - 1;
        *ptr0 = 40;
        --ptr0;
        *ptr0 = gvar_804A0BC;
    }
}

void →glDepthFunc() {
    while(1) {
        /*BAD_CALL!*/ glDepthFunc();
        unsigned int* ptr0 = ptr0 - 1;
        *ptr0 = 152;
        --ptr0;
        *ptr0 = gvar_804A0BC;
    }
}

void →glEnable() {
    while(1) {
        /*BAD_CALL!*/ glEnable();
        unsigned int* ptr0 = ptr0 - 1;
        *ptr0 = 24;
        --ptr0;
        *ptr0 = gvar_804A0BC;
    }
}

void →glEnd() {
    while(1) {
        /*BAD_CALL!*/ glEnd();
        unsigned int* ptr0 = ptr0 - 1;
        *ptr0 = 8;
        --ptr0;
        *ptr0 = gvar_804A0BC;
    }
}

void →glFlush() {
    while(1) {
        /*BAD_CALL!*/ glFlush();
        unsigned int* ptr0 = ptr0 - 1;
        *ptr0 = 192;
        --ptr0;
        *ptr0 = gvar_804A0BC;
    }
}

void →glFrustum() {
    while(1) {
        /*BAD_CALL!*/ glFrustum();
        unsigned int* ptr0 = ptr0 - 1;
        *ptr0 = 120;
        --ptr0;
        *ptr0 = gvar_804A0BC;
    }
}

void →glHint() {
    while(1) {
        /*BAD_CALL!*/ glHint();
        unsigned int* ptr0 = ptr0 - 1;
        *ptr0 = 32;
        --ptr0;
        *ptr0 = gvar_804A0BC;
    }
}

void →glLoadIdentity() {
    while(1) {
        /*BAD_CALL!*/ glLoadIdentity();
        unsigned int* ptr0 = ptr0 - 1;
        *ptr0 = 88;
        --ptr0;
        *ptr0 = gvar_804A0BC;
    }
}

void →glMatrixMode() {
    while(1) {
        /*BAD_CALL!*/ glMatrixMode();
        unsigned int* ptr0 = ptr0 - 1;
        *ptr0 = 48;
        --ptr0;
        *ptr0 = gvar_804A0BC;
    }
}

void →glPopMatrix() {
    while(1) {
        /*BAD_CALL!*/ glPopMatrix();
        unsigned int* ptr0 = ptr0 - 1;
        *ptr0 = 224;
        --ptr0;
        *ptr0 = gvar_804A0BC;
    }
}

void →glPushMatrix() {
    while(1) {
        /*BAD_CALL!*/ glPushMatrix();
        unsigned int* ptr0 = ptr0 - 1;
        *ptr0 = 184;
        --ptr0;
        *ptr0 = gvar_804A0BC;
    }
}

void →glRotatef() {
    while(1) {
        /*BAD_CALL!*/ glRotatef();
        unsigned int* ptr0 = ptr0 - 1;
        *ptr0 = 144;
        --ptr0;
        *ptr0 = gvar_804A0BC;
    }
}

void →glShadeModel() {
    while(1) {
        /*BAD_CALL!*/ glShadeModel();
        unsigned int* ptr0 = ptr0 - 1;
        *ptr0 = 112;
        --ptr0;
        *ptr0 = gvar_804A0BC;
    }
}

void →glTranslated() {
    while(1) {
        /*BAD_CALL!*/ glTranslated();
        unsigned int* ptr0 = ptr0 - 1;
        *ptr0 = 0;
        --ptr0;
        *ptr0 = gvar_804A0BC;
    }
}

void →glTranslatef() {
    while(1) {
        /*BAD_CALL!*/ glTranslatef();
        unsigned int* ptr0 = ptr0 - 1;
        *ptr0 = 128;
        --ptr0;
        *ptr0 = gvar_804A0BC;
    }
}

void →glVertex3f() {
    while(1) {
        /*BAD_CALL!*/ glVertex3f();
        unsigned int* ptr0 = ptr0 - 1;
        *ptr0 = 176;
        --ptr0;
        *ptr0 = gvar_804A0BC;
    }
}

void →glViewport() {
    while(1) {
        /*BAD_CALL!*/ glViewport();
        unsigned int* ptr0 = ptr0 - 1;
        *ptr0 = 232;
        --ptr0;
        *ptr0 = gvar_804A0BC;
    }
}

void →malloc(int param0) {
    unsigned int* ptr0;
    while(1) {
        /*BAD_CALL!*/ malloc(*(size_t*)(ptr0 + 1));
        --ptr0;
        *ptr0 = 0x88;
        --ptr0;
        *ptr0 = gvar_804A0BC;
    }
}

void →rand() {
    while(1) {
        /*BAD_CALL!*/ rand();
        unsigned int* ptr0 = ptr0 - 1;
        *ptr0 = 216;
        --ptr0;
        *ptr0 = gvar_804A0BC;
    }
}

void →srand(int param0) {
    unsigned int* ptr0;
    while(1) {
        /*BAD_CALL!*/ srand(*(ptr0 + 1));
        --ptr0;
        *ptr0 = 16;
        --ptr0;
        *ptr0 = gvar_804A0BC;
    }
}
