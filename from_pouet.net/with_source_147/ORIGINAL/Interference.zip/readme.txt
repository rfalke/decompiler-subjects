My very first 128 bytes FX
Version 2

- Added palette

- Added ESC key test
- Optimized size and speed


Programmed by Frederic Condolo, ex- Soundy / NGC (Amiga) / MCS  (Atari ST)
fcondolo@yahoo.com
