Genius as I am, I got to the party place one day late. I missed the
4k deadline, so I entered it to the demo compo instead :) The sad part 
is that there were only 2 entries in the 4k compo. Even if I got last,
I would still get 100$.


Here is some technical stuff:

This intro uses a 320*200*32 video mode. If you can't get the mode to 
run, you could try the fakemodeversion. It's slow as hell, but looks
good.

The source is included. I've ripped the texturegenerating code
from "spark of hope" by khamoon/Tube27, the rest of the code is mostly mine.
Enjoy!

email: tomrb@sofus.hiof.no
web: sofus.hiof.no/~tomrb/index.html

Have a nice life!