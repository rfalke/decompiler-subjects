
int start() {
    HMODULE v0 = →kernel32.dll!LoadLibraryA("kernel32");
    gvar_403009 = v0;
    if(v0) {
        FARPROC v1 = →kernel32.dll!GetProcAddress(gvar_403009, "WinExec");
        gvar_403015 = v1;
        if(!v1) {
            goto loc_401097;
        }
        else {
            HANDLE v2 = →kernel32.dll!CreateFileA("XOROX-KO.exe", 0x40000000, 0, NULL, 3, 128, NULL);
            gvar_40304E = v2;
            if(!(int*)((int)v2 + 1)) {
                goto loc_401097;
            }
            else {
                →kernel32.dll!SetFilePointer(gvar_40304E, 49, NULL, 0);
                →kernel32.dll!WriteFile(gvar_40304E, (LPCVOID)&gvar_403015, 4, (LPDWORD)0x403052, NULL);
                →kernel32.dll!CloseHandle(gvar_40304E);
                →user32.dll!MessageBoxA(NULL, "DONE! (^_^)", "XOROX-KO SETUP", 0);
            }
        }
    }
    else {
    loc_401097:
        →user32.dll!MessageBoxA(NULL, "ERROR! (>_<)", "XOROX-KO SETUP", 0);
    }
    →kernel32.dll!FreeLibrary(gvar_403009);
    /*NO_RETURN*/ →kernel32.dll!ExitProcess(0);
}

BOOL →kernel32.dll!CloseHandle(HANDLE hObject) {
    return CloseHandle(hObject);
}

HANDLE →kernel32.dll!CreateFileA(LPCSTR lpFileName, DWORD dwDesiredAccess, DWORD dwShareMode, LPSECURITY_ATTRIBUTES lpSecurityAttributes, DWORD dwCreationDisposition, DWORD dwFlagsAndAttributes, HANDLE hTemplateFile) {
    return CreateFileA(lpFileName, dwDesiredAccess, dwShareMode, lpSecurityAttributes, dwCreationDisposition, dwFlagsAndAttributes, hTemplateFile);
}

void →kernel32.dll!ExitProcess(UINT uExitCode) {
    /*NO_RETURN*/ ExitProcess(uExitCode);
}

BOOL →kernel32.dll!FreeLibrary(HMODULE hLibModule) {
    return FreeLibrary(hLibModule);
}

FARPROC →kernel32.dll!GetProcAddress(HMODULE hModule, LPCSTR lpProcName) {
    return GetProcAddress(hModule, lpProcName);
}

HMODULE →kernel32.dll!LoadLibraryA(LPCSTR lpLibFileName) {
    return LoadLibraryA(lpLibFileName);
}

DWORD →kernel32.dll!SetFilePointer(HANDLE hFile, LONG lDistanceToMove, PLONG lpDistanceToMoveHigh, DWORD dwMoveMethod) {
    return SetFilePointer(hFile, lDistanceToMove, lpDistanceToMoveHigh, dwMoveMethod);
}

BOOL →kernel32.dll!WriteFile(HANDLE hFile, LPCVOID lpBuffer, DWORD nNumberOfBytesToWrite, LPDWORD lpNumberOfBytesWritten, LPOVERLAPPED lpOverlapped) {
    return WriteFile(hFile, lpBuffer, nNumberOfBytesToWrite, lpNumberOfBytesWritten, lpOverlapped);
}

int →user32.dll!MessageBoxA(HWND hWnd, LPCSTR lpText, LPCSTR lpCaption, UINT uType) {
    return MessageBoxA(hWnd, lpText, lpCaption, uType);
}
