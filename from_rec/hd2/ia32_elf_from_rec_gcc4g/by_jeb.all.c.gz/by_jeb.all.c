
unsigned int __do_global_ctors_aux() {
    int v0;
    int v1 = v0;
    unsigned int v2 = *(int*)&__CTOR_LIST__;
    if(v2 != -1) {
        unsigned int* ptr0 = (unsigned int*)&__CTOR_LIST__;
        do {
            --ptr0;
            v2();
            v2 = *ptr0;
        }
        while(v2 != -1);
    }
    return -1;
}

unsigned int __do_global_dtors_aux() {
    unsigned int result;
    return result;
}

void __i686.get_pc_thunk.bx() {
}

void __libc_csu_fini() {
}

int __libc_csu_init() {
    initializer_0();
    return &__CTOR_LIST__;
}

int _start(int param0, int param1) {
    int v0;
    char v1;
    void* ptr0;
    int v2;
    int v3 = 0;
    char v4 = 1;
    char v5 = 0;
    char v6 = 1;
    char v7 = 0;
    char v8 = 0;
    int v9 = v0;
    int* ptr1 = &v1;
    char v10 = &v0 ? 0: 1;
    char v11 = (int)&v0 < 0;
    char v12 = __parity__((unsigned char)&v0);
    char v13 = 0;
    char v14 = 0;
    int v15 = v2;
    int* ptr2 = &v15;
    int* ptr3 = &v15;
    int v16 = param1;
    int v17 = &__libc_csu_fini;
    int v18 = &__libc_csu_init;
    int* ptr4 = &v1;
    int v19 = &main;
    int* ptr5 = &ptr0;
    →__libc_start_main();
    hlt();
}

int dumpline(int param0, int param1, unsigned int param2) {
    char v0;
    int result;
    int v1;
    int v2 = v1;
    int v3 = param0;
    int v4 = *(int*)(__GS_BASE + (int)(int*)0x14);
    int v5 = param1;
    →sprintf(&v0, "%08lX:");
    if((int)param2 > 16) {
        param2 = 16;
    }
    unsigned int j = 0;
    unsigned int i;
    for(i = j; (int)i < (int)param2; i = j) {
        v5 = (unsigned int)*(char*)(v3 + j);
        →sprintf(j * 2 + &v0 + (j + 9), " %02lX");
        ++j;
    }
    while(1) {
        i = (unsigned int)((int)j > 15 ? 0: 1) | ((unsigned int)((i >>> 8) & 0xffffff) << 8);
        ++j;
        if(!(unsigned char)i) {
            break;
        }
        else {
            →strcat(&v0, &gvar_8048A2E);
        }
    }
    →strlen(&v0);
    →memcpy(&v0, &gvar_8048A32, 4);
    int v6 = result + 3;
    for(j = 0; (int)j < (int)param2; ++j) {
        *(char*)(&v0 + v6 + j) = *(unsigned char*)(v3 + j) <= 31 || *(unsigned char*)(v3 + j) > 126 ? 46: *(char*)(v3 + j);
    }
    while((int)j <= 15) {
        *(char*)(&v0 + v6 + j) = 32;
        ++j;
    }
    →memcpy(&v0 + v6 + j, &gvar_8048A36, 2);
    →puts(&v0);
    result = *(int*)(__GS_BASE + (int)(int*)0x14) ^ v4;
    if(result) {
        /*NO_RETURN*/ →__stack_chk_fail();
    }
    return result;
}

unsigned int finalizer_0() {
    return __do_global_dtors_aux();
}

unsigned char frame_dummy() {
    return 0;
}

int hexdump(char* param0) {
    int result;
    char v0;
    unsigned int v1;
    char v2;
    char* __file = param0;
    int v3 = *(int*)(__GS_BASE + (int)(int*)0x14);
    int v4 = stat(__file, &v0);
    if(v4) {
        →perror((int)__file);
        result = 1;
    }
    else {
        →fopen((int)__file, &gvar_8048A38);
        int v5 = result;
        if(!v5) {
            →perror((int)__file);
            result = 1;
        }
        else {
            int v6 = 0;
            while(v1 > (unsigned int)v6) {
                →fread(&v2, 1, 16, v5);
                unsigned int v7 = (unsigned int)result;
                if(!v7) {
                    break;
                }
                else {
                    dumpline(&v2, v6, v7);
                    v6 = (int)(v7 + v6);
                }
            }
            →fclose(v5);
            result = 0;
        }
    }
    if((*(int*)(__GS_BASE + (int)(int*)0x14) ^ v3)) {
        /*NO_RETURN*/ →__stack_chk_fail();
    }
    return result;
}

int initializer_0() {
    int result;
    if(__gmon_start__) {
        →__gmon_start__();
    }
    frame_dummy();
    __do_global_ctors_aux();
    return result;
}

int main(unsigned int param0, int param1) {
    int result = 0;
    for(unsigned int i = 1; (int)i < (int)param0; ++i) {
        int v0 = hexdump(*(char**)(i * 4 + param1));
        result += v0;
    }
    return result;
}

int stat(char* __file, stat* __buf) {
    int result;
    →__xstat(3, (int)__file, (int)__buf);
    return result;
}

int sub_804849E() {
    return gvar_8049FFC();
}

void →__gmon_start__() {
    while(1) {
        /*BAD_CALL!*/ __gmon_start__();
        unsigned int* ptr0 = ptr0 - 1;
        *ptr0 = 16;
        --ptr0;
        *ptr0 = gvar_8049FF8;
    }
}

void →__libc_start_main() {
    while(1) {
        /*BAD_CALL!*/ __libc_start_main();
        unsigned int* ptr0 = ptr0 - 1;
        *ptr0 = 24;
        --ptr0;
        *ptr0 = gvar_8049FF8;
    }
}

void →__stack_chk_fail() {
    while(1) {
        /*NO_RETURN*/ __stack_chk_fail();
        unsigned int* ptr0 = ptr0 - 1;
        *ptr0 = 72;
        --ptr0;
        *ptr0 = gvar_8049FF8;
    }
}

void →__xstat(int param0, int param1, int param2) {
    unsigned int* ptr0;
    while(1) {
        /*BAD_CALL!*/ __xstat(*(int*)(ptr0 + 1), *(char**)(ptr0 + 2), *(stat**)(ptr0 + 3));
        --ptr0;
        *ptr0 = 8;
        --ptr0;
        *ptr0 = gvar_8049FF8;
    }
}

void →fclose(int param0) {
    unsigned int* ptr0;
    while(1) {
        /*BAD_CALL!*/ fclose(*(FILE**)(ptr0 + 1));
        --ptr0;
        *ptr0 = 40;
        --ptr0;
        *ptr0 = gvar_8049FF8;
    }
}

void →fopen(int param0, int param1) {
    unsigned int* ptr0;
    while(1) {
        /*BAD_CALL!*/ fopen(*(char**)(ptr0 + 1), *(char**)(ptr0 + 2));
        --ptr0;
        *ptr0 = 64;
        --ptr0;
        *ptr0 = gvar_8049FF8;
    }
}

void →fread(int param0, int param1, int param2, int param3) {
    unsigned int* ptr0;
    while(1) {
        /*BAD_CALL!*/ fread(*(void**)(ptr0 + 1), *(size_t*)(ptr0 + 2), *(size_t*)(ptr0 + 3), *(FILE**)(ptr0 + 4));
        --ptr0;
        *ptr0 = 96;
        --ptr0;
        *ptr0 = gvar_8049FF8;
    }
}

void →memcpy(int param0, int param1, int param2) {
    unsigned int* ptr0;
    while(1) {
        /*BAD_CALL!*/ memcpy(*(void**)(ptr0 + 1), *(void**)(ptr0 + 2), *(size_t*)(ptr0 + 3));
        --ptr0;
        *ptr0 = 48;
        --ptr0;
        *ptr0 = gvar_8049FF8;
    }
}

void →puts(int param0) {
    unsigned int* ptr0;
    while(1) {
        /*BAD_CALL!*/ puts(*(char**)(ptr0 + 1));
        --ptr0;
        *ptr0 = 88;
        --ptr0;
        *ptr0 = gvar_8049FF8;
    }
}

void →sprintf(int param0, int param1) {
    unsigned int* ptr0;
    while(1) {
        /*BAD_CALL!*/ sprintf(*(char**)(ptr0 + 1), *(char**)(ptr0 + 2));
        --ptr0;
        *ptr0 = 0;
        --ptr0;
        *ptr0 = gvar_8049FF8;
    }
}

void →strcat(int param0, int param1) {
    unsigned int* ptr0;
    while(1) {
        /*BAD_CALL!*/ strcat(*(char**)(ptr0 + 1), *(char**)(ptr0 + 2));
        --ptr0;
        *ptr0 = 80;
        --ptr0;
        *ptr0 = gvar_8049FF8;
    }
}

void →strlen(int param0) {
    unsigned int* ptr0;
    while(1) {
        /*BAD_CALL!*/ strlen(*(char**)(ptr0 + 1));
        --ptr0;
        *ptr0 = 56;
        --ptr0;
        *ptr0 = gvar_8049FF8;
    }
}
