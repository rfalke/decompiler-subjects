
void __do_global_ctors_aux() {
    // Decompilation error
}

void __do_global_dtors_aux() {
}

void __libc_csu_fini() {
}

long __libc_csu_init() {
    return initializer_0();
}

long _start() {
    →__libc_start_main();
    hlt();
}

void* call_gmon_start() {
    void* result = __gmon_start__;
    if(result) {
        result = (void*)result();
    }
    return result;
}

int dumpline(long param0, long param1, int param2) {
    char v0;
    char v1;
    long v2 = param0;
    long v3 = param1;
    int max = param2;
    →sprintf(&v0, "%08lX:", v3);
    if(max > 16) {
        max = 16;
    }
    int j = 0;
    char* i;
    for(i = (char*)j; max > j; i = (char*)j) {
        →sprintf((char*)((long)(j * 3) + (long)&v1), " %02lX");
        ++j;
    }
    while(1) {
        i = (unsigned long)(j <= 15 ? 1: 0) | ((unsigned long)(long*)((long)(long*)((long)i >>> 8L) & 0xffffffffffffffL) << 8);
        ++j;
        if(!(unsigned char)i) {
            break;
        }
        else {
            i = →strcat(&v0, (char*)&gvar_400B8A);
        }
    }
    size_t v4 = →strlen(&v0);
    int v5 = (unsigned int)v4;
    →memcpy((void*)((long)v5 + (long)&v0), (void*)&gvar_400B8E, 4L);
    v5 += 3;
    for(j = 0; j < max; ++j) {
        *(char*)((long)(j + v5) + (long)&v0) = *(unsigned char*)((long)j + v2) > 31 && *(unsigned char*)((long)j + v2) <= 126 ? *(char*)((long)j + v2): '.';
    }
    while(j <= 15) {
        *(char*)((long)(j + v5) + (long)&v0) = ' ';
        ++j;
    }
    →memcpy((void*)((long)j + (long)v5 + (long)&v0), (void*)&gvar_400B92, 2L);
    return →puts(&v0);
}

long finalizer_0() {
    long result;
    __do_global_dtors_aux();
    return result;
}

long frame_dummy() {
    long result;
    if(*(long*)&__JCR_LIST__) {
        result = 0L;
    }
    return result;
}

long hexdump(char* param0) {
    long result;
    char v0;
    unsigned long v1;
    char v2;
    char* __file = param0;
    int v3 = stat(__file, &v0);
    if((unsigned int)v3) {
        →perror(__file);
        result = 1L;
    }
    else {
        FILE* __stream = →fopen(__file, (char*)&gvar_400B94);
        if(!__stream) {
            →perror(__file);
            result = 1L;
        }
        else {
            long v4 = 0L;
            while(v1 > (unsigned long)v4) {
                size_t v5 = →fread(&v2, 1L, 16L, __stream);
                int v6 = (int)v5;
                if(!v6) {
                    break;
                }
                else {
                    dumpline((long)&v2, v4, v6);
                    v4 += (long)v6;
                }
            }
            →fclose(__stream);
            result = 0L;
        }
    }
    return result;
}

long initializer_0() {
    call_gmon_start();
    frame_dummy();
    return __do_global_ctors_aux();
}

long main(int param0, long param1) {
    int max = param0;
    long v0 = param1;
    int v1 = 0;
    for(int i = 1; i < max; ++i) {
        long v2 = hexdump(*(char**)((long)i * 8L + v0));
        v1 += (unsigned int)v2;
    }
    return (unsigned long)v1;
}

long r→__libc_start_main() {
    /*BAD_CALL!*/ sub_4005F0();
}

int r→__xstat(int __ver, char* __filename, stat* __stat_buf) {
    /*BAD_CALL!*/ sub_4005F0();
}

int r→fclose(FILE* __stream) {
    /*BAD_CALL!*/ sub_4005F0();
}

FILE* r→fopen(char* __filename, char* __modes) {
    /*BAD_CALL!*/ sub_4005F0();
}

size_t r→fread(void* __ptr, size_t __size, size_t __n, FILE* __stream) {
    /*BAD_CALL!*/ sub_4005F0();
}

void* r→memcpy(void* __dest, void* __src, size_t __n) {
    /*BAD_CALL!*/ sub_4005F0();
}

void r→perror(char* __s) {
    /*BAD_CALL!*/ sub_4005F0();
}

int r→puts(char* __s) {
    /*BAD_CALL!*/ sub_4005F0();
}

int r→sprintf(char* __s, char* __format, ...) {
    /*BAD_CALL!*/ sub_4005F0();
}

char* r→strcat(char* __dest, char* __src) {
    /*BAD_CALL!*/ sub_4005F0();
}

size_t r→strlen(char* __s) {
    /*BAD_CALL!*/ sub_4005F0();
}

int stat(char* __file, stat* __buf) {
    return →__xstat(1, __file, __buf);
}

void sub_4005F0() {
    jump gvar_600E90;
}

long →__libc_start_main() {
    return ptr___libc_start_main{r→__libc_start_main}();
}

int →__xstat(int __ver, char* __filename, stat* __stat_buf) {
    return ptr___xstat[0]{r→__xstat}((int)__ver, __filename, __stat_buf);
}

int →fclose(FILE* __stream) {
    return ptr_fclose[0]{r→fclose}(__stream);
}

FILE* →fopen(char* __filename, char* __modes) {
    return ptr_fopen[0]{r→fopen}(__filename, __modes);
}

size_t →fread(void* __ptr, size_t __size, size_t __n, FILE* __stream) {
    return ptr_fread[0]{r→fread}(__ptr, __size, __n, __stream);
}

void* →memcpy(void* __dest, void* __src, size_t __n) {
    return ptr_memcpy[0]{r→memcpy}(__dest, __src, __n);
}

void →perror(char* __s) {
    ptr_perror[0]{r→perror}(__s);
}

int →puts(char* __s) {
    return ptr_puts[0]{r→puts}(__s);
}

int →sprintf(char* __s, char* __format, ...) {
    return ptr_sprintf[0]{r→sprintf}(__s, __format);
}

char* →strcat(char* __dest, char* __src) {
    return ptr_strcat[0]{r→strcat}(__dest, __src);
}

size_t →strlen(char* __s) {
    return ptr_strlen[0]{r→strlen}(__s);
}
