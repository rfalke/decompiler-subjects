
void __do_global_ctors_aux() {
    // Decompilation error
}

unsigned long __do_global_dtors_aux() {
    unsigned long result;
    return result;
}

void __libc_csu_fini() {
}

long __libc_csu_init(long param0, long param1, long param2) {
    return initializer_0();
}

long _start(long param0, long param1) {
    long v0;
    void* ptr0;
    char v1;
    long v2;
    long v3 = 0L;
    char v4 = 1;
    char v5 = 0;
    char v6 = 1;
    char v7 = 0;
    char v8 = 0;
    long v9 = param1;
    long v10 = v0;
    long* ptr1 = &v1;
    char v11 = &v0 ? 0: 1;
    char v12 = (long)&v0 < 0L;
    char v13 = __parity__((unsigned char)&v0);
    char v14 = 0;
    char v15 = 0;
    long v16 = v2;
    long* ptr2 = &v16;
    long* ptr3 = &v16;
    long v17 = &__libc_csu_fini;
    long v18 = &__libc_csu_init;
    long v19 = &main;
    long* ptr4 = &ptr0;
    →__libc_start_main();
    hlt();
}

void* call_gmon_start() {
    void* result = __gmon_start__;
    if(result) {
        result = (void*)result();
    }
    return result;
}

long dumpline(long param0, long param1, unsigned int param2) {
    char v0;
    unsigned int v1;
    long result;
    long v2;
    long v3 = v2;
    long v4 = param0;
    unsigned int v5 = param2;
    →sprintf(&v0, "%08lX:");
    if((int)v5 > 16) {
        v5 = 16;
    }
    unsigned int j = 0;
    long i;
    for(i = (unsigned long)j; (int)v5 > (int)j; i = (unsigned long)j) {
        →sprintf((char*)((long)(j * 3) + (long)&v0) + 9L, " %02lX");
        ++j;
    }
    while(1) {
        i = (unsigned long)((int)j > 15 ? 0: 1) | ((unsigned long)((i >>> 8L) & 0xffffffffffffffL) << 8);
        ++j;
        if(!(unsigned char)i) {
            break;
        }
        else {
            →strcat(&v0, (char*)&gvar_400B8A);
        }
    }
    →strlen(&v0);
    unsigned int v6 = v1;
    →memcpy(&v0, (void*)&gvar_400B8E, 4L);
    v6 += 3;
    for(j = 0; (int)v5 > (int)j; ++j) {
        *(char*)((long)(j + v6) + (long)&v0) = *(unsigned char*)((long)j + v4) <= 31 || *(unsigned char*)((long)j + v4) > 126 ? '.': *(char*)((long)j + v4);
    }
    while((int)j <= 15) {
        *(char*)((long)(j + v6) + (long)&v0) = ' ';
        ++j;
    }
    →memcpy((void*)((long)j + (long)v6 + (long)&v0), (void*)&gvar_400B92, 2L);
    →puts(&v0);
    return result;
}

unsigned long finalizer_0() {
    return __do_global_dtors_aux();
}

long frame_dummy() {
    long result;
    if(*(long*)&__JCR_LIST__) {
        result = 0L;
    }
    return result;
}

long hexdump(char* param0) {
    long result;
    char v0;
    unsigned long v1;
    char v2;
    FILE* ptr0;
    unsigned int v3;
    char* __file = param0;
    int v4 = /*BAD_CALL!*/ stat(__file, &v0);
    if((unsigned int)v4) {
        →perror(__file);
        result = 1L;
    }
    else {
        →fopen(__file, (char*)&gvar_400B94);
        FILE* __stream = ptr0;
        if(!__stream) {
            →perror(__file);
            result = 1L;
        }
        else {
            long v5 = 0L;
            while(v1 > (unsigned long)v5) {
                →fread(&v2, 1L, 16L, __stream);
                unsigned int v6 = v3;
                if(!v6) {
                    break;
                }
                else {
                    dumpline((long)&v2, v5, v6);
                    v5 += (long)v6;
                }
            }
            →fclose(__stream);
            result = 0L;
        }
    }
    return result;
}

long initializer_0() {
    call_gmon_start();
    frame_dummy();
    return __do_global_ctors_aux();
}

long main(long param0, long param1) {
    unsigned int v0 = (unsigned int)param0;
    long v1 = param1;
    int v2 = 0;
    for(unsigned int i = 1; (int)v0 > (int)i; ++i) {
        long v3 = hexdump(*(char**)((long)i * 8L + v1));
        v2 += (unsigned int)v3;
    }
    return (unsigned long)v2;
}

int stat(char* __file, stat* __buf) {
    int result;
    →__xstat(1L, __file, __buf);
    return result;
}

long sub_4005F6() {
    return gvar_600E90();
}

void →__libc_start_main() {
    while(1) {
        /*BAD_CALL!*/ __libc_start_main();
        unsigned long* ptr0 = ptr0 - 1;
        *ptr0 = 2L;
        --ptr0;
        *ptr0 = gvar_600E88;
    }
}

void →__xstat(long param0, char* __filename, stat* __stat_buf) {
    while(1) {
        /*BAD_CALL!*/ __xstat((int)param0, __filename, __stat_buf);
        unsigned long* ptr0 = ptr0 - 1;
        *ptr0 = 4L;
        --ptr0;
        *ptr0 = gvar_600E88;
    }
}

void →fclose(FILE* __stream) {
    while(1) {
        /*BAD_CALL!*/ fclose(__stream);
        unsigned long* ptr0 = ptr0 - 1;
        *ptr0 = 9L;
        --ptr0;
        *ptr0 = gvar_600E88;
    }
}

void →fopen(char* __filename, char* __modes) {
    while(1) {
        /*BAD_CALL!*/ fopen(__filename, __modes);
        unsigned long* ptr0 = ptr0 - 1;
        *ptr0 = 1L;
        --ptr0;
        *ptr0 = gvar_600E88;
    }
}

void →fread(void* __ptr, size_t __size, size_t __n, FILE* __stream) {
    while(1) {
        /*BAD_CALL!*/ fread(__ptr, __size, __n, __stream);
        unsigned long* ptr0 = ptr0 - 1;
        *ptr0 = 8L;
        --ptr0;
        *ptr0 = gvar_600E88;
    }
}

void →memcpy(void* __dest, void* __src, size_t __n) {
    while(1) {
        /*BAD_CALL!*/ memcpy(__dest, __src, __n);
        unsigned long* ptr0 = ptr0 - 1;
        *ptr0 = 7L;
        --ptr0;
        *ptr0 = gvar_600E88;
    }
}

void →perror(char* __s) {
    while(1) {
        /*BAD_CALL!*/ perror(__s);
        unsigned long* ptr0 = ptr0 - 1;
        *ptr0 = 10L;
        --ptr0;
        *ptr0 = gvar_600E88;
    }
}

void →puts(char* __s) {
    while(1) {
        /*BAD_CALL!*/ puts(__s);
        unsigned long* ptr0 = ptr0 - 1;
        *ptr0 = 0L;
        --ptr0;
        *ptr0 = gvar_600E88;
    }
}

void →sprintf(char* __s, char* __format) {
    while(1) {
        /*BAD_CALL!*/ sprintf(__s, __format);
        unsigned long* ptr0 = ptr0 - 1;
        *ptr0 = 5L;
        --ptr0;
        *ptr0 = gvar_600E88;
    }
}

void →strcat(char* __dest, char* __src) {
    while(1) {
        /*BAD_CALL!*/ strcat(__dest, __src);
        unsigned long* ptr0 = ptr0 - 1;
        *ptr0 = 6L;
        --ptr0;
        *ptr0 = gvar_600E88;
    }
}

void →strlen(char* __s) {
    while(1) {
        /*BAD_CALL!*/ strlen(__s);
        unsigned long* ptr0 = ptr0 - 1;
        *ptr0 = 3L;
        --ptr0;
        *ptr0 = gvar_600E88;
    }
}
