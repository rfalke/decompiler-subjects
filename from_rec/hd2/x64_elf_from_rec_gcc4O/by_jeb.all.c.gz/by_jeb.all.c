
void __do_global_ctors_aux() {
    // Decompilation error
}

void __do_global_dtors_aux() {
}

void __libc_csu_fini() {
}

long __libc_csu_init() {
    return initializer_0();
}

long _start() {
    →__libc_start_main();
    hlt();
}

void* call_gmon_start() {
    void* result = __gmon_start__;
    if(result) {
        result = (void*)result();
    }
    return result;
}

int dumpline(char* param0, long param1, int param2) {
    long v0;
    long v1;
    char v2;
    char v3;
    char* ptr0;
    →sprintf(&v2, "%08lX:", param1);
    long v4 = param2 <= 16 ? (unsigned long)param2: 16L;
    long v5 = 1L;
    if(!((unsigned int)v4 ? 0: 1) && (unsigned int)v4 >= 0) {
        char* ptr1 = ptr0;
        int v6 = 0;
        do {
            →sprintf((char*)((long)v6 + (long)&v3), " %02lX");
            ++ptr1;
            v6 += 3;
        }
        while((unsigned int)ptr1 - (unsigned int)ptr0 < (unsigned int)v4);
        if((unsigned int)v4 <= 15) {
            v5 = (v4 + 1L) & 0xffffffffL;
            goto loc_400759;
        }
        else {
            char* ptr2 = &v2;
            long v7 = -1L;
            while(v7 != 0L) {
                char v8 = ptr2[0] == 0;
                ++ptr2;
                --v7;
                if(!~v8) {
                    break;
                }
            }
            v1 = ~v7 - 1L;
            *(int*)((long)(unsigned int)v1 + (long)&v2) = 0x7c2020;
            v0 = (unsigned long)((unsigned int)v1 + 3);
            goto loc_4007B4;
        }
    }
    else {
    loc_400759:
        do {
            long v9 = -1L;
            while(v9 != 0L) {
                --v9;
                if(v2 == 0) {
                    break;
                }
            }
            *(int*)((char*)(~v9 + (long)&v2) - 1L) = 0x202020;
            v5 = (unsigned long)((unsigned int)v5 + 1);
        }
        while((unsigned int)v5 - 1 <= 15);
        char* ptr3 = &v2;
        long v10 = -1L;
        while(v10 != 0L) {
            char v11 = ptr3[0] == 0;
            ++ptr3;
            --v10;
            if(!~v11) {
                break;
            }
        }
        v1 = ~v10 - 1L;
        *(int*)((long)(unsigned int)v1 + (long)&v2) = 0x7c2020;
        v0 = (unsigned long)((unsigned int)v1 + 3);
        if((((unsigned int)v4 ? 0: 1) || (unsigned int)v4 < 0)) {
            v4 = 0L;
        }
        else {
        loc_4007B4:
            long* ptr4 = (long*)((char*)(((v4 - 1L) & 0xffffffffL) + (long)ptr0) + 1L);
            char* ptr5 = ptr0;
            long v12 = (unsigned long)((unsigned int)v1 - (unsigned int)ptr0 + 3);
            do {
                *(char*)((long)((unsigned int)ptr5 + (unsigned int)v12) + (long)&v2) = (unsigned char)(*ptr5 + 224) < 95 ? *ptr5: '.';
                ++ptr5;
            }
            while(ptr5 != ptr4);
            if((unsigned int)v4 > 15) {
                *(short*)((long)(unsigned int)v0 + (long)(unsigned int)v4 + (long)&v2) = 124;
                return →puts(&v2);
            }
        }
        int v13 = (unsigned int)v0 + (unsigned int)v4;
        do {
            *(char*)((long)v13 + (long)&v2) = ' ';
            v4 = (unsigned long)((unsigned int)v4 + 1);
            ++v13;
        }
        while((unsigned int)v4 <= 15);
    }
    *(short*)((long)(unsigned int)v0 + (long)(unsigned int)v4 + (long)&v2) = 124;
    return →puts(&v2);
}

long finalizer_0() {
    long result;
    __do_global_dtors_aux();
    return result;
}

long frame_dummy() {
    long result;
    if(*(long*)&__JCR_LIST__) {
        result = 0L;
    }
    return result;
}

long hexdump(char* __filename) {
    long result;
    char v0;
    unsigned long v1;
    char v2;
    int v3 = →__xstat(1, __filename, &v0);
    if((unsigned int)v3) {
        →perror(__filename);
        result = 1L;
    }
    else {
        FILE* __stream = →fopen(__filename, (char*)&gvar_400A5A);
        if(__stream) {
            long v4 = 0L;
            if(v1) {
                do {
                    size_t v5 = /*BAD_CALL!*/ →fread(&v2, 1L, 16L, __stream);
                    if(!(int)v5) {
                        break;
                    }
                    else {
                        dumpline((char*)&v2, v4, (int)v5);
                        v4 += (long)(int)v5;
                    }
                }
                while((unsigned long)v4 < v1);
            }
            →fclose(__stream);
            result = 0L;
        }
        else {
            →perror(__filename);
            result = 1L;
        }
    }
    return result;
}

long initializer_0() {
    call_gmon_start();
    frame_dummy();
    return __do_global_ctors_aux();
}

long main(int param0, long param1) {
    int v0 = 0;
    if(param0 > 1) {
        long v1 = param1;
        int v2 = 1;
        do {
            long v3 = hexdump(*(char**)(v1 + 8L));
            v0 += (unsigned int)v3;
            ++v2;
            v1 += 8L;
        }
        while(v2 < param0);
    }
    return (unsigned long)v0;
}

long r→__libc_start_main() {
    /*BAD_CALL!*/ sub_400540();
}

int r→__xstat(int __ver, char* __filename, stat* __stat_buf) {
    /*BAD_CALL!*/ sub_400540();
}

int r→fclose(FILE* __stream) {
    /*BAD_CALL!*/ sub_400540();
}

FILE* r→fopen(char* __filename, char* __modes) {
    /*BAD_CALL!*/ sub_400540();
}

size_t r→fread(void* __ptr, size_t __size, size_t __n, FILE* __stream) {
    /*BAD_CALL!*/ sub_400540();
}

void r→perror(char* __s) {
    /*BAD_CALL!*/ sub_400540();
}

int r→puts(char* __s) {
    /*BAD_CALL!*/ sub_400540();
}

int r→sprintf(char* __s, char* __format, ...) {
    /*BAD_CALL!*/ sub_400540();
}

void sub_400540() {
    jump gvar_600D70;
}

long →__libc_start_main() {
    return ptr___libc_start_main{r→__libc_start_main}();
}

int →__xstat(int __ver, char* __filename, stat* __stat_buf) {
    return ptr___xstat[0]{r→__xstat}((int)__ver, __filename, __stat_buf);
}

int →fclose(FILE* __stream) {
    return ptr_fclose[0]{r→fclose}(__stream);
}

FILE* →fopen(char* __filename, char* __modes) {
    return ptr_fopen[0]{r→fopen}(__filename, __modes);
}

size_t →fread(void* __ptr, size_t __size, size_t __n, FILE* __stream) {
    return ptr_fread[0]{r→fread}(__ptr, __size, __n, __stream);
}

void →perror(char* __s) {
    ptr_perror[0]{r→perror}(__s);
}

int →puts(char* __s) {
    return ptr_puts[0]{r→puts}(__s);
}

int →sprintf(char* __s, char* __format, ...) {
    return ptr_sprintf[0]{r→sprintf}(__s, __format);
}
