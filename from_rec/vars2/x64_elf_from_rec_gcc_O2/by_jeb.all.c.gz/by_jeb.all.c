
void __do_global_ctors_aux() {
    // Decompilation error
}

long __do_global_dtors_aux() {
    long result;
    return result;
}

void __libc_csu_fini() {
}

long __libc_csu_init(long param0, long param1, long param2) {
    return initializer_0();
}

long _start(long param0, long param1) {
    long v0;
    void* ptr0;
    long v1;
    char v2;
    long v3 = 0L;
    char v4 = 1;
    char v5 = 0;
    char v6 = 1;
    char v7 = 0;
    char v8 = 0;
    long v9 = param1;
    long v10 = v0;
    long* ptr1 = &v2;
    char v11 = &v0 ? 0: 1;
    char v12 = (long)&v0 < 0L;
    char v13 = __parity__((unsigned char)&v0);
    char v14 = 0;
    char v15 = 0;
    long v16 = v1;
    long* ptr2 = &v16;
    long* ptr3 = &v16;
    long v17 = &__libc_csu_fini;
    long v18 = &__libc_csu_init;
    long v19 = &main;
    long* ptr4 = &ptr0;
    long v20 = →__libc_start_main();
    hlt();
}

void* call_gmon_start() {
    void* result = __gmon_start__;
    if(result) {
        result = (void*)result();
    }
    return result;
}

long finalizer_0() {
    return __do_global_dtors_aux();
}

long frame_dummy() {
    long result;
    if(*(long*)&__JCR_LIST__) {
        result = 0L;
    }
    return result;
}

void func(int* param0) {
    *param0 = 1;
    *(char*)(param0 + 2) = 107;
    *(long*)(param0 + 4) = 10L;
}

long initializer_0() {
    call_gmon_start();
    frame_dummy();
    return __do_global_ctors_aux();
}

void main() {
    *(int*)&gs1 = 1;
    gvar_6010E8 = 107;
    gvar_6010F0 = 10L;
}

long →__libc_start_main() {
    long result;
    __libc_start_main();
    return result;
}
