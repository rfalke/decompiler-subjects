
void __do_global_ctors_aux() {
    // Decompilation error
}

void __do_global_dtors_aux() {
}

void __libc_csu_fini() {
}

long __libc_csu_init() {
    return initializer_0();
}

long _start() {
    →__libc_start_main();
    hlt();
}

void* call_gmon_start() {
    void* result = __gmon_start__;
    if(result) {
        result = (void*)result();
    }
    return result;
}

long finalizer_0() {
    long result;
    __do_global_dtors_aux();
    return result;
}

long frame_dummy() {
    long result;
    if(*(long*)&__JCR_LIST__) {
        result = 0L;
    }
    return result;
}

void func(int* param0) {
    *param0 = 1;
    *(char*)(param0 + 2) = 107;
    *(long*)(param0 + 4) = 10L;
}

long initializer_0() {
    call_gmon_start();
    frame_dummy();
    return __do_global_ctors_aux();
}

void main() {
    *(int*)&gs1 = 1;
    gvar_6010E8 = 107;
    gvar_6010F0 = 10L;
}

void r→__libc_start_main() {
    jump gvar_600FF8;
}

long →__libc_start_main() {
    long result;
    ptr___libc_start_main{r→__libc_start_main}();
    return result;
}
