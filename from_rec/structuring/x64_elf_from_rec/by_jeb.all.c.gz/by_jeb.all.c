
void __do_global_ctors_aux() {
    // Decompilation error
}

void __do_global_dtors_aux() {
}

void __libc_csu_fini() {
}

long __libc_csu_init() {
    return initializer_0();
}

long _start() {
    →__libc_start_main();
    hlt();
}

void* call_gmon_start() {
    void* result = __gmon_start__;
    if(result) {
        result = (void*)result();
    }
    return result;
}

void enter() {
}

long finalizer_0() {
    long result;
    __do_global_dtors_aux();
    return result;
}

long frame_dummy() {
    long result;
    if(*(long*)&__JCR_LIST__) {
        result = 0L;
    }
    return result;
}

long initializer_0() {
    call_gmon_start();
    frame_dummy();
    return __do_global_ctors_aux();
}

void leave() {
}

int loop1() {
    enter();
    i = 0;
    int i;
    for(i = i; i <= 99; i = i) {
        *(unsigned int*)((long)i * 4L + (long)&arr) = i;
        ++i;
    }
    leave();
    return i;
}

long loop2() {
    int v0;
    enter();
loc_40050D:
    do {
        v0 = *(int*)((long)i * 4L + (long)&arr) + j + v0;
        if(v0 == 10) {
            v0 = 22;
        }
        if(j <= 99) {
            goto loc_40050D;
        }
        else {
            j = 0;
        }
    }
    while(i <= 99);
    leave();
    return (unsigned long)v0;
}

void main() {
}

void r→__libc_start_main() {
    jump gvar_600978;
}

long →__libc_start_main() {
    long result;
    ptr___libc_start_main{r→__libc_start_main}();
    return result;
}
