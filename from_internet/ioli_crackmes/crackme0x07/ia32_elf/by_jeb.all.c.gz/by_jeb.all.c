
int* finalizer_0() {
    return sub_8048450();
}

int initializer_0(int param0, int param1) {
    sub_8048424(param0, param1);
    sub_8048480();
    return sub_8048760();
}

int start(int param0, int param1) {
    int v0;
    char v1;
    void* ptr0;
    int v2;
    int v3 = 0;
    char v4 = 1;
    char v5 = 0;
    char v6 = 1;
    char v7 = 0;
    char v8 = 0;
    int v9 = v0;
    int* ptr1 = &v1;
    char v10 = &v0 ? 0: 1;
    char v11 = (int)&v0 < 0;
    char v12 = __parity__((unsigned char)&v0);
    char v13 = 0;
    char v14 = 0;
    int v15 = v2;
    int* ptr2 = &v15;
    int* ptr3 = &v15;
    int v16 = param1;
    int v17 = &sub_8048750;
    int v18 = &sub_80486E0;
    int* ptr4 = &v1;
    int v19 = &sub_804867D;
    int* ptr5 = &ptr0;
    →__libc_start_main();
    hlt();
}

int sub_804837E() {
    return gvar_8049FFC();
}

int sub_8048424(int param0, int param1) {
    void* ptr0 = __gmon_start__;
    if(ptr0) {
        ptr0();
    }
    return param1;
}

int* sub_8048450() {
    int* result;
    if(!gvar_804A028) {
        while(1) {
            result = gvar_804A024;
            int v0 = *result;
            if(!v0) {
                break;
            }
            else {
                gvar_804A024 = result + 1;
                v0{sub_8049F18}();
            }
        }
        gvar_804A028 = 1;
    }
    return result;
}

unsigned int sub_8048480() {
    return 0;
}

int sub_80484B4(int param0, int param1) {
    int v0;
    int v1 = 0;
    while(*(int*)(v1 * 4 + param1)) {
        int v2 = v1 * 4;
        ++v1;
        int v3 = 3;
        int v4 = "LOLO";
        →strncmp(*(int*)(v2 + param1), "LOLO", 3);
        if(!v0) {
            gvar_804A02C = 1;
            return 1;
        }
    }
    return 0;
}

int sub_8048524() {
    int v0;
    char v1;
    int v2;
    void* ptr0;
    int* ptr1 = &v0;
    int* ptr2 = &v0;
    char v3 = &v1 == 12;
    char v4 = (int)&v2 < 0;
    char v5 = __parity__((unsigned char)&v1 - 12);
    char v6 = (int*)((int)(int*)((int)(int*)((int)(int*)((int)&v0 ^ 0x8) ^ (int)&v2) >>> 4) & 0x1);
    char v7 = (unsigned int)&v0 < 8;
    char v8 = (int)(int*)((int)(int*)((int)&v0 ^ (int)&v2) & (int)(int*)((int)&v0 ^ 0x8)) < 0;
    →printf("Password Incorrect!\n");
    int* ptr3 = &ptr0;
    /*NO_RETURN*/ →exit(0);
}

int sub_8048542(int param0, int param1) {
    int v0;
    →sscanf(param0, &gvar_80487C2);
    int result = sub_80484B4(v0, param1);
    if(result) {
        unsigned int v1 = 0;
        do {
            if(!(v0 & 0x1)) {
                if(gvar_804A02C == 1) {
                    →printf("Password OK!\n");
                }
                /*NO_RETURN*/ →exit(0);
            }
            result = &v1;
            ++v1;
        }
        while((int)v1 > 9);
    }
    return result;
}

int sub_80485B9(int param0, int param1) {
    char v0;
    int v1;
    unsigned int v2;
    int v3;
    int v4;
    int* ptr0 = &v1;
    int* ptr1 = &v1;
    char v5 = &v0 == 44;
    char v6 = (int)&v4 < 0;
    char v7 = __parity__((unsigned char)&v0 - 44);
    char v8 = (int*)((int)(int*)((int)(int*)((int)(int*)((int)&v1 ^ 0x28) ^ (int)&v4) >>> 4) & 0x1);
    char v9 = (unsigned int)&v1 < 40;
    char v10 = (int)(int*)((int)(int*)((int)&v1 ^ (int)&v4) & (int)(int*)((int)&v1 ^ 0x28)) < 0;
    unsigned int v11 = 0;
    int* ptr2 = NULL;
    while(1) {
        int v12 = param0;
        →strlen(v12);
        char v13 = v2 == ptr2;
        char v14 = (int)v2 > (int)ptr2;
        char v15 = __parity__((unsigned char)ptr2 - (unsigned char)v2);
        char v16 = v2 > (unsigned int)ptr2;
        char v17 = (int)(int*)((int)(int*)((int)(int*)((int)ptr2 - v2) ^ (int)ptr2) & (int)(int*)(v2 ^ (int)ptr2)) < 0;
        char v18 = (int*)((int)(int*)((int)(int*)((int)(int*)((int)ptr2 - v2) ^ (int)(int*)(v2 ^ (int)ptr2)) >>> 4) & 0x1);
        if(!v16) {
            break;
        }
        else {
            int* ptr3 = ptr2;
            int* ptr4 = ptr2;
            char* ptr5 = (char*)((int)ptr3 + param0);
            char v19 = ptr5 ? 0: 1;
            char v20 = (int)ptr5 < 0;
            char v21 = __parity__((unsigned char)ptr5);
            char v22 = (int*)((int)(int*)((int)(int*)((int)(int*)((int)ptr4 ^ param0) ^ (int)ptr5) >>> 4) & 0x1);
            char v23 = (int*)__carry__((int)ptr4, param0);
            char v24 = (int)(int*)((int)(int*)((int)ptr5 ^ (int)ptr4) & (int*)~(int)(int*)((int)ptr4 ^ param0)) < 0;
            int v25 = (unsigned int)*ptr5;
            char v26 = *ptr5;
            int* ptr6 = &v3;
            int* ptr7 = &v3;
            int v27 = &v26;
            →sscanf(&v26, &gvar_80487C2);
            int v28 = v3;
            int* ptr8 = &v11;
            v11 = (unsigned int)(v28 + v11);
            char v29 = v11 == 16;
            char v30 = (int)v11 < 16;
            char v31 = __parity__((unsigned char)v11 - 16);
            char v32 = v11 < 16;
            char v33 = (((v11 - 16) ^ v11) & (v11 ^ 0x10)) < 0;
            char v34 = (((v11 - 16) ^ (v11 ^ 0x10)) >>> 4) & 0x1;
            if(v29) {
                int v35 = param1;
                int v36 = param0;
                int v37 = sub_8048542(v36, v35);
            }
            int* ptr9 = &ptr2;
            ptr1 = ptr2;
            ptr2 = (int*)((char*)ptr2 + 1);
            char v38 = ptr2 ? 0: 1;
            char v39 = (int)ptr2 < 0;
            char v40 = __parity__((unsigned char)ptr2);
            char v41 = (int*)((int)(int*)((int)(int*)((int)(int*)((int)ptr1 ^ 0x1) ^ (int)ptr2) >>> 4) & 0x1);
            char v42 = (int)(int*)((int)(int*)((int)ptr1 ^ (int)ptr2) & (int*)~(int)(int*)((int)ptr1 ^ 0x1)) < 0;
        }
    }
    /*NO_RETURN*/ sub_8048524();
}

int sub_804867D(int param0, int param1, int param2) {
    char v0;
    char v1;
    int v2;
    int v3;
    char v4;
    int* ptr0 = &v3;
    char v5 = &v0 == 144;
    char v6 = (int)&v1 < 0;
    char v7 = __parity__((unsigned char)&v0 - 144);
    char v8 = 0;
    char v9 = 0;
    int v10 = 0;
    int v11 = 15;
    int v12 = 15;
    int v13 = 30;
    char v14 = 0;
    char v15 = 0;
    char v16 = 1;
    char v17 = 1;
    char v18 = 0;
    char v19 = 0;
    int v20 = 30;
    int v21 = 1;
    char v22 = 1;
    char v23 = 0;
    char v24 = 0;
    char v25 = 0;
    char v26 = 0;
    int v27 = 1;
    int v28 = 16;
    char v29 = 0;
    char v30 = 0;
    char v31 = 0;
    char v32 = 0;
    char v33 = 0;
    int* ptr1 = &v1;
    char v34 = &v0 == 160;
    char v35 = (int)&v2 < 0;
    char v36 = __parity__((unsigned char)&v0 - 160);
    char v37 = (int*)((int)(int*)((int)(int*)((int)(int*)((int)&v1 ^ 0x10) ^ (int)&v2) >>> 4) & 0x1);
    char v38 = (unsigned int)&v1 < 16;
    char v39 = (int)(int*)((int)(int*)((int)&v2 ^ (int)&v1) & (int)(int*)((int)&v1 ^ 0x10)) < 0;
    →printf("IOLI Crackme Level 0x07\n");
    →printf("Password: ");
    int v40 = &v4;
    →scanf(&gvar_80487FD);
    int v41 = param2;
    /*NO_RETURN*/ sub_80485B9(&v4, v41);
}

int sub_80486E0(int param0, int param1) {
    initializer_0(param0, param1);
    return 0;
}

void sub_8048750() {
}

void sub_8048755() {
}

int sub_8048760() {
    int result;
    int v0;
    int v1 = v0;
    unsigned int* ptr0 = (unsigned int*)&gvar_8049F0C;
    for(unsigned int i = *(int*)&gvar_8049F0C; i != -1; i = *ptr0) {
        --ptr0;
        i();
    }
    return result;
}

void →__libc_start_main() {
    while(1) {
        /*BAD_CALL!*/ __libc_start_main();
        unsigned int* ptr0 = ptr0 - 1;
        *ptr0 = 0;
        --ptr0;
        *ptr0 = gvar_8049FF8;
    }
}

void →exit(int __status) {
    while(1) {
        /*NO_RETURN*/ exit(__status);
        unsigned int* ptr0 = ptr0 - 1;
        *ptr0 = 48;
        --ptr0;
        *ptr0 = gvar_8049FF8;
    }
}

void →printf(int param0) {
    unsigned int* ptr0;
    while(1) {
        /*BAD_CALL!*/ printf(*(char**)(ptr0 + 1));
        --ptr0;
        *ptr0 = 24;
        --ptr0;
        *ptr0 = gvar_8049FF8;
    }
}

void →scanf(int param0) {
    unsigned int* ptr0;
    while(1) {
        /*BAD_CALL!*/ scanf(*(char**)(ptr0 + 1));
        --ptr0;
        *ptr0 = 8;
        --ptr0;
        *ptr0 = gvar_8049FF8;
    }
}

void →sscanf(int param0, int param1) {
    unsigned int* ptr0;
    while(1) {
        /*BAD_CALL!*/ sscanf(*(char**)(ptr0 + 1), *(char**)(ptr0 + 2));
        --ptr0;
        *ptr0 = 32;
        --ptr0;
        *ptr0 = gvar_8049FF8;
    }
}

void →strlen(int param0) {
    unsigned int* ptr0;
    while(1) {
        /*BAD_CALL!*/ strlen(*(char**)(ptr0 + 1));
        --ptr0;
        *ptr0 = 16;
        --ptr0;
        *ptr0 = gvar_8049FF8;
    }
}

void →strncmp(int param0, int param1, int param2) {
    unsigned int* ptr0;
    while(1) {
        /*BAD_CALL!*/ strncmp(*(char**)(ptr0 + 1), *(char**)(ptr0 + 2), *(size_t*)(ptr0 + 3));
        --ptr0;
        *ptr0 = 40;
        --ptr0;
        *ptr0 = gvar_8049FF8;
    }
}
