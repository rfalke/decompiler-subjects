
int __do_global_ctors_aux() {
    int result;
    int v0;
    int v1 = v0;
    unsigned int* ptr0 = (unsigned int*)&__CTOR_LIST__;
    for(unsigned int i = *(int*)&__CTOR_LIST__; i != -1; i = *ptr0) {
        --ptr0;
        i();
    }
    return result;
}

int* __do_global_dtors_aux() {
    int* result;
    if(!completed.1) {
        while(1) {
            result = *(int*)&p.0;
            int v0 = *result;
            if(!v0) {
                break;
            }
            else {
                *(int*)&p.0 = result + 1;
                v0{__DTOR_END__}();
            }
        }
        completed.1 = 1;
    }
    return result;
}

void __i686.get_pc_thunk.bx() {
}

void __libc_csu_fini() {
}

int __libc_csu_init(int param0, int param1) {
    initializer_0(param0, param1);
    return 0;
}

int _start(int param0, int param1) {
    int v0;
    char v1;
    void* ptr0;
    int v2;
    int v3 = 0;
    char v4 = 1;
    char v5 = 0;
    char v6 = 1;
    char v7 = 0;
    char v8 = 0;
    int v9 = v0;
    int* ptr1 = &v1;
    char v10 = &v0 ? 0: 1;
    char v11 = (int)&v0 < 0;
    char v12 = __parity__((unsigned char)&v0);
    char v13 = 0;
    char v14 = 0;
    int v15 = v2;
    int* ptr2 = &v15;
    int* ptr3 = &v15;
    int v16 = param1;
    int v17 = &__libc_csu_fini;
    int v18 = &__libc_csu_init;
    int* ptr4 = &v1;
    int v19 = &main;
    int* ptr5 = &ptr0;
    →__libc_start_main();
    hlt();
}

int* finalizer_0() {
    return __do_global_dtors_aux();
}

unsigned char frame_dummy() {
    return 0;
}

int initializer_0(int param0, int param1) {
    sub_8048354(param0, param1);
    frame_dummy();
    return __do_global_ctors_aux();
}

int main() {
    unsigned int v0;
    →printf("IOLI Crackme Level 0x02\n");
    →printf("Password: ");
    →scanf(&gvar_804856C);
    if(v0 == 0x52b24) {
        →printf("Password OK :)\n");
    }
    else {
        →printf("Invalid Password!\n");
    }
    return 0;
}

int sub_80482F2() {
    return gvar_8049FFC();
}

int sub_8048354(int param0, int param1) {
    void* ptr0 = __gmon_start__;
    if(ptr0) {
        ptr0();
    }
    return param1;
}

void →__libc_start_main() {
    while(1) {
        /*BAD_CALL!*/ __libc_start_main();
        unsigned int* ptr0 = ptr0 - 1;
        *ptr0 = 0;
        --ptr0;
        *ptr0 = gvar_8049FF8;
    }
}

void →printf(int param0) {
    unsigned int* ptr0;
    while(1) {
        /*BAD_CALL!*/ printf(*(char**)(ptr0 + 1));
        --ptr0;
        *ptr0 = 16;
        --ptr0;
        *ptr0 = gvar_8049FF8;
    }
}

void →scanf(int param0) {
    unsigned int* ptr0;
    while(1) {
        /*BAD_CALL!*/ scanf(*(char**)(ptr0 + 1));
        --ptr0;
        *ptr0 = 8;
        --ptr0;
        *ptr0 = gvar_8049FF8;
    }
}
