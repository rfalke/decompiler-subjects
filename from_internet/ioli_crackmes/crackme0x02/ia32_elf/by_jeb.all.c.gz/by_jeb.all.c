
int __do_global_ctors_aux() {
    int result;
    unsigned int* ptr0 = (unsigned int*)&__CTOR_LIST__;
    for(unsigned char i = *(int*)&__CTOR_LIST__; i != -1; i = *ptr0) {
        --ptr0;
        i();
    }
    return result;
}

int* __do_global_dtors_aux() {
    int* result;
    if(!completed.1) {
        while(1) {
            result = *(int*)&p.0;
            int v0 = *result;
            if(!v0) {
                break;
            }
            else {
                *(int*)&p.0 = result + 1;
                v0{__DTOR_END__}();
            }
        }
        completed.1 = 1;
    }
    return result;
}

void __i686.get_pc_thunk.bx() {
}

void __libc_csu_fini() {
}

int __libc_csu_init(int param0, int param1) {
    return initializer_0(param0, param1);
}

int _start(int param0, int param1) {
    →__libc_start_main();
    hlt();
}

int* finalizer_0() {
    return __do_global_dtors_aux();
}

unsigned char frame_dummy() {
    return 0;
}

int initializer_0(int param0, int param1) {
    sub_8048354(param0, param1);
    frame_dummy();
    return __do_global_ctors_aux();
}

int main() {
    int v0;
    →printf("IOLI Crackme Level 0x02\n");
    →printf("Password: ");
    →scanf((char*)&gvar_804856C, &v0);
    if(v0 == 0x52b24) {
        →printf("Password OK :)\n");
    }
    else {
        →printf("Invalid Password!\n");
    }
    return 0;
}

int r→__libc_start_main() {
    /*BAD_CALL!*/ sub_80482EC();
}

int r→printf(char* __format, ...) {
    /*BAD_CALL!*/ sub_80482EC();
}

int r→scanf(char* __format, ...) {
    /*BAD_CALL!*/ sub_80482EC();
}

void sub_80482EC() {
    jump gvar_8049FFC;
}

int sub_8048354(int param0, int param1) {
    void* ptr0 = __gmon_start__;
    if(ptr0) {
        ptr0();
    }
    return param1;
}

int →__libc_start_main() {
    return ptr___libc_start_main{r→__libc_start_main}();
}

int →printf(char* __format, ...) {
    return ptr_printf[0]{r→printf}(__format);
}

int →scanf(char* __format, ...) {
    return ptr_scanf[0]{r→scanf}(__format);
}
