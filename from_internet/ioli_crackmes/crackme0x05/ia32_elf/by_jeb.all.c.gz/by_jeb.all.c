
int __do_global_ctors_aux() {
    int result;
    int v0;
    int v1 = v0;
    unsigned int* ptr0 = (unsigned int*)&__CTOR_LIST__;
    for(unsigned int i = *(int*)&__CTOR_LIST__; i != -1; i = *ptr0) {
        --ptr0;
        i();
    }
    return result;
}

int* __do_global_dtors_aux() {
    int* result;
    if(!completed.1) {
        while(1) {
            result = *(int*)&p.0;
            int v0 = *result;
            if(!v0) {
                break;
            }
            else {
                *(int*)&p.0 = result + 1;
                v0{__DTOR_END__}();
            }
        }
        completed.1 = 1;
    }
    return result;
}

void __i686.get_pc_thunk.bx() {
}

void __libc_csu_fini() {
}

int __libc_csu_init(int param0, int param1) {
    initializer_0(param0, param1);
    return 0;
}

int _start(int param0, int param1) {
    int v0;
    char v1;
    void* ptr0;
    int v2;
    int v3 = 0;
    char v4 = 1;
    char v5 = 0;
    char v6 = 1;
    char v7 = 0;
    char v8 = 0;
    int v9 = v0;
    int* ptr1 = &v1;
    char v10 = &v0 ? 0: 1;
    char v11 = (int)&v0 < 0;
    char v12 = __parity__((unsigned char)&v0);
    char v13 = 0;
    char v14 = 0;
    int v15 = v2;
    int* ptr2 = &v15;
    int* ptr3 = &v15;
    int v16 = param1;
    int v17 = &__libc_csu_fini;
    int v18 = &__libc_csu_init;
    int* ptr4 = &v1;
    int v19 = &main;
    int* ptr5 = &ptr0;
    →__libc_start_main();
    hlt();
}

unsigned int check(int param0) {
    int v0;
    unsigned int result;
    unsigned int v1 = 0;
    unsigned int v2 = 0;
    while(1) {
        →strlen(param0);
        if(result <= v2) {
            break;
        }
        else {
            char v3 = *(char*)(v2 + param0);
            int* ptr0 = &v0;
            →sscanf(&v3, &gvar_8048668);
            v1 += v0;
            if(v1 == 16) {
                parell(param0);
            }
            ++v2;
        }
    }
    →printf("Password Incorrect!\n");
    return result;
}

int* finalizer_0() {
    return __do_global_dtors_aux();
}

unsigned char frame_dummy() {
    return 0;
}

int initializer_0(int param0, int param1) {
    sub_80483F4(param0, param1);
    frame_dummy();
    return __do_global_ctors_aux();
}

int main() {
    char v0;
    →printf("IOLI Crackme Level 0x05\n");
    →printf("Password: ");
    →scanf(&gvar_80486B2);
    check(&v0);
    return 0;
}

int parell(int param0) {
    int v0;
    →sscanf(param0, &gvar_8048668);
    if(!(v0 & 0x1)) {
        →printf("Password OK!\n");
        /*NO_RETURN*/ →exit(0);
    }
    return v0 & 0x1;
}

int sub_804835A() {
    return gvar_8049FFC();
}

int sub_80483F4(int param0, int param1) {
    void* ptr0 = __gmon_start__;
    if(ptr0) {
        ptr0();
    }
    return param1;
}

void →__libc_start_main() {
    while(1) {
        /*BAD_CALL!*/ __libc_start_main();
        unsigned int* ptr0 = ptr0 - 1;
        *ptr0 = 0;
        --ptr0;
        *ptr0 = gvar_8049FF8;
    }
}

void →exit(int __status) {
    while(1) {
        /*NO_RETURN*/ exit(__status);
        unsigned int* ptr0 = ptr0 - 1;
        *ptr0 = 40;
        --ptr0;
        *ptr0 = gvar_8049FF8;
    }
}

void →printf(int param0) {
    unsigned int* ptr0;
    while(1) {
        /*BAD_CALL!*/ printf(*(char**)(ptr0 + 1));
        --ptr0;
        *ptr0 = 24;
        --ptr0;
        *ptr0 = gvar_8049FF8;
    }
}

void →scanf(int param0) {
    unsigned int* ptr0;
    while(1) {
        /*BAD_CALL!*/ scanf(*(char**)(ptr0 + 1));
        --ptr0;
        *ptr0 = 8;
        --ptr0;
        *ptr0 = gvar_8049FF8;
    }
}

void →sscanf(int param0, int param1) {
    unsigned int* ptr0;
    while(1) {
        /*BAD_CALL!*/ sscanf(*(char**)(ptr0 + 1), *(char**)(ptr0 + 2));
        --ptr0;
        *ptr0 = 32;
        --ptr0;
        *ptr0 = gvar_8049FF8;
    }
}

void →strlen(int param0) {
    unsigned int* ptr0;
    while(1) {
        /*BAD_CALL!*/ strlen(*(char**)(ptr0 + 1));
        --ptr0;
        *ptr0 = 16;
        --ptr0;
        *ptr0 = gvar_8049FF8;
    }
}
