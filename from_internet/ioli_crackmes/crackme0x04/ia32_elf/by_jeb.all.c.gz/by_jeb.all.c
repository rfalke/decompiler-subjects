
int __do_global_ctors_aux() {
    int result;
    unsigned int* ptr0 = (unsigned int*)&__CTOR_LIST__;
    for(unsigned char i = *(int*)&__CTOR_LIST__; i != -1; i = *ptr0) {
        --ptr0;
        i();
    }
    return result;
}

int* __do_global_dtors_aux() {
    int* result;
    if(!completed.1) {
        while(1) {
            result = *(int*)&p.0;
            int v0 = *result;
            if(!v0) {
                break;
            }
            else {
                *(int*)&p.0 = result + 1;
                v0{__DTOR_END__}();
            }
        }
        completed.1 = 1;
    }
    return result;
}

void __i686.get_pc_thunk.bx() {
}

void __libc_csu_fini() {
}

int __libc_csu_init(int param0, int param1) {
    return initializer_0(param0, param1);
}

int _start(int param0, int param1) {
    →__libc_start_main();
    hlt();
}

int check(char* __s) {
    int v0;
    int v1 = 0;
    unsigned int min = 0;
    for(size_t i = →strlen(__s); i > min; i = →strlen(__s)) {
        char v2 = __s[min];
        →sscanf(&v2, (char*)&gvar_8048638, &v0);
        v1 += v0;
        if(v1 == 15) {
            →printf("Password OK!\n");
            /*NO_RETURN*/ →exit(0);
        }
        ++min;
    }
    return →printf("Password Incorrect!\n");
}

int* finalizer_0() {
    return __do_global_dtors_aux();
}

unsigned char frame_dummy() {
    return 0;
}

int initializer_0(int param0, int param1) {
    sub_80483F4(param0, param1);
    frame_dummy();
    return __do_global_ctors_aux();
}

int main() {
    char v0;
    →printf("IOLI Crackme Level 0x04\n");
    →printf("Password: ");
    →scanf((char*)&gvar_8048682, &v0);
    check(&v0);
    return 0;
}

int r→__libc_start_main() {
    /*BAD_CALL!*/ sub_8048354();
}

void r→exit(int __status) {
    /*BAD_CALL!*/ sub_8048354();
}

int r→printf(char* __format, ...) {
    /*BAD_CALL!*/ sub_8048354();
}

int r→scanf(char* __format, ...) {
    /*BAD_CALL!*/ sub_8048354();
}

int r→sscanf(char* __s, char* __format, ...) {
    /*BAD_CALL!*/ sub_8048354();
}

size_t r→strlen(char* __s) {
    /*BAD_CALL!*/ sub_8048354();
}

void sub_8048354() {
    jump gvar_8049FFC;
}

int sub_80483F4(int param0, int param1) {
    void* ptr0 = __gmon_start__;
    if(ptr0) {
        ptr0();
    }
    return param1;
}

int →__libc_start_main() {
    return ptr___libc_start_main{r→__libc_start_main}();
}

void →exit(int __status) {
    ptr_exit[0]{r→exit}(__status);
}

int →printf(char* __format, ...) {
    return ptr_printf[0]{r→printf}(__format);
}

int →scanf(char* __format, ...) {
    return ptr_scanf[0]{r→scanf}(__format);
}

int →sscanf(char* __s, char* __format, ...) {
    return ptr_sscanf[0]{r→sscanf}(__s, __format);
}

size_t →strlen(char* __s) {
    return ptr_strlen[0]{r→strlen}(__s);
}
