
void __libc_csu_fini() {
}

void* __libc_csu_init(long param0, long param1, long param2) {
    void* result;
    initializer_0();
    unsigned long v0 = 0L;
    do {
        result = (void*)*(long*)(v0 * 8L + (long)&__frame_dummy_init_array_entry){initializer_1}();
        ++v0;
    }
    while(v0 != 1L);
    return result;
}

void _dl_relocate_static_pie() {
}

long _start(long param0, long param1) {
    long v0;
    long v1;
    long v2;
    long v3;
    char v4;
    long v5 = 0L;
    char v6 = 1;
    char v7 = 0;
    char v8 = 1;
    char v9 = 0;
    char v10 = 0;
    long v11 = param1;
    long v12 = v0;
    long* ptr0 = &v4;
    char v13 = &v0 ? 0: 1;
    char v14 = (long)&v0 < 0L;
    char v15 = __parity__((unsigned char)&v0);
    char v16 = 0;
    char v17 = 0;
    long* ptr1 = &v1;
    long v18 = &__libc_csu_fini;
    long v19 = &__libc_csu_init;
    long v20 = &main;
    long* ptr2 = &v2;
    long v21 = __libc_start_main(&main, v12, (long)&v4, &__libc_csu_init, &__libc_csu_fini, v11, (long)&v1, v3);
    hlt();
}

long deregister_tm_clones() {
    return &__TMC_END__;
}

void finalizer_0() {
}

void finalizer_1() {
    char v0 = completed.0 ? 0: 1;
    char v1 = completed.0 >= 128;
    char v2 = __parity__(completed.0);
    char v3 = completed.0 < 0;
    char v4 = 0;
    char v5 = 0;
    jump v0 ? &sub_4011AD: &sub_4011C0;
}

void* initializer_0() {
    void* result = __gmon_start__;
    if(result) {
        result = (void*)result();
    }
    return result;
}

long initializer_1() {
    return register_tm_clones();
}

long main() {
    unsigned int v0 = 1;
    do {
        →printf((char*)&gvar_40201E);
    loc_401076:
        while(1) {
            ++v0;
            if(v0 == 1000000000) {
                return 0L;
            }
        loc_40109E:
            while(1) {
                if(v0 * 0xaaaaaaab <= 0x55555555) {
                    if((unsigned int)((unsigned int)(((unsigned long)v0 * 0xcccccccdL) >>> 34) * 5) != v0) {
                        →puts("Fizz");
                    }
                    else {
                        →puts("FizzBuzz");
                    }
                    continue loc_401076;
                }
            }
        }
    }
    while((unsigned int)((unsigned int)(((unsigned long)v0 * 0xcccccccdL) >>> 34) * 5) != v0);
    ++v0;
    →puts((char*)"Buzz");
    if(v0 != 1000000000) {
        goto loc_40109E;
    }
    else {
        return 0L;
    }
}

long register_tm_clones() {
    return 0L;
}

long sub_401026() {
    return gvar_404010();
}

long sub_40113D() {
    return 0L;
}

long sub_40117F() {
    return 0L;
}

long sub_4011AD() {
    long result = deregister_tm_clones();
    completed.0 = 1;
    return result;
}

void sub_4011C0() {
}

void →printf(char* __format) {
    while(1) {
        /*BAD_CALL!*/ printf(__format);
        unsigned long* ptr0 = ptr0 - 1;
        *ptr0 = 1L;
        --ptr0;
        *ptr0 = gvar_404008;
    }
}

void →puts(char* __s) {
    while(1) {
        /*BAD_CALL!*/ puts(__s);
        unsigned long* ptr0 = ptr0 - 1;
        *ptr0 = 0L;
        --ptr0;
        *ptr0 = gvar_404008;
    }
}
