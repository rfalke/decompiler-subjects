
void __libc_csu_fini() {
}

void* __libc_csu_init(long param0, long param1, long param2) {
    void* result;
    initializer_0();
    unsigned long v0 = 0L;
    do {
        result = (void*)*(long*)(v0 * 8L + (long)&__frame_dummy_init_array_entry){initializer_1}();
        ++v0;
    }
    while(v0 != 2L);
    return result;
}

void _dl_relocate_static_pie() {
}

long _start(long param0, long param1) {
    long v0;
    long v1;
    long v2;
    long v3;
    char v4;
    long v5 = 0L;
    char v6 = 1;
    char v7 = 0;
    char v8 = 1;
    char v9 = 0;
    char v10 = 0;
    long v11 = param1;
    long v12 = v0;
    long* ptr0 = &v4;
    char v13 = &v0 ? 0: 1;
    char v14 = (long)&v0 < 0L;
    char v15 = __parity__((unsigned char)&v0);
    char v16 = 0;
    char v17 = 0;
    long* ptr1 = &v1;
    long v18 = &__libc_csu_fini;
    long v19 = &__libc_csu_init;
    long v20 = &main;
    long* ptr2 = &v2;
    long v21 = __libc_start_main(&main, v12, (long)&v4, &__libc_csu_init, &__libc_csu_fini, v11, (long)&v1, v3);
    hlt();
}

long deregister_tm_clones() {
    return &__TMC_END__;
}

void finalizer_0() {
}

void finalizer_1() {
    char v0 = completed.0 ? 0: 1;
    char v1 = completed.0 >= 128;
    char v2 = __parity__(completed.0);
    char v3 = completed.0 < 0;
    char v4 = 0;
    char v5 = 0;
    jump v0 ? &sub_402C8D: &sub_402CA0;
}

void* initializer_0() {
    void* result = __gmon_start__;
    if(result) {
        result = (void*)result();
    }
    return result;
}

long initializer_1() {
    return register_tm_clones();
}

long initializer_2() {
    long result;
    →std::ios_base::Init::Init();
    →__cxa_atexit();
    return result;
}

void* main() {
    size_t v0;
    void* __s;
    char v1;
    char v2;
    char v3;
    char v4;
    int v5;
    unsigned int v6;
    long* ptr0;
    long* ptr1;
    long* ptr2;
    long* ptr3;
    long* ptr4;
    char v7;
    long* ptr5;
    long* ptr6;
    size_t __n;
    void* ptr7;
    int v8;
    unsigned int v9;
    unsigned int v10;
    void* ptr8;
    void* ptr9;
    int v11;
    int v12;
    char v13;
    char v14;
    char v15;
    char v16;
    __int128 v17;
    void* ptr10;
    char v18;
    size_t v19;
    long v20;
    char v21;
    char v22;
    void* ptr11;
    long* ptr12;
    char v23;
    void* ptr13;
    char v24;
    void* ptr14;
    int v25;
    size_t v26;
    int v27;
    size_t v28;
    __int128 v29;
    void* ptr15;
    char v30;
    int v31;
    int v32;
    char v33;
    size_t v34;
    char v35;
    void* ptr16;
    __int128 v36;
    char v37;
    unsigned int v38;
    __int128 v39;
    __int128 v40;
    void* ptr17;
    long v41 = v20;
    void* ptr18 = ptr11;
    long v42 = 1000L;
    long* ptr19 = ptr12;
    void* ptr20 = ptr13;
    long v43 = 0x8888888888888889L;
    size_t v44 = v28;
    unsigned int v45 = 4;
    int v46 = 0;
    long* ptr21 = &v44;
    char v47 = &ptr9 == 168L;
    char v48 = (long)&v34 < 0L;
    char v49 = __parity__((unsigned char)&ptr9 - 168);
    char v50 = (long*)((long)(long*)((long)(long*)((long)(long*)((long)&v44 ^ 0x78L) ^ (long)&v34) >>> 4L) & 0x1L);
    char v51 = (unsigned long)&v44 < 120L;
    char v52 = (long)(long*)((long)(long*)((long)&v44 ^ (long)&v34) & (long)(long*)((long)&v44 ^ 0x78L)) < 0L;
    →get_nprocs();
    unsigned int v53 = v38;
    void* ptr22 = (void*)v11;
    do {
        long v54 = v42;
        long v55 = &gvar_405094;
        long v56 = 0L;
        long v57 = 0L;
        long v58 = 0L;
        char v59 = 1;
        char v60 = 0;
        char v61 = 1;
        char v62 = 0;
        char v63 = 0;
        ptr8 = (void*)(v42 * 3L);
        →snprintf(NULL, 0L, (char*)&gvar_405094);
        long v64 = (long)v12;
        long v65 = v64 * 8L + 39L;
        long v66 = v64 * 8L + 39L;
        long v67 = v64 * 8L + 39L;
        long* ptr23 = (long*)(v66 * (long)ptr8);
        long* ptr24 = (long*)(v66 * (long)ptr8);
        long* ptr25 = (long*)((long)ptr23 * 0x8888888888888889L);
        long v68 = (unsigned long)(((unsigned __int128)ptr24 * 0x8888888888888889X) >>> 0x40X);
        char v69 = v68 ? 1: 0;
        char v70 = v68 ? 1: 0;
        long v71 = v68;
        long v72 = 0L;
        char v73 = 1;
        char v74 = 0;
        char v75 = 1;
        char v76 = 0;
        char v77 = 0;
        long v78 = v71;
        unsigned long v79 = (unsigned long)(v71 >>> 3);
        char v80 = (v78 >>> 2L) & 0x1L;
        char v81 = 0;
        char v82 = v79 ? 0: 1;
        char v83 = v79 >= 0x8000000000000000L;
        char v84 = __parity__((unsigned char)v79);
        long* ptr26 = (long*)(v79 % (long)(unsigned long)ptr22);
        long* ptr27 = (long*)(v79 / (long)(unsigned long)ptr22);
        long* ptr28 = ptr26;
        char v85 = ptr27 == 0x10000L;
        char v86 = (long)ptr27 < 0x10000L;
        char v87 = __parity__((unsigned char)ptr27);
        char v88 = (unsigned long)ptr27 < 0x10000L;
        char v89 = (long)(long*)((long)(long*)((long)(ptr27 - 0x2000) ^ (long)ptr27) & (long)(long*)((long)ptr27 ^ 0x10000L)) < 0L;
        char v90 = (long*)((long)(long*)((long)(long*)((long)(ptr27 - 0x2000) ^ (long)(long*)((long)ptr27 ^ 0x10000L)) >>> 4L) & 0x1L);
        if(!v88 && !v85) {
            goto loc_4022D6;
        }
        else {
            void* ptr29 = ptr8;
            ptr8 = (void*)((long)ptr8 * 2L);
            char v91 = ptr8 ? 0: 1;
            char v92 = (long)ptr8 < 0L;
            char v93 = __parity__((unsigned char)ptr8);
            char v94 = (long*)((long)(long*)((long)ptr8 >>> 4L) & 0x1L);
            char v95 = (void*)__carry__((long)ptr29, (long)ptr29);
            char v96 = (long)(long*)((long)ptr8 ^ (long)ptr29) < 0L;
            long v97 = v65;
            long v98 = v65;
            long* ptr30 = (long*)(v97 * (long)ptr8);
            long* ptr31 = (long*)(v97 * (long)ptr8);
            long* ptr32 = (long*)((long)ptr30 * 0x8888888888888889L);
            long v99 = (unsigned long)(((unsigned __int128)ptr31 * 0x8888888888888889X) >>> 0x40X);
            char v100 = v99 ? 1: 0;
            char v101 = v99 ? 1: 0;
            long v102 = v99;
            long v103 = 0L;
            char v104 = 1;
            char v105 = 0;
            char v106 = 1;
            char v107 = 0;
            char v108 = 0;
            long v109 = v102;
            unsigned long v110 = (unsigned long)(v102 >>> 3);
            char v111 = (v109 >>> 2L) & 0x1L;
            char v112 = 0;
            char v113 = v110 ? 0: 1;
            char v114 = v110 >= 0x8000000000000000L;
            char v115 = __parity__((unsigned char)v110);
            long* ptr33 = (long*)(v110 % (long)(unsigned long)ptr22);
            long* ptr34 = (long*)(v110 / (long)(unsigned long)ptr22);
            long* ptr35 = ptr33;
            char v116 = ptr34 == 0x10000L;
            char v117 = (long)ptr34 < 0x10000L;
            char v118 = __parity__((unsigned char)ptr34);
            char v119 = (unsigned long)ptr34 < 0x10000L;
            char v120 = (long)(long*)((long)(long*)((long)(ptr34 - 0x2000) ^ (long)ptr34) & (long)(long*)((long)ptr34 ^ 0x10000L)) < 0L;
            char v121 = (long*)((long)(long*)((long)(long*)((long)(ptr34 - 0x2000) ^ (long)(long*)((long)ptr34 ^ 0x10000L)) >>> 4L) & 0x1L);
            if(!v119 && !v116) {
                goto loc_4022D6;
            }
            else {
                ptr8 = (void*)(v42 * 9L);
                long v122 = v65;
                long* ptr36 = (long*)(v65 * (long)ptr8);
                char v123 = (__int128)ptr8 * (__int128)v122 != (__int128)ptr36;
                char v124 = (__int128)ptr8 * (__int128)v122 != (__int128)ptr36;
                long* ptr37 = ptr36;
                long* ptr38 = ptr36;
                long* ptr39 = (long*)((long)ptr37 * 0x8888888888888889L);
                long v125 = (unsigned long)(((unsigned __int128)ptr38 * 0x8888888888888889X) >>> 0x40X);
                char v126 = v125 ? 1: 0;
                char v127 = v125 ? 1: 0;
                long v128 = v125;
                long v129 = 0L;
                char v130 = 1;
                char v131 = 0;
                char v132 = 1;
                char v133 = 0;
                char v134 = 0;
                long v135 = v128;
                unsigned long v136 = (unsigned long)(v128 >>> 3);
                char v137 = (v135 >>> 2L) & 0x1L;
                char v138 = 0;
                char v139 = v136 ? 0: 1;
                char v140 = v136 >= 0x8000000000000000L;
                char v141 = __parity__((unsigned char)v136);
                long* ptr40 = (long*)(v136 % (long)(unsigned long)ptr22);
                long* ptr41 = (long*)(v136 / (long)(unsigned long)ptr22);
                long* ptr42 = ptr40;
                char v142 = ptr41 == 0x10000L;
                char v143 = (long)ptr41 < 0x10000L;
                char v144 = __parity__((unsigned char)ptr41);
                char v145 = (unsigned long)ptr41 < 0x10000L;
                char v146 = (long)(long*)((long)(long*)((long)(ptr41 - 0x2000) ^ (long)ptr41) & (long)(long*)((long)ptr41 ^ 0x10000L)) < 0L;
                char v147 = (long*)((long)(long*)((long)(long*)((long)(ptr41 - 0x2000) ^ (long)(long*)((long)ptr41 ^ 0x10000L)) >>> 4L) & 0x1L);
                if(!v145 && !v142) {
                    goto loc_4022D6;
                }
                else {
                    long v148 = v42 * 5L;
                    long v149 = v42 * 5L;
                    v42 = v148 * 2L;
                    char v150 = v42 ? 0: 1;
                    char v151 = v42 < 0L;
                    char v152 = __parity__((unsigned char)v42);
                    char v153 = (v42 >>> 4L) & 0x1L;
                    char v154 = __carry__(v149, v149);
                    char v155 = (v42 ^ v149) < 0L;
                    v10 = v45;
                    --v45;
                    v46 = 0;
                    v24 = v45 ? 0: 1;
                    char v156 = v45 >= 0x80000000;
                    char v157 = __parity__((unsigned char)v45);
                    char v158 = ((~v45 ^ ~v10) >>> 4) & 0x1;
                    char v159 = (int)((v45 ^ v10) & v10) < 0;
                }
            }
        }
    }
    while(!v24);
    ptr8 = (void*)0x895440;
loc_4022D6:
    void* ptr43 = &v22;
    void* ptr44 = ptr8;
    void* ptr45 = std::__cxx11::to_string(&v22, ptr44);
    size_t v160 = v19;
    void* ptr46 = *(void**)&v22;
    v34 = v160;
    void* ptr47 = &v18;
    char v161 = ptr46 == &v18;
    char v162 = (long)ptr46 < (long)&v18;
    char v163 = __parity__((unsigned char)ptr46 - (unsigned char)&v18);
    char v164 = ptr46 < &v18;
    char v165 = (long)(long*)((long)(long*)((long)(long*)((long)ptr46 - (long)&v18) ^ (long)ptr46) & (long)(long*)((long)ptr46 ^ (long)&v18)) < 0L;
    char v166 = (long*)((long)(long*)((long)(long*)((long)(long*)((long)ptr46 - (long)&v18) ^ (long)(long*)((long)ptr46 ^ (long)&v18)) >>> 4L) & 0x1L);
    if(!v161) {
        long v167 = *(long*)&v18;
        long v168 = v167 + 1L;
        →operator delete();
    }
    long* ptr48 = (long*)0x1;
    void* ptr49 = (void*)0x346DC5D63886594B;
    unsigned int v169 = 1;
    int v170 = 0;
    long v171 = 1L;
    char v172 = 0;
    char v173 = 1;
    char v174 = 0;
    char v175 = 1;
    char v176 = 0;
    char v177 = 1;
    do {
        void* ptr50 = &v18;
        v9 = 0;
        v8 = 0;
        char v178 = 1;
        char v179 = 0;
        char v180 = 1;
        char v181 = 0;
        char v182 = 0;
        *(void**)&v22 = &v18;
    loc_4025DA:
        do {
            ptr7 = *(void**)&v22;
            v18 = 45;
            __n = 1L;
        loc_4023C4:
            while(1) {
                v19 = __n;
                *(char*)((long)ptr7 + __n) = 0;
                size_t v183 = *(size_t*)&v22;
                char v184 = ptr48 == 99L;
                char v185 = (long)ptr48 < 99L;
                char v186 = __parity__((unsigned char)ptr48 - 99);
                char v187 = (unsigned long)ptr48 < 99L;
                char v188 = (long)(long*)((long)(long*)((long)(long*)((char*)ptr48 - 99L) ^ (long)ptr48) & (long)(long*)((long)ptr48 ^ 0x63L)) < 0L;
                char v189 = (long*)((long)(long*)((long)(long*)((long)(long*)((char*)ptr48 - 99L) ^ (long)(long*)((long)ptr48 ^ 0x63L)) >>> 4L) & 0x1L);
                if(!v187 && !v184) {
                    do {
                        long v190 = (unsigned long)v169;
                        unsigned int v191 = v169;
                        int v192 = 0;
                        long v193 = v190;
                        long v194 = v190 * 1374389535L;
                        char v195 = (__int128)v193 * 0x51EB851FX != (__int128)v194;
                        char v196 = (__int128)v193 * 0x51EB851FX != (__int128)v194;
                        long v197 = v194;
                        long v198 = v194 >>> 37;
                        char v199 = (v197 >>> 36L) & 0x1L;
                        char v200 = v196;
                        char v201 = v198 ? 0: 1;
                        char v202 = v198 < 0L;
                        char v203 = __parity__((unsigned char)v198);
                        int v204 = (unsigned int)ptr46;
                        unsigned int v205 = (unsigned int)((unsigned int)v198 * 100);
                        int v206 = 0;
                        unsigned int v207 = v191;
                        unsigned int v208 = v191 - v205;
                        int v209 = 0;
                        char v210 = v191 == v205;
                        char v211 = v208 >= 0x80000000;
                        char v212 = __parity__((unsigned char)v208);
                        char v213 = (((v205 ^ v207) ^ v208) >>> 4) & 0x1;
                        char v214 = v205 > v207;
                        char v215 = (int)((v208 ^ v207) & (v205 ^ v207)) < 0;
                        ptr46 = (void*)v169;
                        v169 = (unsigned int)v198;
                        v170 = 0;
                        long v216 = (unsigned long)v9;
                        unsigned int v217 = v208;
                        long v218 = (unsigned long)(v208 * 2);
                        char v219 = v208 * 2 ? 0: 1;
                        char v220 = (v218 >>> 31L) & 0x1L;
                        char v221 = __parity__((unsigned char)v218);
                        char v222 = ((((unsigned int)v218 ^ v217) ^ (unsigned int)v218) >>> 4) & 0x1;
                        char v223 = __carry__((unsigned int)v218, v217);
                        char v224 = (((unsigned int)v218 ^ v217) & ~((unsigned int)v218 ^ v217)) < 0;
                        long v225 = (unsigned long)((unsigned int)v218 + 1);
                        unsigned char v226 = *(unsigned char*)((long)&void std::__detail::__to_chars_10_impl<unsigned int>(char*, unsigned int, unsigned int)::__digits + v218);
                        long v227 = 0L;
                        long v228 = (unsigned long)*(unsigned char*)((long)&void std::__detail::__to_chars_10_impl<unsigned int>(char*, unsigned int, unsigned int)::__digits + v225);
                        *(unsigned char*)(v216 + v183) = *(unsigned char*)((long)&void std::__detail::__to_chars_10_impl<unsigned int>(char*, unsigned int, unsigned int)::__digits + v225);
                        long v229 = (unsigned long)(v9 - 1);
                        v10 = v9;
                        v9 -= 2;
                        v8 = 0;
                        char v230 = v9 ? 0: 1;
                        char v231 = v9 >= 0x80000000;
                        char v232 = __parity__((unsigned char)v9);
                        char v233 = (((v10 ^ 0x2) ^ v9) >>> 4) & 0x1;
                        char v234 = v10 < 2;
                        char v235 = (int)((v9 ^ v10) & (v10 ^ 0x2)) < 0;
                        *(unsigned char*)(v229 + v183) = v226;
                        v184 = (unsigned int)ptr46 == 9999;
                        v185 = (unsigned int)ptr46 < 9999;
                        v186 = __parity__((unsigned char)ptr46 - 15);
                        v35 = (unsigned int)ptr46 < 9999;
                        char v236 = ((((unsigned int)ptr46 - 9999) ^ (unsigned int)ptr46) & ((unsigned int)ptr46 ^ 0x270f)) < 0;
                        char v237 = ((((unsigned int)ptr46 - 9999) ^ ((unsigned int)ptr46 ^ 0x270f)) >>> 4) & 0x1;
                    }
                    while(!v35 && !v184);
                }
                long v238 = (unsigned long)(v169 + 48);
                char v239 = v169 == 9;
                char v240 = (int)v169 < 9;
                char v241 = __parity__((unsigned char)v169 - 9);
                char v242 = v169 < 9;
                char v243 = (((v169 - 9) ^ v169) & (v169 ^ 0x9)) < 0;
                char v244 = (((v169 - 9) ^ (v169 ^ 0x9)) >>> 4) & 0x1;
                if(!v242 && !v239) {
                    v10 = v169;
                    long v245 = (unsigned long)(v169 * 2);
                    char v246 = v169 * 2 ? 0: 1;
                    char v247 = (v245 >>> 31L) & 0x1L;
                    char v248 = __parity__((unsigned char)v245);
                    char v249 = ((((unsigned int)v245 ^ v10) ^ (unsigned int)v245) >>> 4) & 0x1;
                    char v250 = __carry__((unsigned int)v245, v10);
                    char v251 = (((unsigned int)v245 ^ v10) & ~((unsigned int)v245 ^ v10)) < 0;
                    long v252 = (unsigned long)((unsigned int)v245 + 1);
                    long v253 = (unsigned long)*(unsigned char*)((long)&void std::__detail::__to_chars_10_impl<unsigned int>(char*, unsigned int, unsigned int)::__digits + v252);
                    *(unsigned char*)(v183 + 1L) = *(unsigned char*)((long)&void std::__detail::__to_chars_10_impl<unsigned int>(char*, unsigned int, unsigned int)::__digits + v252);
                    v238 = (unsigned long)*(unsigned char*)((long)&void std::__detail::__to_chars_10_impl<unsigned int>(char*, unsigned int, unsigned int)::__digits + v245);
                }
                *(char*)v183 = (unsigned char)v238;
                unsigned long v254 = *(unsigned long*)&v22;
                void* ptr51 = &v18;
                size_t v255 = v19;
                char v256 = v254 == &v18;
                char v257 = (long)v254 < (long)&v18;
                char v258 = __parity__((unsigned char)v254 - (unsigned char)&v18);
                char v259 = v254 < (unsigned long)&v18;
                char v260 = (long)(long*)((long)(long*)((long)(long*)(v254 - (long)&v18) ^ v254) & (long)(long*)(v254 ^ (long)&v18)) < 0L;
                char v261 = (long*)((long)(long*)((long)(long*)((long)(long*)(v254 - (long)&v18) ^ (long)(long*)(v254 ^ (long)&v18)) >>> 4L) & 0x1L);
                if(!v256) {
                    long v262 = *(long*)&v18;
                    v183 = (size_t)(v262 + 1L);
                    →operator delete();
                }
                char v263 = v255 == v34;
                char v264 = (long)v255 > (long)v34;
                char v265 = __parity__((unsigned char)v34 - (unsigned char)v255);
                char v266 = v255 > v34;
                char v267 = (long)(((unsigned long)(v34 - v255) ^ v34) & (unsigned long)(v255 ^ v34)) < 0L;
                char v268 = (((unsigned long)(v34 - v255) ^ (unsigned long)(v255 ^ v34)) >>> 4L) & 0x1L;
                if(v266) {
                    long v269 = &std::cout;
                    →std::ostream::flush();
                    void* ptr52 = ptr22;
                    vpxor(v39, v39, v39);
                    void* ptr53 = NULL;
                    void* ptr54 = ptr52;
                    long* ptr55 = (long*)((long)ptr52 >>> 60);
                    char v270 = (long*)((long)(long*)((long)ptr54 >>> 59L) & 0x1L);
                    char v271 = v267;
                    char v272 = ptr55 ? 0: 1;
                    char v273 = (long)ptr55 < 0L;
                    char v274 = __parity__((unsigned char)ptr55);
                    vmovdqa(*(__int128*)&v26, v39);
                    if(!v272) {
                        long v275 = "vector::reserve";
                        →std::__throw_length_error();
                    loc_402B8F:
                        /*NO_RETURN*/ →std::terminate();
                    }
                    char v276 = ptr22 ? 0: 1;
                    char v277 = (long)ptr22 < 0L;
                    char v278 = __parity__((unsigned char)ptr22);
                    char v279 = 0;
                    char v280 = 0;
                    if(!v276) {
                        ptr48 = (long*)((long)ptr22 * 8L);
                        long* ptr56 = (long*)((long)ptr22 * 8L);
                        →operator new();
                        void* ptr57 = ptr14;
                        size_t v281 = v26;
                        vmovq(v36, ptr17);
                        void* ptr58 = ptr17;
                        vpunpcklqdq(v39, v36, v36);
                        char v282 = ptr57 == v281;
                        char v283 = (long)ptr57 < (long)v281;
                        char v284 = __parity__((unsigned char)ptr57 - (unsigned char)v281);
                        char v285 = (unsigned long)ptr57 < v281;
                        char v286 = (long)(long*)((long)(long*)((long)(long*)((long)ptr57 - v281) ^ (long)ptr57) & (long)(long*)((long)ptr57 ^ v281)) < 0L;
                        char v287 = (long*)((long)(long*)((long)(long*)((long)(long*)((long)ptr57 - v281) ^ (long)(long*)((long)ptr57 ^ v281)) >>> 4L) & 0x1L);
                        if(!v282) {
                            long* ptr59 = (long*)((long)ptr57 - 8L);
                            unsigned long v288 = (unsigned long)(v281 + 8L);
                            long* ptr60 = (long*)((long)ptr59 - v281);
                            char v289 = v288 == ptr58;
                            char v290 = (long)v288 > (long)ptr58;
                            char v291 = __parity__((unsigned char)ptr58 - (unsigned char)v288);
                            char v292 = v288 > (unsigned long)ptr58;
                            char v293 = (long)(long*)((long)(long*)((long)(long*)((long)ptr58 - v288) ^ (long)ptr58) & (long)(long*)(v288 ^ (long)ptr58)) < 0L;
                            char v294 = (long*)((long)(long*)((long)(long*)((long)(long*)((long)ptr58 - v288) ^ (long)(long*)(v288 ^ (long)ptr58)) >>> 4L) & 0x1L);
                            if(v289) {
                            loc_402B2B:
                                size_t v295 = v281;
                                void* ptr61 = ptr58;
                                do {
                                    v183 = *(size_t*)v295;
                                    v295 += 8L;
                                    ptr54 = ptr61;
                                    ptr61 = (void*)((long)ptr61 + 8L);
                                    char v296 = ptr61 ? 0: 1;
                                    char v297 = (long)ptr61 < 0L;
                                    char v298 = __parity__((unsigned char)ptr61);
                                    char v299 = (long*)((long)(long*)((long)(long*)((long)(long*)((long)ptr54 ^ 0x8L) ^ (long)ptr61) >>> 4L) & 0x1L);
                                    char v300 = (unsigned long)ptr54 >= 18446744073709551608L;
                                    char v301 = (long)(long*)((long)(long*)((long)ptr61 ^ (long)ptr54) & (long*)~(long)(long*)((long)ptr54 ^ 0x8L)) < 0L;
                                    *(size_t*)((long)ptr61 - 8L) = v183;
                                    v21 = v295 == ptr57;
                                    char v302 = (long)v295 > (long)ptr57;
                                    char v303 = __parity__((unsigned char)ptr57 - (unsigned char)v295);
                                    char v304 = v295 > (unsigned long)ptr57;
                                    char v305 = (long)(long*)((long)(long*)((long)(long*)((long)ptr57 - v295) ^ (long)ptr57) & (long)(long*)(v295 ^ (long)ptr57)) < 0L;
                                    char v306 = (long*)((long)(long*)((long)(long*)((long)(long*)((long)ptr57 - v295) ^ (long)(long*)(v295 ^ (long)ptr57)) >>> 4L) & 0x1L);
                                }
                                while(!v21);
                                goto loc_4026C4;
                            }
                            else {
                                char v307 = ptr60 == 16L;
                                char v308 = (long)ptr60 < 16L;
                                char v309 = __parity__((unsigned char)ptr60 - 16);
                                char v310 = (unsigned long)ptr60 < 16L;
                                char v311 = (long)(long*)((long)(long*)((long)(ptr60 - 2) ^ (long)ptr60) & (long)(long*)((long)ptr60 ^ 0x10L)) < 0L;
                                char v312 = (long*)((long)(long*)((long)(long*)((long)(ptr60 - 2) ^ (long)(long*)((long)ptr60 ^ 0x10L)) >>> 4L) & 0x1L);
                                if(v310 || v307) {
                                    goto loc_402B2B;
                                }
                                else {
                                    long* ptr62 = ptr60;
                                    long* ptr63 = (long*)((long)ptr60 >>> 3);
                                    char v313 = (long*)((long)(long*)((long)ptr62 >>> 2L) & 0x1L);
                                    char v314 = v311;
                                    char v315 = ptr63 ? 0: 1;
                                    char v316 = (long)ptr63 < 0L;
                                    char v317 = __parity__((unsigned char)ptr63);
                                    unsigned long v318 = 0L;
                                    char v319 = 1;
                                    char v320 = 0;
                                    char v321 = 1;
                                    char v322 = 0;
                                    char v323 = 0;
                                    long* ptr64 = ptr63;
                                    long* ptr65 = (long*)((char*)ptr63 + 1L);
                                    char v324 = ptr65 ? 0: 1;
                                    char v325 = (long)ptr65 < 0L;
                                    char v326 = __parity__((unsigned char)ptr65);
                                    char v327 = (long*)((long)(long*)((long)(long*)((long)(long*)((long)ptr64 ^ 0x1L) ^ (long)ptr65) >>> 4L) & 0x1L);
                                    char v328 = (long)(long*)((long)(long*)((long)ptr65 ^ (long)ptr64) & (long*)~(long)(long*)((long)ptr64 ^ 0x1L)) < 0L;
                                    long* ptr66 = ptr65;
                                    long* ptr67 = ptr65;
                                    long* ptr68 = (long*)((long)ptr66 >>> 1);
                                    char v329 = (long*)((long)ptr67 & 0x1L);
                                    char v330 = (long)ptr67 < 0L;
                                    char v331 = ptr68 ? 0: 1;
                                    char v332 = (long)ptr68 < 0L;
                                    char v333 = __parity__((unsigned char)ptr68);
                                    long* ptr69 = ptr68;
                                    long* ptr70 = (long*)((long)ptr68 * 16L);
                                    char v334 = (long*)((long)(long*)((long)ptr69 >>> 60L) & 0x1L);
                                    char v335 = v330;
                                    char v336 = ptr70 ? 0: 1;
                                    char v337 = (long)ptr70 < 0L;
                                    char v338 = __parity__((unsigned char)ptr70);
                                    do {
                                        vmovdqu(v17, *(__int128*)(v318 + v281));
                                        vmovdqu(*(__int128*)(v318 + (long)ptr58), v17);
                                        v318 += 16L;
                                        v16 = v318 == ptr70;
                                        char v339 = (long)v318 < (long)ptr70;
                                        char v340 = __parity__((unsigned char)v318 - (unsigned char)ptr70);
                                        char v341 = v318 < (unsigned long)ptr70;
                                        char v342 = (long)(long*)((long)(long*)((long)(long*)(v318 - (long)ptr70) ^ v318) & (long)(long*)(v318 ^ (long)ptr70)) < 0L;
                                        char v343 = (long*)((long)(long*)((long)(long*)((long)(long*)(v318 - (long)ptr70) ^ (long)(long*)(v318 ^ (long)ptr70)) >>> 4L) & 0x1L);
                                    }
                                    while(!v16);
                                    long* ptr71 = ptr65;
                                    long* ptr72 = (long*)((long)ptr71 & 0xfffffffffffffffeL);
                                    char v344 = ptr72 ? 0: 1;
                                    char v345 = (long)ptr72 < 0L;
                                    char v346 = __parity__((unsigned char)ptr72);
                                    char v347 = 0;
                                    char v348 = 0;
                                    long* ptr73 = (long*)((long)ptr72 * 8L);
                                    ptr6 = (long*)((long)ptr73 + (long)ptr58);
                                    ptr5 = (long*)((long)ptr73 + v281);
                                    v7 = ptr65 == ptr72;
                                    char v349 = (long)ptr65 > (long)ptr72;
                                    char v350 = __parity__((unsigned char)ptr72 - (unsigned char)ptr65);
                                    char v351 = ptr65 > ptr72;
                                    char v352 = (long)(long*)((long)(long*)((long)(long*)((long)ptr72 - (long)ptr65) ^ (long)ptr72) & (long)(long*)((long)ptr65 ^ (long)ptr72)) < 0L;
                                    char v353 = (long*)((long)(long*)((long)(long*)((long)(long*)((long)ptr72 - (long)ptr65) ^ (long)(long*)((long)ptr65 ^ (long)ptr72)) >>> 4L) & 0x1L);
                                }
                            }
                            if(!v7) {
                                long v354 = *ptr5;
                                *ptr6 = *ptr5;
                            }
                            goto loc_4026C4;
                        }
                        else {
                            char v355 = v281 ? 0: 1;
                            char v356 = v281 >= 0x8000000000000000L;
                            char v357 = __parity__((unsigned char)v281);
                            char v358 = 0;
                            char v359 = 0;
                            if(!v355) {
                            loc_4026C4:
                                void* ptr74 = ptr53;
                                vmovdqa(*(__int128*)&v34, v39);
                                ptr54 = ptr74;
                                v183 = (size_t)((long)ptr74 - v281);
                                char v360 = v183 ? 0: 1;
                                char v361 = v183 >= 0x8000000000000000L;
                                char v362 = __parity__((unsigned char)v183);
                                char v363 = (long*)((long)(long*)((long)(long*)((long)(long*)(v281 ^ (long)ptr54) ^ v183) >>> 4L) & 0x1L);
                                char v364 = v281 > (unsigned long)ptr54;
                                char v365 = (long)(long*)((long)(long*)(v183 ^ (long)ptr54) & (long)(long*)(v281 ^ (long)ptr54)) < 0L;
                                →operator delete();
                                vmovdqa(v39, *(__int128*)&v34);
                            }
                        }
                        void* ptr75 = (void*)((long)ptr58 + (long)ptr48);
                        char v366 = v53 ? 0: 1;
                        char v367 = v53 >= 0x80000000;
                        char v368 = __parity__((unsigned char)v53);
                        char v369 = v53 < 0;
                        char v370 = 0;
                        char v371 = 0;
                        vmovdqa(*(__int128*)&v26, v39);
                        ptr53 = ptr75;
                        if(!v366 && v367 == 0) {
                            size_t v372 = (size_t)(unsigned int)v171;
                            long* ptr76 = NULL;
                            ptr48 = NULL;
                            char v373 = 1;
                            char v374 = 0;
                            char v375 = 1;
                            char v376 = 0;
                            char v377 = 0;
                            v0 = v372;
                        loc_402727:
                            do {
                                long* ptr77 = ptr76;
                                long v378 = 0L;
                                ptr76 = (long*)((long)ptr76 + (long)ptr8);
                                long* ptr78 = (long*)((long)(unsigned long)ptr77 % (long)(unsigned long)ptr22);
                                void* ptr79 = (void*)((long)(unsigned long)ptr77 / (long)(unsigned long)ptr22);
                                long* ptr80 = ptr78;
                                long v379 = 0L;
                                char v380 = 1;
                                char v381 = 0;
                                char v382 = 1;
                                char v383 = 0;
                                char v384 = 0;
                                long v385 = 192L;
                                v10 = (unsigned int)ptr48;
                                ptr48 = (long*)((unsigned int)ptr48 + 1);
                                char v386 = (unsigned int)ptr48 ? 0: 1;
                                char v387 = (long*)((long)(long*)((long)ptr48 >>> 31L) & 0x1L);
                                char v388 = __parity__((unsigned char)ptr48);
                                char v389 = (((v10 ^ 0x1) ^ (unsigned int)ptr48) >>> 4) & 0x1;
                                char v390 = (((unsigned int)ptr48 ^ v10) & ~(v10 ^ 0x1)) < 0;
                                void* ptr81 = ptr79;
                                long* ptr82 = ptr76;
                                long* ptr83 = (long*)((long)(unsigned long)ptr82 % (long)(unsigned long)ptr22);
                                long* ptr84 = (long*)((long)(unsigned long)ptr82 / (long)(unsigned long)ptr22);
                                long* ptr85 = ptr83;
                                size_t v391 = (size_t)((long)ptr84 - (long)ptr81);
                                ptr54 = ptr81;
                                v171 = (long)((long)ptr81 + v0);
                                char v392 = v171 ? 0: 1;
                                char v393 = v171 < 0L;
                                char v394 = __parity__((unsigned char)v171);
                                char v395 = (long*)((long)(long*)((long)(long*)((long)(long*)((long)ptr54 ^ v0) ^ v171) >>> 4L) & 0x1L);
                                char v396 = (void*)__carry__((long)ptr54, v0);
                                char v397 = (long)(long*)((long)(long*)(v171 ^ (long)ptr54) & (long*)~(long)(long*)((long)ptr54 ^ v0)) < 0L;
                                v34 = v391;
                                →operator new();
                                size_t __n1 = v34;
                                void* ptr86 = ptr8;
                                ptr49 = ptr17;
                                void* ptr87 = ptr17;
                                long v398 = v171;
                                void* ptr88 = worker::worker(ptr87, v398, __n1, ptr86, ptr10);
                                void* ptr89 = ptr14;
                                *(void**)&v22 = ptr49;
                                char v399 = ptr89 == ptr53;
                                char v400 = (long)ptr89 < (long)ptr53;
                                char v401 = __parity__((unsigned char)ptr89 - (unsigned char)ptr53);
                                char v402 = ptr89 < ptr53;
                                char v403 = (long)(long*)((long)(long*)((long)(long*)((long)ptr89 - (long)ptr53) ^ (long)ptr89) & (long)(long*)((long)ptr89 ^ (long)ptr53)) < 0L;
                                char v404 = (long*)((long)(long*)((long)(long*)((long)(long*)((long)ptr89 - (long)ptr53) ^ (long)(long*)((long)ptr89 ^ (long)ptr53)) >>> 4L) & 0x1L);
                                if(v399) {
                                    void* ptr90 = &v22;
                                    void* ptr91 = &v26;
                                    unsigned long* ptr92 = std::vector<std::unique_ptr<worker, std::default_delete<worker> >, std::allocator<std::unique_ptr<worker, std::default_delete<worker> > > >::_M_realloc_insert<std::unique_ptr<worker, std::default_delete<worker> > >(&v26, ptr89, &v22);
                                    ptr49 = *(void**)&v22;
                                    char v405 = ptr49 ? 0: 1;
                                    char v406 = (long)ptr49 < 0L;
                                    char v407 = __parity__((unsigned char)ptr49);
                                    char v408 = 0;
                                    char v409 = 0;
                                    if(v405) {
                                        goto loc_40271C;
                                    }
                                    else {
                                        long* ptr93 = (long*)((long)ptr49 + 104L);
                                        →std::condition_variable::~condition_variable();
                                        unsigned long v410 = *(unsigned long*)((long)ptr49 + 32L);
                                        char v411 = v410 ? 0: 1;
                                        char v412 = v410 >= 0x8000000000000000L;
                                        char v413 = __parity__((unsigned char)v410);
                                        char v414 = 0;
                                        char v415 = 0;
                                        if(!v411) {
                                            unsigned long v416 = *(unsigned long*)((long)ptr49 + 48L);
                                            unsigned long v417 = v416 - v410;
                                            char v418 = v417 ? 0: 1;
                                            char v419 = v417 >= 0x8000000000000000L;
                                            char v420 = __parity__((unsigned char)v417);
                                            char v421 = (((v416 ^ v410) ^ v417) >>> 4L) & 0x1L;
                                            char v422 = v416 < v410;
                                            char v423 = (long)((v416 ^ v417) & (v416 ^ v410)) < 0L;
                                            →operator delete();
                                        }
                                        unsigned long v424 = *(unsigned long*)ptr49;
                                        long* ptr94 = (long*)((long)ptr49 + 16L);
                                        char v425 = ptr94 == v424;
                                        char v426 = (long)ptr94 > (long)v424;
                                        char v427 = __parity__((unsigned char)v424 - (unsigned char)ptr94);
                                        char v428 = (unsigned long)ptr94 > v424;
                                        char v429 = (long)(long*)((long)(long*)((long)(long*)(v424 - (long)ptr94) ^ v424) & (long)(long*)((long)ptr94 ^ v424)) < 0L;
                                        char v430 = (long*)((long)(long*)((long)(long*)((long)(long*)(v424 - (long)ptr94) ^ (long)(long*)((long)ptr94 ^ v424)) >>> 4L) & 0x1L);
                                        if(!v425) {
                                            long v431 = *(long*)((long)ptr49 + 16L);
                                            long v432 = v431 + 1L;
                                            →operator delete();
                                        }
                                        void* ptr95 = ptr49;
                                        →operator delete();
                                        char v433 = (unsigned int)ptr48 == v53;
                                        char v434 = (unsigned int)ptr48 < (int)v53;
                                        char v435 = __parity__((unsigned char)ptr48 - (unsigned char)v53);
                                        char v436 = (unsigned int)ptr48 < v53;
                                        char v437 = ((((unsigned int)ptr48 - v53) ^ (unsigned int)ptr48) & ((unsigned int)ptr48 ^ v53)) < 0;
                                        char v438 = ((((unsigned int)ptr48 - v53) ^ ((unsigned int)ptr48 ^ v53)) >>> 4) & 0x1;
                                        if(!v433) {
                                            goto loc_402727;
                                        }
                                    }
                                }
                                else {
                                    *(void**)ptr89 = ptr49;
                                    ptr54 = ptr89;
                                    v183 = (size_t)((long)ptr89 + 8L);
                                    char v439 = v183 ? 0: 1;
                                    char v440 = v183 >= 0x8000000000000000L;
                                    char v441 = __parity__((unsigned char)v183);
                                    char v442 = (long*)((long)(long*)((long)(long*)((long)(long*)((long)ptr54 ^ 0x8L) ^ v183) >>> 4L) & 0x1L);
                                    char v443 = (unsigned long)ptr54 >= 18446744073709551608L;
                                    char v444 = (long)(long*)((long)(long*)(v183 ^ (long)ptr54) & (long*)~(long)(long*)((long)ptr54 ^ 0x8L)) < 0L;
                                    ptr14 = (void*)v183;
                                loc_40271C:
                                    v30 = (unsigned int)ptr48 == v53;
                                    char v445 = (unsigned int)ptr48 < (int)v53;
                                    char v446 = __parity__((unsigned char)ptr48 - (unsigned char)v53);
                                    char v447 = (unsigned int)ptr48 < v53;
                                    char v448 = ((((unsigned int)ptr48 - v53) ^ (unsigned int)ptr48) & ((unsigned int)ptr48 ^ v53)) < 0;
                                    char v449 = ((((unsigned int)ptr48 - v53) ^ ((unsigned int)ptr48 ^ v53)) >>> 4) & 0x1;
                                }
                                break;
                            }
                            while(v30);
                        }
                        void* ptr96 = (void*)v26;
                        void* ptr97 = ptr14;
                        char v450 = v53 == 1;
                        char v451 = (int)v53 < 1;
                        char v452 = __parity__((unsigned char)v53 - 1);
                        char v453 = v53 < 1;
                        char v454 = (((v53 - 1) ^ v53) & (v53 ^ 0x1)) < 0;
                        char v455 = (((v53 - 1) ^ (v53 ^ 0x1)) >>> 4) & 0x1;
                        long v456 = *(long*)ptr96;
                        long v457 = *(long*)((long)ptr97 - 8L);
                        *(long*)(v457 + 184L) = v456;
                        if(!v450 && v451 == v454) {
                            long v458 = (unsigned long)v53;
                            long v459 = (unsigned long)(v53 - 2);
                            v183 = (size_t)((long*)(v459 * 8L + (long)ptr96) + 1);
                            do {
                                long v460 = *(long*)((long)ptr96 + 8L);
                                long v461 = *(long*)ptr96;
                                ptr54 = ptr96;
                                ptr96 = (void*)((long)ptr96 + 8L);
                                char v462 = ptr96 ? 0: 1;
                                char v463 = (long)ptr96 < 0L;
                                char v464 = __parity__((unsigned char)ptr96);
                                char v465 = (long*)((long)(long*)((long)(long*)((long)(long*)((long)ptr54 ^ 0x8L) ^ (long)ptr96) >>> 4L) & 0x1L);
                                char v466 = (unsigned long)ptr54 >= 18446744073709551608L;
                                char v467 = (long)(long*)((long)(long*)((long)ptr96 ^ (long)ptr54) & (long*)~(long)(long*)((long)ptr54 ^ 0x8L)) < 0L;
                                *(long*)(v461 + 184L) = v460;
                                v37 = ptr96 == v183;
                                char v468 = (long)ptr96 < (long)v183;
                                char v469 = __parity__((unsigned char)ptr96 - (unsigned char)v183);
                                char v470 = (unsigned long)ptr96 < v183;
                                char v471 = (long)(long*)((long)(long*)((long)(long*)((long)ptr96 - v183) ^ (long)ptr96) & (long)(long*)((long)ptr96 ^ v183)) < 0L;
                                char v472 = (long*)((long)(long*)((long)(long*)((long)(long*)((long)ptr96 - v183) ^ (long)(long*)((long)ptr96 ^ v183)) >>> 4L) & 0x1L);
                            }
                            while(!v37);
                        }
                    }
                    else {
                        size_t v473 = v26;
                        long v474 = *(long*)v473;
                        void* ptr98 = ptr14;
                        long v475 = *(long*)((long)ptr98 - 8L);
                        *(long*)(v475 + 184L) = v474;
                    }
                    vpxor(v39, v39, v39);
                    *(long*)&v18 = 0L;
                    vmovdqa(*(__int128*)&v22, v39);
                    char v476 = ptr22 ? 0: 1;
                    char v477 = (long)ptr22 < 0L;
                    char v478 = __parity__((unsigned char)ptr22);
                    char v479 = 0;
                    char v480 = 0;
                    if(!v476) {
                        void* ptr99 = ptr22;
                        long* ptr100 = (long*)((long)ptr22 * 8L);
                        char v481 = (long*)((long)(long*)((long)ptr99 >>> 61L) & 0x1L);
                        char v482 = 0;
                        char v483 = ptr100 ? 0: 1;
                        char v484 = (long)ptr100 < 0L;
                        char v485 = __parity__((unsigned char)ptr100);
                        long* ptr101 = ptr100;
                        →operator new();
                        size_t v486 = v19;
                        unsigned long* ptr102 = *(unsigned long**)&v22;
                        vmovq(v40, ptr17);
                        void* ptr103 = ptr17;
                        vpunpcklqdq(v39, v40, v40);
                        char v487 = v486 == ptr102;
                        char v488 = (long)v486 < (long)ptr102;
                        char v489 = __parity__((unsigned char)v486 - (unsigned char)ptr102);
                        char v490 = v486 < (unsigned long)ptr102;
                        char v491 = (long)(long*)((long)(long*)((long)(long*)(v486 - (long)ptr102) ^ v486) & (long)(long*)(v486 ^ (long)ptr102)) < 0L;
                        char v492 = (long*)((long)(long*)((long)(long*)((long)(long*)(v486 - (long)ptr102) ^ (long)(long*)(v486 ^ (long)ptr102)) >>> 4L) & 0x1L);
                        if(!v487) {
                            long* ptr104 = (long*)(ptr102 + 1);
                            long* ptr105 = (long*)(v486 - 8L - (long)ptr102);
                            char v493 = (long)ptr104 > (long)ptr103;
                            char v494 = __parity__((unsigned char)ptr103 - (unsigned char)ptr104);
                            char v495 = (unsigned long)ptr104 > (unsigned long)ptr103;
                            char v496 = (long)(long*)((long)(long*)((long)(long*)((long)ptr103 - (long)ptr104) ^ (long)ptr103) & (long)(long*)((long)ptr104 ^ (long)ptr103)) < 0L;
                            char v497 = (long*)((long)(long*)((long)(long*)((long)(long*)((long)ptr103 - (long)ptr104) ^ (long)(long*)((long)ptr104 ^ (long)ptr103)) >>> 4L) & 0x1L);
                            if(ptr104 == ptr103) {
                            loc_402B53:
                                unsigned long* ptr106 = ptr102;
                                void* ptr107 = ptr103;
                                do {
                                    v183 = *ptr106;
                                    ++ptr106;
                                    void* ptr108 = ptr107;
                                    ptr107 = (void*)((long)ptr107 + 8L);
                                    char v498 = ptr107 ? 0: 1;
                                    char v499 = (long)ptr107 < 0L;
                                    char v500 = __parity__((unsigned char)ptr107);
                                    char v501 = (long*)((long)(long*)((long)(long*)((long)(long*)((long)ptr108 ^ 0x8L) ^ (long)ptr107) >>> 4L) & 0x1L);
                                    char v502 = (unsigned long)ptr108 >= 18446744073709551608L;
                                    char v503 = (long)(long*)((long)(long*)((long)ptr107 ^ (long)ptr108) & (long*)~(long)(long*)((long)ptr108 ^ 0x8L)) < 0L;
                                    *(size_t*)((long)ptr107 - 8L) = v183;
                                    v23 = ptr106 == v486;
                                    char v504 = (long)ptr106 > (long)v486;
                                    char v505 = __parity__((unsigned char)v486 - (unsigned char)ptr106);
                                    char v506 = (unsigned long)ptr106 > v486;
                                    char v507 = (long)(long*)((long)(long*)((long)(long*)(v486 - (long)ptr106) ^ v486) & (long)(long*)((long)ptr106 ^ v486)) < 0L;
                                    char v508 = (long*)((long)(long*)((long)(long*)((long)(long*)(v486 - (long)ptr106) ^ (long)(long*)((long)ptr106 ^ v486)) >>> 4L) & 0x1L);
                                }
                                while(!v23);
                                goto loc_4028D4;
                            }
                            else {
                                char v509 = (long)ptr105 < 16L;
                                char v510 = __parity__((unsigned char)ptr105 - 16);
                                char v511 = (long)(long*)((long)(long*)((long)(ptr105 - 2) ^ (long)ptr105) & (long)(long*)((long)ptr105 ^ 0x10L)) < 0L;
                                char v512 = (long*)((long)(long*)((long)(long*)((long)(ptr105 - 2) ^ (long)(long*)((long)ptr105 ^ 0x10L)) >>> 4L) & 0x1L);
                                if((unsigned long)ptr105 <= 16L) {
                                    goto loc_402B53;
                                }
                                else {
                                    long* ptr109 = (long*)((long)ptr105 >>> 3);
                                    char v513 = (long*)((long)(long*)((long)ptr105 >>> 2L) & 0x1L);
                                    char v514 = v511;
                                    char v515 = ptr109 ? 0: 1;
                                    char v516 = (long)ptr109 < 0L;
                                    char v517 = __parity__((unsigned char)ptr109);
                                    unsigned long v518 = 0L;
                                    char v519 = 1;
                                    char v520 = 0;
                                    char v521 = 1;
                                    char v522 = 0;
                                    char v523 = 0;
                                    ptr4 = (long*)((char*)ptr109 + 1L);
                                    char v524 = ptr4 ? 0: 1;
                                    char v525 = (long)ptr4 < 0L;
                                    char v526 = __parity__((unsigned char)ptr4);
                                    char v527 = (long*)((long)(long*)((long)(long*)((long)(long*)((long)ptr109 ^ 0x1L) ^ (long)ptr4) >>> 4L) & 0x1L);
                                    char v528 = (long)(long*)((long)(long*)((long)ptr109 ^ (long)ptr4) & (long*)~(long)(long*)((long)ptr109 ^ 0x1L)) < 0L;
                                    long* ptr110 = (long*)((long)ptr4 >>> 1);
                                    char v529 = (long*)((long)ptr4 & 0x1L);
                                    char v530 = ptr110 ? 0: 1;
                                    char v531 = (long)ptr110 < 0L;
                                    char v532 = __parity__((unsigned char)ptr110);
                                    long* ptr111 = (long*)((long)ptr110 * 16L);
                                    char v533 = (long*)((long)(long*)((long)ptr110 >>> 60L) & 0x1L);
                                    char v534 = (long)ptr4 < 0L;
                                    char v535 = ptr111 ? 0: 1;
                                    char v536 = (long)ptr111 < 0L;
                                    char v537 = __parity__((unsigned char)ptr111);
                                    do {
                                        vmovdqu(v29, *(__int128*)(v518 + (long)ptr102));
                                        vmovdqu(*(__int128*)(v518 + (long)ptr103), v29);
                                        v518 += 16L;
                                        char v538 = (long)v518 > (long)ptr111;
                                        char v539 = __parity__((unsigned char)ptr111 - (unsigned char)v518);
                                        char v540 = v518 > (unsigned long)ptr111;
                                        char v541 = (long)(long*)((long)(long*)((long)(long*)((long)ptr111 - v518) ^ (long)ptr111) & (long)(long*)(v518 ^ (long)ptr111)) < 0L;
                                        char v542 = (long*)((long)(long*)((long)(long*)((long)(long*)((long)ptr111 - v518) ^ (long)(long*)(v518 ^ (long)ptr111)) >>> 4L) & 0x1L);
                                    }
                                    while(v518 != ptr111);
                                    ptr3 = (long*)((long)ptr4 & 0xfffffffffffffffeL);
                                    char v543 = ptr3 ? 0: 1;
                                    char v544 = (long)ptr3 < 0L;
                                    char v545 = __parity__((unsigned char)ptr3);
                                    char v546 = 0;
                                    char v547 = 0;
                                    long* ptr112 = (long*)((long)ptr3 * 8L);
                                    ptr2 = (long*)((long)ptr112 + (long)ptr103);
                                    ptr1 = (long*)((long)ptr112 + (long)ptr102);
                                    char v548 = (long)ptr4 > (long)ptr3;
                                    char v549 = __parity__((unsigned char)ptr3 - (unsigned char)ptr4);
                                    char v550 = ptr4 > ptr3;
                                    char v551 = (long)(long*)((long)(long*)((long)(long*)((long)ptr3 - (long)ptr4) ^ (long)ptr3) & (long)(long*)((long)ptr4 ^ (long)ptr3)) < 0L;
                                    char v552 = (long*)((long)(long*)((long)(long*)((long)(long*)((long)ptr3 - (long)ptr4) ^ (long)(long*)((long)ptr4 ^ (long)ptr3)) >>> 4L) & 0x1L);
                                }
                            }
                            if(ptr4 != ptr3) {
                                *ptr2 = *ptr1;
                            }
                            goto loc_4028D4;
                        }
                        else {
                            char v553 = ptr102 ? 0: 1;
                            char v554 = (long)ptr102 < 0L;
                            char v555 = __parity__((unsigned char)ptr102);
                            char v556 = 0;
                            char v557 = 0;
                            if(!v553) {
                            loc_4028D4:
                                unsigned long v558 = *(unsigned long*)&v18;
                                vmovdqa(*(__int128*)&v34, v39);
                                unsigned long v559 = v558;
                                v183 = (size_t)(v558 - (long)ptr102);
                                char v560 = v183 ? 0: 1;
                                char v561 = v183 >= 0x8000000000000000L;
                                char v562 = __parity__((unsigned char)v183);
                                char v563 = (long*)((long)(long*)((long)(long*)((long)(long*)((long)ptr102 ^ v559) ^ v183) >>> 4L) & 0x1L);
                                char v564 = (unsigned long)ptr102 > v559;
                                char v565 = (long)(long*)((long)(long*)(v183 ^ v559) & (long)(long*)((long)ptr102 ^ v559)) < 0L;
                                →operator delete();
                                vmovdqa(v39, *(__int128*)&v34);
                            }
                        }
                        ptr54 = ptr103;
                        long* ptr113 = (long*)((long)ptr103 + (long)ptr100);
                        char v566 = ptr113 ? 0: 1;
                        char v567 = (long)ptr113 < 0L;
                        char v568 = __parity__((unsigned char)ptr113);
                        char v569 = (long*)((long)(long*)((long)(long*)((long)(long*)((long)ptr100 ^ (long)ptr54) ^ (long)ptr113) >>> 4L) & 0x1L);
                        char v570 = (long*)__carry__((long)ptr100, (long)ptr54);
                        char v571 = (long)(long*)((long)(long*)((long)ptr113 ^ (long)ptr54) & (long*)~(long)(long*)((long)ptr100 ^ (long)ptr54)) < 0L;
                        vmovdqa(*(__int128*)&v22, v39);
                        *(long**)&v18 = ptr113;
                    }
                    ptr8 = ptr14;
                    ptr22 = (void*)v26;
                    char v572 = ptr22 == ptr8;
                    char v573 = (long)ptr22 > (long)ptr8;
                    char v574 = __parity__((unsigned char)ptr8 - (unsigned char)ptr22);
                    char v575 = ptr22 > ptr8;
                    char v576 = (long)(long*)((long)(long*)((long)(long*)((long)ptr8 - (long)ptr22) ^ (long)ptr8) & (long)(long*)((long)ptr22 ^ (long)ptr8)) < 0L;
                    v268 = (long*)((long)(long*)((long)(long*)((long)(long*)((long)ptr8 - (long)ptr22) ^ (long)(long*)((long)ptr22 ^ (long)ptr8)) >>> 4L) & 0x1L);
                    if(!v572) {
                    loc_402929:
                        do {
                            ptr48 = *(long**)ptr22;
                            long v577 = 8L;
                            →operator new();
                            long v578 = 16L;
                            *(long*)ptr17 = 0L;
                            v255 = (size_t)ptr17;
                            →operator new();
                            size_t v579 = v255;
                            long v580 = &→pthread_create;
                            unsigned long* ptr114 = &ptr15;
                            *(long*)ptr17 = &vftable_*NSt6thread11_State_implINS_8_InvokerISt5tupleIJZ4mainEUlP6workerE_S4_EEEEEE;
                            *(unsigned long*)((long)ptr17 + 8L) = ptr48;
                            ptr15 = ptr17;
                            →std::thread::_M_start_thread();
                            void* ptr115 = ptr15;
                            char v581 = ptr115 ? 0: 1;
                            char v582 = (long)ptr115 < 0L;
                            char v583 = __parity__((unsigned char)ptr115);
                            char v584 = 0;
                            char v585 = 0;
                            if(!v581) {
                                long v586 = *(long*)ptr115;
                                *(long*)(v586 + 8L)((long)ptr115, (long)&ptr15);
                            }
                            void* ptr116 = (void*)v19;
                            ptr15 = (void*)v255;
                            char v587 = *(long*)&v18 == ptr116;
                            char v588 = *(long*)&v18 > (long)ptr116;
                            char v589 = __parity__((unsigned char)ptr116 - (unsigned char)*(long*)&v18);
                            char v590 = *(unsigned long*)&v18 > (unsigned long)ptr116;
                            char v591 = (long)(long*)((long)(long*)((long)(long*)((long)ptr116 - *(long*)&v18) ^ (long)ptr116) & (long)(long*)(*(long*)&v18 ^ (long)ptr116)) < 0L;
                            char v592 = (long*)((long)(long*)((long)(long*)((long)(long*)((long)ptr116 - *(long*)&v18) ^ (long)(long*)(*(long*)&v18 ^ (long)ptr116)) >>> 4L) & 0x1L);
                            if(v587) {
                                void* ptr117 = &v22;
                                unsigned long* ptr118 = &ptr15;
                                unsigned long* ptr119 = std::vector<std::unique_ptr<std::thread, std::default_delete<std::thread> >, std::allocator<std::unique_ptr<std::thread, std::default_delete<std::thread> > > >::_M_realloc_insert<std::unique_ptr<std::thread, std::default_delete<std::thread> > >((unsigned long*)&v22, ptr116, &ptr15);
                                void* ptr120 = ptr15;
                                char v593 = ptr120 ? 0: 1;
                                char v594 = (long)ptr120 < 0L;
                                char v595 = __parity__((unsigned char)ptr120);
                                char v596 = 0;
                                char v597 = 0;
                                if(!v593) {
                                    v272 = *(long*)ptr120 ? 0: 1;
                                    v273 = *(long*)ptr120 < 0L;
                                    v274 = __parity__((unsigned char)*(long*)ptr120);
                                    v270 = *(unsigned long*)ptr120 < 0L;
                                    v271 = 0;
                                    v268 = 0;
                                    if(!v272) {
                                        goto loc_402B8F;
                                    }
                                    else {
                                        ptr54 = ptr22;
                                        ptr22 = (void*)((long)ptr22 + 8L);
                                        char v598 = ptr22 ? 0: 1;
                                        char v599 = (long)ptr22 < 0L;
                                        char v600 = __parity__((unsigned char)ptr22);
                                        char v601 = (long*)((long)(long*)((long)(long*)((long)(long*)((long)ptr54 ^ 0x8L) ^ (long)ptr22) >>> 4L) & 0x1L);
                                        char v602 = (unsigned long)ptr54 >= 18446744073709551608L;
                                        char v603 = (long)(long*)((long)(long*)((long)ptr22 ^ (long)ptr54) & (long*)~(long)(long*)((long)ptr54 ^ 0x8L)) < 0L;
                                        →operator delete();
                                        char v604 = ptr22 == ptr8;
                                        char v605 = (long)ptr22 > (long)ptr8;
                                        char v606 = __parity__((unsigned char)ptr8 - (unsigned char)ptr22);
                                        char v607 = ptr22 > ptr8;
                                        char v608 = (long)(long*)((long)(long*)((long)(long*)((long)ptr8 - (long)ptr22) ^ (long)ptr8) & (long)(long*)((long)ptr22 ^ (long)ptr8)) < 0L;
                                        v268 = (long*)((long)(long*)((long)(long*)((long)(long*)((long)ptr8 - (long)ptr22) ^ (long)(long*)((long)ptr22 ^ (long)ptr8)) >>> 4L) & 0x1L);
                                        if(!v604) {
                                            goto loc_402929;
                                        }
                                        else {
                                        loc_4029CC:
                                            v255 = v26;
                                            ptr22 = (void*)&→__pthread_key_create;
                                            long* ptr121 = *(long**)v255;
                                            ptr8 = (void*)(ptr121 + 8);
                                            char v609 = 0;
                                            char v610 = 0;
                                            char v611 = 1;
                                            char v612 = 0;
                                            char v613 = 0;
                                            pthread_mutex_t* __mutex = (pthread_mutex_t*)ptr8;
                                            →pthread_mutex_lock(__mutex);
                                            v272 = v25 ? 0: 1;
                                            v273 = v27 < 0;
                                            v274 = __parity__((unsigned char)v31);
                                            v271 = 0;
                                            v270 = 0;
                                            if(v272) {
                                                ptr121 = *(long**)v255;
                                                long v614 = *ptr121;
                                                *(ptr121 + 20) = 0L;
                                                *(ptr121 + 19) = v614;
                                                char v615 = 0;
                                                char v616 = 0;
                                                char v617 = 1;
                                                char v618 = 0;
                                                char v619 = 0;
                                                pthread_mutex_t* __mutex1 = (pthread_mutex_t*)ptr8;
                                                →pthread_mutex_unlock(__mutex1);
                                                void* ptr122 = *(void**)v255;
                                                ptr54 = *(void**)v255;
                                                long* ptr123 = (long*)((long)ptr122 + 104L);
                                                char v620 = ptr123 ? 0: 1;
                                                char v621 = (long)ptr123 < 0L;
                                                char v622 = __parity__((unsigned char)ptr123);
                                                char v623 = (long*)((long)(long*)((long)(long*)((long)(long*)((long)ptr54 ^ 0x68L) ^ (long)ptr123) >>> 4L) & 0x1L);
                                                char v624 = (unsigned long)ptr54 >= 18446744073709551512L;
                                                char v625 = (long)(long*)((long)(long*)((long)ptr123 ^ (long)ptr54) & (long*)~(long)(long*)((long)ptr54 ^ 0x68L)) < 0L;
                                                →std::condition_variable::notify_one();
                                                long* ptr124 = *(long**)&v22;
                                                long v626 = *ptr124;
                                                →std::thread::join();
                                                ptr22 = (void*)v19;
                                                v255 = *(size_t*)&v22;
                                                char v627 = v255 == ptr22;
                                                char v628 = (long)v255 > (long)ptr22;
                                                char v629 = __parity__((unsigned char)ptr22 - (unsigned char)v255);
                                                char v630 = v255 > (unsigned long)ptr22;
                                                char v631 = (long)(long*)((long)(long*)((long)(long*)((long)ptr22 - v255) ^ (long)ptr22) & (long)(long*)(v255 ^ (long)ptr22)) < 0L;
                                                char v632 = (long*)((long)(long*)((long)(long*)((long)(long*)((long)ptr22 - v255) ^ (long)(long*)(v255 ^ (long)ptr22)) >>> 4L) & 0x1L);
                                                if(!v627) {
                                                    do {
                                                        unsigned long* ptr125 = *(unsigned long**)v255;
                                                        char v633 = ptr125 ? 0: 1;
                                                        char v634 = (long)ptr125 < 0L;
                                                        char v635 = __parity__((unsigned char)ptr125);
                                                        char v636 = 0;
                                                        char v637 = 0;
                                                        if(!v633) {
                                                            v272 = *ptr125 ? 0: 1;
                                                            v273 = *ptr125 < 0L;
                                                            v274 = __parity__((unsigned char)*ptr125);
                                                            v270 = *ptr125 < 0L;
                                                            v271 = 0;
                                                            v268 = 0;
                                                            if(!v272) {
                                                                goto loc_402B8F;
                                                            }
                                                            else {
                                                                v183 = 8L;
                                                                →operator delete();
                                                            }
                                                        }
                                                        v255 += 8L;
                                                        v15 = v255 == ptr22;
                                                        char v638 = (long)v255 > (long)ptr22;
                                                        char v639 = __parity__((unsigned char)ptr22 - (unsigned char)v255);
                                                        char v640 = v255 > (unsigned long)ptr22;
                                                        char v641 = (long)(long*)((long)(long*)((long)(long*)((long)ptr22 - v255) ^ (long)ptr22) & (long)(long*)(v255 ^ (long)ptr22)) < 0L;
                                                        char v642 = (long*)((long)(long*)((long)(long*)((long)(long*)((long)ptr22 - v255) ^ (long)(long*)(v255 ^ (long)ptr22)) >>> 4L) & 0x1L);
                                                    }
                                                    while(!v15);
                                                }
                                                if(*(unsigned long*)&v22) {
                                                    →operator delete();
                                                }
                                                void* ptr126 = ptr14;
                                                for(size_t i = v26; i != ptr126; i += 8L) {
                                                    unsigned long* ptr127 = *(unsigned long**)i;
                                                    if(ptr127) {
                                                        →std::condition_variable::~condition_variable();
                                                        if(*(ptr127 + 4)) {
                                                            →operator delete();
                                                        }
                                                        if((long*)(ptr127 + 2) != *ptr127) {
                                                            →operator delete();
                                                        }
                                                        →operator delete();
                                                    }
                                                }
                                                if(v26) {
                                                    →operator delete();
                                                }
                                                return NULL;
                                            }
                                            size_t v643 = (size_t)v32;
                                            long* ptr128 = &ptr16;
                                            /*BAD_CALL!*/ →std::__throw_system_error();
                                            return;
                                        }
                                    }
                                }
                            }
                            else {
                                *(size_t*)ptr116 = v255;
                                ptr54 = ptr116;
                                v183 = (size_t)((long)ptr116 + 8L);
                                char v644 = v183 ? 0: 1;
                                char v645 = v183 >= 0x8000000000000000L;
                                char v646 = __parity__((unsigned char)v183);
                                char v647 = (long*)((long)(long*)((long)(long*)((long)(long*)((long)ptr54 ^ 0x8L) ^ v183) >>> 4L) & 0x1L);
                                char v648 = (unsigned long)ptr54 >= 18446744073709551608L;
                                char v649 = (long)(long*)((long)(long*)(v183 ^ (long)ptr54) & (long*)~(long)(long*)((long)ptr54 ^ 0x8L)) < 0L;
                                v19 = v183;
                            }
                            ptr22 = (void*)((long)ptr22 + 8L);
                            v33 = ptr22 == ptr8;
                            char v650 = (long)ptr22 > (long)ptr8;
                            char v651 = __parity__((unsigned char)ptr8 - (unsigned char)ptr22);
                            char v652 = ptr22 > ptr8;
                            char v653 = (long)(long*)((long)(long*)((long)(long*)((long)ptr8 - (long)ptr22) ^ (long)ptr8) & (long)(long*)((long)ptr22 ^ (long)ptr8)) < 0L;
                            v268 = (long*)((long)(long*)((long)(long*)((long)(long*)((long)ptr8 - (long)ptr22) ^ (long)(long*)((long)ptr22 ^ (long)ptr8)) >>> 4L) & 0x1L);
                        }
                        while(v33);
                    }
                    goto loc_4029CC;
                }
                else {
                    v10 = (unsigned int)((unsigned int)&ptr9 - 72);
                    unsigned int v654 = (unsigned int)((unsigned int)v171 * 0xeeeeeeef);
                    int v655 = 0;
                    char v656 = (unsigned int)v171 * 0xeeeeeeef == 0x11111111;
                    char v657 = (int)v654 < 0x11111111;
                    char v658 = __parity__((unsigned char)v654 - 17);
                    char v659 = v654 < 0x11111111;
                    char v660 = (((v654 - 0x11111111) ^ v654) & (v654 ^ 0x11111111)) < 0;
                    char v661 = (((v654 - 0x11111111) ^ (v654 ^ 0x11111111)) >>> 4) & 0x1;
                    if(!v659 && !v656) {
                        v10 = v654;
                        unsigned int v662 = (unsigned int)((unsigned int)v171 * 0xcccccccd);
                        int v663 = 0;
                        char v664 = (unsigned int)v171 * 0xcccccccd == 0x33333333;
                        char v665 = (int)v662 < 0x33333333;
                        char v666 = __parity__((unsigned char)v662 - 51);
                        char v667 = v662 < 0x33333333;
                        char v668 = (((v662 - 0x33333333) ^ v662) & (v662 ^ 0x33333333)) < 0;
                        char v669 = (((v662 - 0x33333333) ^ (v662 ^ 0x33333333)) >>> 4) & 0x1;
                        if(!v667 && !v664) {
                            v10 = v662;
                            unsigned int v670 = (unsigned int)((unsigned int)v171 * 0xaaaaaaab);
                            int v671 = 0;
                            char v672 = (unsigned int)v171 * 0xaaaaaaab == 0x55555555;
                            char v673 = (int)v670 < 0x55555555;
                            char v674 = __parity__((unsigned char)v670 - 85);
                            char v675 = v670 < 0x55555555;
                            char v676 = (((v670 - 0x55555555) ^ v670) & (v670 ^ 0x55555555)) < 0;
                            char v677 = (((v670 - 0x55555555) ^ (v670 ^ 0x55555555)) >>> 4) & 0x1;
                            if((v675 || v672)) {
                                long v678 = 5L;
                                long v679 = "Fizz\n";
                                ptr46 = (void*)&std::cout;
                            }
                            else {
                                long v680 = (unsigned long)(unsigned int)v171;
                                long v681 = &std::cout;
                                →std::ostream::operator<<();
                                long v682 = 1L;
                                void* ptr129 = &v22;
                                ptr46 = ptr17;
                            }
                        }
                        else {
                            long v683 = 5L;
                            long v684 = "Buzz\n";
                            ptr46 = (void*)&std::cout;
                        }
                    }
                    else {
                        long v685 = 9L;
                        long v686 = "FizzBuzz\n";
                        ptr46 = (void*)&std::cout;
                    }
                    →std::__ostream_insert<char, std::char_traits<char> >();
                    long* ptr130 = ptr48;
                    ptr48 = (long*)((char*)ptr48 + 1L);
                    char v687 = ptr48 ? 0: 1;
                    char v688 = (long)ptr48 < 0L;
                    char v689 = __parity__((unsigned char)ptr48);
                    char v690 = (long*)((long)(long*)((long)(long*)((long)(long*)((long)ptr130 ^ 0x1L) ^ (long)ptr48) >>> 4L) & 0x1L);
                    char v691 = (long)(long*)((long)(long*)((long)ptr48 ^ (long)ptr130) & (long*)~(long)(long*)((long)ptr130 ^ 0x1L)) < 0L;
                    v169 = (unsigned int)ptr48;
                    v170 = 0;
                    v171 = (long)(unsigned int)ptr48;
                    v14 = ptr48 == 9L;
                    char v692 = (long)ptr48 < 9L;
                    char v693 = __parity__((unsigned char)ptr48 - 9);
                    v13 = (unsigned long)ptr48 < 9L;
                    char v694 = (long)(long*)((long)(long*)((long)(long*)((char*)ptr48 - 9L) ^ (long)ptr48) & (long)(long*)((long)ptr48 ^ 0x9L)) < 0L;
                    char v695 = (long*)((long)(long*)((long)(long*)((long)(long*)((char*)ptr48 - 9L) ^ (long)(long*)((long)ptr48 ^ 0x9L)) >>> 4L) & 0x1L);
                }
            }
        }
        while(1);
    }
    while(!v13 && !v14);
    char v696 = (unsigned int)ptr48 == 99;
    char v697 = (unsigned int)ptr48 < 99;
    char v698 = __parity__((unsigned char)ptr48 - 99);
    char v699 = (unsigned int)ptr48 < 99;
    char v700 = ((((unsigned int)ptr48 - 99) ^ (unsigned int)ptr48) & ((unsigned int)ptr48 ^ 0x63)) < 0;
    char v701 = ((((unsigned int)ptr48 - 99) ^ ((unsigned int)ptr48 ^ 0x63)) >>> 4) & 0x1;
    if(!v699 && !v696) {
        char v702 = (unsigned int)ptr48 == 999;
        char v703 = (unsigned int)ptr48 < 999;
        char v704 = __parity__((unsigned char)ptr48 - 231);
        char v705 = (unsigned int)ptr48 < 999;
        char v706 = ((((unsigned int)ptr48 - 999) ^ (unsigned int)ptr48) & ((unsigned int)ptr48 ^ 0x3e7)) < 0;
        char v707 = ((((unsigned int)ptr48 - 999) ^ ((unsigned int)ptr48 ^ 0x3e7)) >>> 4) & 0x1;
        if(!v705 && !v702) {
            char v708 = (unsigned int)ptr48 == 9999;
            char v709 = (unsigned int)ptr48 < 9999;
            char v710 = __parity__((unsigned char)ptr48 - 15);
            char v711 = (unsigned int)ptr48 < 9999;
            char v712 = ((((unsigned int)ptr48 - 9999) ^ (unsigned int)ptr48) & ((unsigned int)ptr48 ^ 0x270f)) < 0;
            char v713 = ((((unsigned int)ptr48 - 9999) ^ ((unsigned int)ptr48 ^ 0x270f)) >>> 4) & 0x1;
            if(v711 || v708) {
                v9 = 1;
                goto loc_402570;
            }
            else {
                ptr0 = ptr48;
                v9 = 1;
            }
            do {
                long* ptr131 = ptr0;
                long* ptr132 = ptr0;
                long* ptr133 = ptr131;
                long* ptr134 = (long*)((long)ptr131 * 3777893186295716171L);
                long v714 = (unsigned long)(((unsigned __int128)ptr133 * 0x346DC5D63886594BX) >>> 0x40X);
                char v715 = v714 ? 1: 0;
                char v716 = v714 ? 1: 0;
                unsigned int v717 = v9;
                int v718 = 0;
                v10 = v9;
                v9 += 4;
                v8 = 0;
                char v719 = v9 ? 0: 1;
                char v720 = v9 >= 0x80000000;
                char v721 = __parity__((unsigned char)v9);
                char v722 = (((v10 ^ 0x4) ^ v9) >>> 4) & 0x1;
                char v723 = v10 >= 0xfffffffc;
                char v724 = (int)((v9 ^ v10) & ~(v10 ^ 0x4)) < 0;
                long v725 = v714;
                ptr0 = (long*)(v714 >>> 11);
                char v726 = (v725 >>> 10L) & 0x1L;
                char v727 = v724;
                char v728 = ptr0 ? 0: 1;
                char v729 = (long)ptr0 < 0L;
                char v730 = __parity__((unsigned char)ptr0);
                char v731 = ptr132 == 99999L;
                char v732 = (long)ptr132 < 99999L;
                char v733 = __parity__((unsigned char)ptr132 - 159);
                char v734 = (unsigned long)ptr132 < 99999L;
                char v735 = (long)(long*)((long)(long*)((long)(long*)((char*)ptr132 - 99999L) ^ (long)ptr132) & (long)(long*)((long)ptr132 ^ 0x1869fL)) < 0L;
                char v736 = (long*)((long)(long*)((long)(long*)((long)(long*)((char*)ptr132 - 99999L) ^ (long)(long*)((long)ptr132 ^ 0x1869fL)) >>> 4L) & 0x1L);
                if((v734 || v731)) {
                    v6 = v9;
                    v5 = 0;
                    v9 = v717 + 3;
                    v8 = 0;
                    goto loc_4023A1;
                }
                else {
                    v4 = (unsigned int)ptr0 == 99;
                    char v737 = (unsigned int)ptr0 < 99;
                    char v738 = __parity__((unsigned char)ptr0 - 99);
                    v3 = (unsigned int)ptr0 < 99;
                    char v739 = ((((unsigned int)ptr0 - 99) ^ (unsigned int)ptr0) & ((unsigned int)ptr0 ^ 0x63)) < 0;
                    char v740 = ((((unsigned int)ptr0 - 99) ^ ((unsigned int)ptr0 ^ 0x63)) >>> 4) & 0x1;
                }
                if(v3 || v4) {
                    goto loc_402550;
                }
                else {
                    char v741 = (unsigned int)ptr0 == 999;
                    char v742 = (unsigned int)ptr0 < 999;
                    char v743 = __parity__((unsigned char)ptr0 - 231);
                    char v744 = (unsigned int)ptr0 < 999;
                    char v745 = ((((unsigned int)ptr0 - 999) ^ (unsigned int)ptr0) & ((unsigned int)ptr0 ^ 0x3e7)) < 0;
                    char v746 = ((((unsigned int)ptr0 - 999) ^ ((unsigned int)ptr0 ^ 0x3e7)) >>> 4) & 0x1;
                    if(v744 || v741) {
                        goto loc_402560;
                    }
                    else {
                        v2 = (unsigned int)ptr0 == 9999;
                        char v747 = (unsigned int)ptr0 < 9999;
                        char v748 = __parity__((unsigned char)ptr0 - 15);
                        v1 = (unsigned int)ptr0 < 9999;
                        char v749 = ((((unsigned int)ptr0 - 9999) ^ (unsigned int)ptr0) & ((unsigned int)ptr0 ^ 0x270f)) < 0;
                        char v750 = ((((unsigned int)ptr0 - 9999) ^ ((unsigned int)ptr0 ^ 0x270f)) >>> 4) & 0x1;
                    }
                }
            }
            while((!v1 && !v2));
        loc_402570:
            v6 = v9 + 3;
            v5 = 0;
            v10 = v9;
            v9 += 2;
            v8 = 0;
            char v751 = v9 ? 0: 1;
            char v752 = v9 >= 0x80000000;
            char v753 = __parity__((unsigned char)v9);
            char v754 = (((v10 ^ 0x2) ^ v9) >>> 4) & 0x1;
            char v755 = v10 >= 0xfffffffe;
            char v756 = (int)((v9 ^ v10) & ~(v10 ^ 0x2)) < 0;
        }
        else {
            v9 = 1;
        loc_402560:
            v6 = v9 + 2;
            v5 = 0;
            v10 = v9;
            ++v9;
            v8 = 0;
            char v757 = v9 ? 0: 1;
            char v758 = v9 >= 0x80000000;
            char v759 = __parity__((unsigned char)v9);
            char v760 = (((v10 ^ 0x1) ^ v9) >>> 4) & 0x1;
            char v761 = (int)((v9 ^ v10) & ~(v10 ^ 0x1)) < 0;
        }
    }
    else {
        v9 = 1;
        v8 = 0;
    loc_402550:
        v6 = v9 + 1;
        v5 = 0;
    }
loc_4023A1:
    void* ptr135 = &v18;
    __n = (size_t)v6;
    *(void**)&v22 = &v18;
    char v762 = v6 == 15;
    char v763 = (int)v6 < 15;
    char v764 = __parity__((unsigned char)v6 - 15);
    char v765 = v6 < 15;
    char v766 = (((v6 - 15) ^ v6) & (v6 ^ 0xf)) < 0;
    char v767 = (((v6 - 15) ^ (v6 ^ 0xf)) >>> 4) & 0x1;
    if((v765 || v762)) {
        ptr7 = &v18;
        char v768 = __n ? 0: 1;
        char v769 = __n >= 0x8000000000000000L;
        char v770 = __parity__((unsigned char)__n);
        char v771 = 0;
        char v772 = 0;
        if(v768) {
            goto loc_4023C4;
        }
        else {
            char v773 = __n == 1L;
            char v774 = (long)__n < 1L;
            char v775 = __parity__((unsigned char)__n - 1);
            char v776 = __n < 1L;
            char v777 = (((__n - 1L) ^ __n) & (__n ^ 0x1L)) < 0L;
            char v778 = (((__n - 1L) ^ (__n ^ 0x1L)) >>> 4L) & 0x1L;
            if(v773) {
                goto loc_4025DA;
            }
            else {
                __s = &v18;
            }
        }
    }
    else {
        long v779 = __n + 1L;
        /*BAD_CALL!*/ →operator new();
        __s = ptr17;
        *(void**)&v22 = ptr17;
        *(size_t*)&v18 = __n;
    }
    long v780 = 45L;
    unsigned int v781 = v169;
    v0 = __n;
    →memset(__s, 45L, __n);
    ptr7 = *(void**)&v22;
    v169 = v781;
    v170 = 0;
    __n = v0;
    goto loc_4023C4;
}

long register_tm_clones() {
    return 0L;
}

// Package: std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >

void* std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >::_M_mutate(void* __dest1, void* __src2, unsigned long param2, void* param3, size_t param4) {
    void* ptr0;
    void* __src1;
    void* __src;
    void* ptr1;
    unsigned long v0;
    unsigned long v1;
    void* ptr2;
    size_t v2;
    long* ptr3;
    void* ptr4;
    long v3;
    void* __dest;
    void* ptr5;
    void* ptr6;
    long v4 = v3;
    size_t v5 = v2;
    void* ptr7 = param3;
    long* ptr8 = (long*)(param2 + (long)__src2);
    long* ptr9 = ptr3;
    void* ptr10 = ptr5;
    void* ptr11 = __src2;
    size_t __n = param4;
    void* ptr12 = ptr6;
    size_t v6 = param4;
    void* ptr13 = __dest1;
    long* ptr14 = &ptr12;
    char v7 = &v1 == 88L;
    char v8 = (long)&ptr4 < 0L;
    char v9 = __parity__((unsigned char)&v1 - 88);
    char v10 = (long*)((long)(long*)((long)(long*)((long)(long*)((long)&ptr12 ^ 0x28L) ^ (long)&ptr4) >>> 4L) & 0x1L);
    char v11 = (unsigned long)&ptr12 < 40L;
    char v12 = (long)(long*)((long)(long*)((long)&ptr12 ^ (long)&ptr4) & (long)(long*)((long)&ptr12 ^ 0x28L)) < 0L;
    unsigned long v13 = *(unsigned long*)((long)__dest1 + 8L);
    size_t v14 = v6;
    unsigned long v15 = (unsigned long)(v6 - param2);
    char v16 = v15 ? 0: 1;
    char v17 = v15 >= 0x8000000000000000L;
    char v18 = __parity__((unsigned char)v15);
    char v19 = (((param2 ^ v14) ^ v15) >>> 4L) & 0x1L;
    char v20 = param2 > v14;
    char v21 = (long)((param2 ^ v14) & (v15 ^ v14)) < 0L;
    long* ptr15 = (long*)((long)__dest1 + 16L);
    long* ptr16 = ptr8;
    unsigned long v22 = v13;
    unsigned long v23 = v13 + v15;
    unsigned long v24 = v22;
    __src2 = (void*)(v22 - (long)ptr8);
    char v25 = __src2 ? 0: 1;
    char v26 = (long)__src2 < 0L;
    char v27 = __parity__((unsigned char)__src2);
    char v28 = (long*)((long)(long*)((long)(long*)((long)(long*)((long)ptr8 ^ v24) ^ (long)__src2) >>> 4L) & 0x1L);
    char v29 = (unsigned long)ptr8 > v24;
    char v30 = (long)(long*)((long)(long*)((long)ptr8 ^ v24) & (long)(long*)((long)__src2 ^ v24)) < 0L;
    ptr4 = __src2;
    char v31 = *(long*)__dest1 == ptr15;
    char v32 = *(long*)__dest1 > (long)ptr15;
    char v33 = __parity__((unsigned char)ptr15 - (unsigned char)*(long*)__dest1);
    char v34 = *(unsigned long*)__dest1 > (unsigned long)ptr15;
    char v35 = (long)(long*)((long)(long*)((long)(long*)((long)ptr15 - *(long*)__dest1) ^ (long)ptr15) & (long)(long*)(*(long*)__dest1 ^ (long)ptr15)) < 0L;
    char v36 = (long*)((long)(long*)((long)(long*)((long)(long*)((long)ptr15 - *(long*)__dest1) ^ (long)(long*)(*(long*)__dest1 ^ (long)ptr15)) >>> 4L) & 0x1L);
    if(!v31) {
        v0 = *(unsigned long*)((long)__dest1 + 16L);
    loc_40432B:
        char v37 = v23 ? 0: 1;
        char v38 = v23 >= 0x8000000000000000L;
        char v39 = __parity__((unsigned char)v23);
        char v40 = 0;
        char v41 = 0;
        if(v38) {
            __dest1 = "basic_string::_M_create";
            long* ptr17 = &ptr2;
            /*BAD_CALL!*/ →std::__throw_length_error();
            goto loc_4043A5;
        }
        else {
            char v42 = v0 == v23;
            char v43 = (long)v0 > (long)v23;
            char v44 = __parity__((unsigned char)v23 - (unsigned char)v0);
            char v45 = v0 > v23;
            char v46 = (long)(((v23 - v0) ^ v23) & (v0 ^ v23)) < 0L;
            char v47 = (((v23 - v0) ^ (v0 ^ v23)) >>> 4L) & 0x1L;
            if(!v45 && !v42) {
                unsigned long v48 = v0 * 2L;
                char v49 = v48 == v23;
                char v50 = (long)v48 > (long)v23;
                char v51 = __parity__((unsigned char)v23 - (unsigned char)v48);
                char v52 = v48 > v23;
                char v53 = (long)(((v23 - v48) ^ v23) & (v48 ^ v23)) < 0L;
                v36 = (((v23 - v48) ^ (v48 ^ v23)) >>> 4L) & 0x1L;
                if(v52) {
                    char v54 = v48 ? 0: 1;
                    char v55 = v48 >= 0x8000000000000000L;
                    char v56 = __parity__((unsigned char)v48);
                    char v57 = 0;
                    char v58 = 0;
                    if(v55) {
                        →std::__throw_bad_alloc();
                        v0 = 15L;
                        goto loc_40432B;
                    }
                    else {
                        v23 = v48;
                    }
                }
            }
            unsigned long v59 = v23;
            v24 = v23;
            char v60 = (void*)(v59 + 1L) ? 0: 1;
            char v61 = (long)(void*)(v59 + 1L) < 0L;
            char v62 = __parity__((unsigned char)v59 + 1);
            v36 = (long*)((long)(long*)((long)(long*)((long)(void*)(v59 + 1L) ^ (v24 ^ 0x1L)) >>> 4L) & 0x1L);
            char v63 = (long)(long*)((long)(long*)((long)(void*)(v59 + 1L) ^ v24) & ~(v24 ^ 0x1L)) < 0L;
            if(v61) {
                →std::__throw_bad_alloc();
                v0 = 15L;
                goto loc_40432B;
            }
            else {
                ptr1 = ptr7;
                →operator new();
                __src = *(void**)ptr13;
                __src1 = ptr7;
                ptr0 = __dest;
            }
        }
        if(ptr11) {
            if(ptr11 != 1L) {
                void* ptr18 = __src1;
                ptr1 = __src;
                →memcpy(__dest, __src, (size_t)ptr11);
                __src1 = ptr18;
                __src = ptr1;
            }
            else {
                *(char*)ptr0 = *(char*)__src;
            }
        }
    loc_4043A5:
        if(__src1 && __n) {
            __dest1 = (void*)((long)ptr11 + (long)ptr0);
            if(__n == 1L) {
                goto loc_404464;
            }
            else {
                ptr1 = __src;
                →memcpy(__dest1, __src1, __n);
                __src = ptr1;
                goto loc_4043CF;
            }
        }
        else {
        loc_4043CF:
            __dest = ptr4;
            if(__dest) {
                goto loc_4043E1;
            loc_404464:
                *(char*)__dest1 = *(char*)__src1;
                __dest = ptr4;
                if(__dest) {
                loc_4043E1:
                    __dest1 = (void*)((size_t)((long)ptr11 + __n) + (long)ptr0);
                    __src2 = (void*)((long)__src + (long)ptr16);
                    if(__dest == 1L) {
                        goto loc_404480;
                    }
                    else {
                        ptr1 = __src;
                        →memcpy(__dest1, __src2, (size_t)__dest);
                        __src = ptr1;
                    }
                }
            }
            if(__src != ptr15) {
                →operator delete();
                *(void**)ptr13 = ptr0;
                *(unsigned long*)((long)ptr13 + 16L) = v23;
                return __dest;
            loc_404480:
                __dest = (void*)*(char*)__src2;
                *(char*)__dest1 = *(char*)__src2;
                if(__src != ptr15) {
                    →operator delete();
                }
            }
        }
        *(void**)ptr13 = ptr0;
        *(unsigned long*)((long)ptr13 + 16L) = v23;
        return __dest;
    }
    v0 = 15L;
    goto loc_40432B;
}

// Package: std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >

void* std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >::_M_replace_aux(void* __dest1, void* __src, unsigned long param2, size_t __n, long param4) {
    unsigned long v0;
    void* ptr0;
    long v1;
    long v2;
    size_t v3;
    long v4;
    long v5 = v2;
    size_t v6 = v3;
    size_t __n1 = __n;
    long v7 = 0x7fffffffffffffffL;
    long v8 = v4;
    long v9 = 0x7fffffffffffffffL;
    long v10 = (long)(param2 + 0x7fffffffffffffffL);
    char v11 = v10 ? 0: 1;
    char v12 = v10 < 0L;
    char v13 = __parity__((unsigned char)v10);
    char v14 = (((param2 ^ 0x7fffffffffffffffL) ^ v10) >>> 4L) & 0x1L;
    char v15 = param2 >= 0x8000000000000001L;
    char v16 = ((v10 ^ 0x7fffffffffffffffL) & ~(param2 ^ 0x7fffffffffffffffL)) < 0L;
    long v17 = v1;
    unsigned long v18 = *(unsigned long*)((long)__dest1 + 8L);
    unsigned long v19 = (unsigned long)(v10 - v18);
    char v20 = v19 == __n1;
    char v21 = (long)v19 > (long)__n1;
    char v22 = __parity__((unsigned char)__n1 - (unsigned char)v19);
    char v23 = v19 > __n1;
    char v24 = (long)(((unsigned long)(__n1 - v19) ^ __n1) & (v19 ^ __n1)) < 0L;
    char v25 = (((unsigned long)(__n1 - v19) ^ (v19 ^ __n1)) >>> 4L) & 0x1L;
    if((v23 || v20)) {
        v0 = *(unsigned long*)__dest1;
        void* __src2 = __src;
        unsigned long v26 = (unsigned long)(__n1 - param2) + v18;
        unsigned long v27 = (long*)((long)__dest1 + 16L) != v0 ? *(unsigned long*)((long)__dest1 + 16L): 15L;
        if(v27 >= v26) {
            __n = (size_t)(v18 - (long)(long*)(param2 + (long)__src2));
            if(__n && param2 != __n1) {
                long* ptr1 = (long*)(v0 + (long)__src2);
                __src = (void*)(param2 + (long)ptr1);
                void* __dest = (void*)((long)ptr1 + __n1);
                if(__n != 1L) {
                    →memmove(__dest, __src, __n);
                    v0 = *(unsigned long*)__dest1;
                    goto loc_404526;
                }
                else {
                    *(char*)__dest = *(char*)__src;
                    v0 = *(unsigned long*)__dest1;
                    if(__n1) {
                        goto loc_404528;
                    }
                }
            }
            else {
            loc_404526:
                if(__n1) {
                    goto loc_404528;
                }
            }
        }
        else {
            std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >::_M_mutate(__dest1, __src2, param2, NULL, __n1);
            v0 = *(unsigned long*)__dest1;
            if(__n1) {
            loc_404528:
                void* __s = (void*)(v0 + (long)__src2);
                if(__n1 != 1L) {
                    →memset(__s, (long)(int)(unsigned char)param4, __n1);
                }
                else {
                    *(char*)__s = (unsigned char)param4;
                }
                v0 = *(unsigned long*)__dest1;
            }
        }
        *(unsigned long*)((long)__dest1 + 8L) = v26;
        *(char*)(v26 + v0) = 0;
        return __dest1;
    }
    v0 = "basic_string::_M_replace_aux";
    long* ptr2 = &ptr0;
    /*BAD_CALL!*/ →std::__throw_length_error();
}

// Package: std::__cxx11

void* std::__cxx11::to_string(void* __s, void* param1) {
    long v0;
    unsigned int v1;
    void* ptr0;
    int v2;
    size_t __n;
    void* ptr1;
    long v3;
    void* ptr2;
    void* ptr3;
    void* result = __s;
    __s = (void*)((long)__s + 16L);
    long v4 = v3;
    void* ptr4 = param1;
    if((unsigned long)param1 > 9L) {
        if((unsigned long)param1 <= 99L) {
            *(void**)result = __s;
            __n = 2L;
        }
        else if((unsigned long)param1 > 999L) {
            ptr1 = param1;
            param1 = (void*)0x1;
            if((unsigned long)ptr4 <= 9999L) {
                *(void**)result = __s;
                __n = 4L;
            }
            else {
                do {
                    ptr3 = ptr1;
                    v2 = (unsigned int)param1;
                    param1 = (void*)((unsigned int)param1 + 4);
                    ptr1 = (void*)((unsigned long)(((unsigned __int128)ptr1 * 0x346DC5D63886594BX) >>> 0x40X) >>> 11);
                    if((unsigned long)ptr3 <= 99999L) {
                        __n = (size_t)(unsigned int)param1;
                        goto loc_403C04;
                    }
                    else if((unsigned long)ptr3 <= 999999L) {
                        __n = (size_t)(v2 + 5);
                        goto loc_403C04;
                    }
                    else if((unsigned long)ptr3 <= 9999999L) {
                        __n = (size_t)(v2 + 6);
                        goto loc_403C04;
                    }
                }
                while((unsigned long)ptr3 <= 99999999L);
                __n = (size_t)(v2 + 7);
            loc_403C04:
                *(void**)result = __s;
                if(__n > 15L) {
                    →operator new();
                    *(size_t*)((long)result + 16L) = __n;
                    __s = ptr2;
                    *(void**)result = ptr2;
                }
                else if(!__n) {
                    *(long*)((long)result + 8L) = 0L;
                    *(char*)((long)result + 16L) = 0;
                    ptr0 = __s;
                    v1 = 0xffffffff;
                    goto loc_403C50;
                }
                else if(__n == 1L) {
                    goto loc_403D46;
                }
            }
        }
        else {
            *(void**)result = __s;
            __n = 3L;
        }
        →memset(__s, 0L, __n);
        v0 = *(long*)result;
        goto loc_403CE3;
    }
    else {
        *(void**)result = __s;
    loc_403D46:
        v0 = *(long*)result;
        *(char*)((long)result + 16L) = 0;
        __n = 1L;
    loc_403CE3:
        *(size_t*)((long)result + 8L) = __n;
        *(char*)(v0 + __n) = 0;
        ptr0 = *(void**)result;
        v1 = (unsigned int)(*(int*)((long)result + 8L) - 1);
        if((unsigned long)ptr4 > 99L) {
        loc_403C50:
            do {
                void* ptr5 = (void*)((unsigned long)(((unsigned __int128)(long*)((long)ptr4 >>> 2) * 0x28F5C28F5C28F5C3X) >>> 0x40X) >>> 2);
                long* ptr6 = (long*)((long)ptr4 - (long)(long*)((long)ptr5 * 100L));
                __s = ptr4;
                ptr4 = ptr5;
                long* ptr7 = (long*)((long)ptr6 * 2L);
                char v5 = *(char*)(ptr7 + 526888);
                *(char*)((unsigned long)v1 + (long)ptr0) = *(char*)((char*)ptr7 + &a001020304050607);
                ptr1 = (void*)(v1 - 1);
                v1 -= 2;
                *(char*)((long)ptr1 + (long)ptr0) = v5;
            }
            while((unsigned long)__s > 9999L);
        }
    }
    long v6 = (unsigned long)((unsigned int)ptr4 + 48);
    if((unsigned long)ptr4 > 9L) {
        long* ptr8 = (long*)((long)ptr4 * 2L);
        *(char*)((long)ptr0 + 1L) = *(char*)((char*)ptr8 + &a001020304050607);
        v6 = (unsigned long)*(char*)(ptr8 + 526888);
    }
    *(char*)ptr0 = (unsigned char)v6;
    return result;
}

// Stale decompilation - Refresh this view to re-decompile this code
// Package: std::thread::_State_impl<std::thread::_Invoker<std::tuple<main::{lambda(worker*)#1}, worker*> > >

long std::thread::_State_impl<std::thread::_Invoker<std::tuple<main::{lambda(worker*)#1}, worker*> > >::_M_run(long param0, long param1, long param2, long param3, long param4) {
    long v0 = *(long*)(param0 + 8L);
    /*BAD_CALL!*/ worker::loop(v0, param1, param2, param3, param4);
}

// Package: std::thread::_State_impl<std::thread::_Invoker<std::tuple<main::{lambda(worker*)#1}, worker*> > >

long std::thread::_State_impl<std::thread::_Invoker<std::tuple<main::{lambda(worker*)#1}, worker*> > >::~_State_impl(long* param0) {
    long result;
    *param0 = &vftable_*NSt6thread11_State_implINS_8_InvokerISt5tupleIJZ4mainEUlP6workerE_S4_EEEEEE;
    →std::thread::_State::~_State();
    return result;
}

// Package: std::thread::_State_impl<std::thread::_Invoker<std::tuple<main::{lambda(worker*)#1}, worker*> > >

long std::thread::_State_impl<std::thread::_Invoker<std::tuple<main::{lambda(worker*)#1}, worker*> > >::~_State_impl2(long* param0) {
    long result;
    *param0 = &vftable_*NSt6thread11_State_implINS_8_InvokerISt5tupleIJZ4mainEUlP6workerE_S4_EEEEEE;
    →std::thread::_State::~_State();
    →operator delete();
    return result;
}

// Package: std::vector<__gnu_cxx::__normal_iterator<char*, std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> > >, std::allocator<__gnu_cxx::__normal_iterator<char*, std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> > > > >

unsigned long std::vector<__gnu_cxx::__normal_iterator<char*, std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> > >, std::allocator<__gnu_cxx::__normal_iterator<char*, std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> > > > >::_M_realloc_insert<__gnu_cxx::__normal_iterator<char*, std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> > > >(unsigned long* param0, void* param1, unsigned long* param2) {
    unsigned long* ptr0;
    unsigned long v0;
    long* ptr1;
    void* __dest;
    long* ptr2;
    void* ptr3;
    long v1;
    unsigned long v2;
    long v3;
    void* ptr4;
    unsigned long result;
    long v4;
    unsigned long* ptr5;
    __int128 v5;
    __int128 v6;
    unsigned long v7 = v2;
    long v8 = v4;
    long v9 = 0xfffffffffffffffL;
    long v10 = v3;
    unsigned long* ptr6 = ptr5;
    long v11 = v1;
    long* ptr7 = &v11;
    char v12 = &ptr2 == 88L;
    char v13 = (long)&ptr4 < 0L;
    char v14 = __parity__((unsigned char)&ptr2 - 88);
    char v15 = (long*)((long)(long*)((long)(long*)((long)(long*)((long)&v11 ^ 0x28L) ^ (long)&ptr4) >>> 4L) & 0x1L);
    char v16 = (unsigned long)&v11 < 40L;
    char v17 = (long)(long*)((long)(long*)((long)&v11 ^ (long)&ptr4) & (long)(long*)((long)&v11 ^ 0x28L)) < 0L;
    unsigned long v18 = *(param0 + 1);
    unsigned long* ptr8 = *param0;
    unsigned long v19 = v18;
    unsigned long v20 = v18;
    long* ptr9 = (long*)(v19 - (long)ptr8);
    char v21 = ptr9 ? 0: 1;
    char v22 = (long)ptr9 < 0L;
    char v23 = __parity__((unsigned char)ptr9);
    char v24 = (long*)((long)(long*)((long)(long*)((long)(long*)((long)ptr8 ^ v20) ^ (long)ptr9) >>> 4L) & 0x1L);
    char v25 = (unsigned long)ptr8 > v20;
    char v26 = (long)(long*)((long)(long*)((long)ptr9 ^ v20) & (long)(long*)((long)ptr8 ^ v20)) < 0L;
    long* ptr10 = ptr9;
    long* ptr11 = (long*)((long)ptr9 >> 3);
    char v27 = (long*)((long)(long*)((long)ptr10 >>> 2L) & 0x1L);
    char v28 = v26;
    char v29 = ptr11 ? 0: 1;
    char v30 = (long)ptr11 < 0L;
    char v31 = __parity__((unsigned char)ptr11);
    char v32 = ptr11 == 0xfffffffffffffffL;
    char v33 = (long)ptr11 < 0xfffffffffffffffL;
    char v34 = __parity__((unsigned char)ptr11 - 0xff);
    char v35 = (unsigned long)ptr11 < 0xfffffffffffffffL;
    char v36 = (long)(long*)((long)(long*)((long)(long*)((char*)ptr11 - 0xfffffffffffffffL) ^ (long)ptr11) & (long)(long*)((long)ptr11 ^ 0xfffffffffffffffL)) < 0L;
    char v37 = (long*)((long)(long*)((long)(long*)((long)(long*)((char*)ptr11 - 0xfffffffffffffffL) ^ (long)(long*)((long)ptr11 ^ 0xfffffffffffffffL)) >>> 4L) & 0x1L);
    if(!v32) {
        void* __src = param1;
        param1 = (void*)((long)param1 - (long)ptr8);
        if(__carry__(ptr11 ? ptr11: 1L, (long)ptr11)) {
            ptr0 = (unsigned long*)0x7FFFFFFFFFFFFFF8;
        loc_40428D:
            unsigned long* ptr12 = param2;
            ptr4 = param1;
            →operator new();
            param1 = ptr4;
            param2 = ptr12;
            v0 = result;
            ptr1 = (long*)(result + (long)ptr0);
            __dest = (void*)(result + 8L);
        }
        else if(!(long*)((ptr11 ? ptr11: 1L) + (long)ptr11)) {
            __dest = (void*)0x8;
            ptr1 = NULL;
            v0 = 0L;
        }
        else {
            ptr0 = (unsigned long*)(((unsigned long)(long*)((ptr11 ? ptr11: 1L) + (long)ptr11) <= 0xfffffffffffffffL ? (long*)((ptr11 ? ptr11: 1L) + (long)ptr11): 0xfffffffffffffffL) * 8L);
            goto loc_40428D;
        }
        result = *param2;
        *(unsigned long*)((long)param1 + v0) = *param2;
        if(__src != ptr8) {
            result = v0;
            param2 = ptr8;
            long* ptr13 = (long*)((long)(long*)((long)__src - (long)ptr8) + v0);
            do {
                param1 = *param2;
                result += 8L;
                ++param2;
                *(void**)(result - 8L) = param1;
            }
            while(result != ptr13);
            __dest = (void*)(ptr13 + 1);
        }
        if(__src != v18) {
            size_t __n = (size_t)(v18 - (long)__src);
            →memcpy(__dest, __src, __n);
            __dest = (void*)(result + __n);
        }
        vmovq(v5, v0);
        vpinsrd(v6, v5, __dest, 1);
        if(ptr8) {
            vmovdqa(*(__int128*)&ptr4, v6);
            →operator delete();
            vmovdqa(v6, *(__int128*)&ptr4);
        }
        vmovdqu(*(__int128*)param0, v6);
        *(param0 + 2) = ptr1;
        return result;
    }
    param0 = "vector::_M_realloc_insert";
    long* ptr14 = &ptr3;
    /*BAD_CALL!*/ →std::__throw_length_error();
}

// Package: std::vector<std::unique_ptr<std::thread, std::default_delete<std::thread> >, std::allocator<std::unique_ptr<std::thread, std::default_delete<std::thread> > > >

unsigned long* std::vector<std::unique_ptr<std::thread, std::default_delete<std::thread> >, std::allocator<std::unique_ptr<std::thread, std::default_delete<std::thread> > > >::_M_realloc_insert<std::unique_ptr<std::thread, std::default_delete<std::thread> > >(unsigned long* param0, void* param1, unsigned long* param2) {
    unsigned long* ptr0;
    unsigned long* ptr1;
    long* ptr2;
    void* __dest;
    long* ptr3;
    void* ptr4;
    long v0;
    long v1;
    unsigned long v2;
    void* ptr5;
    long v3;
    long v4;
    unsigned long* result;
    __int128 v5;
    __int128 v6;
    __int128 v7;
    unsigned long v8 = v2;
    long v9 = v0;
    long v10 = 0xfffffffffffffffL;
    long v11 = v3;
    long v12 = v1;
    long v13 = v4;
    long* ptr6 = &v13;
    char v14 = &ptr3 == 88L;
    char v15 = (long)&ptr5 < 0L;
    char v16 = __parity__((unsigned char)&ptr3 - 88);
    char v17 = (long*)((long)(long*)((long)(long*)((long)(long*)((long)&v13 ^ 0x28L) ^ (long)&ptr5) >>> 4L) & 0x1L);
    char v18 = (unsigned long)&v13 < 40L;
    char v19 = (long)(long*)((long)(long*)((long)&v13 ^ (long)&ptr5) & (long)(long*)((long)&v13 ^ 0x28L)) < 0L;
    unsigned long v20 = *(param0 + 1);
    unsigned long* ptr7 = *param0;
    unsigned long v21 = v20;
    unsigned long v22 = v20;
    long* ptr8 = (long*)(v21 - (long)ptr7);
    char v23 = ptr8 ? 0: 1;
    char v24 = (long)ptr8 < 0L;
    char v25 = __parity__((unsigned char)ptr8);
    char v26 = (long*)((long)(long*)((long)(long*)((long)(long*)((long)ptr7 ^ v22) ^ (long)ptr8) >>> 4L) & 0x1L);
    char v27 = (unsigned long)ptr7 > v22;
    char v28 = (long)(long*)((long)(long*)((long)ptr8 ^ v22) & (long)(long*)((long)ptr7 ^ v22)) < 0L;
    long* ptr9 = ptr8;
    long* ptr10 = (long*)((long)ptr8 >> 3);
    char v29 = (long*)((long)(long*)((long)ptr9 >>> 2L) & 0x1L);
    char v30 = v28;
    char v31 = ptr10 ? 0: 1;
    char v32 = (long)ptr10 < 0L;
    char v33 = __parity__((unsigned char)ptr10);
    char v34 = ptr10 == 0xfffffffffffffffL;
    char v35 = (long)ptr10 < 0xfffffffffffffffL;
    char v36 = __parity__((unsigned char)ptr10 - 0xff);
    char v37 = (unsigned long)ptr10 < 0xfffffffffffffffL;
    char v38 = (long)(long*)((long)(long*)((long)(long*)((char*)ptr10 - 0xfffffffffffffffL) ^ (long)ptr10) & (long)(long*)((long)ptr10 ^ 0xfffffffffffffffL)) < 0L;
    char v39 = (long*)((long)(long*)((long)(long*)((long)(long*)((char*)ptr10 - 0xfffffffffffffffL) ^ (long)(long*)((long)ptr10 ^ 0xfffffffffffffffL)) >>> 4L) & 0x1L);
    if(!v34) {
        void* __src = param1;
        unsigned long* ptr11 = param0;
        param1 = (void*)((long)param1 - (long)ptr7);
        if(__carry__(ptr10 ? ptr10: 1L, (long)ptr10)) {
            ptr0 = (unsigned long*)0x7FFFFFFFFFFFFFF8;
        loc_4040ED:
            unsigned long* ptr12 = param2;
            ptr5 = param1;
            →operator new();
            param1 = ptr5;
            param2 = ptr12;
            ptr1 = result;
            ptr2 = (long*)((long)result + (long)ptr0);
            __dest = (void*)(result + 1);
        }
        else if(!(long*)((ptr10 ? ptr10: 1L) + (long)ptr10)) {
            __dest = (void*)0x8;
            ptr2 = NULL;
            ptr1 = NULL;
        }
        else {
            ptr0 = (unsigned long*)(((unsigned long)(long*)((ptr10 ? ptr10: 1L) + (long)ptr10) <= 0xfffffffffffffffL ? (long*)((ptr10 ? ptr10: 1L) + (long)ptr10): 0xfffffffffffffffL) * 8L);
            goto loc_4040ED;
        }
        result = *param2;
        *param2 = 0L;
        *(unsigned long*)((long)param1 + (long)ptr1) = result;
        if(ptr7 != __src) {
            long* ptr13 = (long*)((long)__src - (long)ptr7);
            if((long*)(ptr7 + 1) != ptr1 && (unsigned long)(ptr13 - 1) > 16L) {
                unsigned long v40 = 0L;
                do {
                    vmovdqu(v5, *(__int128*)(v40 + (long)ptr7));
                    vmovdqu(*(__int128*)(v40 + (long)ptr1), v5);
                    v40 += 16L;
                }
                while((long*)((long)(long*)((long)(unsigned long*)((char*)((long)(ptr13 - 1) >>> 3) + 1L) >>> 1) * 16L) != v40);
                param1 = (void*)((long)(long*)((long)(unsigned long*)((long)(unsigned long*)((char*)((long)(ptr13 - 1) >>> 3) + 1L) & 0xfffffffffffffffeL) * 8L) + (long)ptr1);
                result = (unsigned long*)((long)(long*)((long)(unsigned long*)((long)(unsigned long*)((char*)((long)(ptr13 - 1) >>> 3) + 1L) & 0xfffffffffffffffeL) * 8L) + (long)ptr7);
                if((unsigned long*)((char*)((long)(ptr13 - 1) >>> 3) + 1L) != (unsigned long*)((long)(unsigned long*)((char*)((long)(ptr13 - 1) >>> 3) + 1L) & 0xfffffffffffffffeL)) {
                    result = *result;
                    *(unsigned long**)param1 = result;
                }
            }
            else {
                param0 = (unsigned long*)((long)ptr13 + (long)ptr1);
                param2 = ptr7;
                result = ptr1;
                do {
                    param1 = *param2;
                    ++result;
                    ++param2;
                    *(void**)(result - 1) = param1;
                }
                while(result != param0);
            }
            __dest = (void*)((long*)((long)ptr13 + (long)ptr1) + 1);
        }
        if(__src != v20) {
            size_t __n = (size_t)(v20 - (long)__src);
            →memcpy(__dest, __src, __n);
            __dest = (void*)((long)result + __n);
        }
        vmovq(v6, ptr1);
        vpinsrd(v7, v6, __dest, 1);
        if(ptr7) {
            vmovdqa(*(__int128*)&ptr5, v7);
            →operator delete();
            vmovdqa(v7, *(__int128*)&ptr5);
        }
        vmovdqu(*(__int128*)ptr11, v7);
        *(ptr11 + 2) = ptr2;
        return result;
    }
    param0 = "vector::_M_realloc_insert";
    long* ptr14 = &ptr4;
    /*BAD_CALL!*/ →std::__throw_length_error();
}

// Package: std::vector<std::unique_ptr<worker, std::default_delete<worker> >, std::allocator<std::unique_ptr<worker, std::default_delete<worker> > > >

unsigned long* std::vector<std::unique_ptr<worker, std::default_delete<worker> >, std::allocator<std::unique_ptr<worker, std::default_delete<worker> > > >::_M_realloc_insert<std::unique_ptr<worker, std::default_delete<worker> > >(void* param0, void* param1, void* param2) {
    void* ptr0;
    unsigned long* ptr1;
    long* ptr2;
    void* __dest;
    long* ptr3;
    void* ptr4;
    long v0;
    long v1;
    unsigned long v2;
    long* ptr5;
    long v3;
    long v4;
    unsigned long* result;
    __int128 v5;
    __int128 v6;
    __int128 v7;
    unsigned long v8 = v2;
    long v9 = v0;
    long v10 = 0xfffffffffffffffL;
    long v11 = v3;
    long v12 = v1;
    long v13 = v4;
    long* ptr6 = &v13;
    char v14 = &ptr3 == 88L;
    char v15 = (long)&ptr5 < 0L;
    char v16 = __parity__((unsigned char)&ptr3 - 88);
    char v17 = (long*)((long)(long*)((long)(long*)((long)(long*)((long)&v13 ^ 0x28L) ^ (long)&ptr5) >>> 4L) & 0x1L);
    char v18 = (unsigned long)&v13 < 40L;
    char v19 = (long)(long*)((long)(long*)((long)&v13 ^ (long)&ptr5) & (long)(long*)((long)&v13 ^ 0x28L)) < 0L;
    unsigned long v20 = *(unsigned long*)((long)param0 + 8L);
    void* ptr7 = *(void**)param0;
    unsigned long v21 = v20;
    unsigned long v22 = v20;
    long* ptr8 = (long*)(v21 - (long)ptr7);
    char v23 = ptr8 ? 0: 1;
    char v24 = (long)ptr8 < 0L;
    char v25 = __parity__((unsigned char)ptr8);
    char v26 = (long*)((long)(long*)((long)(long*)((long)(long*)((long)ptr7 ^ v22) ^ (long)ptr8) >>> 4L) & 0x1L);
    char v27 = (unsigned long)ptr7 > v22;
    char v28 = (long)(long*)((long)(long*)((long)ptr8 ^ v22) & (long)(long*)((long)ptr7 ^ v22)) < 0L;
    long* ptr9 = ptr8;
    long* ptr10 = (long*)((long)ptr8 >> 3);
    char v29 = (long*)((long)(long*)((long)ptr9 >>> 2L) & 0x1L);
    char v30 = v28;
    char v31 = ptr10 ? 0: 1;
    char v32 = (long)ptr10 < 0L;
    char v33 = __parity__((unsigned char)ptr10);
    char v34 = ptr10 == 0xfffffffffffffffL;
    char v35 = (long)ptr10 < 0xfffffffffffffffL;
    char v36 = __parity__((unsigned char)ptr10 - 0xff);
    char v37 = (unsigned long)ptr10 < 0xfffffffffffffffL;
    char v38 = (long)(long*)((long)(long*)((long)(long*)((char*)ptr10 - 0xfffffffffffffffL) ^ (long)ptr10) & (long)(long*)((long)ptr10 ^ 0xfffffffffffffffL)) < 0L;
    char v39 = (long*)((long)(long*)((long)(long*)((long)(long*)((char*)ptr10 - 0xfffffffffffffffL) ^ (long)(long*)((long)ptr10 ^ 0xfffffffffffffffL)) >>> 4L) & 0x1L);
    if(!v34) {
        void* __src = param1;
        param1 = param2;
        void* ptr11 = param0;
        long* ptr12 = (long*)((long)__src - (long)ptr7);
        if(__carry__(ptr10 ? ptr10: 1L, (long)ptr10)) {
            ptr0 = (void*)0x7FFFFFFFFFFFFFF8;
        loc_403EFD:
            void* ptr13 = param1;
            ptr5 = ptr12;
            →operator new();
            ptr12 = ptr5;
            param1 = ptr13;
            ptr1 = result;
            ptr2 = (long*)((long)result + (long)ptr0);
            __dest = (void*)(result + 1);
        }
        else if(!(long*)((ptr10 ? ptr10: 1L) + (long)ptr10)) {
            __dest = (void*)0x8;
            ptr2 = NULL;
            ptr1 = NULL;
        }
        else {
            ptr0 = (void*)(((unsigned long)(long*)((ptr10 ? ptr10: 1L) + (long)ptr10) <= 0xfffffffffffffffL ? (long*)((ptr10 ? ptr10: 1L) + (long)ptr10): 0xfffffffffffffffL) * 8L);
            goto loc_403EFD;
        }
        result = *(unsigned long**)param1;
        *(long*)param1 = 0L;
        *(unsigned long*)((long)ptr1 + (long)ptr12) = result;
        if(ptr7 != __src) {
            long* ptr14 = (long*)((long)__src - (long)ptr7);
            if((long*)((long)ptr7 + 8L) != ptr1 && (unsigned long)(ptr14 - 1) > 16L) {
                unsigned long v40 = 0L;
                do {
                    vmovdqu(v5, *(__int128*)(v40 + (long)ptr7));
                    vmovdqu(*(__int128*)(v40 + (long)ptr1), v5);
                    v40 += 16L;
                }
                while((long*)((long)(long*)((long)(void*)((char*)((long)(ptr14 - 1) >>> 3) + 1L) >>> 1) * 16L) != v40);
                param1 = (void*)((long)(long*)((long)(void*)((long)(void*)((char*)((long)(ptr14 - 1) >>> 3) + 1L) & 0xfffffffffffffffeL) * 8L) + (long)ptr1);
                result = (unsigned long*)((long)(long*)((long)(void*)((long)(void*)((char*)((long)(ptr14 - 1) >>> 3) + 1L) & 0xfffffffffffffffeL) * 8L) + (long)ptr7);
                if((void*)((char*)((long)(ptr14 - 1) >>> 3) + 1L) != (void*)((long)(void*)((char*)((long)(ptr14 - 1) >>> 3) + 1L) & 0xfffffffffffffffeL)) {
                    result = *result;
                    *(unsigned long**)param1 = result;
                }
            }
            else {
                param0 = (void*)((long)ptr14 + (long)ptr1);
                param2 = ptr7;
                result = ptr1;
                do {
                    param1 = *(void**)param2;
                    ++result;
                    param2 = (void*)((long)param2 + 8L);
                    *(void**)(result - 1) = param1;
                }
                while(result != param0);
            }
            __dest = (void*)((long*)((long)ptr14 + (long)ptr1) + 1);
        }
        if(__src != v20) {
            size_t __n = (size_t)(v20 - (long)__src);
            →memcpy(__dest, __src, __n);
            __dest = (void*)((long)result + __n);
        }
        vmovq(v7, ptr1);
        vpinsrd(v6, v7, __dest, 1);
        if(ptr7) {
            vmovdqa(*(__int128*)&ptr5, v6);
            →operator delete();
            vmovdqa(v6, *(__int128*)&ptr5);
        }
        vmovdqu(*(__int128*)ptr11, v6);
        *(unsigned long*)((long)ptr11 + 16L) = ptr2;
        return result;
    }
    param0 = "vector::_M_realloc_insert";
    long* ptr15 = &ptr4;
    /*BAD_CALL!*/ →std::__throw_length_error();
}

long sub_402026() {
    return gvar_407010();
}

long sub_402C1D() {
    return 0L;
}

long sub_402C5F() {
    return 0L;
}

long sub_402C8D() {
    long result = deregister_tm_clones();
    completed.0 = 1;
    return result;
}

void sub_402CA0() {
}

// Package: worker

long worker::loop(void* param0) {
    unsigned char* ptr0;
    unsigned long* ptr1;
    unsigned char* ptr2;
    unsigned char* ptr3;
    int v0;
    int v1;
    unsigned long* ptr4;
    unsigned long v2;
    char v3;
    char v4;
    char v5;
    long v6;
    unsigned long* ptr5;
    long v7;
    char v8;
    char v9;
    char v10;
    char v11;
    char v12;
    long v13;
    char v14;
    char v15;
    void* ptr6;
    long v16;
    char v17;
    pthread_mutex_t* ptr7;
    char v18;
    pthread_mutex_t* ptr8 = ptr7;
    unsigned long* ptr9 = ptr5;
    long v19 = v6;
    long v20 = v7;
    void* ptr10 = param0;
    pthread_mutex_t* ptr11 = (pthread_mutex_t*)((long)param0 + 64L);
    long v21 = v16;
    long v22 = &→__pthread_key_create;
    long* ptr12 = (long*)((long)param0 + 104L);
    size_t v23 = &v21;
    char v24 = &v5 == 88L;
    char v25 = (long)&v14 < 0L;
    char v26 = __parity__((unsigned char)&v5 - 88);
    char v27 = (long*)((long)(long*)((long)(long*)((long)(long*)(&v21 ^ 0x28L) ^ (long)&v14) >>> 4L) & 0x1L);
    char v28 = &v21 < 40L;
    char v29 = (long)(long*)((long)(long*)(&v21 ^ (long)&v14) & (long)(long*)(&v21 ^ 0x28L)) < 0L;
loc_402D10:
    do {
        do {
            pthread_mutex_t* ptr13 = ptr11;
            unsigned char v30 = 0;
            char v31 = 0;
            char v32 = 0;
            char v33 = 1;
            char v34 = 0;
            char v35 = 0;
            pthread_mutex_t* __mutex = ptr11;
            →pthread_mutex_lock(__mutex);
            char v36 = (unsigned int)v13 ? 0: 1;
            char v37 = (unsigned int)v13 < 0;
            char v38 = __parity__((unsigned char)v13);
            char v39 = 0;
            char v40 = 0;
            if(v36) {
                char v41 = *(long*)((long)ptr10 + 152L) ? 0: 1;
                char v42 = *(long*)((long)ptr10 + 152L) < 0L;
                char v43 = __parity__((unsigned char)*(long*)((long)ptr10 + 152L));
                char v44 = *(unsigned long*)((long)ptr10 + 152L) < 0L;
                char v45 = 0;
                char v46 = 0;
                v30 = 1;
                unsigned long* ptr14 = &ptr13;
                if(v41) {
                    do {
                        unsigned long* ptr15 = &ptr13;
                        long* ptr16 = ptr12;
                        →std::condition_variable::wait();
                        v8 = *(long*)((long)ptr10 + 152L) ? 0: 1;
                        char v47 = *(long*)((long)ptr10 + 152L) < 0L;
                        char v48 = __parity__((unsigned char)*(long*)((long)ptr10 + 152L));
                        char v49 = *(unsigned long*)((long)ptr10 + 152L) < 0L;
                        char v50 = 0;
                        char v51 = 0;
                    }
                    while(v8);
                }
                long v52 = 0x10000L;
                long v53 = 0x10000L;
                long v54 = 0x10000L - *(long*)((long)ptr10 + 160L);
                char v55 = v54 ? 0: 1;
                char v56 = v54 < 0L;
                char v57 = __parity__((unsigned char)v54);
                char v58 = (((*(long*)((long)ptr10 + 160L) ^ 0x10000L) ^ v54) >>> 4L) & 0x1L;
                char v59 = *(unsigned long*)((long)ptr10 + 160L) > 0x10000L;
                char v60 = ((*(long*)((long)ptr10 + 160L) ^ 0x10000L) & (v54 ^ 0x10000L)) < 0L;
                iovec* __iovec = (iovec*)((long)ptr10 + 152L);
                long v61 = 2L;
                long v62 = 1L;
                *(long*)((long)ptr10 + 176L) = v54;
                →writev(1L, __iovec, 2L);
                *(long*)((long)ptr10 + 152L) = 0L;
                char v63 = v30 ? 0: 1;
                char v64 = v30 >= 128;
                char v65 = __parity__(v30);
                char v66 = v30 < 0;
                char v67 = 0;
                char v68 = 0;
                if(!v63) {
                    pthread_mutex_t* __mutex1 = ptr13;
                    char v69 = __mutex1 ? 0: 1;
                    char v70 = (long)__mutex1 < 0L;
                    char v71 = __parity__((unsigned char)__mutex1);
                    char v72 = 0;
                    char v73 = 0;
                    if(!v69) {
                        char v74 = 0;
                        char v75 = 0;
                        char v76 = 1;
                        char v77 = 0;
                        char v78 = 0;
                        →pthread_mutex_unlock(__mutex1);
                    }
                }
                long* ptr17 = ptr12;
                →std::condition_variable::notify_one();
                size_t v79 = *(size_t*)ptr10;
                long v80 = *(long*)((long)ptr10 + 176L);
                ptr5 = (unsigned long*)(v79 + v80);
                v23 = v79;
                size_t v81 = (size_t)(*(long*)((long)ptr10 + 8L) + v79);
                char v82 = v81 ? 0: 1;
                char v83 = v81 >= 0x8000000000000000L;
                char v84 = __parity__((unsigned char)v81);
                char v85 = (long*)((long)(long*)((long)(long*)((long)(long*)(*(long*)((long)ptr10 + 8L) ^ v23) ^ v81) >>> 4L) & 0x1L);
                char v86 = __carry__(*(long*)((long)ptr10 + 8L), v23);
                char v87 = (long)(long*)((long)(long*)(v81 ^ v23) & (long*)~(long)(long*)(*(long*)((long)ptr10 + 8L) ^ v23)) < 0L;
                unsigned long* ptr18 = ptr5 + 0x2000;
                char v88 = v81 == ptr18;
                char v89 = (long)v81 > (long)ptr18;
                char v90 = __parity__((unsigned char)ptr18 - (unsigned char)v81);
                char v91 = v81 > (unsigned long)ptr18;
                char v92 = (long)(long*)((long)(long*)((long)(long*)((long)ptr18 - v81) ^ (long)ptr18) & (long)(long*)(v81 ^ (long)ptr18)) < 0L;
                v27 = (long*)((long)(long*)((long)(long*)((long)(long*)((long)ptr18 - v81) ^ (long)(long*)(v81 ^ (long)ptr18)) >>> 4L) & 0x1L);
                if(v91) {
                    unsigned long* ptr19 = ptr18;
                    do {
                        void* __buf = (void*)(ptr19 - 0x2000);
                        long v93 = 0x10000L;
                        long v94 = 1L;
                        ptr5 = ptr19;
                        →write(1L, __buf, 0x10000L);
                        long v95 = *(long*)((long)ptr10 + 8L);
                        ptr19 += 0x2000;
                        v81 = (size_t)(*(long*)ptr10 + v95);
                        v4 = v81 == ptr19;
                        char v96 = (long)v81 < (long)ptr19;
                        char v97 = __parity__((unsigned char)v81 - (unsigned char)ptr19);
                        v3 = v81 < (unsigned long)ptr19;
                        char v98 = (long)(long*)((long)(long*)((long)(long*)(v81 - (long)ptr19) ^ v81) & (long)(long*)(v81 ^ (long)ptr19)) < 0L;
                        v27 = (long*)((long)(long*)((long)(long*)((long)(long*)(v81 - (long)ptr19) ^ (long)(long*)(v81 ^ (long)ptr19)) >>> 4L) & 0x1L);
                    }
                    while(!v3 && !v4);
                }
                long v99 = *(long*)((long)ptr10 + 184L);
                ptr7 = (pthread_mutex_t*)(v99 + 64L);
                char v100 = 0;
                char v101 = 0;
                char v102 = 1;
                char v103 = 0;
                char v104 = 0;
                pthread_mutex_t* __mutex2 = ptr7;
                →pthread_mutex_lock(__mutex2);
                v36 = (unsigned int)v13 ? 0: 1;
                v37 = (unsigned int)v13 < 0;
                v38 = __parity__((unsigned char)v13);
                v39 = 0;
                v40 = 0;
                if(v36) {
                    long v105 = *(long*)((long)ptr10 + 8L);
                    long v106 = *(long*)((long)ptr10 + 8L);
                    v81 = (size_t)(*(long*)ptr10 + v105);
                    char v107 = v81 ? 0: 1;
                    char v108 = v81 >= 0x8000000000000000L;
                    char v109 = __parity__((unsigned char)v81);
                    char v110 = (long*)((long)(long*)((long)(long*)((*(long*)ptr10 ^ v106) ^ v81) >>> 4L) & 0x1L);
                    char v111 = __carry__(*(long*)ptr10, v106);
                    char v112 = (long)(long*)((long)(long*)(v81 ^ v106) & ~(*(long*)ptr10 ^ v106)) < 0L;
                    v99 = *(long*)((long)ptr10 + 184L);
                    v23 = v81;
                    long* ptr20 = (long*)(v81 - (long)ptr5);
                    char v113 = ptr20 ? 0: 1;
                    char v114 = (long)ptr20 < 0L;
                    char v115 = __parity__((unsigned char)ptr20);
                    v27 = (long*)((long)(long*)((long)(long*)((long)(long*)((long)ptr5 ^ v23) ^ (long)ptr20) >>> 4L) & 0x1L);
                    char v116 = (unsigned long)ptr5 > v23;
                    char v117 = (long)(long*)((long)(long*)((long)ptr20 ^ v23) & (long)(long*)((long)ptr5 ^ v23)) < 0L;
                    *(unsigned long*)(v99 + 152L) = ptr5;
                    *(unsigned long*)(v99 + 160L) = ptr20;
                    char v118 = 0;
                    char v119 = 0;
                    char v120 = 1;
                    char v121 = 0;
                    char v122 = 0;
                    pthread_mutex_t* __mutex3 = ptr7;
                    →pthread_mutex_unlock(__mutex3);
                    long v123 = *(long*)((long)ptr10 + 184L);
                    long v124 = v123 + 104L;
                    →std::condition_variable::notify_one();
                    long v125 = *(long*)((long)ptr10 + 184L);
                    v30 = 0;
                    pthread_mutex_t* __mutex4 = (pthread_mutex_t*)(v125 + 64L);
                    ptr13 = (pthread_mutex_t*)(v125 + 64L);
                    char v126 = 0;
                    char v127 = 0;
                    char v128 = 1;
                    char v129 = 0;
                    char v130 = 0;
                    →pthread_mutex_lock(__mutex4);
                    v36 = (unsigned int)v13 ? 0: 1;
                    v37 = (unsigned int)v13 < 0;
                    v38 = __parity__((unsigned char)v13);
                    v39 = 0;
                    v40 = 0;
                    if(v36) {
                        v125 = *(long*)((long)ptr10 + 184L);
                        char v131 = *(long*)(v125 + 152L) ? 0: 1;
                        char v132 = *(long*)(v125 + 152L) < 0L;
                        char v133 = __parity__((unsigned char)*(long*)(v125 + 152L));
                        char v134 = *(unsigned long*)(v125 + 152L) < 0L;
                        char v135 = 0;
                        char v136 = 0;
                        v30 = 1;
                        ptr7 = (pthread_mutex_t*)(v125 + 104L);
                        ptr5 = &ptr13;
                        if(!v131) {
                            do {
                                unsigned long* ptr21 = &ptr13;
                                pthread_mutex_t* ptr22 = ptr7;
                                →std::condition_variable::wait();
                                long v137 = *(long*)((long)ptr10 + 184L);
                                v9 = *(long*)(v137 + 152L) ? 0: 1;
                                char v138 = *(long*)(v137 + 152L) < 0L;
                                char v139 = __parity__((unsigned char)*(long*)(v137 + 152L));
                                char v140 = *(unsigned long*)(v137 + 152L) < 0L;
                                char v141 = 0;
                                char v142 = 0;
                            }
                            while(!v9);
                            char v143 = 0;
                            char v144 = 0;
                            char v145 = 0;
                            char v146 = 0;
                            char v147 = 0;
                            char v148 = 0;
                        }
                        pthread_mutex_t* __mutex5 = ptr13;
                        char v149 = __mutex5 ? 0: 1;
                        char v150 = (long)__mutex5 < 0L;
                        char v151 = __parity__((unsigned char)__mutex5);
                        char v152 = 0;
                        char v153 = 0;
                        if(!v149) {
                            char v154 = 0;
                            char v155 = 0;
                            char v156 = 1;
                            char v157 = 0;
                            char v158 = 0;
                            →pthread_mutex_unlock(__mutex5);
                        }
                        v2 = *(unsigned long*)((long)ptr10 + 40L);
                        ptr4 = *(unsigned long*)((long)ptr10 + 32L);
                        v1 = 0;
                        v0 = 0;
                        char v159 = ptr4 == v2;
                        char v160 = (long)ptr4 > (long)v2;
                        char v161 = __parity__((unsigned char)v2 - (unsigned char)ptr4);
                        char v162 = (unsigned long)ptr4 > v2;
                        char v163 = (long)(long*)((long)(long*)((long)(long*)(v2 - (long)ptr4) ^ v2) & (long)(long*)((long)ptr4 ^ v2)) < 0L;
                        v27 = (long*)((long)(long*)((long)(long*)((long)(long*)(v2 - (long)ptr4) ^ (long)(long*)((long)ptr4 ^ v2)) >>> 4L) & 0x1L);
                        if(v159) {
                            goto loc_402D10;
                        }
                        else {
                            break;
                        }
                    }
                }
            }
            long v164 = (unsigned long)(unsigned int)v13;
            long* ptr23 = &ptr6;
            /*BAD_CALL!*/ →std::__throw_system_error();
        }
        while(1);
        do {
            size_t v165 = *ptr4;
            char v166 = *(char*)(v165 - 2L) == 122;
            char v167 = *(char*)(v165 - 2L) < 122;
            char v168 = __parity__(*(char*)(v165 - 2L) - 122);
            char v169 = *(unsigned char*)(v165 - 2L) < 122;
            char v170 = (((*(char*)(v165 - 2L) - 122) ^ *(char*)(v165 - 2L)) & (*(char*)(v165 - 2L) ^ 0x7a)) < 0;
            char v171 = (((*(char*)(v165 - 2L) - 122) ^ (*(char*)(v165 - 2L) ^ 0x7a)) >>> 4) & 0x1;
            if(!v166) {
                unsigned long v172 = (unsigned long)*(int*)((long)ptr10 + 56L);
                v23 = v165;
                v165 -= v172;
                char v173 = v165 ? 0: 1;
                char v174 = v165 >= 0x8000000000000000L;
                char v175 = __parity__((unsigned char)v165);
                char v176 = (long*)((long)(long*)((long)(long*)((long)(long*)(v172 ^ v23) ^ v165) >>> 4L) & 0x1L);
                char v177 = v172 > v23;
                char v178 = (long)(long*)((long)(long*)(v172 ^ v23) & (long)(long*)(v165 ^ v23)) < 0L;
                char v179 = *(char*)((long)ptr10 + 60L);
                long v180 = (unsigned long)(*(char*)((long)ptr10 + 60L) + *(char*)v165);
                char v181 = *(char*)((long)ptr10 + 60L) + *(char*)v165 ? 0: 1;
                char v182 = (v180 >>> 7L) & 0x1L;
                char v183 = __parity__((unsigned char)v180);
                char v184 = (((*(char*)v165 ^ v179) ^ (unsigned char)v180) >>> 4) & 0x1;
                char v185 = __carry__(*(char*)v165, v179);
                char v186 = (((unsigned char)v180 ^ v179) & ~(*(char*)v165 ^ v179)) < 0;
                *(char*)v165 = (unsigned char)v180;
                char v187 = (unsigned char)v180 == 57;
                char v188 = (unsigned char)v180 < 57;
                char v189 = __parity__((unsigned char)v180 - 57);
                char v190 = (unsigned char)v180 < 57;
                char v191 = ((((unsigned char)v180 - 57) ^ (unsigned char)v180) & ((unsigned char)v180 ^ 0x39)) < 0;
                char v192 = ((((unsigned char)v180 - 57) ^ ((unsigned char)v180 ^ 0x39)) >>> 4) & 0x1;
                if(!v187 && v188 == v191) {
                    do {
                        --v165;
                        unsigned int v193 = (unsigned int)v180;
                        int v194 = (unsigned int)v180 - 10;
                        int v195 = 0;
                        char v196 = (unsigned int)v180 == 10;
                        char v197 = v194 < 0;
                        char v198 = __parity__((unsigned char)v194);
                        char v199 = (((v193 ^ 0xa) ^ v194) >>> 4) & 0x1;
                        char v200 = v193 < 10;
                        char v201 = ((v194 ^ v193) & (v193 ^ 0xa)) < 0;
                        *(char*)(v165 + 1L) = (unsigned char)v194;
                        long v202 = (unsigned long)*(char*)v165;
                        int v203 = (unsigned int)v202;
                        v180 = (unsigned long)((unsigned int)v202 + 1);
                        char v204 = (unsigned int)v202 + 1 ? 0: 1;
                        char v205 = (v180 >>> 31L) & 0x1L;
                        char v206 = __parity__((unsigned char)v180);
                        char v207 = (((v203 ^ 0x1) ^ (unsigned int)v180) >>> 4) & 0x1;
                        char v208 = (((unsigned int)v180 ^ v203) & ~(v203 ^ 0x1)) < 0;
                        *(char*)v165 = (unsigned char)v180;
                        v11 = (unsigned char)v180 == 57;
                        v10 = (unsigned char)v180 < 57;
                        char v209 = __parity__((unsigned char)v180 - 57);
                        char v210 = (unsigned char)v180 < 57;
                        v12 = ((((unsigned char)v180 - 57) ^ (unsigned char)v180) & ((unsigned char)v180 ^ 0x39)) < 0;
                        char v211 = ((((unsigned char)v180 - 57) ^ ((unsigned char)v180 ^ 0x39)) >>> 4) & 0x1;
                    }
                    while(!v11 && v10 == v12);
                }
                char v212 = (unsigned char)v180 == 11;
                char v213 = (unsigned char)v180 < 11;
                char v214 = __parity__((unsigned char)v180 - 11);
                char v215 = (unsigned char)v180 < 11;
                char v216 = ((((unsigned char)v180 - 11) ^ (unsigned char)v180) & ((unsigned char)v180 ^ 0xb)) < 0;
                char v217 = ((((unsigned char)v180 - 11) ^ ((unsigned char)v180 ^ 0xb)) >>> 4) & 0x1;
                v180 = (unsigned long)(v212 ? 1: 0) | ((unsigned long)((v180 >>> 8L) & 0xffffffffffffffL) << 8);
                int v218 = v212 ? 1: 0;
                int v219 = 0;
                int v220 = v1;
                v1 += v218;
                v0 = 0;
                char v221 = v1 ? 0: 1;
                char v222 = v1 < 0;
                char v223 = __parity__((unsigned char)v1);
                char v224 = (((v218 ^ v220) ^ v1) >>> 4) & 0x1;
                char v225 = __carry__(v218, v220);
                char v226 = ((v1 ^ v220) & ~(v218 ^ v220)) < 0;
            }
            ++ptr4;
            v15 = ptr4 == v2;
            char v227 = (long)ptr4 > (long)v2;
            char v228 = __parity__((unsigned char)v2 - (unsigned char)ptr4);
            char v229 = (unsigned long)ptr4 > v2;
            char v230 = (long)(long*)((long)(long*)((long)(long*)(v2 - (long)ptr4) ^ v2) & (long)(long*)((long)ptr4 ^ v2)) < 0L;
            v27 = (long*)((long)(long*)((long)(long*)((long)(long*)(v2 - (long)ptr4) ^ (long)(long*)((long)ptr4 ^ v2)) >>> 4L) & 0x1L);
        }
        while(!v15);
        char v231 = v1 ? 0: 1;
        char v232 = v1 < 0;
        char v233 = __parity__((unsigned char)v1);
        char v234 = 0;
        char v235 = 0;
        if(v231) {
            goto loc_402D10;
        }
        else {
            void* ptr24 = *(void**)((long)ptr10 + 8L);
            size_t __n = (size_t)v1;
            char v236 = 1;
            char v237 = 0;
            char v238 = 1;
            char v239 = 0;
            char v240 = 0;
            ptr5 = *(unsigned long*)((long)ptr10 + 40L);
            size_t v241 = __n;
            ptr7 = *(pthread_mutex_t**)ptr10;
            v23 = v241;
            long* ptr25 = (long*)(v241 + (long)ptr24);
            char v242 = ptr25 ? 0: 1;
            char v243 = (long)ptr25 < 0L;
            char v244 = __parity__((unsigned char)ptr25);
            char v245 = (long*)((long)(long*)((long)(long*)((long)(long*)((long)ptr24 ^ v23) ^ (long)ptr25) >>> 4L) & 0x1L);
            char v246 = (void*)__carry__((long)ptr24, v23);
            char v247 = (long)(long*)((long)(long*)((long)ptr25 ^ v23) & (long*)~(long)(long*)((long)ptr24 ^ v23)) < 0L;
            long v248 = v246 ? 1L: 0L;
            char v249 = ptr25 == ptr24;
            char v250 = (long)ptr25 < (long)ptr24;
            char v251 = __parity__((unsigned char)ptr25 - (unsigned char)ptr24);
            char v252 = (unsigned long)ptr25 < (unsigned long)ptr24;
            char v253 = (long)(long*)((long)(long*)((long)(long*)((long)ptr25 - (long)ptr24) ^ (long)ptr25) & (long)(long*)((long)ptr25 ^ (long)ptr24)) < 0L;
            char v254 = (long*)((long)(long*)((long)(long*)((long)(long*)((long)ptr25 - (long)ptr24) ^ (long)(long*)((long)ptr25 ^ (long)ptr24)) >>> 4L) & 0x1L);
            if((v252 || v249)) {
                ptr3 = (unsigned char*)((long)ptr24 + (long)ptr7);
                char v255 = v248 ? 0: 1;
                char v256 = v248 < 0L;
                char v257 = __parity__((unsigned char)v248);
                char v258 = 0;
                char v259 = 0;
                if(!v255) {
                    *(unsigned long*)((long)ptr10 + 8L) = ptr25;
                    *(char*)((long)ptr25 + (long)ptr7) = 0;
                    size_t v260 = *(size_t*)((long)ptr10 + 8L);
                    v23 = *(size_t*)((long)ptr10 + 8L);
                    ptr3 = (unsigned char*)(*(long*)ptr10 + v260);
                    char v261 = ptr3 ? 0: 1;
                    char v262 = (long)ptr3 < 0L;
                    char v263 = __parity__((unsigned char)ptr3);
                    char v264 = (long*)((long)(long*)((long)(long*)((*(long*)ptr10 ^ v23) ^ (long)ptr3) >>> 4L) & 0x1L);
                    char v265 = __carry__(*(long*)ptr10, v23);
                    char v266 = (long)(long*)((long)(long*)((long)ptr3 ^ v23) & ~(*(long*)ptr10 ^ v23)) < 0L;
                }
            }
            else {
                void* __src = ptr24;
                long v267 = 0L;
                long v268 = 0L;
                char v269 = 1;
                char v270 = 0;
                char v271 = 1;
                char v272 = 0;
                char v273 = 0;
                void* __dest1 = ptr10;
                void* ptr26 = ptr24;
                void* ptr27 = std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >::_M_replace_aux(__dest1, __src, 0L, __n, 0L);
                size_t v274 = *(size_t*)((long)ptr10 + 8L);
                ptr24 = ptr26;
                v23 = v274;
                ptr3 = (unsigned char*)(*(long*)ptr10 + v274);
                char v275 = ptr3 ? 0: 1;
                char v276 = (long)ptr3 < 0L;
                char v277 = __parity__((unsigned char)ptr3);
                char v278 = (long*)((long)(long*)((long)(long*)((*(long*)ptr10 ^ v23) ^ (long)ptr3) >>> 4L) & 0x1L);
                char v279 = __carry__(*(long*)ptr10, v23);
                char v280 = (long)(long*)((long)(long*)((long)ptr3 ^ v23) & ~(*(long*)ptr10 ^ v23)) < 0L;
            }
            ptr2 = ptr3 - 1L;
            size_t v281 = (size_t)((char*)((long)ptr24 + (long)ptr7) - 1L);
            char v282 = v281 == ptr2;
            char v283 = (long)v281 < (long)ptr2;
            char v284 = __parity__((unsigned char)v281 - (unsigned char)ptr2);
            char v285 = v281 < (unsigned long)ptr2;
            char v286 = (long)(long*)((long)(long*)((long)(long*)(v281 - (long)ptr2) ^ v281) & (long)(long*)(v281 ^ (long)ptr2)) < 0L;
            v27 = (long*)((long)(long*)((long)(long*)((long)(long*)(v281 - (long)ptr2) ^ (long)(long*)(v281 ^ (long)ptr2)) >>> 4L) & 0x1L);
            if(!v285) {
                goto loc_402D10;
            }
            else {
            loc_402F5D:
                while(1) {
                    unsigned char v287 = *(unsigned char*)v281;
                    long v288 = 0L;
                    char v289 = *(char*)v281 == 11;
                    char v290 = (char)v287 < 11;
                    char v291 = __parity__(v287 - 11);
                    char v292 = v287 < 11;
                    char v293 = (((v287 - 11) ^ v287) & (v287 ^ 0xb)) < 0;
                    char v294 = (((v287 - 11) ^ (v287 ^ 0xb)) >>> 4) & 0x1;
                    if(v289) {
                        *(char*)v281 = 10;
                        *(char*)(ptr3 - 1L) = 49;
                        v287 = *(unsigned char*)v281;
                        v288 = 0L;
                        ptr2 = ptr3 - 2L;
                    }
                    char v295 = v287 == 10;
                    char v296 = (char)v287 < 10;
                    char v297 = __parity__(v287 - 10);
                    char v298 = v287 < 10;
                    char v299 = (((v287 - 10) ^ v287) & (v287 ^ 0xa)) < 0;
                    char v300 = (((v287 - 10) ^ (v287 ^ 0xa)) >>> 4) & 0x1;
                    if(!v295) {
                        *ptr2 = v287;
                        v23 = v281;
                        --v281;
                        char v301 = v281 ? 0: 1;
                        char v302 = v281 >= 0x8000000000000000L;
                        char v303 = __parity__((unsigned char)v281);
                        char v304 = (((unsigned long)~v281 ^ (unsigned long)~v23) >>> 4L) & 0x1L;
                        char v305 = (long)((unsigned long)(v281 ^ v23) & v23) < 0L;
                        unsigned char* ptr28 = ptr2 - 1L;
                        char v306 = v281 == ptr28;
                        char v307 = (long)v281 > (long)ptr28;
                        char v308 = __parity__((unsigned char)ptr28 - (unsigned char)v281);
                        char v309 = v281 > (unsigned long)ptr28;
                        char v310 = (long)(long*)((long)(long*)((long)(long*)((long)ptr28 - v281) ^ (long)ptr28) & (long)(long*)(v281 ^ (long)ptr28)) < 0L;
                        v27 = (long*)((long)(long*)((long)(long*)((long)(long*)((long)ptr28 - v281) ^ (long)(long*)(v281 ^ (long)ptr28)) >>> 4L) & 0x1L);
                        if(v309 || v306) {
                            goto loc_402D10;
                        }
                        else {
                            ptr3 = ptr2;
                            ptr2 = ptr28;
                        }
                    }
                    else {
                        long* ptr29 = (long*)(ptr2 + 1L);
                        v23 = v281;
                        --v281;
                        char v311 = v281 ? 0: 1;
                        char v312 = v281 >= 0x8000000000000000L;
                        char v313 = __parity__((unsigned char)v281);
                        char v314 = (((unsigned long)~v281 ^ (unsigned long)~v23) >>> 4L) & 0x1L;
                        char v315 = (long)((unsigned long)(v281 ^ v23) & v23) < 0L;
                        ptr1 = ptr5 - 1;
                        *ptr5 = ptr29;
                        long v316 = (unsigned long)*(char*)(v281 + 1L);
                        *ptr2 = *(char*)(v281 + 1L);
                        ptr0 = ptr2 - 1L;
                        v18 = v281 == ptr0;
                        char v317 = (long)v281 > (long)ptr0;
                        char v318 = __parity__((unsigned char)ptr0 - (unsigned char)v281);
                        v17 = v281 > (unsigned long)ptr0;
                        char v319 = (long)(long*)((long)(long*)((long)(long*)((long)ptr0 - v281) ^ (long)ptr0) & (long)(long*)(v281 ^ (long)ptr0)) < 0L;
                        v27 = (long*)((long)(long*)((long)(long*)((long)(long*)((long)ptr0 - v281) ^ (long)(long*)(v281 ^ (long)ptr0)) >>> 4L) & 0x1L);
                    }
                }
            }
        }
    }
    while(v17 || v18);
    ptr5 = ptr1;
    ptr3 = ptr2;
    ptr2 = ptr0;
    goto loc_402F5D;
}

// Package: worker

void* worker::worker(void* param0, unsigned int param1, size_t __n1, void* param3, void* param4) {
    void* ptr0;
    char v0;
    char v1;
    unsigned long v2;
    size_t v3;
    void* ptr1;
    size_t v3;
    void* ptr1;
    unsigned int v4;
    void* ptr2;
    char v5;
    unsigned int v6;
    void* __s1;
    void* ptr3;
    size_t __n2;
    void* ptr4;
    void* ptr5;
    unsigned int v7;
    void* __src2;
    char v8;
    unsigned int v9;
    void* __s;
    void* ptr6;
    void* ptr7;
    size_t v10;
    void* ptr8;
    size_t v11;
    int v12;
    char v13;
    char v14;
    size_t v15;
    size_t v16;
    void* ptr9;
    __int128 v17;
    char v18;
    void* ptr10;
    int v19;
    long v20;
    void* ptr11;
    __int128 v21;
    char v22;
    char v23;
    int v24;
    void* result;
    long* ptr12;
    void* ptr13;
    char v25;
    char v26;
    char v27;
    __int128 v28;
    void* ptr14 = ptr11;
    vpxor(v28, v28, v28);
    size_t v29 = v15;
    long* ptr15 = (long*)((long)param0 + 16L);
    size_t v30 = v16;
    void* ptr16 = ptr9;
    void* ptr17 = param3;
    void* ptr18 = (unsigned long)param1 | ((unsigned long)v12 << 32);
    void* ptr19 = ptr10;
    void* ptr20 = param0;
    size_t v31 = __n1;
    long* ptr21 = &ptr19;
    char v32 = &v11 == 184L;
    char v33 = (long)&ptr12 < 0L;
    char v34 = __parity__((unsigned char)&v11 - 184);
    char v35 = (long*)((long)(long*)((long)(long*)((long)(long*)((long)&ptr19 ^ 0x88L) ^ (long)&ptr12) >>> 4L) & 0x1L);
    char v36 = (unsigned long)&ptr19 < 0x88L;
    char v37 = (long)(long*)((long)(long*)((long)&ptr19 ^ (long)&ptr12) & (long)(long*)((long)&ptr19 ^ 0x88L)) < 0L;
    vmovdqu(*(__int128*)((long)param0 + 32L), v28);
    vpxor(v28, v28, v28);
    *(long**)param0 = ptr15;
    ptr12 = ptr15;
    *(long*)((long)param0 + 8L) = 0L;
    unsigned long* ptr22 = (unsigned long*)((long)param0 + 32L);
    void* ptr23 = param0;
    long* ptr24 = (long*)((long)param0 + 104L);
    char v38 = ptr24 ? 0: 1;
    char v39 = (long)ptr24 < 0L;
    char v40 = __parity__((unsigned char)ptr24);
    char v41 = (long*)((long)(long*)((long)(long*)((long)(long*)((long)ptr23 ^ 0x68L) ^ (long)ptr24) >>> 4L) & 0x1L);
    char v42 = (unsigned long)ptr23 >= 18446744073709551512L;
    char v43 = (long)(long*)((long)(long*)((long)ptr24 ^ (long)ptr23) & (long*)~(long)(long*)((long)ptr23 ^ 0x68L)) < 0L;
    *(char*)(ptr24 - 11) = 0;
    *(ptr24 - 7) = 0L;
    *(int*)(ptr24 - 6) = 0;
    *(char*)((char*)ptr24 - 44L) = 0;
    vmovdqu(*(__int128*)(ptr24 - 5), v28);
    vmovdqu(*(__int128*)(ptr24 - 3), v28);
    *(ptr24 - 1) = 0L;
    unsigned long* ptr25 = ptr22;
    long* ptr26 = &ptr13;
    →std::condition_variable::condition_variable();
    *(long*)((long)ptr20 + 152L) = 0L;
    *(long*)((long)ptr20 + 160L) = 0L;
    *(long*)((long)ptr20 + 168L) = 0L;
    *(long*)((long)ptr20 + 176L) = 0L;
    *(long*)((long)ptr20 + 184L) = 0L;
    char v44 = ptr17 == 9L;
    char v45 = (long)ptr17 < 9L;
    char v46 = __parity__((unsigned char)ptr17 - 9);
    char v47 = (unsigned long)ptr17 < 9L;
    char v48 = (long)(long*)((long)(long*)((long)(long*)((long)ptr17 - 9L) ^ (long)ptr17) & (long)(long*)((long)ptr17 ^ 0x9L)) < 0L;
    char v49 = (long*)((long)(long*)((long)(long*)((long)(long*)((long)ptr17 - 9L) ^ (long)(long*)((long)ptr17 ^ 0x9L)) >>> 4L) & 0x1L);
    if(!v47 && !v44) {
        char v50 = ptr17 == 99L;
        char v51 = (long)ptr17 < 99L;
        char v52 = __parity__((unsigned char)ptr17 - 99);
        char v53 = (unsigned long)ptr17 < 99L;
        char v54 = (long)(long*)((long)(long*)((long)(long*)((long)ptr17 - 99L) ^ (long)ptr17) & (long)(long*)((long)ptr17 ^ 0x63L)) < 0L;
        char v55 = (long*)((long)(long*)((long)(long*)((long)(long*)((long)ptr17 - 99L) ^ (long)(long*)((long)ptr17 ^ 0x63L)) >>> 4L) & 0x1L);
        if(!v53 && !v50) {
            char v56 = ptr17 == 999L;
            char v57 = (long)ptr17 < 999L;
            char v58 = __parity__((unsigned char)ptr17 - 231);
            char v59 = (unsigned long)ptr17 < 999L;
            char v60 = (long)(long*)((long)(long*)((long)(long*)((long)ptr17 - 999L) ^ (long)ptr17) & (long)(long*)((long)ptr17 ^ 0x3e7L)) < 0L;
            char v61 = (long*)((long)(long*)((long)(long*)((long)(long*)((long)ptr17 - 999L) ^ (long)(long*)((long)ptr17 ^ 0x3e7L)) >>> 4L) & 0x1L);
            if(!v59 && !v56) {
                ptr8 = ptr17;
                param1 = 1;
                v12 = 0;
                long v62 = 3777893186295716171L;
                char v63 = ptr17 == 9999L;
                char v64 = (long)ptr17 < 9999L;
                char v65 = __parity__((unsigned char)ptr17 - 15);
                char v66 = (unsigned long)ptr17 < 9999L;
                char v67 = (long)(long*)((long)(long*)((long)(long*)((long)ptr17 - 9999L) ^ (long)ptr17) & (long)(long*)((long)ptr17 ^ 0x270fL)) < 0L;
                char v68 = (long*)((long)(long*)((long)(long*)((long)(long*)((long)ptr17 - 9999L) ^ (long)(long*)((long)ptr17 ^ 0x270fL)) >>> 4L) & 0x1L);
                if((v66 || v63)) {
                    void* ptr27 = &v23;
                    v10 = 4L;
                    ptr7 = &v23;
                    ptr6 = &v23;
                    __s = &v23;
                }
                else {
                    do {
                        void* ptr28 = ptr8;
                        void* ptr29 = ptr8;
                        void* ptr30 = ptr28;
                        long* ptr31 = (long*)((long)ptr28 * 3777893186295716171L);
                        long v69 = (unsigned long)(((unsigned __int128)ptr30 * 0x346DC5D63886594BX) >>> 0x40X);
                        char v70 = v69 ? 1: 0;
                        char v71 = v69 ? 1: 0;
                        v9 = param1;
                        int v72 = 0;
                        unsigned int v73 = param1;
                        param1 += 4;
                        v12 = 0;
                        char v74 = param1 ? 0: 1;
                        char v75 = (int)param1 < 0;
                        char v76 = __parity__((unsigned char)param1);
                        char v77 = (((v73 ^ 0x4) ^ param1) >>> 4) & 0x1;
                        char v78 = v73 >= 0xfffffffc;
                        char v79 = (int)((param1 ^ v73) & ~(v73 ^ 0x4)) < 0;
                        long v80 = v69;
                        ptr8 = (void*)(v69 >>> 11);
                        char v81 = (v80 >>> 10L) & 0x1L;
                        char v82 = v79;
                        char v83 = ptr8 ? 0: 1;
                        char v84 = (long)ptr8 < 0L;
                        char v85 = __parity__((unsigned char)ptr8);
                        char v86 = ptr29 == 99999L;
                        char v87 = (long)ptr29 < 99999L;
                        char v88 = __parity__((unsigned char)ptr29 - 159);
                        char v89 = (unsigned long)ptr29 < 99999L;
                        char v90 = (long)(long*)((long)(long*)((long)(long*)((long)ptr29 - 99999L) ^ (long)ptr29) & (long)(long*)((long)ptr29 ^ 0x1869fL)) < 0L;
                        char v91 = (long*)((long)(long*)((long)(long*)((long)(long*)((long)ptr29 - 99999L) ^ (long)(long*)((long)ptr29 ^ 0x1869fL)) >>> 4L) & 0x1L);
                        if(!v89 && !v86) {
                            char v92 = ptr29 == 999999L;
                            char v93 = (long)ptr29 < 999999L;
                            char v94 = __parity__((unsigned char)ptr29 - 63);
                            char v95 = (unsigned long)ptr29 < 999999L;
                            char v96 = (long)(long*)((long)(long*)((long)(long*)((long)ptr29 - 999999L) ^ (long)ptr29) & (long)(long*)((long)ptr29 ^ 0xf423fL)) < 0L;
                            char v97 = (long*)((long)(long*)((long)(long*)((long)(long*)((long)ptr29 - 999999L) ^ (long)(long*)((long)ptr29 ^ 0xf423fL)) >>> 4L) & 0x1L);
                            if(v95 || v92) {
                                v10 = (size_t)(v9 + 5);
                            loc_4031B5:
                                void* ptr32 = &v23;
                                ptr6 = &v23;
                                ptr7 = &v23;
                                char v98 = v10 == 15L;
                                char v99 = (long)v10 < 15L;
                                char v100 = __parity__((unsigned char)v10 - 15);
                                char v101 = v10 < 15L;
                                char v102 = (((v10 - 15L) ^ v10) & (v10 ^ 0xfL)) < 0L;
                                char v103 = (((v10 - 15L) ^ (v10 ^ 0xfL)) >>> 4L) & 0x1L;
                                if((v101 || v98)) {
                                    v8 = 0;
                                    if(!v10) {
                                        __src2 = &v23;
                                        *(long*)&v24 = 0L;
                                        v23 = 0;
                                        v7 = 0xffffffff;
                                        goto loc_4031ED;
                                    }
                                    else {
                                        char v104 = v10 == 1L;
                                        char v105 = (long)v10 < 1L;
                                        char v106 = __parity__((unsigned char)v10 - 1);
                                        char v107 = v10 < 1L;
                                        char v108 = (((v10 - 1L) ^ v10) & (v10 ^ 0x1L)) < 0L;
                                        char v109 = (((v10 - 1L) ^ (v10 ^ 0x1L)) >>> 4L) & 0x1L;
                                        if(v104) {
                                            goto loc_403A76;
                                        }
                                        else {
                                            __s = ptr6;
                                        }
                                    }
                                }
                                else {
                                    long v110 = v10 + 1L;
                                    →operator new();
                                    *(size_t*)&v23 = v10;
                                    __s = result;
                                    ptr7 = result;
                                }
                                goto loc_403976;
                            }
                            else {
                                char v111 = ptr29 == 9999999L;
                                char v112 = (long)ptr29 < 9999999L;
                                char v113 = __parity__((unsigned char)ptr29 - 127);
                                char v114 = (unsigned long)ptr29 < 9999999L;
                                char v115 = (long)(long*)((long)(long*)((long)(long*)((long)ptr29 - 9999999L) ^ (long)ptr29) & (long)(long*)((long)ptr29 ^ 0x98967fL)) < 0L;
                                char v116 = (long*)((long)(long*)((long)(long*)((long)(long*)((long)ptr29 - 9999999L) ^ (long)(long*)((long)ptr29 ^ 0x98967fL)) >>> 4L) & 0x1L);
                                if(v114 || v111) {
                                    v10 = (size_t)(v9 + 6);
                                }
                                else {
                                    v13 = ptr29 == 99999999L;
                                    char v117 = (long)ptr29 < 99999999L;
                                    char v118 = __parity__((unsigned char)ptr29 - 0xff);
                                    v14 = (unsigned long)ptr29 < 99999999L;
                                    char v119 = (long)(long*)((long)(long*)((long)(long*)((long)ptr29 - 99999999L) ^ (long)ptr29) & (long)(long*)((long)ptr29 ^ 0x5f5e0ffL)) < 0L;
                                    char v120 = (long*)((long)(long*)((long)(long*)((long)(long*)((long)ptr29 - 99999999L) ^ (long)(long*)((long)ptr29 ^ 0x5f5e0ffL)) >>> 4L) & 0x1L);
                                }
                            }
                        }
                        else {
                            v10 = (size_t)param1;
                        }
                        goto loc_4031B5;
                    }
                    while(v14 || v13);
                    v10 = (size_t)(v9 + 7);
                    goto loc_4031B5;
                }
                goto loc_403976;
            }
            else {
                void* ptr33 = &v23;
                v10 = 3L;
            }
        }
        else {
            void* ptr34 = &v23;
            v10 = 2L;
        }
        ptr7 = &v23;
        ptr6 = &v23;
        __s = &v23;
    loc_403976:
        size_t __n = v10;
        long v121 = 0L;
        char v122 = 1;
        char v123 = 0;
        char v124 = 1;
        char v125 = 0;
        char v126 = 0;
        ptr26 = &ptr13;
        →memset(__s, 0L, __n);
        ptr5 = ptr7;
        goto loc_403985;
    }
    else {
        void* ptr35 = &v23;
        ptr6 = &v23;
        ptr7 = &v23;
    loc_403A76:
        ptr5 = ptr6;
        v23 = 0;
        v10 = 1L;
    loc_403985:
        *(size_t*)&v24 = v10;
        *(char*)((long)ptr5 + v10) = 0;
        int v127 = v24;
        int v128 = 0;
        __src2 = ptr7;
        v7 = (unsigned int)(v127 - 1);
        int v129 = 0;
        char v130 = ptr17 == 99L;
        char v131 = (long)ptr17 < 99L;
        char v132 = __parity__((unsigned char)ptr17 - 99);
        char v133 = (unsigned long)ptr17 < 99L;
        v8 = (long)(long*)((long)(long*)((long)(long*)((long)ptr17 - 99L) ^ (long)ptr17) & (long)(long*)((long)ptr17 ^ 0x63L)) < 0L;
        char v134 = (long*)((long)(long*)((long)(long*)((long)(long*)((long)ptr17 - 99L) ^ (long)(long*)((long)ptr17 ^ 0x63L)) >>> 4L) & 0x1L);
        if(!v133 && !v130) {
        loc_4031ED:
            long v135 = 0x28f5c28f5c28f5c3L;
            do {
                void* ptr36 = ptr17;
                void* ptr37 = ptr17;
                long* ptr38 = (long*)((long)ptr36 >>> 2);
                char v136 = (long*)((long)(long*)((long)ptr37 >>> 1L) & 0x1L);
                char v137 = v8;
                char v138 = ptr38 ? 0: 1;
                char v139 = (long)ptr38 < 0L;
                char v140 = __parity__((unsigned char)ptr38);
                long* ptr39 = ptr38;
                long* ptr40 = ptr38;
                long* ptr41 = (long*)((long)ptr39 * 0x28f5c28f5c28f5c3L);
                long v141 = (unsigned long)(((unsigned __int128)ptr40 * 0x28F5C28F5C28F5C3X) >>> 0x40X);
                char v142 = v141 ? 1: 0;
                char v143 = v141 ? 1: 0;
                void* ptr42 = ptr17;
                long v144 = v141;
                void* ptr43 = (void*)(v141 >>> 2);
                char v145 = (v144 >>> 1L) & 0x1L;
                char v146 = v143;
                char v147 = ptr43 ? 0: 1;
                char v148 = (long)ptr43 < 0L;
                char v149 = __parity__((unsigned char)ptr43);
                void* ptr44 = param4;
                long* ptr45 = (long*)((long)ptr43 * 100L);
                void* ptr46 = ptr42;
                long* ptr47 = (long*)((long)ptr42 - (long)ptr45);
                char v150 = ptr47 ? 0: 1;
                char v151 = (long)ptr47 < 0L;
                char v152 = __parity__((unsigned char)ptr47);
                char v153 = (long*)((long)(long*)((long)(long*)((long)(long*)((long)ptr45 ^ (long)ptr46) ^ (long)ptr47) >>> 4L) & 0x1L);
                char v154 = (unsigned long)ptr45 > (unsigned long)ptr46;
                char v155 = (long)(long*)((long)(long*)((long)ptr47 ^ (long)ptr46) & (long)(long*)((long)ptr45 ^ (long)ptr46)) < 0L;
                param4 = ptr17;
                ptr17 = ptr43;
                long v156 = (unsigned long)v7;
                long* ptr48 = ptr47;
                long* ptr49 = (long*)((long)ptr47 * 2L);
                char v157 = ptr49 ? 0: 1;
                char v158 = (long)ptr49 < 0L;
                char v159 = __parity__((unsigned char)ptr49);
                char v160 = (long*)((long)(long*)((long)ptr49 >>> 4L) & 0x1L);
                char v161 = (long*)__carry__((long)ptr48, (long)ptr48);
                char v162 = (long)(long*)((long)ptr49 ^ (long)ptr48) < 0L;
                ptr4 = (void*)*(char*)((char*)ptr49 + &a001020304050607);
                char v163 = *(char*)(ptr49 + 526888);
                long v164 = 0L;
                *(char*)(v156 + (long)__src2) = (unsigned char)ptr4;
                ptr8 = (void*)(v7 - 1);
                unsigned int v165 = v7;
                v7 -= 2;
                v129 = 0;
                char v166 = v7 ? 0: 1;
                char v167 = v7 >= 0x80000000;
                char v168 = __parity__((unsigned char)v7);
                char v169 = (((v165 ^ 0x2) ^ v7) >>> 4) & 0x1;
                char v170 = v165 < 2;
                char v171 = (int)((v7 ^ v165) & (v165 ^ 0x2)) < 0;
                *(char*)((long)ptr8 + (long)__src2) = v163;
                v130 = param4 == 9999L;
                v131 = (long)param4 < 9999L;
                v132 = __parity__((unsigned char)param4 - 15);
                v133 = (unsigned long)param4 < 9999L;
                v8 = (long)(long*)((long)(long*)((long)(long*)((long)param4 - 9999L) ^ (long)param4) & (long)(long*)((long)param4 ^ 0x270fL)) < 0L;
                char v172 = (long*)((long)(long*)((long)(long*)((long)(long*)((long)param4 - 9999L) ^ (long)(long*)((long)param4 ^ 0x270fL)) >>> 4L) & 0x1L);
            }
            while(!v133 && !v130);
        }
    }
    long v173 = (unsigned long)((unsigned int)ptr17 + 48);
    char v174 = ptr17 == 9L;
    char v175 = (long)ptr17 < 9L;
    char v176 = __parity__((unsigned char)ptr17 - 9);
    char v177 = (unsigned long)ptr17 < 9L;
    char v178 = (long)(long*)((long)(long*)((long)(long*)((long)ptr17 - 9L) ^ (long)ptr17) & (long)(long*)((long)ptr17 ^ 0x9L)) < 0L;
    char v179 = (long*)((long)(long*)((long)(long*)((long)(long*)((long)ptr17 - 9L) ^ (long)(long*)((long)ptr17 ^ 0x9L)) >>> 4L) & 0x1L);
    if(!v177 && !v174) {
        void* ptr50 = ptr17;
        long* ptr51 = (long*)((long)ptr17 * 2L);
        char v180 = ptr51 ? 0: 1;
        char v181 = (long)ptr51 < 0L;
        char v182 = __parity__((unsigned char)ptr51);
        char v183 = (long*)((long)(long*)((long)ptr51 >>> 4L) & 0x1L);
        char v184 = (void*)__carry__((long)ptr50, (long)ptr50);
        char v185 = (long)(long*)((long)ptr51 ^ (long)ptr50) < 0L;
        long v186 = (unsigned long)*(char*)((char*)ptr51 + &a001020304050607);
        *(char*)((long)__src2 + 1L) = *(char*)((char*)ptr51 + &a001020304050607);
        v173 = (unsigned long)*(char*)(ptr51 + 526888);
    }
    *(char*)__src2 = (unsigned char)v173;
    int v187 = v24;
    int v188 = 0;
    void* ptr52 = ptr8;
    long v189 = v31 * 239L;
    char v190 = (__int128)v31 * 0xEFX != (__int128)v189;
    char v191 = (__int128)v31 * 0xEFX != (__int128)v189;
    param3 = (void*)0x8888888888888889;
    int v192 = v187;
    int v193 = v187 + 1;
    int v194 = 0;
    char v195 = v187 + 1 ? 0: 1;
    char v196 = v193 < 0;
    char v197 = __parity__((unsigned char)v193);
    char v198 = (((v192 ^ 0x1) ^ v193) >>> 4) & 0x1;
    char v199 = ((v193 ^ v192) & ~(v192 ^ 0x1)) < 0;
    *(int*)((long)ptr20 + 56L) = v193;
    void* ptr53 = ptr7;
    long v200 = (unsigned long)*(char*)ptr53;
    unsigned int v201 = (unsigned int)v200;
    int v202 = (unsigned int)v200 - 48;
    int v203 = 0;
    char v204 = (unsigned int)v200 == 48;
    char v205 = v202 < 0;
    char v206 = __parity__((unsigned char)v202);
    char v207 = (((v201 ^ 0x30) ^ v202) >>> 4) & 0x1;
    char v208 = v201 < 48;
    char v209 = ((v202 ^ v201) & (v201 ^ 0x30)) < 0;
    *(char*)((long)ptr20 + 60L) = (unsigned char)v202;
    long v210 = v189;
    long v211 = v189;
    long v212 = v210 * 0x8888888888888889L;
    long v213 = (unsigned long)(((unsigned __int128)v211 * 0x8888888888888889X) >>> 0x40X);
    char v214 = v213 ? 1: 0;
    char v215 = v213 ? 1: 0;
    long* ptr54 = ptr12;
    long v216 = v213;
    long v217 = v213 >>> 3;
    char v218 = (v216 >>> 2L) & 0x1L;
    char v219 = v215;
    char v220 = v217 ? 0: 1;
    char v221 = v217 < 0L;
    char v222 = __parity__((unsigned char)v217);
    __n1 = (size_t)(v217 + 1L);
    char v223 = *(long*)ptr20 == ptr54;
    char v224 = *(long*)ptr20 < (long)ptr54;
    char v225 = __parity__((unsigned char)*(long*)ptr20 - (unsigned char)ptr54);
    char v226 = *(unsigned long*)ptr20 < (unsigned long)ptr54;
    char v227 = (long)(long*)((long)(long*)((long)(long*)(*(long*)ptr20 - (long)ptr54) ^ *(long*)ptr20) & (long)(long*)(*(long*)ptr20 ^ (long)ptr54)) < 0L;
    char v228 = (long*)((long)(long*)((long)(long*)((long)(long*)(*(long*)ptr20 - (long)ptr54) ^ (long)(long*)(*(long*)ptr20 ^ (long)ptr54)) >>> 4L) & 0x1L);
    size_t v229 = !v223 ? *(size_t*)((long)ptr20 + 16L): 15L;
    char v230 = __n1 == v229;
    char v231 = (long)__n1 < (long)v229;
    char v232 = __parity__((unsigned char)__n1 - (unsigned char)v229);
    char v233 = __n1 < v229;
    char v234 = (long)(((unsigned long)(__n1 - v229) ^ __n1) & (unsigned long)(__n1 ^ v229)) < 0L;
    char v235 = (((unsigned long)(__n1 - v229) ^ (unsigned long)(__n1 ^ v229)) >>> 4L) & 0x1L;
    if(!v233 && !v230) {
        size_t v236 = v229 * 2L;
        char v237 = __n1 == v236;
        char v238 = (long)__n1 > (long)v236;
        char v239 = __parity__((unsigned char)v236 - (unsigned char)__n1);
        char v240 = __n1 > v236;
        char v241 = (long)(((unsigned long)(v236 - __n1) ^ v236) & (unsigned long)(__n1 ^ v236)) < 0L;
        char v242 = (((unsigned long)(v236 - __n1) ^ (unsigned long)(__n1 ^ v236)) >>> 4L) & 0x1L;
        v229 = v240 ? __n1: v236;
        long v243 = v229 + 1L;
        ptr26 = &ptr13;
        →operator new();
        ptr11 = *(void**)ptr20;
        v10 = (size_t)result;
        long v244 = *(long*)((long)ptr20 + 8L);
        __n1 = (size_t)(v244 + 1L);
        char v245 = v244 ? 0: 1;
        char v246 = v244 < 0L;
        char v247 = __parity__((unsigned char)v244);
        char v248 = 0;
        char v249 = 0;
        if(!v245) {
            char v250 = __n1 ? 0: 1;
            char v251 = __n1 >= 0x8000000000000000L;
            char v252 = __parity__((unsigned char)__n1);
            char v253 = 0;
            char v254 = 0;
            if(!v250) {
                void* __src = ptr11;
                void* __dest = (void*)v10;
                ptr26 = &ptr13;
                →memcpy(__dest, __src, __n1);
            }
        }
        else {
            long v255 = (unsigned long)*(char*)ptr11;
            *(char*)v10 = *(char*)ptr11;
        }
        v230 = ptr11 == ptr12;
        v231 = (long)ptr11 < (long)ptr12;
        v232 = __parity__((unsigned char)ptr11 - (unsigned char)ptr12);
        v233 = (unsigned long)ptr11 < (unsigned long)ptr12;
        v234 = (long)(long*)((long)(long*)((long)(long*)((long)ptr11 - (long)ptr12) ^ (long)ptr11) & (long)(long*)((long)ptr11 ^ (long)ptr12)) < 0L;
        v235 = (long*)((long)(long*)((long)(long*)((long)(long*)((long)ptr11 - (long)ptr12) ^ (long)(long*)((long)ptr11 ^ (long)ptr12)) >>> 4L) & 0x1L);
        if(!v230) {
            long v256 = *(long*)((long)ptr20 + 16L);
            void* ptr55 = ptr11;
            __src2 = (void*)(v256 + 1L);
            ptr26 = &ptr13;
            →operator delete();
        }
        *(size_t*)ptr20 = v10;
        *(size_t*)((long)ptr20 + 16L) = v229;
    }
    size_t v257 = v31;
    size_t v258 = v31;
    long v259 = (long)(v257 >>> 60);
    char v260 = (v258 >>> 59L) & 0x1L;
    char v261 = v234;
    char v262 = v259 ? 0: 1;
    char v263 = v259 < 0L;
    char v264 = __parity__((unsigned char)v259);
    if(v262) {
        size_t v265 = *(size_t*)((long)ptr20 + 32L);
        unsigned long v266 = *(unsigned long*)((long)ptr20 + 48L);
        unsigned long v267 = *(unsigned long*)((long)ptr20 + 48L);
        size_t v268 = (size_t)(v266 - v265);
        char v269 = v268 ? 0: 1;
        char v270 = v268 >= 0x8000000000000000L;
        char v271 = __parity__((unsigned char)v268);
        char v272 = (((unsigned long)(v265 ^ v267) ^ v268) >>> 4L) & 0x1L;
        char v273 = v265 > v267;
        char v274 = (long)((unsigned long)(v265 ^ v267) & (unsigned long)(v268 ^ v267)) < 0L;
        size_t v275 = v268;
        size_t v276 = v268;
        unsigned long v277 = (unsigned long)(v275 >> 3);
        char v278 = (v276 >>> 2L) & 0x1L;
        char v279 = v274;
        char v280 = v277 ? 0: 1;
        char v281 = v277 >= 0x8000000000000000L;
        char v282 = __parity__((unsigned char)v277);
        char v283 = v277 == v31;
        char v284 = (long)v277 > (long)v31;
        char v285 = __parity__((unsigned char)v31 - (unsigned char)v277);
        char v286 = v277 > v31;
        char v287 = (long)(((unsigned long)(v31 - v277) ^ v31) & (v277 ^ v31)) < 0L;
        char v288 = (((unsigned long)(v31 - v277) ^ (v277 ^ v31)) >>> 4L) & 0x1L;
        if(!v286 && !v283) {
            __src2 = *(void**)((long)ptr20 + 40L);
            long v289 = v31 * 8L;
            void* ptr56 = NULL;
            char v290 = 1;
            char v291 = 0;
            char v292 = 1;
            char v293 = 0;
            char v294 = 0;
            void* ptr57 = __src2;
            long* ptr58 = (long*)((long)ptr57 - v265);
            char v295 = v31 ? 0: 1;
            char v296 = v31 >= 0x8000000000000000L;
            char v297 = __parity__((unsigned char)v31);
            char v298 = 0;
            char v299 = 0;
            if(!v295) {
                long v300 = v289;
                ptr26 = &ptr13;
                →operator new();
                v265 = *(size_t*)((long)ptr20 + 32L);
                unsigned long v301 = *(unsigned long*)((long)ptr20 + 48L);
                __src2 = *(void**)((long)ptr20 + 40L);
                ptr56 = result;
                unsigned long v302 = v301;
                v268 = (size_t)(v301 - v265);
                char v303 = v268 ? 0: 1;
                char v304 = v268 >= 0x8000000000000000L;
                char v305 = __parity__((unsigned char)v268);
                char v306 = (((unsigned long)(v265 ^ v302) ^ v268) >>> 4L) & 0x1L;
                char v307 = v265 > v302;
                char v308 = (long)((unsigned long)(v265 ^ v302) & (unsigned long)(v268 ^ v302)) < 0L;
            }
            char v309 = __src2 == v265;
            char v310 = (long)__src2 > (long)v265;
            char v311 = __parity__((unsigned char)v265 - (unsigned char)__src2);
            char v312 = (unsigned long)__src2 > v265;
            char v313 = (long)(long*)((long)(long*)((long)(long*)(v265 - (long)__src2) ^ v265) & (long)(long*)((long)__src2 ^ v265)) < 0L;
            char v314 = (long*)((long)(long*)((long)(long*)((long)(long*)(v265 - (long)__src2) ^ (long)(long*)((long)__src2 ^ v265)) >>> 4L) & 0x1L);
            if(!v309) {
                void* ptr59 = __src2;
                long* ptr60 = (long*)((long)__src2 - v265);
                char v315 = ptr60 ? 0: 1;
                char v316 = (long)ptr60 < 0L;
                char v317 = __parity__((unsigned char)ptr60);
                char v318 = (long*)((long)(long*)((long)(long*)((long)(long*)(v265 ^ (long)ptr59) ^ (long)ptr60) >>> 4L) & 0x1L);
                char v319 = v265 > (unsigned long)ptr59;
                char v320 = (long)(long*)((long)(long*)((long)ptr60 ^ (long)ptr59) & (long)(long*)(v265 ^ (long)ptr59)) < 0L;
                void* ptr61 = ptr56;
                __n1 = v265;
                long* ptr62 = ptr60;
                __src2 = (void*)((long)ptr60 + (long)ptr56);
                char v321 = __src2 ? 0: 1;
                char v322 = (long)__src2 < 0L;
                char v323 = __parity__((unsigned char)__src2);
                char v324 = (long*)((long)(long*)((long)(long*)((long)(long*)((long)ptr56 ^ (long)ptr62) ^ (long)__src2) >>> 4L) & 0x1L);
                char v325 = (void*)__carry__((long)ptr56, (long)ptr62);
                char v326 = (long)(long*)((long)(long*)((long)__src2 ^ (long)ptr62) & (long*)~(long)(long*)((long)ptr56 ^ (long)ptr62)) < 0L;
                do {
                    param3 = *(void**)__n1;
                    ptr61 = (void*)((long)ptr61 + 8L);
                    size_t v327 = __n1;
                    __n1 += 8L;
                    char v328 = __n1 ? 0: 1;
                    char v329 = __n1 >= 0x8000000000000000L;
                    char v330 = __parity__((unsigned char)__n1);
                    char v331 = (((v327 ^ 0x8L) ^ __n1) >>> 4L) & 0x1L;
                    char v332 = v327 >= 18446744073709551608L;
                    char v333 = (long)((unsigned long)(__n1 ^ v327) & ~(v327 ^ 0x8L)) < 0L;
                    *(void**)((long)ptr61 - 8L) = param3;
                    v22 = ptr61 == __src2;
                    char v334 = (long)ptr61 < (long)__src2;
                    char v335 = __parity__((unsigned char)ptr61 - (unsigned char)__src2);
                    char v336 = ptr61 < __src2;
                    char v337 = (long)(long*)((long)(long*)((long)(long*)((long)ptr61 - (long)__src2) ^ (long)ptr61) & (long)(long*)((long)ptr61 ^ (long)__src2)) < 0L;
                    char v338 = (long*)((long)(long*)((long)(long*)((long)(long*)((long)ptr61 - (long)__src2) ^ (long)(long*)((long)ptr61 ^ (long)__src2)) >>> 4L) & 0x1L);
                }
                while(!v22);
            }
            char v339 = v265 ? 0: 1;
            char v340 = v265 >= 0x8000000000000000L;
            char v341 = __parity__((unsigned char)v265);
            char v342 = 0;
            char v343 = 0;
            if(!v339) {
                ptr26 = &ptr13;
                →operator delete();
            }
            long* ptr63 = ptr58;
            long* ptr64 = (long*)((long)ptr58 + (long)ptr56);
            char v344 = ptr64 ? 0: 1;
            char v345 = (long)ptr64 < 0L;
            char v346 = __parity__((unsigned char)ptr64);
            char v347 = (long*)((long)(long*)((long)(long*)((long)(long*)((long)ptr56 ^ (long)ptr63) ^ (long)ptr64) >>> 4L) & 0x1L);
            char v348 = (void*)__carry__((long)ptr56, (long)ptr63);
            char v349 = (long)(long*)((long)(long*)((long)ptr64 ^ (long)ptr63) & (long*)~(long)(long*)((long)ptr56 ^ (long)ptr63)) < 0L;
            vmovq(v17, ptr56);
            void* ptr65 = ptr56;
            ptr11 = (void*)(v289 + (long)ptr56);
            char v350 = ptr11 ? 0: 1;
            char v351 = (long)ptr11 < 0L;
            char v352 = __parity__((unsigned char)ptr11);
            char v353 = (long*)((long)(long*)((long)(long*)((long)(long*)(v289 ^ (long)ptr65) ^ (long)ptr11) >>> 4L) & 0x1L);
            char v354 = __carry__(v289, (long)ptr65);
            char v355 = (long)(long*)((long)(long*)((long)ptr11 ^ (long)ptr65) & (long*)~(long)(long*)(v289 ^ (long)ptr65)) < 0L;
            vpinsrd(v28, v17, ptr64, 1);
            *(void**)((long)ptr20 + 48L) = ptr11;
            vmovdqu(*(__int128*)((long)ptr20 + 32L), v28);
        }
        size_t v356 = v31;
        long* ptr66 = (long*)(v31 + (long)ptr18);
        char v357 = ptr66 ? 0: 1;
        char v358 = (long)ptr66 < 0L;
        char v359 = __parity__((unsigned char)ptr66);
        char v360 = (long*)((long)(long*)((long)(long*)((long)(long*)((long)ptr18 ^ v356) ^ (long)ptr66) >>> 4L) & 0x1L);
        char v361 = (void*)__carry__((long)ptr18, v356);
        char v362 = (long)(long*)((long)(long*)((long)ptr66 ^ v356) & (unsigned long)~(long)(long*)((long)ptr18 ^ v356)) < 0L;
        long v363 = 0xeeeeeeeeeeeeeeefL;
        long v364 = 0x1111111111111111L;
        char v365 = ptr66 == ptr18;
        char v366 = (long)ptr66 > (long)ptr18;
        char v367 = __parity__((unsigned char)ptr18 - (unsigned char)ptr66);
        char v368 = (unsigned long)ptr66 > (unsigned long)ptr18;
        char v369 = (long)(long*)((long)(long*)((long)(long*)((long)ptr18 - (long)ptr66) ^ (long)ptr18) & (long)(long*)((long)ptr66 ^ (long)ptr18)) < 0L;
        char v370 = (long*)((long)(long*)((long)(long*)((long)(long*)((long)ptr18 - (long)ptr66) ^ (long)(long*)((long)ptr66 ^ (long)ptr18)) >>> 4L) & 0x1L);
        if(v368) {
        loc_4033E0:
            do {
                void* ptr67 = ptr18;
                void* ptr68 = ptr18;
                long* ptr69 = (long*)((long)ptr67 * 0xeeeeeeeeeeeeeeefL);
                char v371 = ptr69 == 0x1111111111111111L;
                char v372 = (long)ptr69 < 0x1111111111111111L;
                char v373 = __parity__((unsigned char)ptr69 - 17);
                char v374 = (unsigned long)ptr69 < 0x1111111111111111L;
                char v375 = (long)(long*)((long)(long*)((long)(long*)((char*)ptr69 - 0x1111111111111111L) ^ (long)ptr69) & (long)(long*)((long)ptr69 ^ 0x1111111111111111L)) < 0L;
                char v376 = (long*)((long)(long*)((long)(long*)((long)(long*)((char*)ptr69 - 0x1111111111111111L) ^ (long)(long*)((long)ptr69 ^ 0x1111111111111111L)) >>> 4L) & 0x1L);
                if(!v374 && !v371) {
                    long v377 = 0xcccccccccccccccdL;
                    long v378 = 0x3333333333333333L;
                    long v379 = 0xcccccccccccccccdL;
                    long* ptr70 = (long*)((long)ptr18 * 0xcccccccccccccccdL);
                    char v380 = ptr70 == 0x3333333333333333L;
                    char v381 = (long)ptr70 < 0x3333333333333333L;
                    char v382 = __parity__((unsigned char)ptr70 - 51);
                    char v383 = (unsigned long)ptr70 < 0x3333333333333333L;
                    char v384 = (long)(long*)((long)(long*)((long)(long*)((char*)ptr70 - 0x3333333333333333L) ^ (long)ptr70) & (long)(long*)((long)ptr70 ^ 0x3333333333333333L)) < 0L;
                    char v385 = (long*)((long)(long*)((long)(long*)((long)(long*)((char*)ptr70 - 0x3333333333333333L) ^ (long)(long*)((long)ptr70 ^ 0x3333333333333333L)) >>> 4L) & 0x1L);
                    if(v383 || v380) {
                        __src2 = *(void**)((long)ptr20 + 8L);
                        long v386 = 0x7fffffffffffffffL;
                        long* ptr71 = (long*)(0x7fffffffffffffffL - (long)__src2);
                        char v387 = ptr71 == 4L;
                        char v388 = (long)ptr71 < 4L;
                        char v389 = __parity__((unsigned char)ptr71 - 4);
                        char v390 = (unsigned long)ptr71 < 4L;
                        char v391 = (long)(long*)((long)(long*)((long)(long*)((char*)ptr71 - 4L) ^ (long)ptr71) & (long)(long*)((long)ptr71 ^ 0x4L)) < 0L;
                        char v392 = (long*)((long)(long*)((long)(long*)((long)(long*)((char*)ptr71 - 4L) ^ (long)(long*)((long)ptr71 ^ 0x4L)) >>> 4L) & 0x1L);
                        if(v390 || v387) {
                            goto loc_403B4E;
                        }
                        else {
                            unsigned long v393 = *(unsigned long*)ptr20;
                            ptr11 = (void*)((long)__src2 + 5L);
                            char v394 = v393 == ptr12;
                            char v395 = (long)v393 > (long)ptr12;
                            char v396 = __parity__((unsigned char)ptr12 - (unsigned char)v393);
                            char v397 = v393 > (unsigned long)ptr12;
                            char v398 = (long)(long*)((long)(long*)((long)(long*)((long)ptr12 - v393) ^ (long)ptr12) & (long)(long*)(v393 ^ (long)ptr12)) < 0L;
                            char v399 = (long*)((long)(long*)((long)(long*)((long)(long*)((long)ptr12 - v393) ^ (long)(long*)(v393 ^ (long)ptr12)) >>> 4L) & 0x1L);
                            __n1 = !v394 ? *(size_t*)((long)ptr20 + 16L): 15L;
                            char v400 = __n1 == ptr11;
                            char v401 = (long)__n1 > (long)ptr11;
                            char v402 = __parity__((unsigned char)ptr11 - (unsigned char)__n1);
                            char v403 = __n1 > (unsigned long)ptr11;
                            char v404 = (long)(long*)((long)(long*)((long)(long*)((long)ptr11 - __n1) ^ (long)ptr11) & (long)(long*)(__n1 ^ (long)ptr11)) < 0L;
                            char v405 = (long*)((long)(long*)((long)(long*)((long)(long*)((long)ptr11 - __n1) ^ (long)(long*)(__n1 ^ (long)ptr11)) >>> 4L) & 0x1L);
                            if((v403 || v400)) {
                                unsigned long v406 = v393;
                                int* ptr72 = (int*)(v393 + (long)__src2);
                                char v407 = ptr72 ? 0: 1;
                                char v408 = (long)ptr72 < 0L;
                                char v409 = __parity__((unsigned char)ptr72);
                                char v410 = (long*)((long)(long*)((long)(long*)((long)(long*)((long)__src2 ^ v406) ^ (long)ptr72) >>> 4L) & 0x1L);
                                char v411 = (void*)__carry__((long)__src2, v406);
                                char v412 = (long)(long*)((long)(long*)((long)ptr72 ^ v406) & (long*)~(long)(long*)((long)__src2 ^ v406)) < 0L;
                                *ptr72 = 0x7a7a7542;
                                *(char*)(ptr72 + 1) = 10;
                            }
                            else {
                                long v413 = 5L;
                                long v414 = "Buzz\n";
                                long v415 = 0L;
                                char v416 = 1;
                                char v417 = 0;
                                char v418 = 1;
                                char v419 = 0;
                                char v420 = 0;
                                void* __dest1 = ptr20;
                                ptr26 = &ptr13;
                                std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >::_M_mutate(__dest1, __src2, 0L, (void*)"Buzz\n", 5L);
                            }
                        }
                        goto loc_403480;
                    }
                    else {
                        long v421 = 0xaaaaaaaaaaaaaaabL;
                        long v422 = 0x5555555555555555L;
                        long v423 = 0xaaaaaaaaaaaaaaabL;
                        long* ptr73 = (long*)((long)ptr18 * 0xaaaaaaaaaaaaaaabL);
                        char v424 = ptr73 == 0x5555555555555555L;
                        char v425 = (long)ptr73 < 0x5555555555555555L;
                        char v426 = __parity__((unsigned char)ptr73 - 85);
                        char v427 = (unsigned long)ptr73 < 0x5555555555555555L;
                        char v428 = (long)(long*)((long)(long*)((long)(long*)((char*)ptr73 - 0x5555555555555555L) ^ (long)ptr73) & (long)(long*)((long)ptr73 ^ 0x5555555555555555L)) < 0L;
                        char v429 = (long*)((long)(long*)((long)(long*)((long)(long*)((char*)ptr73 - 0x5555555555555555L) ^ (long)(long*)((long)ptr73 ^ 0x5555555555555555L)) >>> 4L) & 0x1L);
                        if(!v427 && !v424) {
                            char v430 = ptr18 == 9L;
                            char v431 = (long)ptr18 < 9L;
                            char v432 = __parity__((unsigned char)ptr18 - 9);
                            char v433 = (unsigned long)ptr18 < 9L;
                            char v434 = (long)(long*)((long)(long*)((long)(long*)((long)ptr18 - 9L) ^ (long)ptr18) & (long)(long*)((long)ptr18 ^ 0x9L)) < 0L;
                            char v435 = (long*)((long)(long*)((long)(long*)((long)(long*)((long)ptr18 - 9L) ^ (long)(long*)((long)ptr18 ^ 0x9L)) >>> 4L) & 0x1L);
                            if(!v433 && !v430) {
                                char v436 = ptr18 == 99L;
                                char v437 = (long)ptr18 < 99L;
                                char v438 = __parity__((unsigned char)ptr18 - 99);
                                char v439 = (unsigned long)ptr18 < 99L;
                                char v440 = (long)(long*)((long)(long*)((long)(long*)((long)ptr18 - 99L) ^ (long)ptr18) & (long)(long*)((long)ptr18 ^ 0x63L)) < 0L;
                                char v441 = (long*)((long)(long*)((long)(long*)((long)(long*)((long)ptr18 - 99L) ^ (long)(long*)((long)ptr18 ^ 0x63L)) >>> 4L) & 0x1L);
                                if(!v439 && !v436) {
                                    char v442 = ptr18 == 999L;
                                    char v443 = (long)ptr18 < 999L;
                                    char v444 = __parity__((unsigned char)ptr18 - 231);
                                    char v445 = (unsigned long)ptr18 < 999L;
                                    char v446 = (long)(long*)((long)(long*)((long)(long*)((long)ptr18 - 999L) ^ (long)ptr18) & (long)(long*)((long)ptr18 ^ 0x3e7L)) < 0L;
                                    char v447 = (long*)((long)(long*)((long)(long*)((long)(long*)((long)ptr18 - 999L) ^ (long)(long*)((long)ptr18 ^ 0x3e7L)) >>> 4L) & 0x1L);
                                    if(!v445 && !v442) {
                                        void* ptr74 = ptr18;
                                        unsigned int v448 = 1;
                                        int v449 = 0;
                                        long v450 = 3777893186295716171L;
                                        char v451 = ptr18 == 9999L;
                                        char v452 = (long)ptr18 < 9999L;
                                        char v453 = __parity__((unsigned char)ptr18 - 15);
                                        char v454 = (unsigned long)ptr18 < 9999L;
                                        char v455 = (long)(long*)((long)(long*)((long)(long*)((long)ptr18 - 9999L) ^ (long)ptr18) & (long)(long*)((long)ptr18 ^ 0x270fL)) < 0L;
                                        char v456 = (long*)((long)(long*)((long)(long*)((long)(long*)((long)ptr18 - 9999L) ^ (long)(long*)((long)ptr18 ^ 0x270fL)) >>> 4L) & 0x1L);
                                        if((v454 || v451)) {
                                            ptr11 = &v18;
                                            __n2 = 4L;
                                            ptr3 = &v18;
                                            __s1 = &v18;
                                        }
                                        else {
                                            do {
                                                void* ptr75 = ptr74;
                                                void* ptr76 = ptr74;
                                                void* ptr77 = ptr75;
                                                long* ptr78 = (long*)((long)ptr75 * 3777893186295716171L);
                                                long v457 = (unsigned long)(((unsigned __int128)ptr77 * 0x346DC5D63886594BX) >>> 0x40X);
                                                char v458 = v457 ? 1: 0;
                                                char v459 = v457 ? 1: 0;
                                                v6 = v448;
                                                int v460 = 0;
                                                v201 = v448;
                                                v448 += 4;
                                                v449 = 0;
                                                char v461 = v448 ? 0: 1;
                                                char v462 = v448 >= 0x80000000;
                                                char v463 = __parity__((unsigned char)v448);
                                                char v464 = (((v201 ^ 0x4) ^ v448) >>> 4) & 0x1;
                                                char v465 = v201 >= 0xfffffffc;
                                                char v466 = (int)((v448 ^ v201) & ~(v201 ^ 0x4)) < 0;
                                                long v467 = v457;
                                                ptr74 = (void*)(v457 >>> 11);
                                                char v468 = (v467 >>> 10L) & 0x1L;
                                                char v469 = v466;
                                                char v470 = ptr74 ? 0: 1;
                                                char v471 = (long)ptr74 < 0L;
                                                char v472 = __parity__((unsigned char)ptr74);
                                                char v473 = ptr76 == 99999L;
                                                char v474 = (long)ptr76 < 99999L;
                                                char v475 = __parity__((unsigned char)ptr76 - 159);
                                                char v476 = (unsigned long)ptr76 < 99999L;
                                                char v477 = (long)(long*)((long)(long*)((long)(long*)((long)ptr76 - 99999L) ^ (long)ptr76) & (long)(long*)((long)ptr76 ^ 0x1869fL)) < 0L;
                                                char v478 = (long*)((long)(long*)((long)(long*)((long)(long*)((long)ptr76 - 99999L) ^ (long)(long*)((long)ptr76 ^ 0x1869fL)) >>> 4L) & 0x1L);
                                                if(!v476 && !v473) {
                                                    char v479 = ptr76 == 999999L;
                                                    char v480 = (long)ptr76 < 999999L;
                                                    char v481 = __parity__((unsigned char)ptr76 - 63);
                                                    char v482 = (unsigned long)ptr76 < 999999L;
                                                    char v483 = (long)(long*)((long)(long*)((long)(long*)((long)ptr76 - 999999L) ^ (long)ptr76) & (long)(long*)((long)ptr76 ^ 0xf423fL)) < 0L;
                                                    char v484 = (long*)((long)(long*)((long)(long*)((long)(long*)((long)ptr76 - 999999L) ^ (long)(long*)((long)ptr76 ^ 0xf423fL)) >>> 4L) & 0x1L);
                                                    if(v482 || v479) {
                                                        __n2 = (size_t)(v6 + 5);
                                                    loc_4035F4:
                                                        ptr11 = &v18;
                                                        ptr3 = &v18;
                                                        char v485 = __n2 == 15L;
                                                        char v486 = (long)__n2 < 15L;
                                                        char v487 = __parity__((unsigned char)__n2 - 15);
                                                        char v488 = __n2 < 15L;
                                                        char v489 = (((__n2 - 15L) ^ __n2) & (__n2 ^ 0xfL)) < 0L;
                                                        char v490 = (((__n2 - 15L) ^ (__n2 ^ 0xfL)) >>> 4L) & 0x1L;
                                                        if((v488 || v485)) {
                                                            v5 = 0;
                                                            if(!__n2) {
                                                                *(long*)&v19 = 0L;
                                                                v18 = 0;
                                                                ptr2 = &v18;
                                                                v4 = 0xffffffff;
                                                                goto loc_403627;
                                                            }
                                                            else {
                                                                char v491 = __n2 == 1L;
                                                                char v492 = (long)__n2 < 1L;
                                                                char v493 = __parity__((unsigned char)__n2 - 1);
                                                                char v494 = __n2 < 1L;
                                                                char v495 = (((__n2 - 1L) ^ __n2) & (__n2 ^ 0x1L)) < 0L;
                                                                char v496 = (((__n2 - 1L) ^ (__n2 ^ 0x1L)) >>> 4L) & 0x1L;
                                                                if(!v491) {
                                                                    goto loc_403B58;
                                                                }
                                                                else {
                                                                    v18 = 0;
                                                                    ptr1 = &v18;
                                                                    v3 = 1L;
                                                                    goto loc_4038E6;
                                                                }
                                                            }
                                                        }
                                                        else {
                                                            long v497 = __n2 + 1L;
                                                            /*BAD_CALL!*/ →operator new();
                                                            __s1 = result;
                                                            ptr3 = result;
                                                            *(size_t*)&v18 = __n2;
                                                        }
                                                        goto loc_4038D0;
                                                    }
                                                    else {
                                                        char v498 = ptr76 == 9999999L;
                                                        char v499 = (long)ptr76 < 9999999L;
                                                        char v500 = __parity__((unsigned char)ptr76 - 127);
                                                        char v501 = (unsigned long)ptr76 < 9999999L;
                                                        char v502 = (long)(long*)((long)(long*)((long)(long*)((long)ptr76 - 9999999L) ^ (long)ptr76) & (long)(long*)((long)ptr76 ^ 0x98967fL)) < 0L;
                                                        char v503 = (long*)((long)(long*)((long)(long*)((long)(long*)((long)ptr76 - 9999999L) ^ (long)(long*)((long)ptr76 ^ 0x98967fL)) >>> 4L) & 0x1L);
                                                        if(v501 || v498) {
                                                            __n2 = (size_t)(v6 + 6);
                                                        }
                                                        else {
                                                            v26 = ptr76 == 99999999L;
                                                            char v504 = (long)ptr76 < 99999999L;
                                                            char v505 = __parity__((unsigned char)ptr76 - 0xff);
                                                            v27 = (unsigned long)ptr76 < 99999999L;
                                                            char v506 = (long)(long*)((long)(long*)((long)(long*)((long)ptr76 - 99999999L) ^ (long)ptr76) & (long)(long*)((long)ptr76 ^ 0x5f5e0ffL)) < 0L;
                                                            char v507 = (long*)((long)(long*)((long)(long*)((long)(long*)((long)ptr76 - 99999999L) ^ (long)(long*)((long)ptr76 ^ 0x5f5e0ffL)) >>> 4L) & 0x1L);
                                                        }
                                                    }
                                                }
                                                else {
                                                    __n2 = (size_t)v448;
                                                }
                                                goto loc_4035F4;
                                            }
                                            while(v27 || v26);
                                            __n2 = (size_t)(v6 + 7);
                                            goto loc_4035F4;
                                        }
                                        goto loc_4038D0;
                                    }
                                    else {
                                        ptr11 = &v18;
                                        __n2 = 3L;
                                    }
                                }
                                else {
                                    ptr11 = &v18;
                                    __n2 = 2L;
                                }
                                ptr3 = &v18;
                                __s1 = &v18;
                                goto loc_4038D0;
                            }
                            else {
                                ptr11 = &v18;
                                ptr3 = &v18;
                                v18 = 0;
                                ptr1 = &v18;
                                v3 = 1L;
                                goto loc_4038E6;
                            }
                        }
                        else {
                            __src2 = *(void**)((long)ptr20 + 8L);
                            long v508 = 0x7fffffffffffffffL;
                            long* ptr79 = (long*)(0x7fffffffffffffffL - (long)__src2);
                            char v509 = ptr79 == 4L;
                            char v510 = (long)ptr79 < 4L;
                            char v511 = __parity__((unsigned char)ptr79 - 4);
                            char v512 = (unsigned long)ptr79 < 4L;
                            char v513 = (long)(long*)((long)(long*)((long)(long*)((char*)ptr79 - 4L) ^ (long)ptr79) & (long)(long*)((long)ptr79 ^ 0x4L)) < 0L;
                            char v514 = (long*)((long)(long*)((long)(long*)((long)(long*)((char*)ptr79 - 4L) ^ (long)(long*)((long)ptr79 ^ 0x4L)) >>> 4L) & 0x1L);
                            if(v512 || v509) {
                                goto loc_403B4E;
                            }
                            else {
                                v2 = *(unsigned long*)ptr20;
                                ptr11 = (void*)((long)__src2 + 5L);
                                char v515 = v2 == ptr12;
                                char v516 = (long)v2 > (long)ptr12;
                                char v517 = __parity__((unsigned char)ptr12 - (unsigned char)v2);
                                char v518 = v2 > (unsigned long)ptr12;
                                char v519 = (long)(long*)((long)(long*)((long)(long*)((long)ptr12 - v2) ^ (long)ptr12) & (long)(long*)(v2 ^ (long)ptr12)) < 0L;
                                char v520 = (long*)((long)(long*)((long)(long*)((long)(long*)((long)ptr12 - v2) ^ (long)(long*)(v2 ^ (long)ptr12)) >>> 4L) & 0x1L);
                                __n1 = !v515 ? *(size_t*)((long)ptr20 + 16L): 15L;
                                v1 = __n1 == ptr11;
                                char v521 = (long)__n1 > (long)ptr11;
                                char v522 = __parity__((unsigned char)ptr11 - (unsigned char)__n1);
                                v0 = __n1 > (unsigned long)ptr11;
                                char v523 = (long)(long*)((long)(long*)((long)(long*)((long)ptr11 - __n1) ^ (long)ptr11) & (long)(long*)(__n1 ^ (long)ptr11)) < 0L;
                                char v524 = (long*)((long)(long*)((long)(long*)((long)(long*)((long)ptr11 - __n1) ^ (long)(long*)(__n1 ^ (long)ptr11)) >>> 4L) & 0x1L);
                            }
                        }
                    }
                    if((v0 || v1)) {
                        unsigned long v525 = v2;
                        int* ptr80 = (int*)(v2 + (long)__src2);
                        char v526 = ptr80 ? 0: 1;
                        char v527 = (long)ptr80 < 0L;
                        char v528 = __parity__((unsigned char)ptr80);
                        char v529 = (long*)((long)(long*)((long)(long*)((long)(long*)((long)__src2 ^ v525) ^ (long)ptr80) >>> 4L) & 0x1L);
                        char v530 = (void*)__carry__((long)__src2, v525);
                        char v531 = (long)(long*)((long)(long*)((long)ptr80 ^ v525) & (long*)~(long)(long*)((long)__src2 ^ v525)) < 0L;
                        *ptr80 = 0x7a7a6946;
                        *(char*)(ptr80 + 1) = 10;
                    }
                    else {
                        long v532 = 5L;
                        long v533 = "Fizz\n";
                        long v534 = 0L;
                        char v535 = 1;
                        char v536 = 0;
                        char v537 = 1;
                        char v538 = 0;
                        char v539 = 0;
                        void* __dest1_1 = ptr20;
                        ptr26 = &ptr13;
                        std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >::_M_mutate(__dest1_1, __src2, 0L, "Fizz\n", 5L);
                    }
                    goto loc_403480;
                }
                else {
                    __src2 = *(void**)((long)ptr20 + 8L);
                    long v540 = 0x7fffffffffffffffL;
                    long* ptr81 = (long*)(0x7fffffffffffffffL - (long)__src2);
                    char v541 = ptr81 == 8L;
                    char v542 = (long)ptr81 < 8L;
                    char v543 = __parity__((unsigned char)ptr81 - 8);
                    char v544 = (unsigned long)ptr81 < 8L;
                    char v545 = (long)(long*)((long)(long*)((long)(ptr81 - 1) ^ (long)ptr81) & (long)(long*)((long)ptr81 ^ 0x8L)) < 0L;
                    char v546 = (long*)((long)(long*)((long)(long*)((long)(ptr81 - 1) ^ (long)(long*)((long)ptr81 ^ 0x8L)) >>> 4L) & 0x1L);
                    if(!v544 && !v541) {
                        unsigned long v547 = *(unsigned long*)ptr20;
                        ptr11 = (void*)((long)__src2 + 9L);
                        char v548 = v547 == ptr12;
                        char v549 = (long)v547 > (long)ptr12;
                        char v550 = __parity__((unsigned char)ptr12 - (unsigned char)v547);
                        char v551 = v547 > (unsigned long)ptr12;
                        char v552 = (long)(long*)((long)(long*)((long)(long*)((long)ptr12 - v547) ^ (long)ptr12) & (long)(long*)(v547 ^ (long)ptr12)) < 0L;
                        char v553 = (long*)((long)(long*)((long)(long*)((long)(long*)((long)ptr12 - v547) ^ (long)(long*)(v547 ^ (long)ptr12)) >>> 4L) & 0x1L);
                        __n1 = !v548 ? *(size_t*)((long)ptr20 + 16L): 15L;
                        char v554 = __n1 == ptr11;
                        char v555 = (long)__n1 > (long)ptr11;
                        char v556 = __parity__((unsigned char)ptr11 - (unsigned char)__n1);
                        char v557 = __n1 > (unsigned long)ptr11;
                        char v558 = (long)(long*)((long)(long*)((long)(long*)((long)ptr11 - __n1) ^ (long)ptr11) & (long)(long*)(__n1 ^ (long)ptr11)) < 0L;
                        char v559 = (long*)((long)(long*)((long)(long*)((long)(long*)((long)ptr11 - __n1) ^ (long)(long*)(__n1 ^ (long)ptr11)) >>> 4L) & 0x1L);
                        if((v557 || v554)) {
                            unsigned long v560 = v547;
                            long* ptr82 = (long*)(v547 + (long)__src2);
                            char v561 = ptr82 ? 0: 1;
                            char v562 = (long)ptr82 < 0L;
                            char v563 = __parity__((unsigned char)ptr82);
                            char v564 = (long*)((long)(long*)((long)(long*)((long)(long*)((long)__src2 ^ v560) ^ (long)ptr82) >>> 4L) & 0x1L);
                            char v565 = (void*)__carry__((long)__src2, v560);
                            char v566 = (long)(long*)((long)(long*)((long)ptr82 ^ v560) & (long*)~(long)(long*)((long)__src2 ^ v560)) < 0L;
                            long v567 = 0x7a7a75427a7a6946L;
                            *ptr82 = 0x7a7a75427a7a6946L;
                            *(char*)(ptr82 + 1) = 10;
                        }
                        else {
                            long v568 = 9L;
                            long v569 = "FizzBuzz\n";
                            long v570 = 0L;
                            char v571 = 1;
                            char v572 = 0;
                            char v573 = 1;
                            char v574 = 0;
                            char v575 = 0;
                            void* __dest1_2 = ptr20;
                            ptr26 = &ptr13;
                            std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >::_M_mutate(__dest1_2, __src2, 0L, "FizzBuzz\n", 9L);
                        }
                    loc_403480:
                        *(void**)((long)ptr20 + 8L) = ptr11;
                        long v576 = *(long*)ptr20;
                        *(char*)(v576 + (long)ptr11) = 0;
                    }
                    else {
                    loc_403B4E:
                        long v577 = "basic_string::append";
                        →std::__throw_length_error();
                    loc_403B58:
                        __s1 = ptr11;
                    loc_4038D0:
                        long v578 = 0L;
                        char v579 = 1;
                        char v580 = 0;
                        char v581 = 1;
                        char v582 = 0;
                        char v583 = 0;
                        size_t v584 = __n2;
                        →memset(__s1, 0L, __n2);
                        ptr1 = ptr3;
                        v3 = v584;
                    loc_4038E6:
                        *(size_t*)&v19 = v3;
                        *(char*)((long)ptr1 + v3) = 0;
                        int v585 = v19;
                        int v586 = 0;
                        ptr2 = ptr3;
                        void* ptr83 = ptr18;
                        v4 = (unsigned int)(v585 - 1);
                        int v587 = 0;
                        char v588 = ptr18 == 99L;
                        char v589 = (long)ptr18 < 99L;
                        char v590 = __parity__((unsigned char)ptr18 - 99);
                        char v591 = (unsigned long)ptr18 < 99L;
                        v5 = (long)(long*)((long)(long*)((long)(long*)((long)ptr18 - 99L) ^ (long)ptr18) & (long)(long*)((long)ptr18 ^ 0x63L)) < 0L;
                        char v592 = (long*)((long)(long*)((long)(long*)((long)(long*)((long)ptr18 - 99L) ^ (long)(long*)((long)ptr18 ^ 0x63L)) >>> 4L) & 0x1L);
                        if(!v591 && !v588) {
                        loc_403627:
                            ptr83 = ptr18;
                            long v593 = 0x28f5c28f5c28f5c3L;
                            do {
                                void* ptr84 = ptr83;
                                void* ptr85 = ptr83;
                                long* ptr86 = (long*)((long)ptr84 >>> 2);
                                char v594 = (long*)((long)(long*)((long)ptr85 >>> 1L) & 0x1L);
                                char v595 = v5;
                                char v596 = ptr86 ? 0: 1;
                                char v597 = (long)ptr86 < 0L;
                                char v598 = __parity__((unsigned char)ptr86);
                                long* ptr87 = ptr86;
                                long* ptr88 = ptr86;
                                long* ptr89 = (long*)((long)ptr87 * 0x28f5c28f5c28f5c3L);
                                long v599 = (unsigned long)(((unsigned __int128)ptr88 * 0x28F5C28F5C28F5C3X) >>> 0x40X);
                                char v600 = v599 ? 1: 0;
                                char v601 = v599 ? 1: 0;
                                void* ptr90 = ptr83;
                                long v602 = v599;
                                void* ptr91 = (void*)(v599 >>> 2);
                                char v603 = (v602 >>> 1L) & 0x1L;
                                char v604 = v601;
                                char v605 = ptr91 ? 0: 1;
                                char v606 = (long)ptr91 < 0L;
                                char v607 = __parity__((unsigned char)ptr91);
                                void* ptr92 = ptr4;
                                long* ptr93 = (long*)((long)ptr91 * 100L);
                                void* ptr94 = ptr90;
                                long* ptr95 = (long*)((long)ptr90 - (long)ptr93);
                                char v608 = ptr95 ? 0: 1;
                                char v609 = (long)ptr95 < 0L;
                                char v610 = __parity__((unsigned char)ptr95);
                                char v611 = (long*)((long)(long*)((long)(long*)((long)(long*)((long)ptr93 ^ (long)ptr94) ^ (long)ptr95) >>> 4L) & 0x1L);
                                char v612 = (unsigned long)ptr93 > (unsigned long)ptr94;
                                char v613 = (long)(long*)((long)(long*)((long)ptr95 ^ (long)ptr94) & (long)(long*)((long)ptr93 ^ (long)ptr94)) < 0L;
                                ptr4 = ptr83;
                                ptr83 = ptr91;
                                long v614 = (unsigned long)v4;
                                long* ptr96 = ptr95;
                                long* ptr97 = (long*)((long)ptr95 * 2L);
                                char v615 = ptr97 ? 0: 1;
                                char v616 = (long)ptr97 < 0L;
                                char v617 = __parity__((unsigned char)ptr97);
                                char v618 = (long*)((long)(long*)((long)ptr97 >>> 4L) & 0x1L);
                                char v619 = (long*)__carry__((long)ptr96, (long)ptr96);
                                char v620 = (long)(long*)((long)ptr97 ^ (long)ptr96) < 0L;
                                char v621 = *(char*)((char*)ptr97 + &a001020304050607);
                                long v622 = 0L;
                                char v623 = *(char*)(ptr97 + 526888);
                                long v624 = 0L;
                                *(char*)(v614 + (long)ptr2) = v621;
                                v3 = (size_t)(v4 - 1);
                                v201 = v4;
                                v4 -= 2;
                                v587 = 0;
                                char v625 = v4 ? 0: 1;
                                char v626 = v4 >= 0x80000000;
                                char v627 = __parity__((unsigned char)v4);
                                char v628 = (((v201 ^ 0x2) ^ v4) >>> 4) & 0x1;
                                char v629 = v201 < 2;
                                char v630 = (int)((v4 ^ v201) & (v201 ^ 0x2)) < 0;
                                *(char*)(v3 + (long)ptr2) = v623;
                                v588 = ptr4 == 9999L;
                                v589 = (long)ptr4 < 9999L;
                                v590 = __parity__((unsigned char)ptr4 - 15);
                                v591 = (unsigned long)ptr4 < 9999L;
                                v5 = (long)(long*)((long)(long*)((long)(long*)((long)ptr4 - 9999L) ^ (long)ptr4) & (long)(long*)((long)ptr4 ^ 0x270fL)) < 0L;
                                char v631 = (long*)((long)(long*)((long)(long*)((long)(long*)((long)ptr4 - 9999L) ^ (long)(long*)((long)ptr4 ^ 0x270fL)) >>> 4L) & 0x1L);
                            }
                            while(!v591 && !v588);
                        }
                        long v632 = (unsigned long)((unsigned int)ptr83 + 48);
                        char v633 = ptr83 == 9L;
                        char v634 = (long)ptr83 < 9L;
                        char v635 = __parity__((unsigned char)ptr83 - 9);
                        char v636 = (unsigned long)ptr83 < 9L;
                        char v637 = (long)(long*)((long)(long*)((long)(long*)((long)ptr83 - 9L) ^ (long)ptr83) & (long)(long*)((long)ptr83 ^ 0x9L)) < 0L;
                        char v638 = (long*)((long)(long*)((long)(long*)((long)(long*)((long)ptr83 - 9L) ^ (long)(long*)((long)ptr83 ^ 0x9L)) >>> 4L) & 0x1L);
                        if(!v636 && !v633) {
                            void* ptr98 = ptr83;
                            long* ptr99 = (long*)((long)ptr83 * 2L);
                            char v639 = ptr99 ? 0: 1;
                            char v640 = (long)ptr99 < 0L;
                            char v641 = __parity__((unsigned char)ptr99);
                            char v642 = (long*)((long)(long*)((long)ptr99 >>> 4L) & 0x1L);
                            char v643 = (void*)__carry__((long)ptr98, (long)ptr98);
                            char v644 = (long)(long*)((long)ptr99 ^ (long)ptr98) < 0L;
                            long v645 = (unsigned long)*(char*)((char*)ptr99 + &a001020304050607);
                            *(char*)((long)ptr2 + 1L) = *(char*)((char*)ptr99 + &a001020304050607);
                            v632 = (unsigned long)*(char*)(ptr99 + 526888);
                        }
                        *(char*)ptr2 = (unsigned char)v632;
                        void* __src1 = *(void**)&v19;
                        long v646 = 1L;
                        long v647 = 0L;
                        char v648 = 1;
                        char v649 = 0;
                        char v650 = 1;
                        char v651 = 0;
                        char v652 = 0;
                        long v653 = 10L;
                        void* ptr100 = &ptr3;
                        ptr26 = &ptr13;
                        void* ptr101 = std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >::_M_replace_aux(&ptr3, __src1, 0L, 1L, 10L);
                        ptr4 = &v20;
                        void* ptr102 = &v20;
                        void* ptr103 = *(void**)ptr101;
                        __n1 = (size_t)((long)ptr101 + 16L);
                        char v654 = ptr103 == __n1;
                        char v655 = (long)ptr103 < (long)__n1;
                        char v656 = __parity__((unsigned char)ptr103 - (unsigned char)__n1);
                        char v657 = (unsigned long)ptr103 < __n1;
                        char v658 = (long)(long*)((long)(long*)((long)(long*)((long)ptr103 - __n1) ^ (long)ptr103) & (long)(long*)((long)ptr103 ^ __n1)) < 0L;
                        char v659 = (long*)((long)(long*)((long)(long*)((long)(long*)((long)ptr103 - __n1) ^ (long)(long*)((long)ptr103 ^ __n1)) >>> 4L) & 0x1L);
                        if(!v654) {
                            ptr102 = ptr103;
                            long v660 = *(long*)((long)ptr101 + 16L);
                            v20 = *(long*)((long)ptr101 + 16L);
                        }
                        else {
                            vmovdqu(v21, *(__int128*)((long)ptr101 + 16L));
                            vmovdqa(*(__int128*)&v20, v21);
                        }
                        size_t v661 = *(size_t*)((long)ptr101 + 8L);
                        *(char*)((long)ptr101 + 16L) = 0;
                        size_t v662 = v661;
                        *(long*)((long)ptr101 + 8L) = 0L;
                        v268 = v662;
                        void* __src2_1 = *(void**)((long)ptr20 + 8L);
                        *(size_t*)ptr101 = __n1;
                        param3 = ptr102;
                        unsigned long v663 = *(unsigned long*)ptr20;
                        size_t v664 = (size_t)((long)__src2_1 + v268);
                        char v665 = v663 == ptr12;
                        char v666 = (long)v663 > (long)ptr12;
                        char v667 = __parity__((unsigned char)ptr12 - (unsigned char)v663);
                        char v668 = v663 > (unsigned long)ptr12;
                        char v669 = (long)(long*)((long)(long*)((long)(long*)((long)ptr12 - v663) ^ (long)ptr12) & (long)(long*)(v663 ^ (long)ptr12)) < 0L;
                        char v670 = (long*)((long)(long*)((long)(long*)((long)(long*)((long)ptr12 - v663) ^ (long)(long*)(v663 ^ (long)ptr12)) >>> 4L) & 0x1L);
                        unsigned long v671 = !v665 ? *(unsigned long*)((long)ptr20 + 16L): 15L;
                        char v672 = v671 == v664;
                        char v673 = (long)v671 > (long)v664;
                        char v674 = __parity__((unsigned char)v664 - (unsigned char)v671);
                        char v675 = v671 > v664;
                        char v676 = (long)(long*)((long)(long*)((long)(long*)(v664 - v671) ^ v664) & (long)(long*)(v671 ^ v664)) < 0L;
                        char v677 = (long*)((long)(long*)((long)(long*)((long)(long*)(v664 - v671) ^ (long)(long*)(v671 ^ v664)) >>> 4L) & 0x1L);
                        if((v675 || v672)) {
                            char v678 = v268 ? 0: 1;
                            char v679 = v268 >= 0x8000000000000000L;
                            char v680 = __parity__((unsigned char)v268);
                            char v681 = 0;
                            char v682 = 0;
                            if(!v678) {
                                void* __dest2 = (void*)((long)__src2_1 + v663);
                                char v683 = v268 == 1L;
                                char v684 = (long)v268 < 1L;
                                char v685 = __parity__((unsigned char)v268 - 1);
                                char v686 = v268 < 1L;
                                char v687 = (((v268 - 1L) ^ v268) & (v268 ^ 0x1L)) < 0L;
                                char v688 = (((v268 - 1L) ^ (v268 ^ 0x1L)) >>> 4L) & 0x1L;
                                if(!v683) {
                                    size_t __n3 = v268;
                                    void* __src3 = param3;
                                    v584 = v664;
                                    ptr26 = &ptr13;
                                    →memcpy(__dest2, __src3, __n3);
                                    ptr4 = &v20;
                                    v663 = *(unsigned long*)ptr20;
                                    v664 = v584;
                                }
                                else {
                                    long v689 = (unsigned long)*(char*)param3;
                                    *(char*)__dest2 = *(char*)param3;
                                    v663 = *(unsigned long*)ptr20;
                                }
                            }
                        }
                        else {
                            void* __dest1_3 = ptr20;
                            long v690 = 0L;
                            char v691 = 1;
                            char v692 = 0;
                            char v693 = 1;
                            char v694 = 0;
                            char v695 = 0;
                            v584 = v664;
                            ptr26 = &ptr13;
                            std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >::_M_mutate(__dest1_3, __src2_1, 0L, param3, v268);
                            ptr4 = &v20;
                            v663 = *(unsigned long*)ptr20;
                            v664 = v584;
                        }
                        *(size_t*)((long)ptr20 + 8L) = v664;
                        *(char*)(v663 + v664) = 0;
                        void* ptr104 = ptr102;
                        char v696 = ptr104 == &v20;
                        char v697 = (long)ptr104 < (long)&v20;
                        char v698 = __parity__((unsigned char)ptr104 - (unsigned char)&v20);
                        char v699 = ptr104 < &v20;
                        char v700 = (long)(long*)((long)(long*)((long)(long*)((long)ptr104 - (long)&v20) ^ (long)ptr104) & (long)(long*)((long)ptr104 ^ (long)&v20)) < 0L;
                        char v701 = (long*)((long)(long*)((long)(long*)((long)(long*)((long)ptr104 - (long)&v20) ^ (long)(long*)((long)ptr104 ^ (long)&v20)) >>> 4L) & 0x1L);
                        if(!v696) {
                            long v702 = v20;
                            long v703 = v702 + 1L;
                            ptr26 = &ptr13;
                            →operator delete();
                        }
                        void* ptr105 = ptr3;
                        char v704 = ptr105 == ptr11;
                        char v705 = (long)ptr105 < (long)ptr11;
                        char v706 = __parity__((unsigned char)ptr105 - (unsigned char)ptr11);
                        char v707 = ptr105 < ptr11;
                        char v708 = (long)(long*)((long)(long*)((long)(long*)((long)ptr105 - (long)ptr11) ^ (long)ptr105) & (long)(long*)((long)ptr105 ^ (long)ptr11)) < 0L;
                        char v709 = (long*)((long)(long*)((long)(long*)((long)(long*)((long)ptr105 - (long)ptr11) ^ (long)(long*)((long)ptr105 ^ (long)ptr11)) >>> 4L) & 0x1L);
                        if(!v704) {
                            long v710 = *(long*)&v18;
                            long v711 = v710 + 1L;
                            ptr26 = &ptr13;
                            →operator delete();
                        }
                    }
                }
                long v712 = *(long*)((long)ptr20 + 8L);
                long v713 = *(long*)((long)ptr20 + 8L);
                void* ptr106 = (void*)(*(long*)ptr20 + v712);
                char v714 = ptr106 ? 0: 1;
                char v715 = (long)ptr106 < 0L;
                char v716 = __parity__((unsigned char)ptr106);
                char v717 = (long*)((long)(long*)((long)(long*)((*(long*)ptr20 ^ v713) ^ (long)ptr106) >>> 4L) & 0x1L);
                char v718 = __carry__(*(long*)ptr20, v713);
                char v719 = (long)(long*)((long)(long*)((long)ptr106 ^ v713) & ~(*(long*)ptr20 ^ v713)) < 0L;
                void* ptr107 = *(void**)((long)ptr20 + 40L);
                ptr3 = ptr106;
                char v720 = *(long*)((long)ptr20 + 48L) == ptr107;
                char v721 = *(long*)((long)ptr20 + 48L) > (long)ptr107;
                char v722 = __parity__((unsigned char)ptr107 - (unsigned char)*(long*)((long)ptr20 + 48L));
                char v723 = *(unsigned long*)((long)ptr20 + 48L) > (unsigned long)ptr107;
                char v724 = (long)(long*)((long)(long*)((long)(long*)((long)ptr107 - *(long*)((long)ptr20 + 48L)) ^ (long)ptr107) & (long)(long*)(*(long*)((long)ptr20 + 48L) ^ (long)ptr107)) < 0L;
                char v725 = (long*)((long)(long*)((long)(long*)((long)(long*)((long)ptr107 - *(long*)((long)ptr20 + 48L)) ^ (long)(long*)(*(long*)((long)ptr20 + 48L) ^ (long)ptr107)) >>> 4L) & 0x1L);
                if(!v720) {
                    *(void**)ptr107 = ptr106;
                    ptr18 = (void*)((long)ptr18 + 1L);
                    void* ptr108 = ptr107;
                    __src2 = (void*)((long)ptr107 + 8L);
                    char v726 = __src2 ? 0: 1;
                    char v727 = (long)__src2 < 0L;
                    char v728 = __parity__((unsigned char)__src2);
                    char v729 = (long*)((long)(long*)((long)(long*)((long)(long*)((long)ptr108 ^ 0x8L) ^ (long)__src2) >>> 4L) & 0x1L);
                    char v730 = (unsigned long)ptr108 >= 18446744073709551608L;
                    char v731 = (long)(long*)((long)(long*)((long)__src2 ^ (long)ptr108) & (long*)~(long)(long*)((long)ptr108 ^ 0x8L)) < 0L;
                    *(void**)((long)ptr20 + 40L) = __src2;
                    char v732 = ptr66 == ptr18;
                    char v733 = (long)ptr66 < (long)ptr18;
                    char v734 = __parity__((unsigned char)ptr66 - (unsigned char)ptr18);
                    char v735 = (unsigned long)ptr66 < (unsigned long)ptr18;
                    char v736 = (long)(long*)((long)(long*)((long)(long*)((long)ptr66 - (long)ptr18) ^ (long)ptr66) & (long)(long*)((long)ptr66 ^ (long)ptr18)) < 0L;
                    char v737 = (long*)((long)(long*)((long)(long*)((long)(long*)((long)ptr66 - (long)ptr18) ^ (long)(long*)((long)ptr66 ^ (long)ptr18)) >>> 4L) & 0x1L);
                    if(!v735 && !v732) {
                        goto loc_4033E0;
                    }
                    else {
                        break;
                    }
                }
                else {
                    unsigned long* ptr109 = ptr25;
                    void* ptr110 = &ptr3;
                    void* ptr111 = ptr18;
                    ptr18 = (void*)((long)ptr18 + 1L);
                    char v738 = ptr18 ? 0: 1;
                    char v739 = (long)ptr18 < 0L;
                    char v740 = __parity__((unsigned char)ptr18);
                    char v741 = (long*)((long)(long*)((long)(long*)((long)(long*)((long)ptr111 ^ 0x1L) ^ (long)ptr18) >>> 4L) & 0x1L);
                    char v742 = (long)(long*)((long)(long*)((long)ptr18 ^ (long)ptr111) & (long*)~(long)(long*)((long)ptr111 ^ 0x1L)) < 0L;
                    ptr26 = &ptr13;
                    std::vector<__gnu_cxx::__normal_iterator<char*, std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> > >, std::allocator<__gnu_cxx::__normal_iterator<char*, std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> > > > >::_M_realloc_insert<__gnu_cxx::__normal_iterator<char*, std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> > > >(ptr109, ptr107, (unsigned long*)&ptr3);
                    char v743 = ptr66 == ptr18;
                    char v744 = (long)ptr66 > (long)ptr18;
                    char v745 = __parity__((unsigned char)ptr18 - (unsigned char)ptr66);
                    v25 = (unsigned long)ptr66 > (unsigned long)ptr18;
                    char v746 = (long)(long*)((long)(long*)((long)(long*)((long)ptr18 - (long)ptr66) ^ (long)ptr18) & (long)(long*)((long)ptr66 ^ (long)ptr18)) < 0L;
                    char v747 = (long*)((long)(long*)((long)(long*)((long)(long*)((long)ptr18 - (long)ptr66) ^ (long)(long*)((long)ptr66 ^ (long)ptr18)) >>> 4L) & 0x1L);
                }
            }
            while(v25);
        }
        result = *(void**)ptr20;
        ptr0 = ptr7;
        *(void**)((long)ptr20 + 168L) = result;
        if(ptr0 != ptr6) {
            →operator delete();
        }
        return result;
    }
    ptr0 = "vector::reserve";
    ptr26 = &ptr13;
    /*BAD_CALL!*/ →std::__throw_length_error();
}

void →__cxa_atexit() {
    while(1) {
        /*BAD_CALL!*/ __cxa_atexit();
        unsigned long* ptr0 = ptr0 - 1;
        *ptr0 = 14L;
        --ptr0;
        *ptr0 = gvar_407008;
    }
}

long →__pthread_key_create() {
    return →__pthread_key_create();
}

void →get_nprocs() {
    while(1) {
        /*BAD_CALL!*/ get_nprocs();
        unsigned long* ptr0 = ptr0 - 1;
        *ptr0 = 0L;
        --ptr0;
        *ptr0 = gvar_407008;
    }
}

void →memcpy(void* __dest, void* __src, size_t __n) {
    while(1) {
        /*BAD_CALL!*/ memcpy(__dest, __src, __n);
        unsigned long* ptr0 = ptr0 - 1;
        *ptr0 = 13L;
        --ptr0;
        *ptr0 = gvar_407008;
    }
}

void →memmove(void* __dest, void* __src, size_t __n) {
    while(1) {
        /*BAD_CALL!*/ memmove(__dest, __src, __n);
        unsigned long* ptr0 = ptr0 - 1;
        *ptr0 = 24L;
        --ptr0;
        *ptr0 = gvar_407008;
    }
}

void →memset(void* __s, long param1, size_t __n) {
    while(1) {
        /*BAD_CALL!*/ memset(__s, (int)param1, __n);
        unsigned long* ptr0 = ptr0 - 1;
        *ptr0 = 8L;
        --ptr0;
        *ptr0 = gvar_407008;
    }
}

void →operator delete() {
    while(1) {
        /*BAD_CALL!*/ operator delete();
        unsigned long* ptr0 = ptr0 - 1;
        *ptr0 = 17L;
        --ptr0;
        *ptr0 = gvar_407008;
    }
}

void →operator new() {
    while(1) {
        /*BAD_CALL!*/ operator new();
        unsigned long* ptr0 = ptr0 - 1;
        *ptr0 = 16L;
        --ptr0;
        *ptr0 = gvar_407008;
    }
}

int →pthread_create(pthread_t* __newthread, pthread_attr_t* __attr, FUNCPTR __start_routine, void* __arg) {
    return →pthread_create(__newthread, __attr, __start_routine, __arg);
}

void →pthread_mutex_lock(pthread_mutex_t* __mutex) {
    while(1) {
        /*BAD_CALL!*/ pthread_mutex_lock(__mutex);
        unsigned long* ptr0 = ptr0 - 1;
        *ptr0 = 20L;
        --ptr0;
        *ptr0 = gvar_407008;
    }
}

void →pthread_mutex_unlock(pthread_mutex_t* __mutex) {
    while(1) {
        /*BAD_CALL!*/ pthread_mutex_unlock(__mutex);
        unsigned long* ptr0 = ptr0 - 1;
        *ptr0 = 12L;
        --ptr0;
        *ptr0 = gvar_407008;
    }
}

void →snprintf(char* __s, size_t __maxlen, char* __format) {
    while(1) {
        /*BAD_CALL!*/ snprintf(__s, __maxlen, __format);
        unsigned long* ptr0 = ptr0 - 1;
        *ptr0 = 23L;
        --ptr0;
        *ptr0 = gvar_407008;
    }
}

void →std::__ostream_insert<char, std::char_traits<char> >() {
    while(1) {
        /*BAD_CALL!*/ std::__ostream_insert<char, std::char_traits<char> >();
        unsigned long* ptr0 = ptr0 - 1;
        *ptr0 = 18L;
        --ptr0;
        *ptr0 = gvar_407008;
    }
}

void →std::__throw_bad_alloc() {
    while(1) {
        /*BAD_CALL!*/ std::__throw_bad_alloc();
        unsigned long* ptr0 = ptr0 - 1;
        *ptr0 = 3L;
        --ptr0;
        *ptr0 = gvar_407008;
    }
}

void →std::__throw_length_error() {
    while(1) {
        /*BAD_CALL!*/ std::__throw_length_error();
        unsigned long* ptr0 = ptr0 - 1;
        *ptr0 = 6L;
        --ptr0;
        *ptr0 = gvar_407008;
    }
}

void →std::__throw_system_error() {
    while(1) {
        /*BAD_CALL!*/ std::__throw_system_error();
        unsigned long* ptr0 = ptr0 - 1;
        *ptr0 = 10L;
        --ptr0;
        *ptr0 = gvar_407008;
    }
}

void →std::condition_variable::condition_variable() {
    while(1) {
        /*BAD_CALL!*/ std::condition_variable::condition_variable();
        unsigned long* ptr0 = ptr0 - 1;
        *ptr0 = 19L;
        --ptr0;
        *ptr0 = gvar_407008;
    }
}

void →std::condition_variable::notify_one() {
    while(1) {
        /*BAD_CALL!*/ std::condition_variable::notify_one();
        unsigned long* ptr0 = ptr0 - 1;
        *ptr0 = 5L;
        --ptr0;
        *ptr0 = gvar_407008;
    }
}

void →std::condition_variable::wait() {
    while(1) {
        /*BAD_CALL!*/ std::condition_variable::wait();
        unsigned long* ptr0 = ptr0 - 1;
        *ptr0 = 22L;
        --ptr0;
        *ptr0 = gvar_407008;
    }
}

void →std::condition_variable::~condition_variable() {
    while(1) {
        /*BAD_CALL!*/ std::condition_variable::~condition_variable();
        unsigned long* ptr0 = ptr0 - 1;
        *ptr0 = 28L;
        --ptr0;
        *ptr0 = gvar_407008;
    }
}

void →std::ios_base::Init::Init() {
    while(1) {
        /*BAD_CALL!*/ std::ios_base::Init::Init();
        unsigned long* ptr0 = ptr0 - 1;
        *ptr0 = 21L;
        --ptr0;
        *ptr0 = gvar_407008;
    }
}

long →std::ios_base::Init::~Init() {
    return →std::ios_base::Init::~Init();
}

void →std::ostream::flush() {
    while(1) {
        /*BAD_CALL!*/ std::ostream::flush();
        unsigned long* ptr0 = ptr0 - 1;
        *ptr0 = 11L;
        --ptr0;
        *ptr0 = gvar_407008;
    }
}

void →std::ostream::operator<<() {
    while(1) {
        /*BAD_CALL!*/ std::ostream::operator<<();
        unsigned long* ptr0 = ptr0 - 1;
        *ptr0 = 27L;
        --ptr0;
        *ptr0 = gvar_407008;
    }
}

void →std::terminate() {
    while(1) {
        /*NO_RETURN*/ std::terminate();
        unsigned long* ptr0 = ptr0 - 1;
        *ptr0 = 1L;
        --ptr0;
        *ptr0 = gvar_407008;
    }
}

void →std::thread::_M_start_thread() {
    while(1) {
        /*BAD_CALL!*/ std::thread::_M_start_thread();
        unsigned long* ptr0 = ptr0 - 1;
        *ptr0 = 15L;
        --ptr0;
        *ptr0 = gvar_407008;
    }
}

void →std::thread::_State::~_State() {
    while(1) {
        /*BAD_CALL!*/ std::thread::_State::~_State();
        unsigned long* ptr0 = ptr0 - 1;
        *ptr0 = 4L;
        --ptr0;
        *ptr0 = gvar_407008;
    }
}

void →std::thread::join() {
    while(1) {
        /*BAD_CALL!*/ std::thread::join();
        unsigned long* ptr0 = ptr0 - 1;
        *ptr0 = 26L;
        --ptr0;
        *ptr0 = gvar_407008;
    }
}

void →write(long param0, void* __buf, size_t __n) {
    while(1) {
        /*BAD_CALL!*/ write((int)param0, __buf, __n);
        unsigned long* ptr0 = ptr0 - 1;
        *ptr0 = 2L;
        --ptr0;
        *ptr0 = gvar_407008;
    }
}

void →writev(long param0, iovec* __iovec, long param2) {
    while(1) {
        /*BAD_CALL!*/ writev((int)param0, __iovec, (int)param2);
        unsigned long* ptr0 = ptr0 - 1;
        *ptr0 = 7L;
        --ptr0;
        *ptr0 = gvar_407008;
    }
}
