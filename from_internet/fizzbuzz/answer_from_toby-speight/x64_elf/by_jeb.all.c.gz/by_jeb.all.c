
void __libc_csu_fini() {
}

void* __libc_csu_init(long param0, long param1, long param2) {
    void* result;
    initializer_0();
    unsigned long v0 = 0L;
    do {
        result = (void*)*(long*)(v0 * 8L + (long)&__frame_dummy_init_array_entry){initializer_1}();
        ++v0;
    }
    while(v0 != 1L);
    return result;
}

void _dl_relocate_static_pie() {
}

long _start(long param0, long param1) {
    long v0;
    long v1;
    long v2;
    long v3;
    char v4;
    long v5 = 0L;
    char v6 = 1;
    char v7 = 0;
    char v8 = 1;
    char v9 = 0;
    char v10 = 0;
    long v11 = param1;
    long v12 = v0;
    long* ptr0 = &v4;
    char v13 = &v0 ? 0: 1;
    char v14 = (long)&v0 < 0L;
    char v15 = __parity__((unsigned char)&v0);
    char v16 = 0;
    char v17 = 0;
    long* ptr1 = &v1;
    long v18 = &__libc_csu_fini;
    long v19 = &__libc_csu_init;
    long v20 = &main;
    long* ptr2 = &v2;
    long v21 = __libc_start_main(&main, v12, (long)&v4, &__libc_csu_init, &__libc_csu_fini, v11, (long)&v1, v3);
    hlt();
}

long deregister_tm_clones() {
    return &__TMC_END__;
}

void finalizer_0() {
}

void finalizer_1() {
    char v0 = completed.0 ? 0: 1;
    char v1 = completed.0 >= 128;
    char v2 = __parity__(completed.0);
    char v3 = completed.0 < 0;
    char v4 = 0;
    char v5 = 0;
    jump v0 ? &sub_40131D: &sub_401330;
}

void* initializer_0() {
    void* result = __gmon_start__;
    if(result) {
        result = (void*)result();
    }
    return result;
}

long initializer_1() {
    return register_tm_clones();
}

unsigned int main._omp_fn.0(unsigned long* param0) {
    unsigned int v0;
    int v1;
    unsigned long* ptr0 = param0;
    →omp_get_num_threads();
    →omp_get_thread_num();
    int v2 = 6000 / v1;
    unsigned int* ptr1 = (unsigned int*)(6000 % v1);
    if(6000 % v1 > (int)v0) {
        ++v2;
        ptr1 = NULL;
    }
    long v3 = (unsigned long)(v0 * v2 + (unsigned int)ptr1);
    unsigned int result = (unsigned int)(v0 * v2 + (unsigned int)ptr1 + v2);
    if((unsigned int)v3 < (int)result) {
        v3 = (long)(unsigned int)v3;
        do {
            param0 = *(unsigned long*)(v3 * 8L + (long)&gvar_404088);
            if(*(char*)((char*)param0 - 2L) != 122) {
                char* ptr2 = (char*)((char*)param0 - 5L);
                ptr1 = (unsigned int*)((unsigned int)*(char*)((char*)param0 - 5L) + 6);
                *(char*)((char*)param0 - 5L) = (unsigned char)ptr1;
                while((unsigned char)ptr1 > 57) {
                    param0 = (unsigned long*)*(ptr2 - 1L);
                    --ptr2;
                    *(ptr2 + 1L) = (unsigned char)ptr1 - 10;
                    ptr1 = (unsigned int*)((unsigned int)param0 + 1);
                    *ptr2 = (unsigned char)ptr1;
                }
                if(*(unsigned long*)(v3 * 8L + (long)&nl) > (unsigned long)ptr2) {
                    ptr1 = *ptr0;
                    *ptr1 = *ptr1 + 1;
                }
            }
            ++v3;
        }
        while((unsigned int)v3 < (int)result);
    }
    return result;
}

void main() {
    int v0;
    long v1 = 1L;
    do {
        *(long*)&nl = 32;
        long v2 = 0L;
        char* __s = (char*)&format;
        do {
            int v3 = (unsigned int)v2 + (unsigned int)v1;
            if((unsigned int)(((unsigned int)v2 + (unsigned int)v1) * 0xeeeeeeef) <= 0x11111111) {
                *(long*)&__s[0] = 'F';
                *(short*)&__s[8] = 10;
                __s += 9L;
            }
            else if((unsigned int)(v3 * 0xcccccccd) <= 0x33333333) {
                *(int*)&__s[0] = 'B';
                *(short*)&__s[4] = 10;
                __s += 5L;
            }
            else if((unsigned int)(v3 * 0xaaaaaaab) <= 0x55555555) {
                *(int*)&__s[0] = 'F';
                *(short*)&__s[4] = 10;
                __s += 5L;
            }
            else {
                →sprintf(__s, (char*)&gvar_402010);
                __s = &__s[(long)v0];
            }
            *(char**)(v2 * 8L + (long)&nl) = __s;
            ++v2;
        }
        while(v2 == 6001L);
        unsigned long v4 = gvar_40FC00;
        v1 = (unsigned long)((unsigned int)v1 + 6001);
        →write(1L, (void*)&format, (size_t)(v4 - &format));
    }
    while((unsigned int)v1 != 0x2ee3);
    while(1) {
        →GOMP_parallel();
        →write(1L, (void*)&format, (size_t)(gvar_40FC00 - &format));
    }
}

long register_tm_clones() {
    return 0L;
}

long sub_401026() {
    return gvar_404010();
}

long sub_4012AD() {
    return 0L;
}

long sub_4012EF() {
    return 0L;
}

long sub_40131D() {
    long result = deregister_tm_clones();
    completed.0 = 1;
    return result;
}

void sub_401330() {
}

void →GOMP_parallel() {
    while(1) {
        /*BAD_CALL!*/ GOMP_parallel();
        unsigned long* ptr0 = ptr0 - 1;
        *ptr0 = 4L;
        --ptr0;
        *ptr0 = gvar_404008;
    }
}

void →omp_get_num_threads() {
    while(1) {
        /*BAD_CALL!*/ omp_get_num_threads();
        unsigned long* ptr0 = ptr0 - 1;
        *ptr0 = 2L;
        --ptr0;
        *ptr0 = gvar_404008;
    }
}

void →omp_get_thread_num() {
    while(1) {
        /*BAD_CALL!*/ omp_get_thread_num();
        unsigned long* ptr0 = ptr0 - 1;
        *ptr0 = 1L;
        --ptr0;
        *ptr0 = gvar_404008;
    }
}

void →sprintf(char* __s, char* __format) {
    while(1) {
        /*BAD_CALL!*/ sprintf(__s, __format);
        unsigned long* ptr0 = ptr0 - 1;
        *ptr0 = 3L;
        --ptr0;
        *ptr0 = gvar_404008;
    }
}

void →write(long param0, void* __buf, size_t __n) {
    while(1) {
        /*BAD_CALL!*/ write((int)param0, __buf, __n);
        unsigned long* ptr0 = ptr0 - 1;
        *ptr0 = 0L;
        --ptr0;
        *ptr0 = gvar_404008;
    }
}
