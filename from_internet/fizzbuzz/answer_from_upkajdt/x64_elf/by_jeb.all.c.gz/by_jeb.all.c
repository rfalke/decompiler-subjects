
void __libc_csu_fini() {
}

void* __libc_csu_init(long param0, long param1, long param2) {
    void* result;
    initializer_0();
    unsigned long v0 = 0L;
    do {
        result = (void*)*(long*)(v0 * 8L + (long)&__frame_dummy_init_array_entry){initializer_1}();
        ++v0;
    }
    while(v0 != 2L);
    return result;
}

void _dl_relocate_static_pie() {
}

long _start(long param0, long param1) {
    long v0;
    long v1;
    long v2;
    long v3;
    char v4;
    long v5 = 0L;
    char v6 = 1;
    char v7 = 0;
    char v8 = 1;
    char v9 = 0;
    char v10 = 0;
    long v11 = param1;
    long v12 = v0;
    long* ptr0 = &v4;
    char v13 = &v0 ? 0: 1;
    char v14 = (long)&v0 < 0L;
    char v15 = __parity__((unsigned char)&v0);
    char v16 = 0;
    char v17 = 0;
    long* ptr1 = &v1;
    long v18 = &__libc_csu_fini;
    long v19 = &__libc_csu_init;
    long v20 = &main;
    long* ptr2 = &v2;
    long v21 = __libc_start_main(&main, v12, (long)&v4, &__libc_csu_init, &__libc_csu_fini, v11, (long)&v1, v3);
    hlt();
}

long deregister_tm_clones() {
    return &__TMC_END__;
}

void finalizer_0() {
}

void finalizer_1() {
    char v0 = completed.0 ? 0: 1;
    char v1 = completed.0 >= 128;
    char v2 = __parity__(completed.0);
    char v3 = completed.0 < 0;
    char v4 = 0;
    char v5 = 0;
    jump v0 ? &sub_4015AD: &sub_4015C0;
}

void* initializer_0() {
    void* result = __gmon_start__;
    if(result) {
        result = (void*)result();
    }
    return result;
}

long initializer_1() {
    return register_tm_clones();
}

long initializer_2() {
    long result;
    →std::ios_base::Init::Init();
    →__cxa_atexit();
    return result;
}

long main() {
    char v0;
    char v1;
    char v2;
    void* ptr0;
    unsigned long* ptr1;
    char v3;
    void* ptr2;
    char v4;
    void* ptr3;
    void* ptr4;
    long v5;
    unsigned long* ptr5;
    char v6;
    char v7;
    long v8;
    void* ptr6;
    long v9;
    void* ptr7;
    unsigned long* ptr8;
    char v10;
    unsigned long* ptr9;
    void* ptr10;
    void* ptr11 = ptr10;
    long v11 = v5;
    long v12 = v8;
    long v13 = v9;
    unsigned long* ptr12 = ptr5;
    long* ptr13 = &ptr12;
    char v14 = &v4 == 152L;
    char v15 = (long)&v6 < 0L;
    char v16 = __parity__((unsigned char)&v4 - 152);
    char v17 = (long*)((long)(long*)((long)(long*)((long)(long*)((long)&ptr12 ^ 0x68L) ^ (long)&v6) >>> 4L) & 0x1L);
    char v18 = (unsigned long)&ptr12 < 104L;
    char v19 = (long)(long*)((long)(long*)((long)&ptr12 ^ (long)&v6) & (long)(long*)((long)&ptr12 ^ 0x68L)) < 0L;
    →std::thread::hardware_concurrency();
    __int128 v20 = 0x0X;
    void* ptr14 = NULL;
    unsigned long v21 = (unsigned long)(unsigned int)ptr7;
    *(__int128*)&ptr9 = 0x0X;
    char v22 = v21 ? 0: 1;
    char v23 = v21 >= 0x8000000000000000L;
    char v24 = __parity__((unsigned char)v21);
    char v25 = 0;
    char v26 = 0;
    if(!v22) {
        void* ptr15 = NULL;
        ptr5 = NULL;
        char v27 = 1;
        char v28 = 0;
        char v29 = 1;
        char v30 = 0;
        char v31 = 0;
        while(1) {
            long v32 = 40L;
            →operator new();
            *(long*)((long)ptr7 + 16L) = 10000000L;
            long v33 = 400000000L;
            →operator new[]();
            *(void**)((long)ptr7 + 24L) = ptr7;
            unsigned long* ptr16 = ptr8;
            ptr2 = ptr7;
            char v34 = ptr16 == ptr15;
            char v35 = (long)ptr16 < (long)ptr15;
            char v36 = __parity__((unsigned char)ptr16 - (unsigned char)ptr15);
            char v37 = (unsigned long)ptr16 < (unsigned long)ptr15;
            char v38 = (long)(long*)((long)(long*)((long)(long*)((long)ptr16 - (long)ptr15) ^ (long)ptr16) & (long)(long*)((long)ptr16 ^ (long)ptr15)) < 0L;
            char v39 = (long*)((long)(long*)((long)(long*)((long)(long*)((long)ptr16 - (long)ptr15) ^ (long)(long*)((long)ptr16 ^ (long)ptr15)) >>> 4L) & 0x1L);
            if(v34) {
                size_t v40 = &ptr2;
                void* __src1 = ptr15;
                void* ptr17 = &ptr9;
                void* ptr18 = std::vector<worker*, std::allocator<worker*> >::_M_realloc_insert<worker*>(&ptr9, __src1, &ptr2);
                ptr5 = (unsigned long*)((char*)ptr5 + 1L);
                char v41 = ptr5 == v21;
                char v42 = (long)ptr5 > (long)v21;
                char v43 = __parity__((unsigned char)v21 - (unsigned char)ptr5);
                char v44 = (unsigned long)ptr5 > v21;
                char v45 = (long)(long*)((long)(long*)((long)(long*)(v21 - (long)ptr5) ^ v21) & (long)(long*)((long)ptr5 ^ v21)) < 0L;
                char v46 = (long*)((long)(long*)((long)(long*)((long)(long*)(v21 - (long)ptr5) ^ (long)(long*)((long)ptr5 ^ v21)) >>> 4L) & 0x1L);
                if(!v41) {
                    goto loc_401269;
                }
                else {
                    break;
                }
            }
            else {
                *ptr16 = ptr7;
                ptr5 = (unsigned long*)((char*)ptr5 + 1L);
                unsigned long* ptr19 = ptr16;
                unsigned long* ptr20 = ptr16 + 1;
                char v47 = ptr20 ? 0: 1;
                char v48 = (long)ptr20 < 0L;
                char v49 = __parity__((unsigned char)ptr20);
                char v50 = (long*)((long)(long*)((long)(long*)((long)(long*)((long)ptr19 ^ 0x8L) ^ (long)ptr20) >>> 4L) & 0x1L);
                char v51 = (unsigned long)ptr19 >= 18446744073709551608L;
                char v52 = (long)(long*)((long)(long*)((long)ptr20 ^ (long)ptr19) & (long*)~(long)(long*)((long)ptr19 ^ 0x8L)) < 0L;
                ptr8 = ptr20;
                v3 = ptr5 == v21;
                char v53 = (long)ptr5 > (long)v21;
                char v54 = __parity__((unsigned char)v21 - (unsigned char)ptr5);
                char v55 = (unsigned long)ptr5 > v21;
                char v56 = (long)(long*)((long)(long*)((long)(long*)(v21 - (long)ptr5) ^ v21) & (long)(long*)((long)ptr5 ^ v21)) < 0L;
                char v57 = (long*)((long)(long*)((long)(long*)((long)(long*)(v21 - (long)ptr5) ^ (long)(long*)((long)ptr5 ^ v21)) >>> 4L) & 0x1L);
            }
            if(v3) {
                break;
            }
            else {
            loc_401269:
                ptr15 = ptr14;
            }
        }
    }
    unsigned long* ptr21 = ptr8;
    unsigned long* ptr22 = ptr9;
    long* ptr23 = NULL;
    char v58 = 1;
    char v59 = 0;
    char v60 = 1;
    char v61 = 0;
    char v62 = 0;
    long* ptr24 = (long*)(ptr21 - 1);
    long* ptr25 = (long*)(ptr21 - 1);
    long* ptr26 = (long*)((long)ptr24 - (long)ptr22);
    char v63 = ptr26 ? 0: 1;
    char v64 = (long)ptr26 < 0L;
    char v65 = __parity__((unsigned char)ptr26);
    char v66 = (long*)((long)(long*)((long)(long*)((long)(long*)((long)ptr22 ^ (long)ptr25) ^ (long)ptr26) >>> 4L) & 0x1L);
    char v67 = (unsigned long)ptr22 > (unsigned long)ptr25;
    char v68 = (long)(long*)((long)(long*)((long)ptr26 ^ (long)ptr25) & (long)(long*)((long)ptr22 ^ (long)ptr25)) < 0L;
    long* ptr27 = ptr26;
    long* ptr28 = (long*)((long)ptr26 >>> 3);
    char v69 = (long*)((long)(long*)((long)ptr27 >>> 2L) & 0x1L);
    char v70 = v68;
    char v71 = ptr28 ? 0: 1;
    char v72 = (long)ptr28 < 0L;
    char v73 = __parity__((unsigned char)ptr28);
    unsigned long* ptr29 = (unsigned long*)((char*)ptr28 + 1L);
    unsigned long* ptr30 = (unsigned long*)((char*)ptr28 + 1L);
    long* ptr31 = (long*)((long)ptr29 * 10000000L);
    char v74 = (__int128)ptr30 * 0x989680X != (__int128)ptr31;
    char v75 = (__int128)ptr30 * 0x989680X != (__int128)ptr31;
    long* ptr32 = ptr31;
loc_4012E8:
    char v76 = ptr21 == ptr22;
    char v77 = (long)ptr21 < (long)ptr22;
    char v78 = __parity__((unsigned char)ptr21 - (unsigned char)ptr22);
    char v79 = ptr21 < ptr22;
    char v80 = (long)(long*)((long)(long*)((long)(long*)((long)ptr21 - (long)ptr22) ^ (long)ptr21) & (long)(long*)((long)ptr21 ^ (long)ptr22)) < 0L;
    char v81 = (long*)((long)(long*)((long)(long*)((long)(long*)((long)ptr21 - (long)ptr22) ^ (long)(long*)((long)ptr21 ^ (long)ptr22)) >>> 4L) & 0x1L);
    if(v76) {
    loc_401481:
        __int128 v82 = 0x0X;
        ptr10 = NULL;
        ptr0 = NULL;
        char v83 = 1;
        char v84 = 0;
        char v85 = 1;
        char v86 = 0;
        char v87 = 0;
        ptr1 = NULL;
        *(__int128*)&ptr2 = 0x0X;
        goto loc_401426;
    }
    else {
    loc_4012F1:
        unsigned long* ptr33 = ptr22;
        long* ptr34 = ptr23;
        do {
            long* ptr35 = ptr34;
            long v88 = 0L;
            long* ptr36 = ptr34;
            ptr34 += 1250000;
            char v89 = ptr34 ? 0: 1;
            char v90 = (long)ptr34 < 0L;
            char v91 = __parity__((unsigned char)ptr34);
            char v92 = (long*)((long)(long*)((long)(long*)((long)(long*)((long)ptr36 ^ 0x989680L) ^ (long)ptr34) >>> 4L) & 0x1L);
            char v93 = (unsigned long)ptr36 >= 18446744073699551616L;
            char v94 = (long)(long*)((long)(long*)((long)ptr34 ^ (long)ptr36) & (long*)~(long)(long*)((long)ptr36 ^ 0x989680L)) < 0L;
            __int128* ptr37 = *ptr33;
            unsigned long* ptr38 = ptr33;
            ++ptr33;
            char v95 = ptr33 ? 0: 1;
            char v96 = (long)ptr33 < 0L;
            char v97 = __parity__((unsigned char)ptr33);
            char v98 = (long*)((long)(long*)((long)(long*)((long)(long*)((long)ptr38 ^ 0x8L) ^ (long)ptr33) >>> 4L) & 0x1L);
            char v99 = (unsigned long)ptr38 >= 18446744073709551608L;
            char v100 = (long)(long*)((long)(long*)((long)ptr33 ^ (long)ptr38) & (long*)~(long)(long*)((long)ptr38 ^ 0x8L)) < 0L;
            long* ptr39 = ptr34;
            long v101 = 0L;
            long* ptr40 = ptr35;
            long* ptr41 = ptr39;
            v20 = (unsigned __int128)ptr40 | ((unsigned __int128)ptr41 << 64);
            *ptr37 = (unsigned __int128)ptr40 | ((unsigned __int128)ptr41 << 64);
            v10 = ptr33 == ptr21;
            char v102 = (long)ptr33 < (long)ptr21;
            char v103 = __parity__((unsigned char)ptr33 - (unsigned char)ptr21);
            char v104 = ptr33 < ptr21;
            char v105 = (long)(long*)((long)(long*)((long)(long*)((long)ptr33 - (long)ptr21) ^ (long)ptr33) & (long)(long*)((long)ptr33 ^ (long)ptr21)) < 0L;
            char v106 = (long*)((long)(long*)((long)(long*)((long)(long*)((long)ptr33 - (long)ptr21) ^ (long)(long*)((long)ptr33 ^ (long)ptr21)) >>> 4L) & 0x1L);
        }
        while(!v10);
        __int128 v107 = 0x0X;
        long* ptr42 = ptr23;
        ptr23 = (long*)((long)ptr23 + (long)ptr32);
        char v108 = ptr23 ? 0: 1;
        char v109 = (long)ptr23 < 0L;
        char v110 = __parity__((unsigned char)ptr23);
        char v111 = (long*)((long)(long*)((long)(long*)((long)(long*)((long)ptr42 ^ (long)ptr32) ^ (long)ptr23) >>> 4L) & 0x1L);
        char v112 = (long*)__carry__((long)ptr42, (long)ptr32);
        char v113 = (long)(long*)((long)(long*)((long)ptr23 ^ (long)ptr42) & (long*)~(long)(long*)((long)ptr42 ^ (long)ptr32)) < 0L;
        unsigned long* ptr43 = ptr22;
        unsigned long* ptr44 = NULL;
        char v114 = 1;
        char v115 = 0;
        char v116 = 1;
        char v117 = 0;
        char v118 = 0;
        ptr1 = NULL;
        ptr0 = NULL;
        char v119 = 1;
        char v120 = 0;
        char v121 = 1;
        char v122 = 0;
        char v123 = 0;
        *(__int128*)&ptr2 = 0x0X;
        while(1) {
            long v124 = *ptr43;
            long v125 = *ptr43;
            char v126 = ptr44 == ptr0;
            char v127 = (long)ptr44 > (long)ptr0;
            char v128 = __parity__((unsigned char)ptr0 - (unsigned char)ptr44);
            char v129 = (unsigned long)ptr44 > (unsigned long)ptr0;
            char v130 = (long)(long*)((long)(long*)((long)(long*)((long)ptr0 - (long)ptr44) ^ (long)ptr0) & (long)(long*)((long)ptr44 ^ (long)ptr0)) < 0L;
            char v131 = (long*)((long)(long*)((long)(long*)((long)(long*)((long)ptr0 - (long)ptr44) ^ (long)(long*)((long)ptr44 ^ (long)ptr0)) >>> 4L) & 0x1L);
            if(v126) {
                void* ptr45 = &v125;
                long v132 = &task;
                void* __src = ptr0;
                size_t v133 = &ptr2;
                unsigned long* ptr46 = std::vector<std::thread, std::allocator<std::thread> >::_M_realloc_insert<void (&)(worker*), worker*&>((unsigned long*)&ptr2, __src, (unsigned long*)&task, &v125);
                ptr30 = ptr43;
                ++ptr43;
                char v134 = ptr43 ? 0: 1;
                char v135 = (long)ptr43 < 0L;
                char v136 = __parity__((unsigned char)ptr43);
                char v137 = (long*)((long)(long*)((long)(long*)((long)(long*)((long)ptr30 ^ 0x8L) ^ (long)ptr43) >>> 4L) & 0x1L);
                char v138 = (unsigned long)ptr30 >= 18446744073709551608L;
                char v139 = (long)(long*)((long)(long*)((long)ptr43 ^ (long)ptr30) & (long*)~(long)(long*)((long)ptr30 ^ 0x8L)) < 0L;
                ptr0 = ptr4;
                char v140 = ptr43 == ptr21;
                char v141 = (long)ptr43 > (long)ptr21;
                char v142 = __parity__((unsigned char)ptr21 - (unsigned char)ptr43);
                char v143 = ptr43 > ptr21;
                char v144 = (long)(long*)((long)(long*)((long)(long*)((long)ptr21 - (long)ptr43) ^ (long)ptr21) & (long)(long*)((long)ptr43 ^ (long)ptr21)) < 0L;
                char v145 = (long*)((long)(long*)((long)(long*)((long)(long*)((long)ptr21 - (long)ptr43) ^ (long)(long*)((long)ptr43 ^ (long)ptr21)) >>> 4L) & 0x1L);
                if(!v140) {
                    goto loc_4013A6;
                }
                else {
                    break;
                }
            }
            else {
                *(long*)ptr0 = 0L;
                long v146 = 24L;
                →operator new();
                *(long*)ptr7 = &vftable_NSt6thread11_State_implINS_8_InvokerISt5tupleIJPFvP6workerES4_EEEEEE;
                long v147 = &→pthread_create;
                long* ptr47 = &ptr3;
                void* ptr48 = ptr0;
                *(long*)((long)ptr7 + 8L) = v124;
                *(long*)((long)ptr7 + 16L) = &task;
                ptr3 = ptr7;
                →std::thread::_M_start_thread();
                void* ptr49 = ptr3;
                char v148 = ptr49 ? 0: 1;
                char v149 = (long)ptr49 < 0L;
                char v150 = __parity__((unsigned char)ptr49);
                char v151 = 0;
                char v152 = 0;
                if(!v148) {
                    long v153 = *(long*)ptr49;
                    long v154 = *(long*)(v153 + 8L)((long)ptr49, (long)&ptr3);
                }
                ptr0 = (void*)((long)ptr0 + 8L);
                ptr30 = ptr43;
                ++ptr43;
                char v155 = ptr43 ? 0: 1;
                char v156 = (long)ptr43 < 0L;
                char v157 = __parity__((unsigned char)ptr43);
                char v158 = (long*)((long)(long*)((long)(long*)((long)(long*)((long)ptr30 ^ 0x8L) ^ (long)ptr43) >>> 4L) & 0x1L);
                char v159 = (unsigned long)ptr30 >= 18446744073709551608L;
                char v160 = (long)(long*)((long)(long*)((long)ptr43 ^ (long)ptr30) & (long*)~(long)(long*)((long)ptr30 ^ 0x8L)) < 0L;
                ptr4 = ptr0;
                v2 = ptr43 == ptr21;
                char v161 = (long)ptr43 > (long)ptr21;
                char v162 = __parity__((unsigned char)ptr21 - (unsigned char)ptr43);
                char v163 = ptr43 > ptr21;
                char v164 = (long)(long*)((long)(long*)((long)(long*)((long)ptr21 - (long)ptr43) ^ (long)ptr21) & (long)(long*)((long)ptr43 ^ (long)ptr21)) < 0L;
                char v165 = (long*)((long)(long*)((long)(long*)((long)(long*)((long)ptr21 - (long)ptr43) ^ (long)(long*)((long)ptr43 ^ (long)ptr21)) >>> 4L) & 0x1L);
            }
            if(v2) {
                break;
            }
            else {
            loc_4013A6:
                ptr44 = ptr1;
            }
        }
        ptr10 = ptr2;
        void* ptr50 = ptr2;
        char v166 = ptr0 == ptr10;
        char v167 = (long)ptr0 > (long)ptr10;
        char v168 = __parity__((unsigned char)ptr10 - (unsigned char)ptr0);
        char v169 = ptr0 > ptr10;
        char v170 = (long)(long*)((long)(long*)((long)(long*)((long)ptr10 - (long)ptr0) ^ (long)ptr10) & (long)(long*)((long)ptr0 ^ (long)ptr10)) < 0L;
        char v171 = (long*)((long)(long*)((long)(long*)((long)(long*)((long)ptr10 - (long)ptr0) ^ (long)(long*)((long)ptr0 ^ (long)ptr10)) >>> 4L) & 0x1L);
        if(!v166) {
            do {
                void* ptr51 = ptr50;
                →std::thread::join();
                ptr50 = (void*)((long)ptr50 + 8L);
                v7 = ptr50 == ptr0;
                char v172 = (long)ptr50 > (long)ptr0;
                char v173 = __parity__((unsigned char)ptr0 - (unsigned char)ptr50);
                char v174 = ptr50 > ptr0;
                char v175 = (long)(long*)((long)(long*)((long)(long*)((long)ptr0 - (long)ptr50) ^ (long)ptr0) & (long)(long*)((long)ptr50 ^ (long)ptr0)) < 0L;
                char v176 = (long*)((long)(long*)((long)(long*)((long)(long*)((long)ptr0 - (long)ptr50) ^ (long)(long*)((long)ptr50 ^ (long)ptr0)) >>> 4L) & 0x1L);
            }
            while(!v7);
        }
        ptr5 = ptr22;
    }
    do {
        long v177 = *ptr5;
        long v178 = 1L;
        size_t __n = *(size_t*)(v177 + 32L);
        void* __buf = *(void**)(v177 + 24L);
        →write(1L, __buf, __n);
        ++ptr5;
        v1 = ptr5 == ptr21;
        char v179 = (long)ptr5 > (long)ptr21;
        char v180 = __parity__((unsigned char)ptr21 - (unsigned char)ptr5);
        char v181 = ptr5 > ptr21;
        char v182 = (long)(long*)((long)(long*)((long)(long*)((long)ptr21 - (long)ptr5) ^ (long)ptr21) & (long)(long*)((long)ptr5 ^ (long)ptr21)) < 0L;
        char v183 = (long*)((long)(long*)((long)(long*)((long)(long*)((long)ptr21 - (long)ptr5) ^ (long)(long*)((long)ptr5 ^ (long)ptr21)) >>> 4L) & 0x1L);
    }
    while(!v1);
loc_401426:
    long* ptr52 = ptr23;
    long v184 = &std::cerr;
    →std::ostream::_M_insert<unsigned long>();
    void* ptr53 = ptr7;
    long v185 = 1L;
    long v186 = &gvar_40302A;
    →std::__ostream_insert<char, std::char_traits<char> >();
    void* ptr54 = ptr10;
    char v187 = ptr0 == ptr10;
    char v188 = (long)ptr0 < (long)ptr10;
    char v189 = __parity__((unsigned char)ptr0 - (unsigned char)ptr10);
    char v190 = ptr0 < ptr10;
    char v191 = (long)(long*)((long)(long*)((long)(long*)((long)ptr0 - (long)ptr10) ^ (long)ptr0) & (long)(long*)((long)ptr0 ^ (long)ptr10)) < 0L;
    char v192 = (long*)((long)(long*)((long)(long*)((long)(long*)((long)ptr0 - (long)ptr10) ^ (long)(long*)((long)ptr0 ^ (long)ptr10)) >>> 4L) & 0x1L);
    if(!v187) {
        do {
            char v193 = *(long*)ptr54 ? 0: 1;
            char v194 = *(long*)ptr54 < 0L;
            char v195 = __parity__((unsigned char)*(long*)ptr54);
            char v196 = *(unsigned long*)ptr54 < 0L;
            char v197 = 0;
            char v198 = 0;
            if(!v193) {
                long* ptr55 = &ptr6;
                /*NO_RETURN*/ →std::terminate();
            }
            ptr54 = (void*)((long)ptr54 + 8L);
            v0 = ptr54 == ptr0;
            char v199 = (long)ptr54 < (long)ptr0;
            char v200 = __parity__((unsigned char)ptr54 - (unsigned char)ptr0);
            char v201 = ptr54 < ptr0;
            char v202 = (long)(long*)((long)(long*)((long)(long*)((long)ptr54 - (long)ptr0) ^ (long)ptr54) & (long)(long*)((long)ptr54 ^ (long)ptr0)) < 0L;
            char v203 = (long*)((long)(long*)((long)(long*)((long)(long*)((long)ptr54 - (long)ptr0) ^ (long)(long*)((long)ptr54 ^ (long)ptr0)) >>> 4L) & 0x1L);
        }
        while(!v0);
    }
    char v204 = ptr10 ? 0: 1;
    char v205 = (long)ptr10 < 0L;
    char v206 = __parity__((unsigned char)ptr10);
    char v207 = 0;
    char v208 = 0;
    if(v204) {
        goto loc_4012E8;
    }
    else {
        unsigned long* ptr56 = ptr1;
        void* ptr57 = ptr10;
        ptr30 = ptr56;
        long* ptr58 = (long*)((long)ptr56 - (long)ptr10);
        char v209 = ptr58 ? 0: 1;
        char v210 = (long)ptr58 < 0L;
        char v211 = __parity__((unsigned char)ptr58);
        char v212 = (long*)((long)(long*)((long)(long*)((long)(long*)((long)ptr10 ^ (long)ptr30) ^ (long)ptr58) >>> 4L) & 0x1L);
        char v213 = (unsigned long)ptr10 > (unsigned long)ptr30;
        char v214 = (long)(long*)((long)(long*)((long)ptr58 ^ (long)ptr30) & (long)(long*)((long)ptr10 ^ (long)ptr30)) < 0L;
        →operator delete();
        char v215 = ptr21 == ptr22;
        char v216 = (long)ptr21 < (long)ptr22;
        char v217 = __parity__((unsigned char)ptr21 - (unsigned char)ptr22);
        char v218 = ptr21 < ptr22;
        char v219 = (long)(long*)((long)(long*)((long)(long*)((long)ptr21 - (long)ptr22) ^ (long)ptr21) & (long)(long*)((long)ptr21 ^ (long)ptr22)) < 0L;
        char v220 = (long*)((long)(long*)((long)(long*)((long)(long*)((long)ptr21 - (long)ptr22) ^ (long)(long*)((long)ptr21 ^ (long)ptr22)) >>> 4L) & 0x1L);
        if(!v215) {
            goto loc_4012F1;
        }
        else {
            goto loc_401481;
        }
    }
}

long main.cold() {
    void* ptr0;
    long v0;
    long v1;
    long v2 = v0;
    long v3 = 40L;
    long v4 = v1;
    long* ptr1 = &ptr0;
    /*BAD_CALL!*/ →operator delete();
}

long register_tm_clones() {
    return 0L;
}

// Package: std::thread::_State_impl<std::thread::_Invoker<std::tuple<void (*)(worker*), worker*> > >

long std::thread::_State_impl<std::thread::_Invoker<std::tuple<void (*)(worker*), worker*> > >::_M_run(long param0) {
    long v0 = *(long*)(param0 + 8L);
    long v1 = *(long*)(param0 + 16L);
    long v2 = v0;
    jump v1;
}

// Package: std::thread::_State_impl<std::thread::_Invoker<std::tuple<void (*)(worker*), worker*> > >

long std::thread::_State_impl<std::thread::_Invoker<std::tuple<void (*)(worker*), worker*> > >::~_State_impl(long* param0) {
    long result;
    *param0 = &vftable_NSt6thread11_State_implINS_8_InvokerISt5tupleIJPFvP6workerES4_EEEEEE;
    →std::thread::_State::~_State();
    return result;
}

// Package: std::thread::_State_impl<std::thread::_Invoker<std::tuple<void (*)(worker*), worker*> > >

long std::thread::_State_impl<std::thread::_Invoker<std::tuple<void (*)(worker*), worker*> > >::~_State_impl2(long* param0) {
    long result;
    *param0 = &vftable_NSt6thread11_State_implINS_8_InvokerISt5tupleIJPFvP6workerES4_EEEEEE;
    →std::thread::_State::~_State();
    →operator delete();
    return result;
}

// Stale decompilation - Refresh this view to re-decompile this code
unsigned long* std::vector<std::thread, std::allocator<std::thread> >::_M_realloc_insert<void (&)(worker*), worker*&>(unsigned long* param0, void* __src, unsigned long* param2, void* __dest) {
    unsigned long* ptr0;
    long* ptr1;
    long* ptr2;
    void* ptr3;
    unsigned long* result;
    long v0;
    long* ptr4;
    long* ptr5 = ptr4;
    long v1 = v0;
    unsigned long* ptr6 = *(param0 + 1);
    unsigned long* ptr7 = *param0;
    unsigned long* ptr8 = param2;
    unsigned long* ptr9 = ptr6;
    void* ptr10 = __dest;
    void* ptr11 = (void*)((long)(long*)((long)ptr6 - (long)ptr7) >> 3);
    if(ptr11 == 0xfffffffffffffffL) {
        →std::__throw_length_error();
        goto loc_401E44;
    }
    else {
        ptr2 = (long*)((ptr11 ? ptr11: 1L) + (long)ptr11);
        ptr1 = (long*)((long)__src - (long)ptr7);
    }
    if(__carry__(ptr11 ? ptr11: 1L, (long)ptr11)) {
        ptr2 = (long*)0x7FFFFFFFFFFFFFF8;
    loc_401DFD:
        →operator new();
        ptr0 = result;
    }
    else if(ptr2) {
        ptr2 = (long*)(((unsigned long)ptr2 <= 0xfffffffffffffffL ? ptr2: 0xfffffffffffffffL) * 8L);
        goto loc_401DFD;
    }
    else {
        ptr0 = NULL;
    }
    *(long*)((long)ptr0 + (long)ptr1) = 0L;
    →operator new();
    void* ptr12 = ptr10;
    unsigned long* ptr13 = ptr8;
    unsigned long* ptr14 = result;
    *result = &vftable_NSt6thread11_State_implINS_8_InvokerISt5tupleIJPFvP6workerES4_EEEEEE;
    long v2 = *(long*)ptr12;
    *(result + 2) = ptr13;
    *(long*)(result + 1) = v2;
    /*BAD_CALL!*/ →std::thread::_M_start_thread();
    if(ptr14) {
        *(long*)(*ptr14 + 8L)((long)ptr14, (long)&ptr14);
    }
    unsigned long* ptr15 = ptr7;
    param2 = ptr0;
    unsigned long* ptr16 = ptr0;
    long* ptr17 = (long*)((long)__src - (long)ptr7);
    if(ptr17 != 0L) {
        do {
            long v3 = *ptr15;
            ++ptr15;
            ++param2;
            *(long*)(param2 - 1) = v3;
        }
        while(ptr15 != __src);
        ptr16 = (unsigned long*)((long)ptr17 + (long)ptr0);
    }
    result = ptr9;
    __dest = (void*)(ptr16 + 1);
    if(result != __src) {
        size_t __n = (size_t)((long)result - (long)__src);
        →memcpy(__dest, __src, __n);
        __dest = (void*)((long)result + __n);
    }
    __int128 v4 = (unsigned __int128)ptr0 | ((unsigned __int128)__dest << 64);
    if(ptr7) {
        *(__int128*)&ptr9 = v4;
        →operator delete();
        v4 = *(__int128*)&ptr9;
    }
    *(__int128*)param0 = v4;
    *(param0 + 2) = (long*)((long)ptr2 + (long)ptr0);
    return result;
loc_401E44:
    →__cxa_begin_catch();
    if(v0) {
        __src = (void*)0xFFFFFFFFFFFFFFF;
        →operator delete();
    loc_401E59:
        /*NO_RETURN*/ →__cxa_rethrow();
    }
    if(!*ptr4) {
        goto loc_401E59;
    }
    else {
        /*NO_RETURN*/ →std::terminate();
        *(&ptr3 - 1) = &loc_401E71;
        /*BAD_CALL!*/ →__cxa_end_catch();
        *(&ptr3 - 2) = &loc_401E79;
        /*BAD_CALL!*/ →_Unwind_Resume();
        long v5 = *result;
        *(&ptr3 - 3) = &loc_401E7F;
        /*BAD_CALL!*/ *(long*)(v5 + 8L)((long)result, (long)__src);
        goto loc_401E44;
    }
}

// Package: std::vector<worker*, std::allocator<worker*> >

void* std::vector<worker*, std::allocator<worker*> >::_M_realloc_insert<worker*>(void* __dest, void* __src1, size_t __n) {
    long v0;
    long* ptr0;
    long* ptr1;
    void* ptr2;
    void* ptr3;
    size_t v1;
    long v2;
    long v3;
    size_t v4;
    void* result;
    unsigned long v5;
    size_t v6 = v1;
    size_t v7 = __n;
    long v8 = 0xfffffffffffffffL;
    void* ptr4 = ptr3;
    long v9 = v3;
    unsigned long v10 = v5;
    long v11 = v2;
    long* ptr5 = &v11;
    char v12 = &ptr1 == 88L;
    char v13 = (long)&v4 < 0L;
    char v14 = __parity__((unsigned char)&ptr1 - 88);
    char v15 = (long*)((long)(long*)((long)(long*)((long)(long*)((long)&v11 ^ 0x28L) ^ (long)&v4) >>> 4L) & 0x1L);
    char v16 = (unsigned long)&v11 < 40L;
    char v17 = (long)(long*)((long)(long*)((long)&v11 ^ (long)&v4) & (long)(long*)((long)&v11 ^ 0x28L)) < 0L;
    unsigned long v18 = *(unsigned long*)((long)__dest + 8L);
    void* __src = *(void**)__dest;
    unsigned long v19 = v18;
    unsigned long v20 = v18;
    long* ptr6 = (long*)(v19 - (long)__src);
    char v21 = ptr6 ? 0: 1;
    char v22 = (long)ptr6 < 0L;
    char v23 = __parity__((unsigned char)ptr6);
    char v24 = (long*)((long)(long*)((long)(long*)((long)(long*)((long)__src ^ v20) ^ (long)ptr6) >>> 4L) & 0x1L);
    char v25 = (unsigned long)__src > v20;
    char v26 = (long)(long*)((long)(long*)((long)ptr6 ^ v20) & (long)(long*)((long)__src ^ v20)) < 0L;
    long* ptr7 = ptr6;
    long* ptr8 = (long*)((long)ptr6 >> 3);
    char v27 = (long*)((long)(long*)((long)ptr7 >>> 2L) & 0x1L);
    char v28 = v26;
    char v29 = ptr8 ? 0: 1;
    char v30 = (long)ptr8 < 0L;
    char v31 = __parity__((unsigned char)ptr8);
    char v32 = ptr8 == 0xfffffffffffffffL;
    char v33 = (long)ptr8 < 0xfffffffffffffffL;
    char v34 = __parity__((unsigned char)ptr8 - 0xff);
    char v35 = (unsigned long)ptr8 < 0xfffffffffffffffL;
    char v36 = (long)(long*)((long)(long*)((long)(long*)((char*)ptr8 - 0xfffffffffffffffL) ^ (long)ptr8) & (long)(long*)((long)ptr8 ^ 0xfffffffffffffffL)) < 0L;
    char v37 = (long*)((long)(long*)((long)(long*)((long)(long*)((char*)ptr8 - 0xfffffffffffffffL) ^ (long)(long*)((long)ptr8 ^ 0xfffffffffffffffL)) >>> 4L) & 0x1L);
    if(!v32) {
        void* ptr9 = __dest;
        __n = (size_t)((long)__src1 - (long)__src);
        if(__carry__(ptr8 ? ptr8: 1L, (long)ptr8)) {
            v0 = 0x7ffffffffffffff8L;
        loc_401FA5:
            v4 = __n;
            →operator new();
            __n = v4;
            __dest = result;
            ptr0 = (long*)((long)result + v0);
        }
        else if(!(long*)((ptr8 ? ptr8: 1L) + (long)ptr8)) {
            ptr0 = NULL;
            __dest = NULL;
        }
        else {
            v0 = ((unsigned long)(long*)((ptr8 ? ptr8: 1L) + (long)ptr8) <= 0xfffffffffffffffL ? (long*)((ptr8 ? ptr8: 1L) + (long)ptr8): 0xfffffffffffffffL) * 8L;
            goto loc_401FA5;
        }
        void* __dest1 = (void*)((long*)(__n + (long)__dest) + 1);
        size_t __n1 = (size_t)(v18 - (long)__src1);
        *(long*)(__n + (long)__dest) = *(long*)v7;
        result = (void*)((long)__dest1 + __n1);
        *(__int128*)&v4 = (unsigned __int128)__dest | ((unsigned __int128)result << 64);
        if((long)__n > 0L) {
            void* ptr10 = __dest1;
            →memmove(__dest, __src, __n);
            __dest1 = ptr10;
            if((long)__n1 <= 0L) {
                goto loc_401F70;
            }
            else {
            loc_401F89:
                →memcpy(__dest1, __src1, __n1);
            }
            if(__src) {
            loc_401F70:
                →operator delete();
            }
        }
        else if((long)__n1 > 0L) {
            goto loc_401F89;
        }
        else if(__src) {
            goto loc_401F70;
        }
        __int128 v38 = *(__int128*)&v4;
        *(unsigned long*)((long)ptr9 + 16L) = ptr0;
        *(__int128*)ptr9 = v38;
        return result;
    }
    __dest = "vector::_M_realloc_insert";
    long* ptr11 = &ptr2;
    /*BAD_CALL!*/ →std::__throw_length_error();
}

long sub_401026() {
    return gvar_405010();
}

long sub_4011B0(long param0, long param1, long param2, long param3, long param4, long param5, long param6, unsigned long* param7, unsigned long param8, long param9) {
    long v0;
    long* ptr0;
    void* ptr1;
    long v1;
    while(1) {
        long v2 = v1;
        long v3 = param5;
        long v4 = v3 - v2;
        char v5 = v2 ? 0: 1;
        char v6 = v2 < 0L;
        char v7 = __parity__((unsigned char)v2);
        char v8 = 0;
        char v9 = 0;
        if(!v5) {
            →operator delete();
        }
        long v10 = v0;
        →_Unwind_Resume();
        long* ptr2 = ptr0;
        char v11 = ptr2 ? 0: 1;
        char v12 = (long)ptr2 < 0L;
        char v13 = __parity__((unsigned char)ptr2);
        char v14 = 0;
        char v15 = 0;
        if(!v11) {
            long v16 = *ptr2;
            *(long*)(v16 + 8L)((long)ptr2, v4);
        }
        unsigned long* ptr3 = param7;
        unsigned long v17 = param8;
        unsigned long* ptr4 = ptr3;
        while(1) {
            char v18 = ptr4 == v17;
            char v19 = (long)ptr4 > (long)v17;
            char v20 = __parity__((unsigned char)v17 - (unsigned char)ptr4);
            char v21 = (unsigned long)ptr4 > v17;
            char v22 = (long)(long*)((long)(long*)((long)(long*)(v17 - (long)ptr4) ^ v17) & (long)(long*)((long)ptr4 ^ v17)) < 0L;
            char v23 = (long*)((long)(long*)((long)(long*)((long)(long*)(v17 - (long)ptr4) ^ (long)(long*)((long)ptr4 ^ v17)) >>> 4L) & 0x1L);
            if(!v18) {
                char v24 = *ptr4 ? 0: 1;
                char v25 = *ptr4 < 0L;
                char v26 = __parity__((unsigned char)*ptr4);
                char v27 = *ptr4 < 0L;
                char v28 = 0;
                char v29 = 0;
                if(!v24) {
                    long* ptr5 = &ptr1;
                    /*NO_RETURN*/ →std::terminate();
                }
                unsigned long* ptr6 = ptr4;
                ++ptr4;
                char v30 = ptr4 ? 0: 1;
                char v31 = (long)ptr4 < 0L;
                char v32 = __parity__((unsigned char)ptr4);
                char v33 = (long*)((long)(long*)((long)(long*)((long)(long*)((long)ptr6 ^ 0x8L) ^ (long)ptr4) >>> 4L) & 0x1L);
                char v34 = (unsigned long)ptr6 >= 18446744073709551608L;
                char v35 = (long)(long*)((long)(long*)((long)ptr4 ^ (long)ptr6) & (long*)~(long)(long*)((long)ptr6 ^ 0x8L)) < 0L;
            }
            else {
                break;
            }
        }
        long v36 = param9;
        long* ptr7 = (long*)(v36 - (long)ptr3);
        char v37 = ptr3 ? 0: 1;
        char v38 = (long)ptr3 < 0L;
        char v39 = __parity__((unsigned char)ptr3);
        char v40 = 0;
        char v41 = 0;
        if(!v37) {
            →operator delete();
        }
    }
}

long sub_40153D() {
    return 0L;
}

long sub_40157F() {
    return 0L;
}

long sub_4015AD() {
    long result = deregister_tm_clones();
    completed.0 = 1;
    return result;
}

void sub_4015C0() {
}

void task(unsigned long* param0) {
    char* ptr0;
    long v0;
    long v1;
    char v2;
    unsigned long v3;
    long v4;
    int v5;
    long v6;
    char v7;
    int v8;
    long v9;
    long* ptr1 = *(param0 + 3);
    unsigned long v10 = *param0;
    unsigned long* ptr2 = param0;
    if(*(param0 + 1) > v10) {
        long v11 = v6;
        param0 = NULL;
        long v12 = v4;
        long v13 = v1;
        long v14 = v0;
        long v15 = (unsigned long)v5 | ((unsigned long)v8 << 32);
        long v16 = v9;
        unsigned long v17 = 18446744073709551516L;
        do {
            long v18 = (unsigned long)(((unsigned __int128)v10 * 0xAAAAAAAAAAAAAAABX) >>> 0x40X);
            unsigned long v19 = v10;
            long v20 = v10 - ((v18 & 0xfffffffffffffffeL) + (v18 >>> 1));
            unsigned long v21 = v10 - (unsigned long)(((unsigned long)(((unsigned __int128)v19 * 0xCCCCCCCCCCCCCCCDX) >>> 0x40X) & 0xfffffffffffffffcL) + ((unsigned long)(((unsigned __int128)v19 * 0xCCCCCCCCCCCCCCCDX) >>> 0x40X) >>> 2));
            unsigned long v22 = v21 | v20;
            if(!v22) {
                ptr0 = (char*)(ptr1 + 1);
                *ptr1 = 0x7a7a75427a7a6946L;
            }
            else if(!v20) {
                *(int*)ptr1 = 0x7a7a6946;
                ptr0 = (char*)((char*)ptr1 + 4L);
            }
            else if(!v21) {
                *(int*)ptr1 = 0x7a7a7542;
                ptr0 = (char*)((char*)ptr1 + 4L);
            }
            else {
                unsigned long v23 = v10 - v17;
                char v24 = v23 == 9L;
                if((v23 < 9L || v24)) {
                    long v25 = (unsigned long)(int)(unsigned char)v5;
                    long v26 = (unsigned long)(int)(unsigned char)param0;
                    unsigned int v27 = (unsigned int)((unsigned int)v25 + (unsigned int)v26);
                    v24 = (unsigned int)v25 + (unsigned int)v26 == 9;
                    if(!v24 && (int)v27 >= 9) {
                        goto loc_401702;
                    }
                    else {
                        if(v3 != 15L) {
                            long v28 = 15L - v3;
                            char* ptr3 = (char*)(v3 + (long)&v7);
                            if((unsigned int)v28 >= 8) {
                                *ptr1 = *(long*)ptr3;
                                long v29 = (unsigned long)(unsigned int)v28;
                                *((long*)(v29 + (long)ptr1) - 1) = *((long*)(v29 + (long)ptr3) - 1);
                                long* ptr4 = ptr1 + 1;
                                long* ptr5 = ptr1;
                                long* ptr6 = (long*)((long)ptr4 & 0xfffffffffffffff8L);
                                long* ptr7 = (long*)((long)ptr5 - (long)ptr6);
                                long* ptr8 = ptr6;
                                long* ptr9 = ptr7;
                                long* ptr10 = (long*)((long)ptr3 - (long)ptr7);
                                unsigned int v30 = (unsigned int)(((unsigned int)ptr9 + (unsigned int)v28) & 0xfffffff8);
                                char v31 = v30 < 8;
                                if(!v31) {
                                    unsigned long v32 = v10;
                                    unsigned int v33 = v30 & 0xfffffff8;
                                    unsigned int v34 = 0;
                                    long* ptr11 = ptr1;
                                    do {
                                        long v35 = (unsigned long)v34;
                                        v34 += 8;
                                        *(long*)(v35 + (long)ptr8) = *(long*)(v35 + (long)ptr10);
                                    }
                                    while(v33 > v34);
                                    v10 = v32;
                                    ptr1 = ptr11;
                                }
                            }
                            else if(((unsigned char)v28 & 0x4)) {
                                *(int*)ptr1 = *(int*)ptr3;
                                long v36 = (unsigned long)(unsigned int)v28;
                                *(int*)((char*)(v36 + (long)ptr1) - 4L) = *(int*)((char*)(v36 + (long)ptr3) - 4L);
                            }
                            else if((unsigned int)v28) {
                                *(char*)ptr1 = *ptr3;
                                if((unsigned char)v28 & 0x2) {
                                    long v37 = (unsigned long)(unsigned int)v28;
                                    *(short*)((char*)(v37 + (long)ptr1) - 2L) = *(short*)((char*)(v37 + (long)ptr3) - 2L);
                                }
                            }
                            ptr1 = (long*)((long)ptr1 + v28);
                        }
                        int v38 = (unsigned int)param0;
                        ptr0 = (char*)((char*)ptr1 + 1L);
                        *(char*)ptr1 = (unsigned char)v38 - (unsigned char)v5 + v2;
                    }
                }
                else {
                loc_401702:
                    long v39 = (unsigned long)(((unsigned __int128)v10 * 0xCCCCCCCCCCCCCCCDX) >>> 0x40X);
                    unsigned long v40 = v10;
                    unsigned long v41 = (unsigned long)(v39 >>> 3);
                    unsigned long v42 = v40 - v41 * 10L;
                    v5 = (unsigned int)v42;
                    v8 = 0;
                    v2 = (unsigned char)v42 + 48;
                    if(v10 > 9L) {
                        long v43 = (unsigned long)(((unsigned __int128)v41 * 0xCCCCCCCCCCCCCCCDX) >>> 0x40X);
                        unsigned long v44 = v41;
                        unsigned long v45 = (unsigned long)(v43 >>> 3);
                        unsigned long v46 = (unsigned long)(v43 >>> 3);
                        char v47 = (unsigned char)v44 - (unsigned char)v45 * 10 + 48;
                        if(v10 > 99L) {
                            long v48 = (unsigned long)(((unsigned __int128)v46 * 0xCCCCCCCCCCCCCCCDX) >>> 0x40X);
                            unsigned long v49 = v46;
                            unsigned long v50 = (unsigned long)(v48 >>> 3);
                            unsigned long v51 = (unsigned long)(v48 >>> 3);
                            char v52 = (unsigned char)v49 - (unsigned char)v50 * 10 + 48;
                            if(v10 > 999L) {
                                long v53 = (unsigned long)(((unsigned __int128)v51 * 0xCCCCCCCCCCCCCCCDX) >>> 0x40X);
                                unsigned long v54 = v51;
                                long v55 = v53 >>> 3;
                                long v56 = v53 >>> 3;
                                char v57 = (unsigned char)v54 - (unsigned char)v55 * 10 + 48;
                                if(v10 > 9999L) {
                                    long v58 = (unsigned long)(((unsigned __int128)v56 * 0xCCCCCCCCCCCCCCCDX) >>> 0x40X) >>> 3;
                                    long v59 = v58 * 5L;
                                    long v60 = v58;
                                    char v61 = (unsigned char)v56 - (unsigned char)v59 * 2 + 48;
                                    if(v10 > 99999L) {
                                        long v62 = (unsigned long)(((unsigned __int128)v58 * 0xCCCCCCCCCCCCCCCDX) >>> 0x40X) >>> 3;
                                        long v63 = v62 * 5L;
                                        long v64 = v62;
                                        char v65 = (unsigned char)v60 - (unsigned char)v63 * 2 + 48;
                                        if(v10 > 999999L) {
                                            long v66 = (unsigned long)(((unsigned __int128)v62 * 0xCCCCCCCCCCCCCCCDX) >>> 0x40X) >>> 3;
                                            long v67 = v66 * 5L;
                                            long v68 = v66;
                                            char v69 = (unsigned char)v64 - (unsigned char)v67 * 2 + 48;
                                            if(v10 > 9999999L) {
                                                long v70 = (unsigned long)(((unsigned __int128)v66 * 0xCCCCCCCCCCCCCCCDX) >>> 0x40X) >>> 3;
                                                long v71 = v70 * 5L;
                                                long v72 = v70;
                                                char v73 = (unsigned char)v68 - (unsigned char)v71 * 2 + 48;
                                                if(v10 > 99999999L) {
                                                    unsigned long v74 = (unsigned long)((unsigned long)(((unsigned __int128)v70 * 0xCCCCCCCCCCCCCCCDX) >>> 0x40X) >>> 3);
                                                    long v75 = v74 * 5L;
                                                    unsigned long v76 = v74;
                                                    char v77 = (unsigned char)v72 - (unsigned char)v75 * 2 + 48;
                                                    if(v10 > 999999999L) {
                                                        unsigned long v78 = (unsigned long)((unsigned long)(((unsigned __int128)v74 * 0xCCCCCCCCCCCCCCCDX) >>> 0x40X) >>> 3);
                                                        long v79 = v78 * 5L;
                                                        unsigned long v80 = v78;
                                                        char v81 = (unsigned char)v76 - (unsigned char)v79 * 2 + 48;
                                                        if(v10 > 9999999999L) {
                                                            long v82 = (unsigned long)(((unsigned __int128)v78 * 0xCCCCCCCCCCCCCCCDX) >>> 0x40X) >>> 3;
                                                            long v83 = v82 * 5L;
                                                            long v84 = v82;
                                                            char v85 = (unsigned char)v80 - (unsigned char)v83 * 2 + 48;
                                                            if(v10 > 99999999999L) {
                                                                long v86 = (unsigned long)(((unsigned __int128)v82 * 0xCCCCCCCCCCCCCCCDX) >>> 0x40X) >>> 3;
                                                                long v87 = v86 * 5L;
                                                                long v88 = v86;
                                                                char v89 = (unsigned char)v84 - (unsigned char)v87 * 2 + 48;
                                                                if(v10 > 999999999999L) {
                                                                    unsigned long v90 = (unsigned long)((unsigned long)(((unsigned __int128)v86 * 0xCCCCCCCCCCCCCCCDX) >>> 0x40X) >>> 3);
                                                                    long v91 = v90 * 5L;
                                                                    unsigned long v92 = v90;
                                                                    char v93 = (unsigned char)v88 - (unsigned char)v91 * 2 + 48;
                                                                    if(v41 > 999999999999L) {
                                                                        unsigned long v94 = (unsigned long)((unsigned long)(((unsigned __int128)v90 * 0xCCCCCCCCCCCCCCCDX) >>> 0x40X) >>> 3);
                                                                        long v95 = v94 * 5L;
                                                                        unsigned long v96 = v94;
                                                                        char v97 = (unsigned char)v92 - (unsigned char)v95 * 2 + 48;
                                                                        if(v46 > 999999999999L) {
                                                                            unsigned long v98 = (unsigned long)((unsigned long)(((unsigned __int128)v94 * 0xCCCCCCCCCCCCCCCDX) >>> 0x40X) >>> 3);
                                                                            char v99 = (unsigned char)v96 - (unsigned char)v98 * 10 + 48;
                                                                            if(v51 > 999999999999L) {
                                                                                unsigned long v100 = v98;
                                                                                v3 = 0L;
                                                                                v7 = (unsigned char)v98 - (unsigned char)((unsigned long)(((unsigned __int128)v100 * 0xCCCCCCCCCCCCCCCDX) >>> 0x40X) >>> 3) * 10 + 48;
                                                                            }
                                                                            else {
                                                                                v3 = 1L;
                                                                            }
                                                                        }
                                                                        else {
                                                                            v3 = 2L;
                                                                        }
                                                                    }
                                                                    else {
                                                                        v3 = 3L;
                                                                    }
                                                                }
                                                                else {
                                                                    v3 = 4L;
                                                                }
                                                            }
                                                            else {
                                                                v3 = 5L;
                                                            }
                                                        }
                                                        else {
                                                            v3 = 6L;
                                                        }
                                                    }
                                                    else {
                                                        v3 = 7L;
                                                    }
                                                }
                                                else {
                                                    v3 = 8L;
                                                }
                                            }
                                            else {
                                                v3 = 9L;
                                            }
                                        }
                                        else {
                                            v3 = 10L;
                                        }
                                    }
                                    else {
                                        v3 = 11L;
                                    }
                                }
                                else {
                                    v3 = 12L;
                                }
                            }
                            else {
                                v3 = 13L;
                            }
                        }
                        else {
                            v3 = 14L;
                        }
                    }
                    else {
                        v3 = 15L;
                    }
                    long v101 = v3 + 1L <= 16L ? 16L - v3: 1L;
                    char* ptr12 = (char*)(v3 + (long)&v7);
                    if((unsigned int)v101 >= 8) {
                        long v102 = *(long*)ptr12;
                        long* ptr13 = (long*)((long)(ptr1 + 1) & 0xfffffffffffffff8L);
                        *ptr1 = v102;
                        long v103 = (unsigned long)(unsigned int)v101;
                        *((long*)(v103 + (long)ptr1) - 1) = *((long*)(v103 + (long)ptr12) - 1);
                        long* ptr14 = (long*)((long)ptr1 - (long)ptr13);
                        long* ptr15 = (long*)((long)ptr12 - (long)ptr14);
                        v22 = (unsigned long)(((unsigned int)v101 + (unsigned int)ptr14) & 0xfffffff8);
                        if((unsigned int)(((unsigned int)v101 + (unsigned int)ptr14) & 0xfffffff8) >= 8) {
                            v22 = (unsigned long)((unsigned int)v22 & 0xfffffff8);
                            unsigned int v104 = 0;
                            do {
                                long v105 = (unsigned long)v104;
                                v104 += 8;
                                *(long*)(v105 + (long)ptr13) = *(long*)((long)ptr15 + v105);
                            }
                            while((unsigned int)v22 > v104);
                        }
                    }
                    else if(((unsigned char)v101 & 0x4)) {
                        *(int*)ptr1 = *(int*)ptr12;
                        v22 = (unsigned long)(unsigned int)v101;
                        *(int*)((char*)(v22 + (long)ptr1) - 4L) = *(int*)((char*)(v22 + (long)ptr12) - 4L);
                    }
                    else if((unsigned int)v101) {
                        *(char*)ptr1 = *ptr12;
                        if((unsigned char)v101 & 0x2) {
                            v22 = (unsigned long)(unsigned int)v101;
                            *(short*)((char*)(v22 + (long)ptr1) - 2L) = *(short*)((char*)(v22 + (long)ptr12) - 2L);
                        }
                    }
                    ptr0 = (char*)(v101 + (long)ptr1);
                    v17 = v10;
                }
            }
            param0 = (unsigned long*)((unsigned int)param0 + 1);
            *ptr0 = 10;
            ptr1 = (long*)(ptr0 + 1L);
            ++v10;
            if((unsigned char)param0 == 10) {
                char v106 = *(long*)(ptr2 + 1) == v10;
                if(*(ptr2 + 1) < v10 || v106) {
                    break;
                }
                else {
                    param0 = NULL;
                }
            }
        }
        while(*(ptr2 + 1) > v10);
        *(ptr2 + 4) = (long*)((long)ptr1 - *(long*)(ptr2 + 3));
    }
    else {
        *(long*)(param0 + 4) = 0L;
    }
}

void →_Unwind_Resume() {
    while(1) {
        /*BAD_CALL!*/ _Unwind_Resume();
        unsigned long* ptr0 = ptr0 - 1;
        *ptr0 = 21L;
        --ptr0;
        *ptr0 = gvar_405008;
    }
}

void →__cxa_atexit() {
    while(1) {
        /*BAD_CALL!*/ __cxa_atexit();
        unsigned long* ptr0 = ptr0 - 1;
        *ptr0 = 9L;
        --ptr0;
        *ptr0 = gvar_405008;
    }
}

void →__cxa_begin_catch() {
    while(1) {
        /*BAD_CALL!*/ __cxa_begin_catch();
        unsigned long* ptr0 = ptr0 - 1;
        *ptr0 = 3L;
        --ptr0;
        *ptr0 = gvar_405008;
    }
}

void →__cxa_end_catch() {
    while(1) {
        /*BAD_CALL!*/ __cxa_end_catch();
        unsigned long* ptr0 = ptr0 - 1;
        *ptr0 = 18L;
        --ptr0;
        *ptr0 = gvar_405008;
    }
}

void →__cxa_rethrow() {
    while(1) {
        /*NO_RETURN*/ __cxa_rethrow();
        unsigned long* ptr0 = ptr0 - 1;
        *ptr0 = 15L;
        --ptr0;
        *ptr0 = gvar_405008;
    }
}

long →__gxx_personality_v0() {
    return →__gxx_personality_v0();
}

void →memcpy(void* __dest, void* __src, size_t __n) {
    while(1) {
        /*BAD_CALL!*/ memcpy(__dest, __src, __n);
        unsigned long* ptr0 = ptr0 - 1;
        *ptr0 = 8L;
        --ptr0;
        *ptr0 = gvar_405008;
    }
}

void →memmove(void* __dest, void* __src, size_t __n) {
    while(1) {
        /*BAD_CALL!*/ memmove(__dest, __src, __n);
        unsigned long* ptr0 = ptr0 - 1;
        *ptr0 = 17L;
        --ptr0;
        *ptr0 = gvar_405008;
    }
}

void →operator delete() {
    while(1) {
        /*BAD_CALL!*/ operator delete();
        unsigned long* ptr0 = ptr0 - 1;
        *ptr0 = 12L;
        --ptr0;
        *ptr0 = gvar_405008;
    }
}

void →operator new() {
    while(1) {
        /*BAD_CALL!*/ operator new();
        unsigned long* ptr0 = ptr0 - 1;
        *ptr0 = 11L;
        --ptr0;
        *ptr0 = gvar_405008;
    }
}

void →operator new[]() {
    while(1) {
        /*BAD_CALL!*/ operator new[]();
        unsigned long* ptr0 = ptr0 - 1;
        *ptr0 = 0L;
        --ptr0;
        *ptr0 = gvar_405008;
    }
}

int →pthread_create(pthread_t* __newthread, pthread_attr_t* __attr, FUNCPTR __start_routine, void* __arg) {
    return →pthread_create(__newthread, __attr, __start_routine, __arg);
}

void →std::__ostream_insert<char, std::char_traits<char> >() {
    while(1) {
        /*BAD_CALL!*/ std::__ostream_insert<char, std::char_traits<char> >();
        unsigned long* ptr0 = ptr0 - 1;
        *ptr0 = 13L;
        --ptr0;
        *ptr0 = gvar_405008;
    }
}

void →std::__throw_length_error() {
    while(1) {
        /*BAD_CALL!*/ std::__throw_length_error();
        unsigned long* ptr0 = ptr0 - 1;
        *ptr0 = 5L;
        --ptr0;
        *ptr0 = gvar_405008;
    }
}

void →std::ios_base::Init::Init() {
    while(1) {
        /*BAD_CALL!*/ std::ios_base::Init::Init();
        unsigned long* ptr0 = ptr0 - 1;
        *ptr0 = 16L;
        --ptr0;
        *ptr0 = gvar_405008;
    }
}

long →std::ios_base::Init::~Init() {
    return →std::ios_base::Init::~Init();
}

void →std::ostream::_M_insert<unsigned long>() {
    while(1) {
        /*BAD_CALL!*/ std::ostream::_M_insert<unsigned long>();
        unsigned long* ptr0 = ptr0 - 1;
        *ptr0 = 7L;
        --ptr0;
        *ptr0 = gvar_405008;
    }
}

void →std::terminate() {
    while(1) {
        /*NO_RETURN*/ std::terminate();
        unsigned long* ptr0 = ptr0 - 1;
        *ptr0 = 1L;
        --ptr0;
        *ptr0 = gvar_405008;
    }
}

void →std::thread::_M_start_thread() {
    while(1) {
        /*BAD_CALL!*/ std::thread::_M_start_thread();
        unsigned long* ptr0 = ptr0 - 1;
        *ptr0 = 10L;
        --ptr0;
        *ptr0 = gvar_405008;
    }
}

void →std::thread::_State::~_State() {
    while(1) {
        /*BAD_CALL!*/ std::thread::_State::~_State();
        unsigned long* ptr0 = ptr0 - 1;
        *ptr0 = 4L;
        --ptr0;
        *ptr0 = gvar_405008;
    }
}

void →std::thread::hardware_concurrency() {
    while(1) {
        /*BAD_CALL!*/ std::thread::hardware_concurrency();
        unsigned long* ptr0 = ptr0 - 1;
        *ptr0 = 14L;
        --ptr0;
        *ptr0 = gvar_405008;
    }
}

void →std::thread::join() {
    while(1) {
        /*BAD_CALL!*/ std::thread::join();
        unsigned long* ptr0 = ptr0 - 1;
        *ptr0 = 20L;
        --ptr0;
        *ptr0 = gvar_405008;
    }
}

void →write(long param0, void* __buf, size_t __n) {
    while(1) {
        /*BAD_CALL!*/ write((int)param0, __buf, __n);
        unsigned long* ptr0 = ptr0 - 1;
        *ptr0 = 2L;
        --ptr0;
        *ptr0 = gvar_405008;
    }
}
