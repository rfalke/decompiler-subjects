
int start() {
    int v0 = 0;
    char v1 = 1;
    char v2 = 0;
    char v3 = 1;
    char v4 = 0;
    char v5 = 0;
    int v6 = 0x100;
    int v7 = 134512764;
    char v8 = 1;
    char v9 = 0;
    char v10 = 1;
    char v11 = 0;
    char v12 = 0;
    int v13 = 183;
    interrupt(128);
}
