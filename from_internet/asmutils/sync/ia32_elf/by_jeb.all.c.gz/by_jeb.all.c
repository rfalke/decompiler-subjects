
int start() {
    char v0;
    int v1 = 36;
    int v2 = 36;
    int* ptr0 = &v0;
    interrupt(128);
}
