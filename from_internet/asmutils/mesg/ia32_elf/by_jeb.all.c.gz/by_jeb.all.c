
int start() {
    char v0;
    int v1 = 0;
    char v2 = 1;
    char v3 = 0;
    char v4 = 1;
    char v5 = 0;
    char v6 = 0;
    int v7 = 0x100;
    int v8 = 134512865;
    int v9 = "/proc/self/fd/0";
    int v10 = 85;
    int v11 = 85;
    int* ptr0 = &v0;
    interrupt(128);
}
