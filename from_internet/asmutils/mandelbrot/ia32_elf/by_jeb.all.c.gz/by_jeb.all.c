
int start() {
    char v0;
    int v1 = 2;
    int v2 = &gvar_80480A7;
    int v3 = 5;
    int v4 = 5;
    int* ptr0 = &v0;
    interrupt(128);
}
