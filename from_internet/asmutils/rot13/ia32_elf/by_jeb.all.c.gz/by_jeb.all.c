
int start() {
    char v0;
    char v1;
    int* ptr0 = &v0;
    char v2 = &v0 == 80;
    char v3 = (int)&v1 < 0;
    char v4 = __parity__((unsigned char)&v0 - 80);
    char v5 = (int*)((int)(int*)((int)(int*)((int)(int*)((int)&v0 ^ 0x50) ^ (int)&v1) >>> 4) & 0x1);
    char v6 = (unsigned int)&v0 < 80;
    char v7 = (int)(int*)((int)(int*)((int)&v0 ^ (int)&v1) & (int)(int*)((int)&v0 ^ 0x50)) < 0;
    int v8 = 80;
    int* ptr1 = &v1;
    int v9 = 0;
    char v10 = 1;
    char v11 = 0;
    char v12 = 1;
    char v13 = 0;
    char v14 = 0;
    int v15 = 3;
    int v16 = 3;
    int* ptr2 = &v1;
    interrupt(128);
}
