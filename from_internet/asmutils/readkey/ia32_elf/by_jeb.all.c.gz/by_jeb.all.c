
int start() {
    char v0;
    int v1;
    int v2 = 134512894;
    int v3 = 134512894;
    int v4 = 21505;
    unsigned short v5 = (unsigned short)((unsigned short)&v0 - 4);
    char v6 = (unsigned short)&v0 == 8;
    char v7 = (int*)((int)(int*)((int)&v1 >>> 15) & 0x1);
    char v8 = __parity__((unsigned char)&v0 - 8);
    char v9 = ((((unsigned short)&v0 - 8) ^ (v5 ^ 0x4)) >>> 4) & 0x1;
    char v10 = v5 < 4;
    char v11 = ((((unsigned short)&v0 - 8) ^ v5) & (v5 ^ 0x4)) < 0;
    int v12 = sub_804805C();
    int v13 = 21505;
    int v14 = &gvar_8048122;
    int v15 = sub_804805C();
    gvar_804812E &= -12;
    char v16 = gvar_804812E ? 0: 1;
    char v17 = gvar_804812E >= 0x80000000;
    char v18 = __parity__((unsigned char)gvar_804812E);
    char v19 = 0;
    char v20 = 0;
    int v21 = 21506;
    int v22 = &gvar_8048122;
    v1 = 21506;
    int v23 = sub_804805C();
    int v24 = 0;
    char v25 = 1;
    char v26 = 0;
    char v27 = 1;
    char v28 = 0;
    char v29 = 0;
    gvar_8048122 = 0;
    int v30 = 4;
    int v31 = &gvar_8048122;
    int v32 = 0;
    char v33 = 1;
    char v34 = 0;
    char v35 = 1;
    char v36 = 0;
    char v37 = 0;
    int v38 = 3;
    int v39 = 3;
    int* ptr0 = &v1;
    interrupt(128);
}

int sub_804805C() {
    char v0;
    int v1 = 0;
    char v2 = 1;
    char v3 = 0;
    char v4 = 1;
    char v5 = 0;
    char v6 = 0;
    int v7 = 54;
    int v8 = 54;
    int* ptr0 = &v0;
    interrupt(128);
}
