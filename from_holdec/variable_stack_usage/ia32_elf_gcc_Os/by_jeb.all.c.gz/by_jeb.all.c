
void __libc_csu_fini() {
}

int __libc_csu_init(int param0, int param1, int param2) {
    int result;
    initializer_0();
    int v0 = 0;
    do {
        result = *(int*)(v0 * 4 + (int)&__frame_dummy_init_array_entry){initializer_1}();
        ++v0;
    }
    while(v0 != 1);
    return result;
}

void __x86.get_pc_thunk.bx() {
}

int _start(int param0, int param1) {
    →__libc_start_main();
    hlt();
}

// Stale decompilation - Refresh this view to re-decompile this code
int deregister_tm_clones() {
    return 3;
}

int fill(char* param0, int param1) {
    char* ptr0 = param0;
    int v0 = param1 * 4;
    int result = (unsigned int)120 | ((unsigned int)((param1 >>> 8) & 0xffffff) << 8);
    while(v0 != 0) {
        *ptr0 = (unsigned char)result;
        ++ptr0;
        --v0;
    }
    return result;
}

void finalizer_0() {
}

int finalizer_1() {
    int result;
    return result;
}

int initializer_0() {
    int result;
    if(__gmon_start__) {
        sub_80482D0();
    }
    return result;
}

int initializer_1() {
    return register_tm_clones();
}

int main(int param0) {
    with_alloca(param0);
    with_array(param0);
    return 0;
}

int register_tm_clones() {
    return 0;
}

void r→__libc_start_main() {
    jump gvar_804A008;
}

void sub_80482D0() {
    jump __gmon_start__;
}

int use(int* param0) {
    int result = *param0;
    sum += result;
    return result;
}

int with_alloca(int param0) {
    char v0;
    int* ptr0;
    int v1 = 7;
    int v2 = 8;
    int v3 = (param0 * 4 + 30) & 0xfffffff0;
    int v4 = (param0 * 4 + 30) & 0xfffffff0;
    fill((char*)((int)&v0 & 0xfffffff0), param0);
    use(&v1);
    use(ptr0);
    return use(&v2);
}

int with_array(int param0) {
    char v0;
    int* ptr0;
    int v1 = 7;
    int v2 = 8;
    int v3 = (param0 * 4 + 18) & 0xfffffff0;
    int v4 = (param0 * 4 + 18) & 0xfffffff0;
    fill(&v0, param0);
    use(&v1);
    use(ptr0);
    return use(&v2);
}

int →__libc_start_main() {
    int result;
    ptr___libc_start_main{r→__libc_start_main}();
    return result;
}
