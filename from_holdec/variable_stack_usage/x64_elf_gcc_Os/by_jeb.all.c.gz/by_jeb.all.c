
void __libc_csu_fini() {
}

void* __libc_csu_init(long param0, long param1) {
    void* result;
    initializer_0();
    long v0 = 0L;
    do {
        result = (void*)*(long*)(v0 * 8L + (long)&__frame_dummy_init_array_entry){initializer_1}();
        ++v0;
    }
    while(v0 != 1L);
    return result;
}

long _start(long param0, long param1) {
    long v0;
    long v1;
    long v2;
    char v3;
    __libc_start_main(&main, v0, (long)&v3, &__libc_csu_init, &__libc_csu_fini, param1, (long)&v1, v2);
    hlt();
}

// Stale decompilation - Refresh this view to re-decompile this code
long deregister_tm_clones() {
    return 7L;
}

char fill(char* param0, int param1) {
    for(long i = (long)param1 * 4L; i != 0L; --i) {
        *param0 = 120;
        ++param0;
    }
    return 120;
}

void finalizer_0() {
}

long finalizer_1() {
    long result;
    return result;
}

void* initializer_0() {
    void* result = __gmon_start__;
    if(result) {
        result = (void*)result();
    }
    return result;
}

long initializer_1() {
    return register_tm_clones();
}

long main(long param0, long param1, long param2, long param3, int param4) {
    with_alloca(param0);
    with_array((long)param4);
    return 0L;
}

long register_tm_clones() {
    return 0L;
}

int use(int* param0) {
    int result = *param0;
    sum += result;
    return result;
}

int with_alloca(int param0) {
    long v0;
    long v1;
    int* ptr0;
    fill((char*)((long)(long*)((char*)&v0 + 7L) & 0xfffffffffffffff0L), (long)param0);
    use(&v1);
    use(ptr0);
    return use(&v1 + 1);
}

int with_array(int param0) {
    long v0;
    long v1;
    fill(&v0, (long)param0);
    use(&v1);
    use((int*)&v0);
    return use(&v1 + 1);
}
