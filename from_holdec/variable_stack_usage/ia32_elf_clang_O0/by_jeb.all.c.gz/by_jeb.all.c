
void __libc_csu_fini() {
}

int __libc_csu_init(int param0, int param1, int param2) {
    int result;
    initializer_0();
    int v0 = 0;
    do {
        result = *(int*)(v0 * 4 + (int)&__frame_dummy_init_array_entry){initializer_1}();
        ++v0;
    }
    while(v0 != 1);
    return result;
}

void __x86.get_pc_thunk.bx() {
}

int _start(int param0, int param1) {
    →__libc_start_main();
    hlt();
}

// Stale decompilation - Refresh this view to re-decompile this code
int deregister_tm_clones() {
    return 3;
}

void* fill(void* __s, int param1) {
    void* ptr0 = __s;
    int v0 = param1;
    int v1 = 120;
    return →memset(__s, 120, (size_t)(param1 * 4));
}

void finalizer_0() {
}

int finalizer_1() {
    int result;
    return result;
}

int initializer_0() {
    int result;
    if(__gmon_start__) {
        sub_8048300();
    }
    return result;
}

int initializer_1() {
    return register_tm_clones();
}

int main(int param0, int param1) {
    with_alloca(param0);
    with_array(param0);
    return 0;
}

int register_tm_clones() {
    return 0;
}

int r→__libc_start_main() {
    /*BAD_CALL!*/ sub_80482D0();
}

void* r→memset(void* __s, int __c, size_t __n) {
    /*BAD_CALL!*/ sub_80482D0();
}

void sub_80482D0() {
    jump gvar_804A008;
}

void sub_8048300() {
    jump __gmon_start__;
}

unsigned int use(int* param0) {
    unsigned int result = sum + *param0;
    sum += *param0;
    return result;
}

unsigned int with_alloca(int param0) {
    char v0;
    int v1 = param0;
    int v2 = 7;
    void* __s = (void*)((int)&v0 - ((v1 * 4 + 15) & 0xfffffff0));
    int v3 = 8;
    fill(__s, v1);
    use(&v2);
    use((int*)__s);
    return use(&v3);
}

void* with_array(int param0) {
    char v0;
    int v1 = param0;
    int v2 = 7;
    void* result = &v0;
    int v3 = 8;
    int v4 = v1;
    int* ptr0 = (int*)&v0;
    fill(&v0, v4);
    use(&v2);
    use(ptr0);
    use(&v3);
    return result;
}

int →__libc_start_main() {
    return ptr___libc_start_main{r→__libc_start_main}();
}

void* →memset(void* __s, int __c, size_t __n) {
    return ptr_memset[0]{r→memset}(__s, __c, __n);
}
