
void __libc_csu_fini() {
}

void* __libc_csu_init(long param0, long param1) {
    void* result;
    initializer_0();
    long v0 = 0L;
    do {
        result = (void*)*(long*)(v0 * 8L + (long)&__frame_dummy_init_array_entry){initializer_1}();
        ++v0;
    }
    while(v0 != 1L);
    return result;
}

long _start(long param0, long param1) {
    long v0;
    long v1;
    long v2;
    char v3;
    __libc_start_main(&main, v0, (long)&v3, &__libc_csu_init, &__libc_csu_fini, param1, (long)&v1, v2);
    hlt();
}

// Stale decompilation - Refresh this view to re-decompile this code
long deregister_tm_clones() {
    return 7L;
}

void* fill(void* __s, int param1) {
    return →memset(__s, 120, (size_t)((long)param1 * 4L));
}

void finalizer_0() {
}

long finalizer_1() {
    long result;
    return result;
}

void* initializer_0() {
    void* result = __gmon_start__;
    if(result) {
        result = (void*)result();
    }
    return result;
}

long initializer_1() {
    return register_tm_clones();
}

long main(int param0, long param1) {
    with_alloca((long)param0);
    with_array((long)param0);
    return 0L;
}

long register_tm_clones() {
    return 0L;
}

void* r→memset(void* __s, int __c, size_t __n) {
    jump gvar_601010;
}

unsigned int use(int* param0) {
    unsigned int result = sum + *param0;
    sum += *param0;
    return result;
}

unsigned int with_alloca(int param0) {
    char v0;
    int v1 = param0;
    int v2 = 7;
    void* __s = (void*)((long)(long*)((long)&v0 >>> 4) * 16L);
    int v3 = 8;
    fill(__s, (long)v1);
    use(&v2);
    use((int*)__s);
    return use(&v3);
}

unsigned int with_array(int param0) {
    char v0;
    int v1 = param0;
    int v2 = 7;
    long v3 = (long)v1 - 1L;
    void* __s = (void*)((long)(long*)((long)&v0 >>> 2) * 4L);
    int v4 = 8;
    fill(__s, (long)v1);
    use(&v2);
    use((int*)__s);
    return use(&v4);
}

void* →memset(void* __s, int __c, size_t __n) {
    return ptr_memset[0]{r→memset}(__s, (int)__c, __n);
}
