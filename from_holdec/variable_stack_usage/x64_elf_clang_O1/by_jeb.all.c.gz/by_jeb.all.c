
void __libc_csu_fini() {
}

void* __libc_csu_init(long param0, long param1, long param2) {
    void* result;
    initializer_0();
    unsigned long v0 = 0L;
    do {
        *(long*)(v0 * 8L + (long)&__frame_dummy_init_array_entry){initializer_1}();
        ++v0;
    }
    while(v0 != 1L);
    return result;
}

long _start(long param0, long param1) {
    long v0;
    long v1;
    long v2;
    long v3;
    char v4;
    long v5 = 0L;
    char v6 = 1;
    char v7 = 0;
    char v8 = 1;
    char v9 = 0;
    char v10 = 0;
    long v11 = param1;
    long v12 = v0;
    long* ptr0 = &v4;
    char v13 = &v0 ? 0: 1;
    char v14 = (long)&v0 < 0L;
    char v15 = __parity__((unsigned char)&v0);
    char v16 = 0;
    char v17 = 0;
    long* ptr1 = &v1;
    long v18 = &__libc_csu_fini;
    long v19 = &__libc_csu_init;
    long v20 = &main;
    long* ptr2 = &v2;
    long v21 = __libc_start_main(&main, v12, (long)&v4, &__libc_csu_init, &__libc_csu_fini, v11, (long)&v1, v3);
    hlt();
}

long deregister_tm_clones() {
    return 7L;
}

void* fill(void* __s, int param1) {
    return →memset(__s, 120L, (size_t)((long)param1 * 4L));
}

void finalizer_0() {
}

void finalizer_1() {
    char v0 = completed.6917 ? 0: 1;
    char v1 = completed.6917 >= 128;
    char v2 = __parity__(completed.6917);
    char v3 = completed.6917 < 0;
    char v4 = 0;
    char v5 = 0;
    jump v0 ? &sub_4004B9: &sub_4004CA;
}

void* initializer_0() {
    void* result = __gmon_start__;
    if(result) {
        result = (void*)result();
    }
    return result;
}

void initializer_1() {
    long v0 = &__JCR_LIST__;
    char v1 = *(long*)&__JCR_LIST__ ? 0: 1;
    char v2 = *(long*)&__JCR_LIST__ >= 0x8000000000000000L;
    char v3 = __parity__((unsigned char)*(long*)&__JCR_LIST__);
    char v4 = *(long*)&__JCR_LIST__ < 0L;
    char v5 = 0;
    char v6 = 0;
    jump v1 ? &→register_tm_clones: &sub_4004E0;
}

long main(long param0) {
    with_alloca(param0);
    with_array((long)(unsigned int)param0);
    return 0L;
}

long sub_4004B9() {
    long v0;
    long v1 = v0;
    deregister_tm_clones();
    completed.6917 = 1;
}

void sub_4004CA() {
}

long sub_4004E0() {
    return register_tm_clones();
}

int use(int* param0) {
    int result = *param0;
    sum += result;
    return result;
}

int with_alloca(int param0) {
    int v0;
    int v1;
    long v2;
    int v3;
    long v4 = v2;
    *(long*)&v0 = v3;
    void* __s = (void*)((long)&v0 - (unsigned long)(((long)param0 * 4L + 15L) & 0xfffffffffffffff0L));
    *(long*)&v0 = &loc_4005D4;
    /*BAD_CALL!*/ fill(__s, (long)param0);
    *(long*)&v0 = &loc_4005DD;
    /*BAD_CALL!*/ use(&v0);
    *(long*)&v0 = &loc_4005E5;
    /*BAD_CALL!*/ use((int*)__s);
    *(long*)&v0 = &loc_4005EE;
    return /*BAD_CALL!*/ use(&v1);
}

int with_array(int param0) {
    void* ptr0;
    long v0;
    long v1;
    long v2 = v1;
    long v3 = v0;
    int v4 = 7;
    void* __s = (void*)((long)&ptr0 - (unsigned long)(((unsigned long)param0 * 4L + 15L) & 0x7fffffff0L));
    int v5 = 8;
    fill(__s, (long)param0);
    use(&v4);
    use((int*)__s);
    return use(&v5);
}

void* →memset(void* __s, long param1, size_t __n) {
    return memset(__s, (int)param1, __n);
}
