
void __libc_csu_fini() {
}

void* __libc_csu_init(long param0, long param1) {
    void* result;
    initializer_0();
    long v0 = 0L;
    do {
        result = (void*)*(long*)(v0 * 8L + (long)&__frame_dummy_init_array_entry){initializer_1}();
        ++v0;
    }
    while(v0 != 1L);
    return result;
}

long _start(long param0, long param1) {
    long v0;
    long v1;
    long v2;
    char v3;
    __libc_start_main(&main, v0, (long)&v3, &__libc_csu_init, &__libc_csu_fini, param1, (long)&v1, v2);
    hlt();
}

// Stale decompilation - Refresh this view to re-decompile this code
long deregister_tm_clones() {
    return 7L;
}

void* fill(void* __s, long param1) {
    return →memset(__s, 120, (size_t)((long)(unsigned int)param1 * 4L));
}

void finalizer_0() {
}

long finalizer_1() {
    long result;
    return result;
}

void* initializer_0() {
    void* result = __gmon_start__;
    if(result) {
        result = (void*)result();
    }
    return result;
}

long initializer_1() {
    return register_tm_clones();
}

long main(long param0) {
    with_alloca(param0);
    with_array((long)(unsigned int)param0);
    return 0L;
}

long register_tm_clones() {
    return 0L;
}

void* r→memset(void* __s, int __c, size_t __n) {
    jump gvar_601010;
}

int use(int* param0) {
    int result = *param0;
    sum += result;
    return result;
}

int with_alloca(int param0) {
    long v0;
    void* __s = (void*)((long)&v0 - (((long)param0 * 4L + 15L) & 0xfffffffffffffff0L));
    fill(__s, (long)param0);
    use(&v0);
    use((int*)__s);
    return use(&v0 + 1);
}

int with_array(int param0) {
    char v0;
    int v1;
    int v2;
    void* __s = (void*)((long)&v0 - (((unsigned long)param0 * 4L + 15L) & 0x7fffffff0L));
    fill(__s, (long)param0);
    use(&v1);
    use((int*)__s);
    return use(&v2);
}

void* →memset(void* __s, int __c, size_t __n) {
    return ptr_memset[0]{r→memset}(__s, (int)__c, __n);
}
