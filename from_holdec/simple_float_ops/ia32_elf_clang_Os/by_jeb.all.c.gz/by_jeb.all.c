
void __libc_csu_fini() {
}

int __libc_csu_init(int param0, int param1, int param2) {
    int result;
    initializer_0();
    unsigned int v0 = 0;
    do {
        result = *(int*)(v0 * 4 + (int)&__frame_dummy_init_array_entry){initializer_1}();
        ++v0;
    }
    while(v0 != 1);
    return result;
}

void __x86.get_pc_thunk.bx() {
}

int _start(int param0, int param1) {
    int v0;
    char v1;
    void* ptr0;
    int v2;
    int v3 = 0;
    char v4 = 1;
    char v5 = 0;
    char v6 = 1;
    char v7 = 0;
    char v8 = 0;
    int v9 = v0;
    int* ptr1 = &v1;
    char v10 = &v0 ? 0: 1;
    char v11 = (int)&v0 < 0;
    char v12 = __parity__((unsigned char)&v0);
    char v13 = 0;
    char v14 = 0;
    int v15 = v2;
    int* ptr2 = &v15;
    int* ptr3 = &v15;
    int v16 = param1;
    int v17 = &__libc_csu_fini;
    int v18 = &__libc_csu_init;
    int* ptr4 = &v1;
    int v19 = &main;
    int* ptr5 = &ptr0;
    →__libc_start_main();
    hlt();
}

void basic_operations() {
    // Decompilation error
}

void compare_floats() {
    // Decompilation error
}

int constants(double param0, int param1) {
    →printf(&gvar_8048930);
    →printf(&gvar_8048930);
    →printf(&gvar_8048930);
    →printf(&gvar_8048930);
    →printf(&gvar_8048930);
    return 125;
}

void converting_between_floats_d1() {
    global_double = global_float;
}

void converting_between_floats_d2() {
    global_double = *(__int128*)&global_long_double;
}

void converting_between_floats_f1() {
    global_float = global_double;
}

void converting_between_floats_f2() {
    global_float = *(__int128*)&global_long_double;
}

void converting_between_floats_l1() {
    *(__int128*)&global_long_double = global_float;
}

void converting_between_floats_l2() {
    *(__int128*)&global_long_double = global_double;
}

int deregister_tm_clones() {
    return 3;
}

void finalizer_0() {
}

void finalizer_1() {
    char v0 = completed.6532 ? 0: 1;
    char v1 = completed.6532 >= 128;
    char v2 = __parity__(completed.6532);
    char v3 = completed.6532 < 0;
    char v4 = 0;
    char v5 = 0;
    jump v0 ? &sub_80483C9: &sub_80483DC;
}

int initializer_0() {
    int result = __gmon_start__;
    if(result) {
        result = sub_8048300();
    }
    return result;
}

int initializer_1() {
    int v0 = &__JCR_LIST__;
    unsigned char v1 = *(int*)&__JCR_LIST__;
    char v2 = v1 ? 0: 1;
    char v3 = v1 >= 0x80000000;
    char v4 = __parity__((unsigned char)v1);
    char v5 = 0;
    char v6 = 0;
    jump v2 ? &→register_tm_clones: &sub_80483F0;
}

int main() {
    →printf("%zu %zu %zu %zu %zu\n");
    →printf("%zu %zu %zu\n");
    return 0;
}

int read_floats() {
    →printf(&gvar_8048930);
    return 122;
}

int read_ints() {
    →printf(&gvar_8048930);
    return 120;
}

int sub_80482D6() {
    return gvar_804A008();
}

int sub_8048300() {
    return __gmon_start__();
}

int sub_804835F() {
    return 0;
}

void sub_8048398() {
}

int sub_80483C9() {
    int v0;
    int v1 = v0;
    deregister_tm_clones();
    completed.6532 = 1;
}

void sub_80483DC() {
}

int sub_80483F0() {
    return register_tm_clones();
}

int use(long long param0, int param1) {
    int result;
    →printf(&gvar_8048930);
    return result;
}

int use_int(int param0) {
    int result;
    →printf(&gvar_8048933);
    return result;
}

void write_floats(double param0, int param1) {
    global_double = param0;
    global_float = param0;
    *(__int128*)&global_long_double = param0;
}

int write_ints(double param0, int param1) {
    short v0;
    int v1;
    int v2;
    global_char = (unsigned char)(int)param0;
    global_short = (unsigned short)(int)param0;
    global_int = (int)param0;
    global_long = (int)param0;
    short v0 = fnstcw();
    fldcw(3199);
    *(long long*)&v1 = (long long)param0;
    fldcw(v0);
    global_long_long = (unsigned long long)v1 | ((unsigned long long)v2 << 32);
    return 121;
}

void →__libc_start_main() {
    while(1) {
        /*BAD_CALL!*/ __libc_start_main();
        unsigned int* ptr0 = ptr0 - 1;
        *ptr0 = 8;
        --ptr0;
        *ptr0 = gvar_804A004;
    }
}

void →printf(int param0) {
    unsigned int* ptr0;
    while(1) {
        /*BAD_CALL!*/ printf(*(char**)(ptr0 + 1));
        --ptr0;
        *ptr0 = 0;
        --ptr0;
        *ptr0 = gvar_804A004;
    }
}
