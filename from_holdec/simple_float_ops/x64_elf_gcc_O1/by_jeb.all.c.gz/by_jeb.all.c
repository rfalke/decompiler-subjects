
void __libc_csu_fini() {
}

void* __libc_csu_init(long param0, long param1, long param2) {
    void* result;
    initializer_0();
    unsigned long v0 = 0L;
    do {
        *(long*)(v0 * 8L + (long)&__frame_dummy_init_array_entry){initializer_1}();
        ++v0;
    }
    while(v0 != 1L);
    return result;
}

long _start(long param0, long param1) {
    long v0;
    long v1;
    long v2;
    long v3;
    char v4;
    long v5 = 0L;
    char v6 = 1;
    char v7 = 0;
    char v8 = 1;
    char v9 = 0;
    char v10 = 0;
    long v11 = param1;
    long v12 = v0;
    long* ptr0 = &v4;
    char v13 = &v0 ? 0: 1;
    char v14 = (long)&v0 < 0L;
    char v15 = __parity__((unsigned char)&v0);
    char v16 = 0;
    char v17 = 0;
    long* ptr1 = &v1;
    long v18 = &__libc_csu_fini;
    long v19 = &__libc_csu_init;
    long v20 = &main;
    long* ptr2 = &v2;
    long v21 = __libc_start_main(&main, v12, (long)&v4, &__libc_csu_init, &__libc_csu_fini, v11, (long)&v1, v3);
    hlt();
}

long basic_operations() {
    use();
    use();
    use();
    use();
    use();
    use();
    use();
    return 123L;
}

long compare_floats() {
    char v0;
    char v1;
    char v2;
    char v3;
    char v4;
    char v5;
    char v6;
    char v7;
    double v8;
    double v9;
    if(v9 == v8) {
        v7 = 1;
        v6 = 0;
    }
    else if(v9 > v8) {
        v7 = 0;
        v6 = 0;
    }
    else if(v9 < v8) {
        v7 = 0;
        v6 = 0;
    }
    else {
        v7 = 1;
        v6 = 1;
    }
    /*BAD_CALL!*/ use_int(v7 ? v6 ? 0L: 1L: 0L);
    if(v9 == v8) {
        v5 = 1;
        v4 = 0;
    }
    else if(v9 > v8) {
        v5 = 0;
        v4 = 0;
    }
    else if(v9 < v8) {
        v5 = 0;
        v4 = 0;
    }
    else {
        v5 = 1;
        v4 = 1;
    }
    /*BAD_CALL!*/ use_int(v5 ? v4 ? 1L: 0L: 1L);
    if(v9 == v8) {
        v3 = 1;
        v2 = 0;
    }
    else if(v9 > v8) {
        v3 = 0;
        v2 = 0;
    }
    else {
        v3 = v9 < v8 ? 0: 1;
        v2 = 1;
    }
    use_int(v2 || v3 ? 0L: 1L);
    /*BAD_CALL!*/ use_int(v9 != v8 ? v9 <= v8: 0 ? 0L: 1L);
    if(v8 == v9) {
        v1 = 1;
        v0 = 0;
    }
    else if(v8 > v9) {
        v1 = 0;
        v0 = 0;
    }
    else {
        v1 = v8 < v9 ? 0: 1;
        v0 = 1;
    }
    use_int(v0 || v1 ? 0L: 1L);
    use_int(v8 != v9 ? v8 <= v9: 0 ? 0L: 1L);
    return 124L;
}

long constants() {
    use();
    use();
    use();
    use();
    use();
    return 125L;
}

void converting_between_floats_d1() {
    global_double = global_float;
}

void converting_between_floats_d2() {
    global_double = *(__int128*)&global_long_double;
}

void converting_between_floats_f1() {
    global_float = global_double;
}

void converting_between_floats_f2() {
    global_float = *(__int128*)&global_long_double;
}

void converting_between_floats_l1() {
    *(__int128*)&global_long_double = global_float;
}

void converting_between_floats_l2() {
    *(__int128*)&global_long_double = global_double;
}

long deregister_tm_clones() {
    return 7L;
}

void finalizer_0() {
}

void finalizer_1() {
    char v0 = completed.6917 ? 0: 1;
    char v1 = completed.6917 >= 128;
    char v2 = __parity__(completed.6917);
    char v3 = completed.6917 < 0;
    char v4 = 0;
    char v5 = 0;
    jump v0 ? &sub_4004B9: &sub_4004CA;
}

void* initializer_0() {
    void* result = __gmon_start__;
    if(result) {
        result = (void*)result();
    }
    return result;
}

void initializer_1() {
    long v0 = &__JCR_LIST__;
    char v1 = *(long*)&__JCR_LIST__ ? 0: 1;
    char v2 = *(long*)&__JCR_LIST__ >= 0x8000000000000000L;
    char v3 = __parity__((unsigned char)*(long*)&__JCR_LIST__);
    char v4 = *(long*)&__JCR_LIST__ < 0L;
    char v5 = 0;
    char v6 = 0;
    jump v1 ? &→register_tm_clones: &sub_4004E0;
}

long main() {
    →printf("%zu %zu %zu %zu %zu\n");
    →printf((char*)"%zu %zu %zu\n");
    return 0L;
}

long read_floats() {
    use();
    return 122L;
}

long read_ints() {
    use();
    return 120L;
}

long sub_4004B9() {
    long v0;
    long v1 = v0;
    deregister_tm_clones();
    completed.6917 = 1;
}

void sub_4004CA() {
}

long sub_4004E0() {
    return register_tm_clones();
}

int use() {
    return →printf((char*)&gvar_400920);
}

int use_int(long param0) {
    return →printf((char*)&gvar_400923);
}

void write_floats() {
    double v0;
    global_float = v0;
    global_double = v0;
    *(__int128*)&global_long_double = v0;
}

long write_ints() {
    int v0;
    double v1;
    global_char = (unsigned char)(int)v1;
    global_short = (unsigned short)(int)v1;
    global_int = (int)v1;
    global_long = (unsigned long)(int)v1 | ((unsigned long)v0 << 32);
    global_long_long = (unsigned long)(int)v1 | ((unsigned long)v0 << 32);
    return 121L;
}

int →printf(char* __format) {
    return printf(__format);
}
