
void __libc_csu_fini() {
}

int __libc_csu_init(int param0, int param1, int param2) {
    int result;
    initializer_0();
    int v0 = 0;
    do {
        result = *(int*)(v0 * 4 + (int)&__frame_dummy_init_array_entry){initializer_1}();
        ++v0;
    }
    while(v0 != 1);
    return result;
}

void __x86.get_pc_thunk.bx() {
}

void _dl_relocate_static_pie() {
}

int _start(int param0, int param1) {
    →__libc_start_main();
    hlt();
}

int a_func() {
    int v0;
    int v1;
    int v2;
    return →printf("in func: %d\n", a_global, v0, v1, v2);
}

// Stale decompilation - Refresh this view to re-decompile this code
int deregister_tm_clones() {
    return &completed.6844;
}

void finalizer_0() {
}

void finalizer_1() {
    if(!completed.6844) {
        deregister_tm_clones();
        completed.6844 = 1;
    }
}

void* initializer_0() {
    void* result = __gmon_start__;
    if(result) {
        result = (void*)result();
    }
    return result;
}

int initializer_1() {
    return register_tm_clones();
}

int main() {
    int v0 = →printf("in main: %d\n", a_global);
    ++a_global;
    a_func();
    return 0;
}

int register_tm_clones() {
    return 0;
}

int r→__libc_start_main() {
    /*BAD_CALL!*/ sub_8049030();
}

int r→printf(char* __format, ...) {
    /*BAD_CALL!*/ sub_8049030();
}

void sub_8049030() {
    jump gvar_804C008;
}

void sub_8049097() {
}

int →__libc_start_main() {
    return ptr___libc_start_main{r→__libc_start_main}();
}

int →printf(char* __format, ...) {
    return ptr_printf[0]{r→printf}(__format);
}
