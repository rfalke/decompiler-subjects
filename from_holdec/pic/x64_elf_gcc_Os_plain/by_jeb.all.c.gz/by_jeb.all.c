
void __libc_csu_fini() {
}

void* __libc_csu_init(long param0, long param1, long param2) {
    void* result;
    initializer_0();
    unsigned long v0 = 0L;
    do {
        result = (void*)*(long*)(v0 * 8L + (long)&__frame_dummy_init_array_entry){initializer_1}();
        ++v0;
    }
    while(v0 != 1L);
    return result;
}

void _dl_relocate_static_pie() {
}

long _start(long param0, long param1) {
    long v0;
    long v1;
    long v2;
    long v3;
    char v4;
    long v5 = 0L;
    char v6 = 1;
    char v7 = 0;
    char v8 = 1;
    char v9 = 0;
    char v10 = 0;
    long v11 = param1;
    long v12 = v0;
    long* ptr0 = &v4;
    char v13 = &v0 ? 0: 1;
    char v14 = (long)&v0 < 0L;
    char v15 = __parity__((unsigned char)&v0);
    char v16 = 0;
    char v17 = 0;
    long* ptr1 = &v1;
    long v18 = &__libc_csu_fini;
    long v19 = &__libc_csu_init;
    long v20 = &main;
    long* ptr2 = &v2;
    long v21 = __libc_start_main(&main, v12, (long)&v4, &__libc_csu_init, &__libc_csu_fini, v11, (long)&v1, v3);
    hlt();
}

int a_func() {
    return →printf("in func: %d\n");
}

long deregister_tm_clones() {
    return &completed.7287;
}

void finalizer_0() {
}

void finalizer_1() {
    char v0 = completed.7287 ? 0: 1;
    char v1 = completed.7287 >= 128;
    char v2 = __parity__(completed.7287);
    char v3 = completed.7287 < 0;
    char v4 = 0;
    char v5 = 0;
    jump v0 ? &sub_40112D: &sub_401140;
}

void* initializer_0() {
    void* result = __gmon_start__;
    if(result) {
        result = (void*)result();
    }
    return result;
}

long initializer_1() {
    return register_tm_clones();
}

long main() {
    →printf("in main: %d\n");
    ++a_global;
    a_func();
    return 0L;
}

long register_tm_clones() {
    return 0L;
}

long sub_4010BD() {
    return 0L;
}

long sub_4010FF() {
    return 0L;
}

long sub_40112D() {
    long result = deregister_tm_clones();
    completed.7287 = 1;
    return result;
}

void sub_401140() {
}

int →printf(char* __format) {
    return printf(__format);
}
