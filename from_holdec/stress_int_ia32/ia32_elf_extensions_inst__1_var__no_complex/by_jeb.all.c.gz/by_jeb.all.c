
void __libc_csu_fini() {
}

int __libc_csu_init(int param0, int param1, int param2) {
    int result;
    initializer_0();
    int v0 = 0;
    do {
        result = *(int*)(v0 * 4 + (int)&__frame_dummy_init_array_entry){initializer_1}();
        ++v0;
    }
    while(v0 != 1);
    return result;
}

void __x86.get_pc_thunk.bx() {
}

void _dl_relocate_static_pie() {
}

int _start(int param0, int param1) {
    →__libc_start_main();
    hlt();
}

// Stale decompilation - Refresh this view to re-decompile this code
int deregister_tm_clones() {
    return &completed.6844;
}

void finalizer_0() {
}

void finalizer_1() {
    if(!completed.6844) {
        deregister_tm_clones();
        completed.6844 = 1;
    }
}

void* initializer_0() {
    void* result = __gmon_start__;
    if(result) {
        result = (void*)result();
    }
    return result;
}

int initializer_1() {
    return register_tm_clones();
}

int inst_0_flags_var_0() {
    for(short i = 0; !((4335 >>> i) & 0x1); ++i) {
    }
    return 1;
}

int inst_0_values_var_0() {
    short i;
    for(i = 0; !((42631 >>> i) & 0x1); ++i) {
    }
    return ((unsigned int)i | ((unsigned int)0x7671 << 16)) - 0x76710000;
}

int inst_10_flags_var_0() {
    int v0 = pext(1677974700, 254618161, -908041639);
    return 0;
}

int inst_10_values_var_0() {
    int v0;
    int v0 = pext(559544181, 0x10632017, -754745945);
    return v0 - 39431;
}

int inst_11_flags_var_0() {
    int v0 = rorx(2005303432, -848104206, 131);
    return 0;
}

int inst_11_values_var_0() {
    int v0;
    int v0 = rorx(1157804980, 1149586349, 55);
    return v0 - 177691273;
}

int inst_12_flags_var_0() {
    int v0 = sarx(-499244090, -499244090, 240633786);
    return 0;
}

int inst_12_values_var_0() {
    int v0;
    int v0 = sarx(545436252, -1921826626, -431313248);
    return v0 + 1921826626;
}

int inst_13_flags_var_0() {
    int v0 = shlx(0xa1e08aa, 372815352, -1231582943);
    return 0;
}

int inst_13_values_var_0() {
    int v0;
    int v0 = shlx(-255251217, -1492275047, -1476330234);
    return v0 + 1016322496;
}

int inst_14_flags_var_0() {
    int v0 = shrx(-1099582407, -1212442342, -1533018830);
    return 0;
}

int inst_14_values_var_0() {
    int v0;
    int v0 = shrx(1139148397, -1264045333, 1214553529);
    return v0 - 90;
}

int inst_15_flags_var_0() {
    int v0 = adox(-212912351, -1134117440);
    return -2;
}

int inst_15_values_var_0() {
    int v0;
    int v0 = adox(-966792466, 0x1c9d9dd7);
    return v0 + 486700859;
}

int inst_16_flags_var_0() {
    int v0 = adcx(0xd28e89cb, -1154752663);
    return 0;
}

int inst_16_values_var_0() {
    int v0;
    int v0 = adcx(1995195195, 1995195195);
    return v0 + 0x12277989;
}

int inst_17_flags_var_0() {
    int v0 = crc32(-37965669, 134);
    return 0;
}

int inst_17_values_var_0() {
    int v0;
    int v0 = crc32(1364262155, 126);
    return v0 - 1144525036;
}

int inst_18_flags_var_0() {
    int v0 = crc32(691499111, 37285);
    return 0;
}

int inst_18_values_var_0() {
    int v0;
    int v0 = crc32(0xd47780c8, 31598);
    return v0 + 0x789fa710;
}

int inst_19_flags_var_0() {
    int v0 = crc32(-1488273469, 982821990);
    return 0;
}

int inst_19_values_var_0() {
    int result;
    int result = crc32(1298586160, 1298586160);
    return result;
}

int inst_1_flags_var_0() {
    int v0 = tzcnt(505644846, 505644846);
    return 1;
}

int inst_1_values_var_0() {
    int result;
    int result = tzcnt(1188606471, 2126687567);
    return result;
}

int inst_20_flags_var_0() {
    for(short i = 15; !(58334 >>> i); --i) {
    }
    return 0;
}

int inst_20_values_var_0() {
    short i;
    for(i = 15; !(0xe79e >>> i); --i) {
    }
    return ((unsigned int)i | ((unsigned int)0xee18 << 16)) + 0x11e80000;
}

int inst_21_flags_var_0() {
    int v0 = lzcnt(0x8d73a5d9, -958458679);
    return 0;
}

int inst_21_values_var_0() {
    int result;
    int result = lzcnt(3913962, -1380445091);
    return result;
}

int inst_2_flags_var_0() {
    int v0 = andn(-426369894, 1655466428, -1535964828);
    return 1;
}

int inst_2_values_var_0() {
    int result;
    int result = andn(-558817161, 0xac3bbbc9, 0xac3bbbc9);
    return result;
}

int inst_3_flags_var_0() {
    int v0 = blsi(337787027, 1326047737);
    return 0;
}

int inst_3_values_var_0() {
    int v0;
    int v0 = blsi(-832579020, 0x341ddbdc);
    return v0 - 4;
}

int inst_4_flags_var_0() {
    int v0 = blsmsk(-727843299, -101510262);
    return 9;
}

int inst_4_values_var_0() {
    int v0;
    int v0 = blsmsk(-1900828896, 549408184);
    return v0 - 15;
}

int inst_5_flags_var_0() {
    int v0 = blsr(-1317964494, -1275481825);
    return 1;
}

int inst_5_values_var_0() {
    int v0;
    int v0 = blsr(1961760895, -1989225311);
    return v0 + 1989225312;
}

int inst_6_flags_var_0() {
    int v0 = bextr(1282184010, -566779378, 1437002413);
    return 1;
}

int inst_6_values_var_0() {
    int result;
    int result = bextr(0xda0def02, 1955479381, -384479238);
    return result;
}

int inst_7_flags_var_0() {
    int v0 = bzhi(0x38088e39, -1382549296, -610942451);
    return 9;
}

int inst_7_values_var_0() {
    int v0;
    int v0 = bzhi(-641642159, 1855746570, 1304388882);
    return v0 - 29194;
}

int inst_8_flags_var_0() {
    int v0 = mulx(-2043665945, 1123906385, -1063472138, 2047309213);
    return 0;
}

int inst_8_values_var_0() {
    int v0;
    int v0 = mulx(-199684445, 471484636, 0x1a654336, 2019130086);
    return v0 + 1760131319;
}

int inst_9_flags_var_0() {
    int v0 = pdep(0xf47ebbc0, 0xf47ebbc0, -730499874);
    return 0;
}

int inst_9_values_var_0() {
    int v0;
    int v0 = pdep(-1517668516, -1538208650, 586697082);
    return v0 - 543164760;
}

int main() {
    int v0 = inst_0_values_var_0();
    int v1 = /*BAD_CALL!*/ inst_0_flags_var_0();
    int v2 = /*BAD_CALL!*/ inst_1_values_var_0();
    int v3 = /*BAD_CALL!*/ inst_1_flags_var_0();
    int v4 = /*BAD_CALL!*/ inst_2_values_var_0();
    int v5 = /*BAD_CALL!*/ inst_2_flags_var_0();
    int v6 = /*BAD_CALL!*/ inst_3_values_var_0();
    int v7 = /*BAD_CALL!*/ inst_3_flags_var_0();
    int v8 = /*BAD_CALL!*/ inst_4_values_var_0();
    int v9 = /*BAD_CALL!*/ inst_4_flags_var_0();
    int v10 = /*BAD_CALL!*/ inst_5_values_var_0();
    int v11 = /*BAD_CALL!*/ inst_5_flags_var_0();
    int v12 = /*BAD_CALL!*/ inst_6_values_var_0();
    int v13 = /*BAD_CALL!*/ inst_6_flags_var_0();
    int v14 = /*BAD_CALL!*/ inst_7_values_var_0();
    int v15 = /*BAD_CALL!*/ inst_7_flags_var_0();
    int v16 = /*BAD_CALL!*/ inst_8_values_var_0();
    int v17 = /*BAD_CALL!*/ inst_8_flags_var_0();
    int v18 = /*BAD_CALL!*/ inst_9_values_var_0();
    int v19 = /*BAD_CALL!*/ inst_9_flags_var_0();
    int v20 = /*BAD_CALL!*/ inst_10_values_var_0();
    int v21 = /*BAD_CALL!*/ inst_10_flags_var_0();
    int v22 = /*BAD_CALL!*/ inst_11_values_var_0();
    int v23 = /*BAD_CALL!*/ inst_11_flags_var_0();
    int v24 = /*BAD_CALL!*/ inst_12_values_var_0();
    int v25 = /*BAD_CALL!*/ inst_12_flags_var_0();
    int v26 = /*BAD_CALL!*/ inst_13_values_var_0();
    int v27 = /*BAD_CALL!*/ inst_13_flags_var_0();
    int v28 = /*BAD_CALL!*/ inst_14_values_var_0();
    int v29 = /*BAD_CALL!*/ inst_14_flags_var_0();
    int v30 = /*BAD_CALL!*/ inst_15_values_var_0();
    int v31 = /*BAD_CALL!*/ inst_15_flags_var_0();
    int v32 = /*BAD_CALL!*/ inst_16_values_var_0();
    int v33 = /*BAD_CALL!*/ inst_16_flags_var_0();
    int v34 = /*BAD_CALL!*/ inst_17_values_var_0();
    int v35 = /*BAD_CALL!*/ inst_17_flags_var_0();
    int v36 = /*BAD_CALL!*/ inst_18_values_var_0();
    int v37 = /*BAD_CALL!*/ inst_18_flags_var_0();
    int v38 = /*BAD_CALL!*/ inst_19_values_var_0();
    int v39 = /*BAD_CALL!*/ inst_19_flags_var_0();
    int v40 = /*BAD_CALL!*/ inst_20_values_var_0();
    int v41 = /*BAD_CALL!*/ inst_20_flags_var_0();
    int v42 = /*BAD_CALL!*/ inst_21_values_var_0();
    int v43 = inst_21_flags_var_0();
    if((v1 + v10 + (v11 + v12) + (v13 + v14 + (v15 + v16)) + (v17 + v18 + (v19 + v2) + (v20 + v21 + (v22 + v23))) + (v24 + v25 + (v26 + v27) + (v28 + v29 + (v3 + v30)) + (v31 + v32 + (v33 + v34) + (v35 + v36 + (v37 + v38)))) + (v39 + v4 + (v40 + v41) + (v42 + v43 + (v5 + v6)) + (v7 + v8 + (v9 + v0))))) {
        /*NO_RETURN*/ →__assert_fail("sum==0", "source_extensions_inst__1_var__no_complex.c", 99, (char*)&__PRETTY_FUNCTION__.2138);
    }
    return 0;
}

int register_tm_clones() {
    return 0;
}

void r→__assert_fail(char* __assertion, char* __file, unsigned int __line, char* __function) {
    /*BAD_CALL!*/ sub_8049030();
}

int r→__libc_start_main() {
    /*BAD_CALL!*/ sub_8049030();
}

void sub_8049030() {
    jump gvar_804D008;
}

void sub_8049207() {
}

void →__assert_fail(char* __assertion, char* __file, unsigned int __line, char* __function) {
    ptr___assert_fail[0]{r→__assert_fail}(__assertion, __file, __line, __function);
}

int →__libc_start_main() {
    return ptr___libc_start_main{r→__libc_start_main}();
}
