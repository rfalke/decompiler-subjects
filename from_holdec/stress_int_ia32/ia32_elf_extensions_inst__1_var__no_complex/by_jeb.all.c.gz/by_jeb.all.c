
void __libc_csu_fini() {
}

int __libc_csu_init(int param0, int param1, int param2) {
    int result;
    initializer_0();
    unsigned int v0 = 0;
    do {
        result = *(int*)(v0 * 4 + (int)&__frame_dummy_init_array_entry){initializer_1}();
        ++v0;
    }
    while(v0 != 1);
    return result;
}

void __x86.get_pc_thunk.bx() {
}

void _dl_relocate_static_pie() {
}

int _start(int param0, int param1) {
    int v0;
    char v1;
    void* ptr0;
    int v2;
    int v3 = 0;
    char v4 = 1;
    char v5 = 0;
    char v6 = 1;
    char v7 = 0;
    char v8 = 0;
    int v9 = v0;
    int* ptr1 = &v1;
    char v10 = &v0 ? 0: 1;
    char v11 = (int)&v0 < 0;
    char v12 = __parity__((unsigned char)&v0);
    char v13 = 0;
    char v14 = 0;
    int v15 = v2;
    int* ptr2 = &v15;
    int* ptr3 = &v15;
    int v16 = param1;
    int v17 = &loc_80491E4;
    int v18 = &loc_80491E4;
    int v19 = &_GLOBAL_OFFSET_TABLE_;
    char v20 = 0;
    char v21 = 0;
    char v22 = 1;
    char v23 = 1;
    char v24 = 0;
    char v25 = 0;
    int v26 = &__libc_csu_fini;
    int v27 = &__libc_csu_fini;
    int v28 = &__libc_csu_init;
    int v29 = &__libc_csu_init;
    int* ptr4 = &v1;
    int v30 = &main;
    int v31 = &main;
    int* ptr5 = &ptr0;
    →__libc_start_main();
    hlt();
}

int deregister_tm_clones() {
    return &completed.6844;
}

void finalizer_0() {
}

void finalizer_1() {
    char v0 = completed.6844 ? 0: 1;
    char v1 = completed.6844 >= 128;
    char v2 = __parity__(completed.6844);
    char v3 = completed.6844 < 0;
    char v4 = 0;
    char v5 = 0;
    jump v0 ? &sub_80492BD: &sub_80492D8;
}

void* initializer_0() {
    void* result = __gmon_start__;
    if(result) {
        result = (void*)result();
    }
    return result;
}

int initializer_1() {
    return register_tm_clones();
}

unsigned int inst_0_flags_var_0() {
    short v0;
    short v1;
    char v2;
    *(int*)&v0 = (unsigned int)v1;
    (unsigned short)v3 = tzcnt(4335);
    return v2 ? 1: 0;
}

int inst_0_values_var_0() {
    short v0;
    short v1;
    int v2;
    *(int*)&v0 = (unsigned int)v1;
    (unsigned short)v3 = tzcnt(42631);
    return v2 - 0x76710000;
}

int inst_10_flags_var_0() {
    short v0;
    short v1;
    *(int*)&v0 = (unsigned int)v1;
    int v2 = pext(254618161, -908041639);
    return 0;
}

int inst_10_values_var_0() {
    short v0;
    short v1;
    int v2;
    *(int*)&v0 = (unsigned int)v1;
    int v2 = pext(0x10632017, -754745945);
    return v2 - 39431;
}

int inst_11_flags_var_0() {
    short v0;
    short v1;
    *(int*)&v0 = (unsigned int)v1;
    int v2 = rorx(-848104206, 131);
    return 0;
}

int inst_11_values_var_0() {
    short v0;
    short v1;
    int v2;
    *(int*)&v0 = (unsigned int)v1;
    int v2 = rorx(1149586349, 55);
    return v2 - 177691273;
}

int inst_12_flags_var_0() {
    short v0;
    short v1;
    *(int*)&v0 = (unsigned int)v1;
    int v2 = sarx(-499244090, 240633786);
    return 0;
}

int inst_12_values_var_0() {
    short v0;
    short v1;
    int v2;
    *(int*)&v0 = (unsigned int)v1;
    int v2 = sarx(-1921826626, -431313248);
    return v2 + 1921826626;
}

int inst_13_flags_var_0() {
    short v0;
    short v1;
    *(int*)&v0 = (unsigned int)v1;
    int v2 = shlx(372815352, -1231582943);
    return 0;
}

int inst_13_values_var_0() {
    short v0;
    short v1;
    int v2;
    *(int*)&v0 = (unsigned int)v1;
    int v2 = shlx(-1492275047, -1476330234);
    return v2 + 1016322496;
}

int inst_14_flags_var_0() {
    short v0;
    short v1;
    *(int*)&v0 = (unsigned int)v1;
    int v2 = shrx(-1212442342, -1533018830);
    return 0;
}

int inst_14_values_var_0() {
    short v0;
    short v1;
    int v2;
    *(int*)&v0 = (unsigned int)v1;
    int v2 = shrx(-1264045333, 1214553529);
    return v2 - 90;
}

int inst_15_flags_var_0() {
    short v0;
    short v1;
    *(int*)&v0 = (unsigned int)v1;
    adox(-212912351, -1134117440);
    return -2;
}

int inst_15_values_var_0() {
    short v0;
    short v1;
    *(int*)&v0 = (unsigned int)v1;
    adox(-966792466, 0x1c9d9dd7);
    return 0xe3626229;
}

int inst_16_flags_var_0() {
    short v0;
    short v1;
    *(int*)&v0 = (unsigned int)v1;
    adcx(0xd28e89cb, -1154752663);
    return 0;
}

int inst_16_values_var_0() {
    short v0;
    short v1;
    *(int*)&v0 = (unsigned int)v1;
    adcx(1995195195, 1995195195);
    return 0x8913bcc4;
}

int inst_17_flags_var_0() {
    short v0;
    short v1;
    *(int*)&v0 = (unsigned int)v1;
    crc32(-37965669, 134);
    return 0;
}

int inst_17_values_var_0() {
    short v0;
    short v1;
    *(int*)&v0 = (unsigned int)v1;
    crc32(1364262155, 126);
    return 219737119;
}

int inst_18_flags_var_0() {
    short v0;
    short v1;
    *(int*)&v0 = (unsigned int)v1;
    crc32(691499111, 37285);
    return 0;
}

int inst_18_values_var_0() {
    short v0;
    short v1;
    *(int*)&v0 = (unsigned int)v1;
    crc32(0xd47780c8, 31598);
    return 1293363160;
}

int inst_19_flags_var_0() {
    short v0;
    short v1;
    *(int*)&v0 = (unsigned int)v1;
    crc32(-1488273469, 982821990);
    return 0;
}

int inst_19_values_var_0() {
    short v0;
    short v1;
    *(int*)&v0 = (unsigned int)v1;
    crc32(1298586160, 1298586160);
    return 1298586160;
}

unsigned int inst_1_flags_var_0() {
    short v0;
    short v1;
    char v2;
    *(int*)&v0 = (unsigned int)v1;
    int v3 = tzcnt(505644846);
    return v2 ? 1: 0;
}

int inst_1_values_var_0() {
    short v0;
    short v1;
    int result;
    *(int*)&v0 = (unsigned int)v1;
    int result = tzcnt(2126687567);
    return result;
}

int inst_20_flags_var_0() {
    short v0;
    short v1;
    *(int*)&v0 = (unsigned int)v1;
    short v2 = lzcnt(58334);
    return 0;
}

int inst_20_values_var_0(int param0, int param1) {
    short v0;
    short v1;
    *(int*)&v0 = (unsigned int)v1;
    short v2 = lzcnt(0xe79e);
    return param1 + 0x11e80000;
}

int inst_21_flags_var_0() {
    short v0;
    short v1;
    *(int*)&v0 = (unsigned int)v1;
    int v2 = lzcnt(-958458679);
    return 0;
}

int inst_21_values_var_0() {
    short v0;
    short v1;
    int result;
    *(int*)&v0 = (unsigned int)v1;
    int result = lzcnt(-1380445091);
    return result;
}

int inst_2_flags_var_0() {
    short v0;
    char v1;
    char v2;
    short v3;
    char v4;
    *(int*)&v0 = (unsigned int)v3;
    int v5 = andn(1655466428, -1535964828);
    return (unsigned int)((v4 ? 1: 0) + (v1 ? 8: 0) + (v2 ? 2: 0)) - 8;
}

int inst_2_values_var_0() {
    short v0;
    short v1;
    int result;
    *(int*)&v0 = (unsigned int)v1;
    int result = andn(0xac3bbbc9, 0xac3bbbc9);
    return result;
}

int inst_3_flags_var_0() {
    short v0;
    char v1;
    char v2;
    short v3;
    char v4;
    *(int*)&v0 = (unsigned int)v3;
    int v5 = blsi(1326047737);
    return (unsigned int)((v4 ? 1: 0) + (v1 ? 8: 0) + (v2 ? 2: 0)) - 1;
}

int inst_3_values_var_0() {
    short v0;
    short v1;
    int v2;
    *(int*)&v0 = (unsigned int)v1;
    int v2 = blsi(0x341ddbdc);
    return v2 - 4;
}

unsigned int inst_4_flags_var_0() {
    short v0;
    char v1;
    char v2;
    short v3;
    char v4;
    *(int*)&v0 = (unsigned int)v3;
    int v5 = blsmsk(-101510262);
    return (unsigned int)((v4 ? 1: 0) + (v1 ? 8: 0) + (v2 ? 2: 0));
}

int inst_4_values_var_0() {
    short v0;
    short v1;
    int v2;
    *(int*)&v0 = (unsigned int)v1;
    int v2 = blsmsk(549408184);
    return v2 - 15;
}

int inst_5_flags_var_0() {
    short v0;
    char v1;
    char v2;
    short v3;
    char v4;
    *(int*)&v0 = (unsigned int)v3;
    int v5 = blsr(-1275481825);
    return (unsigned int)((v4 ? 1: 0) + (v1 ? 8: 0) + (v2 ? 2: 0)) - 8;
}

int inst_5_values_var_0() {
    short v0;
    short v1;
    int v2;
    *(int*)&v0 = (unsigned int)v1;
    int v2 = blsr(-1989225311);
    return v2 + 1989225312;
}

unsigned int inst_6_flags_var_0() {
    short v0;
    char v1;
    short v2;
    char v3;
    *(int*)&v0 = (unsigned int)v2;
    int v4 = bextr(-566779378, 1437002413);
    return (unsigned int)((v3 ? 1: 0) + (v1 ? 2: 0));
}

int inst_6_values_var_0() {
    short v0;
    short v1;
    int result;
    *(int*)&v0 = (unsigned int)v1;
    int result = bextr(1955479381, -384479238);
    return result;
}

unsigned int inst_7_flags_var_0() {
    short v0;
    char v1;
    char v2;
    short v3;
    char v4;
    *(int*)&v0 = (unsigned int)v3;
    int v5 = bzhi(-1382549296, -610942451);
    return (unsigned int)((v4 ? 1: 0) + (v1 ? 8: 0) + (v2 ? 2: 0));
}

int inst_7_values_var_0() {
    short v0;
    short v1;
    int v2;
    *(int*)&v0 = (unsigned int)v1;
    int v2 = bzhi(1855746570, 1304388882);
    return v2 - 29194;
}

int inst_8_flags_var_0() {
    short v0;
    short v1;
    *(int*)&v0 = (unsigned int)v1;
    (int v2, int v3) = mulx(2047309213, -1063472138);
    return 0;
}

int inst_8_values_var_0() {
    short v0;
    short v1;
    int v2;
    int v3;
    *(int*)&v0 = (unsigned int)v1;
    (int v2, int v3) = mulx(2019130086, 0x1a654336);
    return v3 + v2 + 1288646683;
}

int inst_9_flags_var_0() {
    short v0;
    short v1;
    *(int*)&v0 = (unsigned int)v1;
    int v2 = pdep(0xf47ebbc0, -730499874);
    return 0;
}

int inst_9_values_var_0() {
    short v0;
    short v1;
    int v2;
    *(int*)&v0 = (unsigned int)v1;
    int v2 = pdep(-1538208650, 586697082);
    return v2 - 543164760;
}

int main() {
    int v0;
    char v1;
    int* ptr0;
    int v2;
    void* ptr1;
    int v3;
    int v4;
    int v5 = &v1;
    char v6 = &v0 ? 0: 1;
    char v7 = (int)&v0 < 0;
    char v8 = __parity__((unsigned char)&v0);
    char v9 = 0;
    char v10 = 0;
    int v11 = v0;
    int* ptr2 = &ptr0;
    int v12 = v3;
    int v13 = &v1;
    int v14 = inst_0_values_var_0();
    int v15 = v14;
    unsigned int v16 = inst_0_flags_var_0();
    int v17 = v15;
    int v18 = (int)(v16 + v15);
    char v19 = v18 ? 0: 1;
    char v20 = v18 < 0;
    char v21 = __parity__((unsigned char)v18);
    char v22 = (((v16 ^ v17) ^ v18) >>> 4) & 0x1;
    char v23 = __carry__(v16, v17);
    char v24 = ((v18 ^ v17) & ~(v16 ^ v17)) < 0;
    int v25 = inst_1_values_var_0();
    int v26 = v18;
    int v27 = v25 + v18;
    char v28 = v27 ? 0: 1;
    char v29 = v27 < 0;
    char v30 = __parity__((unsigned char)v27);
    char v31 = (((v25 ^ v26) ^ v27) >>> 4) & 0x1;
    char v32 = __carry__(v25, v26);
    char v33 = ((v27 ^ v26) & ~(v25 ^ v26)) < 0;
    unsigned int v34 = inst_1_flags_var_0();
    int v35 = v27;
    int v36 = (int)(v34 + v27);
    char v37 = v36 ? 0: 1;
    char v38 = v36 < 0;
    char v39 = __parity__((unsigned char)v36);
    char v40 = (((v34 ^ v35) ^ v36) >>> 4) & 0x1;
    char v41 = __carry__(v34, v35);
    char v42 = ((v36 ^ v35) & ~(v34 ^ v35)) < 0;
    int v43 = inst_2_values_var_0();
    int v44 = v36;
    int v45 = v43 + v36;
    char v46 = v45 ? 0: 1;
    char v47 = v45 < 0;
    char v48 = __parity__((unsigned char)v45);
    char v49 = (((v43 ^ v44) ^ v45) >>> 4) & 0x1;
    char v50 = __carry__(v43, v44);
    char v51 = ((v45 ^ v44) & ~(v43 ^ v44)) < 0;
    int v52 = inst_2_flags_var_0();
    int v53 = v45;
    int v54 = v52 + v45;
    char v55 = v54 ? 0: 1;
    char v56 = v54 < 0;
    char v57 = __parity__((unsigned char)v54);
    char v58 = (((v52 ^ v53) ^ v54) >>> 4) & 0x1;
    char v59 = __carry__(v52, v53);
    char v60 = ((v54 ^ v53) & ~(v52 ^ v53)) < 0;
    int v61 = inst_3_values_var_0();
    int v62 = v54;
    int v63 = v61 + v54;
    char v64 = v63 ? 0: 1;
    char v65 = v63 < 0;
    char v66 = __parity__((unsigned char)v63);
    char v67 = (((v61 ^ v62) ^ v63) >>> 4) & 0x1;
    char v68 = __carry__(v61, v62);
    char v69 = ((v63 ^ v62) & ~(v61 ^ v62)) < 0;
    int v70 = inst_3_flags_var_0();
    int v71 = v63;
    int v72 = v70 + v63;
    char v73 = v72 ? 0: 1;
    char v74 = v72 < 0;
    char v75 = __parity__((unsigned char)v72);
    char v76 = (((v70 ^ v71) ^ v72) >>> 4) & 0x1;
    char v77 = __carry__(v70, v71);
    char v78 = ((v72 ^ v71) & ~(v70 ^ v71)) < 0;
    int v79 = inst_4_values_var_0();
    int v80 = v72;
    int v81 = v79 + v72;
    char v82 = v81 ? 0: 1;
    char v83 = v81 < 0;
    char v84 = __parity__((unsigned char)v81);
    char v85 = (((v79 ^ v80) ^ v81) >>> 4) & 0x1;
    char v86 = __carry__(v79, v80);
    char v87 = ((v81 ^ v80) & ~(v79 ^ v80)) < 0;
    unsigned int v88 = inst_4_flags_var_0();
    int v89 = v81;
    int v90 = (int)(v88 + v81);
    char v91 = v90 ? 0: 1;
    char v92 = v90 < 0;
    char v93 = __parity__((unsigned char)v90);
    char v94 = (((v88 ^ v89) ^ v90) >>> 4) & 0x1;
    char v95 = __carry__(v88, v89);
    char v96 = ((v90 ^ v89) & ~(v88 ^ v89)) < 0;
    int v97 = inst_5_values_var_0();
    int v98 = v90;
    int v99 = v97 + v90;
    char v100 = v99 ? 0: 1;
    char v101 = v99 < 0;
    char v102 = __parity__((unsigned char)v99);
    char v103 = (((v97 ^ v98) ^ v99) >>> 4) & 0x1;
    char v104 = __carry__(v97, v98);
    char v105 = ((v99 ^ v98) & ~(v97 ^ v98)) < 0;
    int v106 = inst_5_flags_var_0();
    int v107 = v99;
    int v108 = v106 + v99;
    char v109 = v108 ? 0: 1;
    char v110 = v108 < 0;
    char v111 = __parity__((unsigned char)v108);
    char v112 = (((v106 ^ v107) ^ v108) >>> 4) & 0x1;
    char v113 = __carry__(v106, v107);
    char v114 = ((v108 ^ v107) & ~(v106 ^ v107)) < 0;
    int v115 = inst_6_values_var_0();
    int v116 = v108;
    int v117 = v115 + v108;
    char v118 = v117 ? 0: 1;
    char v119 = v117 < 0;
    char v120 = __parity__((unsigned char)v117);
    char v121 = (((v115 ^ v116) ^ v117) >>> 4) & 0x1;
    char v122 = __carry__(v115, v116);
    char v123 = ((v117 ^ v116) & ~(v115 ^ v116)) < 0;
    unsigned int v124 = inst_6_flags_var_0();
    int v125 = v117;
    int v126 = (int)(v124 + v117);
    char v127 = v126 ? 0: 1;
    char v128 = v126 < 0;
    char v129 = __parity__((unsigned char)v126);
    char v130 = (((v124 ^ v125) ^ v126) >>> 4) & 0x1;
    char v131 = __carry__(v124, v125);
    char v132 = ((v126 ^ v125) & ~(v124 ^ v125)) < 0;
    int v133 = inst_7_values_var_0();
    int v134 = v126;
    int v135 = v133 + v126;
    char v136 = v135 ? 0: 1;
    char v137 = v135 < 0;
    char v138 = __parity__((unsigned char)v135);
    char v139 = (((v133 ^ v134) ^ v135) >>> 4) & 0x1;
    char v140 = __carry__(v133, v134);
    char v141 = ((v135 ^ v134) & ~(v133 ^ v134)) < 0;
    unsigned int v142 = inst_7_flags_var_0();
    int v143 = v135;
    int v144 = (int)(v142 + v135);
    char v145 = v144 ? 0: 1;
    char v146 = v144 < 0;
    char v147 = __parity__((unsigned char)v144);
    char v148 = (((v142 ^ v143) ^ v144) >>> 4) & 0x1;
    char v149 = __carry__(v142, v143);
    char v150 = ((v144 ^ v143) & ~(v142 ^ v143)) < 0;
    int v151 = inst_8_values_var_0();
    int v152 = v144;
    int v153 = v151 + v144;
    char v154 = v153 ? 0: 1;
    char v155 = v153 < 0;
    char v156 = __parity__((unsigned char)v153);
    char v157 = (((v151 ^ v152) ^ v153) >>> 4) & 0x1;
    char v158 = __carry__(v151, v152);
    char v159 = ((v153 ^ v152) & ~(v151 ^ v152)) < 0;
    int v160 = inst_8_flags_var_0();
    int v161 = v153;
    int v162 = v160 + v153;
    char v163 = v162 ? 0: 1;
    char v164 = v162 < 0;
    char v165 = __parity__((unsigned char)v162);
    char v166 = (((v160 ^ v161) ^ v162) >>> 4) & 0x1;
    char v167 = __carry__(v160, v161);
    char v168 = ((v162 ^ v161) & ~(v160 ^ v161)) < 0;
    int v169 = inst_9_values_var_0();
    int v170 = v162;
    int v171 = v169 + v162;
    char v172 = v171 ? 0: 1;
    char v173 = v171 < 0;
    char v174 = __parity__((unsigned char)v171);
    char v175 = (((v169 ^ v170) ^ v171) >>> 4) & 0x1;
    char v176 = __carry__(v169, v170);
    char v177 = ((v171 ^ v170) & ~(v169 ^ v170)) < 0;
    int v178 = inst_9_flags_var_0();
    int v179 = v171;
    int v180 = v178 + v171;
    char v181 = v180 ? 0: 1;
    char v182 = v180 < 0;
    char v183 = __parity__((unsigned char)v180);
    char v184 = (((v178 ^ v179) ^ v180) >>> 4) & 0x1;
    char v185 = __carry__(v178, v179);
    char v186 = ((v180 ^ v179) & ~(v178 ^ v179)) < 0;
    int v187 = inst_10_values_var_0();
    int v188 = v180;
    int v189 = v187 + v180;
    char v190 = v189 ? 0: 1;
    char v191 = v189 < 0;
    char v192 = __parity__((unsigned char)v189);
    char v193 = (((v187 ^ v188) ^ v189) >>> 4) & 0x1;
    char v194 = __carry__(v187, v188);
    char v195 = ((v189 ^ v188) & ~(v187 ^ v188)) < 0;
    int v196 = inst_10_flags_var_0();
    int v197 = v189;
    int v198 = v196 + v189;
    char v199 = v198 ? 0: 1;
    char v200 = v198 < 0;
    char v201 = __parity__((unsigned char)v198);
    char v202 = (((v196 ^ v197) ^ v198) >>> 4) & 0x1;
    char v203 = __carry__(v196, v197);
    char v204 = ((v198 ^ v197) & ~(v196 ^ v197)) < 0;
    int v205 = inst_11_values_var_0();
    int v206 = v198;
    int v207 = v205 + v198;
    char v208 = v207 ? 0: 1;
    char v209 = v207 < 0;
    char v210 = __parity__((unsigned char)v207);
    char v211 = (((v205 ^ v206) ^ v207) >>> 4) & 0x1;
    char v212 = __carry__(v205, v206);
    char v213 = ((v207 ^ v206) & ~(v205 ^ v206)) < 0;
    int v214 = inst_11_flags_var_0();
    int v215 = v207;
    int v216 = v214 + v207;
    char v217 = v216 ? 0: 1;
    char v218 = v216 < 0;
    char v219 = __parity__((unsigned char)v216);
    char v220 = (((v214 ^ v215) ^ v216) >>> 4) & 0x1;
    char v221 = __carry__(v214, v215);
    char v222 = ((v216 ^ v215) & ~(v214 ^ v215)) < 0;
    int v223 = inst_12_values_var_0();
    int v224 = v216;
    int v225 = v223 + v216;
    char v226 = v225 ? 0: 1;
    char v227 = v225 < 0;
    char v228 = __parity__((unsigned char)v225);
    char v229 = (((v223 ^ v224) ^ v225) >>> 4) & 0x1;
    char v230 = __carry__(v223, v224);
    char v231 = ((v225 ^ v224) & ~(v223 ^ v224)) < 0;
    int v232 = inst_12_flags_var_0();
    int v233 = v225;
    int v234 = v232 + v225;
    char v235 = v234 ? 0: 1;
    char v236 = v234 < 0;
    char v237 = __parity__((unsigned char)v234);
    char v238 = (((v232 ^ v233) ^ v234) >>> 4) & 0x1;
    char v239 = __carry__(v232, v233);
    char v240 = ((v234 ^ v233) & ~(v232 ^ v233)) < 0;
    int v241 = inst_13_values_var_0();
    int v242 = v234;
    int v243 = v241 + v234;
    char v244 = v243 ? 0: 1;
    char v245 = v243 < 0;
    char v246 = __parity__((unsigned char)v243);
    char v247 = (((v241 ^ v242) ^ v243) >>> 4) & 0x1;
    char v248 = __carry__(v241, v242);
    char v249 = ((v243 ^ v242) & ~(v241 ^ v242)) < 0;
    int v250 = inst_13_flags_var_0();
    int v251 = v243;
    int v252 = v250 + v243;
    char v253 = v252 ? 0: 1;
    char v254 = v252 < 0;
    char v255 = __parity__((unsigned char)v252);
    char v256 = (((v250 ^ v251) ^ v252) >>> 4) & 0x1;
    char v257 = __carry__(v250, v251);
    char v258 = ((v252 ^ v251) & ~(v250 ^ v251)) < 0;
    int v259 = inst_14_values_var_0();
    int v260 = v252;
    int v261 = v259 + v252;
    char v262 = v261 ? 0: 1;
    char v263 = v261 < 0;
    char v264 = __parity__((unsigned char)v261);
    char v265 = (((v259 ^ v260) ^ v261) >>> 4) & 0x1;
    char v266 = __carry__(v259, v260);
    char v267 = ((v261 ^ v260) & ~(v259 ^ v260)) < 0;
    int v268 = inst_14_flags_var_0();
    int v269 = v261;
    int v270 = v268 + v261;
    char v271 = v270 ? 0: 1;
    char v272 = v270 < 0;
    char v273 = __parity__((unsigned char)v270);
    char v274 = (((v268 ^ v269) ^ v270) >>> 4) & 0x1;
    char v275 = __carry__(v268, v269);
    char v276 = ((v270 ^ v269) & ~(v268 ^ v269)) < 0;
    int v277 = inst_15_values_var_0();
    int v278 = v270;
    int v279 = v277 + v270;
    char v280 = v279 ? 0: 1;
    char v281 = v279 < 0;
    char v282 = __parity__((unsigned char)v279);
    char v283 = (((v277 ^ v278) ^ v279) >>> 4) & 0x1;
    char v284 = __carry__(v277, v278);
    char v285 = ((v279 ^ v278) & ~(v277 ^ v278)) < 0;
    int v286 = inst_15_flags_var_0();
    int v287 = v279;
    int v288 = v286 + v279;
    char v289 = v288 ? 0: 1;
    char v290 = v288 < 0;
    char v291 = __parity__((unsigned char)v288);
    char v292 = (((v286 ^ v287) ^ v288) >>> 4) & 0x1;
    char v293 = __carry__(v286, v287);
    char v294 = ((v288 ^ v287) & ~(v286 ^ v287)) < 0;
    int v295 = inst_16_values_var_0();
    int v296 = v288;
    int v297 = v295 + v288;
    char v298 = v297 ? 0: 1;
    char v299 = v297 < 0;
    char v300 = __parity__((unsigned char)v297);
    char v301 = (((v295 ^ v296) ^ v297) >>> 4) & 0x1;
    char v302 = __carry__(v295, v296);
    char v303 = ((v297 ^ v296) & ~(v295 ^ v296)) < 0;
    int v304 = inst_16_flags_var_0();
    int v305 = v297;
    int v306 = v304 + v297;
    char v307 = v306 ? 0: 1;
    char v308 = v306 < 0;
    char v309 = __parity__((unsigned char)v306);
    char v310 = (((v304 ^ v305) ^ v306) >>> 4) & 0x1;
    char v311 = __carry__(v304, v305);
    char v312 = ((v306 ^ v305) & ~(v304 ^ v305)) < 0;
    int v313 = inst_17_values_var_0();
    int v314 = v306;
    int v315 = v313 + v306;
    char v316 = v315 ? 0: 1;
    char v317 = v315 < 0;
    char v318 = __parity__((unsigned char)v315);
    char v319 = (((v313 ^ v314) ^ v315) >>> 4) & 0x1;
    char v320 = __carry__(v313, v314);
    char v321 = ((v315 ^ v314) & ~(v313 ^ v314)) < 0;
    int v322 = inst_17_flags_var_0();
    int v323 = v315;
    int v324 = v322 + v315;
    char v325 = v324 ? 0: 1;
    char v326 = v324 < 0;
    char v327 = __parity__((unsigned char)v324);
    char v328 = (((v322 ^ v323) ^ v324) >>> 4) & 0x1;
    char v329 = __carry__(v322, v323);
    char v330 = ((v324 ^ v323) & ~(v322 ^ v323)) < 0;
    int v331 = inst_18_values_var_0();
    int v332 = v324;
    int v333 = v331 + v324;
    char v334 = v333 ? 0: 1;
    char v335 = v333 < 0;
    char v336 = __parity__((unsigned char)v333);
    char v337 = (((v331 ^ v332) ^ v333) >>> 4) & 0x1;
    char v338 = __carry__(v331, v332);
    char v339 = ((v333 ^ v332) & ~(v331 ^ v332)) < 0;
    int v340 = inst_18_flags_var_0();
    int v341 = v333;
    int v342 = v340 + v333;
    char v343 = v342 ? 0: 1;
    char v344 = v342 < 0;
    char v345 = __parity__((unsigned char)v342);
    char v346 = (((v340 ^ v341) ^ v342) >>> 4) & 0x1;
    char v347 = __carry__(v340, v341);
    char v348 = ((v342 ^ v341) & ~(v340 ^ v341)) < 0;
    int v349 = inst_19_values_var_0();
    int v350 = v342;
    int v351 = v349 + v342;
    char v352 = v351 ? 0: 1;
    char v353 = v351 < 0;
    char v354 = __parity__((unsigned char)v351);
    char v355 = (((v349 ^ v350) ^ v351) >>> 4) & 0x1;
    char v356 = __carry__(v349, v350);
    char v357 = ((v351 ^ v350) & ~(v349 ^ v350)) < 0;
    int v358 = inst_19_flags_var_0();
    int v359 = v351;
    int v360 = v358 + v351;
    char v361 = v360 ? 0: 1;
    char v362 = v360 < 0;
    char v363 = __parity__((unsigned char)v360);
    char v364 = (((v358 ^ v359) ^ v360) >>> 4) & 0x1;
    char v365 = __carry__(v358, v359);
    char v366 = ((v360 ^ v359) & ~(v358 ^ v359)) < 0;
    int v367 = inst_20_values_var_0(v4, v2);
    int v368 = v360;
    int v369 = v367 + v360;
    char v370 = v369 ? 0: 1;
    char v371 = v369 < 0;
    char v372 = __parity__((unsigned char)v369);
    char v373 = (((v367 ^ v368) ^ v369) >>> 4) & 0x1;
    char v374 = __carry__(v367, v368);
    char v375 = ((v369 ^ v368) & ~(v367 ^ v368)) < 0;
    int v376 = inst_20_flags_var_0();
    int v377 = v369;
    int v378 = v376 + v369;
    char v379 = v378 ? 0: 1;
    char v380 = v378 < 0;
    char v381 = __parity__((unsigned char)v378);
    char v382 = (((v376 ^ v377) ^ v378) >>> 4) & 0x1;
    char v383 = __carry__(v376, v377);
    char v384 = ((v378 ^ v377) & ~(v376 ^ v377)) < 0;
    int v385 = inst_21_values_var_0();
    int v386 = v378;
    int v387 = v385 + v378;
    char v388 = v387 ? 0: 1;
    char v389 = v387 < 0;
    char v390 = __parity__((unsigned char)v387);
    char v391 = (((v385 ^ v386) ^ v387) >>> 4) & 0x1;
    char v392 = __carry__(v385, v386);
    char v393 = ((v387 ^ v386) & ~(v385 ^ v386)) < 0;
    int v394 = inst_21_flags_var_0();
    int v395 = v387;
    int v396 = v394 + v387;
    char v397 = v396 ? 0: 1;
    char v398 = v396 < 0;
    char v399 = __parity__((unsigned char)v396);
    char v400 = (((v394 ^ v395) ^ v396) >>> 4) & 0x1;
    char v401 = __carry__(v394, v395);
    char v402 = ((v396 ^ v395) & ~(v394 ^ v395)) < 0;
    if(!v397) {
        int* ptr3 = &ptr1;
        /*NO_RETURN*/ →__assert_fail("sum==0", "source_extensions_inst__1_var__no_complex.c", 99, (char*)&__PRETTY_FUNCTION__.2138);
    }
    return 0;
}

int register_tm_clones() {
    return 0;
}

int sub_8049036() {
    return gvar_804D008();
}

void sub_8049207() {
}

int sub_804923C() {
    return 0;
}

void sub_8049288() {
}

int sub_80492BD() {
    int result = deregister_tm_clones();
    completed.6844 = 1;
    return result;
}

void sub_80492D8() {
}

void →__assert_fail(char* __assertion, char* __file, unsigned int __line, char* __function) {
    while(1) {
        /*NO_RETURN*/ __assert_fail(__assertion, __file, __line, __function);
        unsigned int* ptr0 = ptr0 - 1;
        *ptr0 = 8;
        --ptr0;
        *ptr0 = gvar_804D004;
    }
}

void →__libc_start_main() {
    while(1) {
        /*BAD_CALL!*/ __libc_start_main();
        unsigned int* ptr0 = ptr0 - 1;
        *ptr0 = 0;
        --ptr0;
        *ptr0 = gvar_804D004;
    }
}
