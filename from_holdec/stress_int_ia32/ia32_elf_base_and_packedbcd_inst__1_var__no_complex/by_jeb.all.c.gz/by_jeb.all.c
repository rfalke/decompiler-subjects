
void __libc_csu_fini() {
}

int __libc_csu_init(int param0, int param1, int param2) {
    int result;
    initializer_0();
    int v0 = 0;
    do {
        result = *(int*)(v0 * 4 + (int)&__frame_dummy_init_array_entry){initializer_1}();
        ++v0;
    }
    while(v0 != 1);
    return result;
}

void __x86.get_pc_thunk.bx() {
}

void _dl_relocate_static_pie() {
}

int _start(int param0, int param1) {
    →__libc_start_main();
    hlt();
}

// Stale decompilation - Refresh this view to re-decompile this code
int deregister_tm_clones() {
    return &completed.6844;
}

void finalizer_0() {
}

void finalizer_1() {
    if(!completed.6844) {
        deregister_tm_clones();
        completed.6844 = 1;
    }
}

void* initializer_0() {
    void* result = __gmon_start__;
    if(result) {
        result = (void*)result();
    }
    return result;
}

int initializer_1() {
    return register_tm_clones();
}

int inst_0_flags_var_0() {
    return 0;
}

int inst_0_values_var_0() {
    return 0;
}

int inst_100_flags_var_0() {
    return -4;
}

int inst_100_values_var_0() {
    return -102;
}

int inst_101_flags_var_0() {
    return 0;
}

int inst_101_values_var_0() {
    return 6;
}

int inst_102_flags_var_0() {
    return 0;
}

int inst_102_values_var_0() {
    return 0;
}

int inst_103_flags_var_0() {
    return 0;
}

int inst_103_values_var_0() {
    return 0;
}

int inst_104_flags_var_0() {
    return 0;
}

int inst_104_values_var_0() {
    return 0;
}

int inst_105_flags_var_0() {
    return 0;
}

int inst_105_values_var_0() {
    return 0;
}

int inst_106_flags_var_0() {
    return 0;
}

int inst_106_values_var_0() {
    return 0;
}

int inst_107_flags_var_0() {
    return 0;
}

int inst_107_values_var_0() {
    return 0;
}

int inst_108_flags_var_0() {
    return 0;
}

int inst_108_values_var_0() {
    return 0;
}

int inst_109_flags_var_0() {
    return 0;
}

int inst_109_values_var_0() {
    return 0;
}

int inst_10_flags_var_0() {
    return 0;
}

int inst_10_values_var_0() {
    return 0;
}

int inst_110_flags_var_0() {
    return 0;
}

int inst_110_values_var_0() {
    return 0;
}

int inst_111_flags_var_0() {
    return 0;
}

int inst_111_values_var_0() {
    return 0;
}

int inst_112_flags_var_0() {
    return 0;
}

int inst_112_values_var_0() {
    return 0;
}

int inst_113_flags_var_0() {
    return 0;
}

int inst_113_values_var_0() {
    return 0;
}

int inst_114_flags_var_0() {
    return 0;
}

int inst_114_values_var_0() {
    return 0;
}

int inst_115_flags_var_0() {
    return 0;
}

int inst_115_values_var_0() {
    return 0;
}

int inst_116_flags_var_0() {
    return 0;
}

int inst_116_values_var_0() {
    return 0;
}

int inst_117_flags_var_0() {
    return 0;
}

int inst_117_values_var_0() {
    return 0;
}

int inst_118_flags_var_0() {
    return 0;
}

int inst_118_values_var_0() {
    return 0;
}

int inst_119_flags_var_0() {
    return 0;
}

int inst_119_values_var_0() {
    return 0;
}

int inst_11_flags_var_0() {
    return 0;
}

int inst_11_values_var_0() {
    return 0;
}

int inst_120_flags_var_0() {
    return 0;
}

int inst_120_values_var_0() {
    return 0;
}

int inst_121_flags_var_0() {
    return 0;
}

int inst_121_values_var_0() {
    return 0;
}

int inst_122_flags_var_0() {
    return 0;
}

int inst_122_values_var_0() {
    return 0;
}

int inst_123_flags_var_0() {
    return 0;
}

int inst_123_values_var_0() {
    return 0;
}

int inst_124_flags_var_0() {
    return 0;
}

int inst_124_values_var_0() {
    return 0;
}

int inst_125_flags_var_0() {
    return 0;
}

int inst_125_values_var_0() {
    return 0;
}

int inst_126_flags_var_0() {
    return 0;
}

int inst_126_values_var_0() {
    return 0;
}

int inst_127_flags_var_0() {
    return 0;
}

int inst_127_values_var_0() {
    return 0;
}

int inst_128_flags_var_0() {
    return 0;
}

int inst_128_values_var_0() {
    return 0;
}

int inst_129_flags_var_0() {
    return 0;
}

int inst_129_values_var_0() {
    return 0;
}

int inst_12_flags_var_0() {
    return 0;
}

int inst_12_values_var_0() {
    return 0;
}

int inst_130_flags_var_0() {
    return 0;
}

int inst_130_values_var_0() {
    return 0;
}

int inst_131_flags_var_0() {
    return 0;
}

int inst_131_values_var_0() {
    return 0;
}

int inst_132_flags_var_0() {
    return 0;
}

int inst_132_values_var_0() {
    return 0;
}

int inst_133_flags_var_0() {
    return 0;
}

int inst_133_values_var_0() {
    return 0;
}

int inst_134_flags_var_0() {
    return 0;
}

int inst_134_values_var_0() {
    return 0;
}

int inst_135_flags_var_0() {
    return 0;
}

int inst_135_values_var_0() {
    return 0;
}

int inst_136_flags_var_0() {
    return 0;
}

int inst_136_values_var_0() {
    return 0;
}

int inst_137_flags_var_0() {
    return 0;
}

int inst_137_values_var_0() {
    return 0;
}

int inst_138_flags_var_0() {
    return 0;
}

int inst_138_values_var_0() {
    return 0;
}

int inst_139_flags_var_0() {
    return 0;
}

int inst_139_values_var_0() {
    return 0;
}

int inst_13_flags_var_0() {
    return 0;
}

int inst_13_values_var_0() {
    return 0;
}

int inst_140_flags_var_0() {
    return 0;
}

int inst_140_values_var_0() {
    return 0;
}

int inst_141_flags_var_0() {
    return 0;
}

int inst_141_values_var_0() {
    return 0;
}

int inst_142_flags_var_0() {
    return 0;
}

int inst_142_values_var_0() {
    return 0;
}

int inst_143_flags_var_0() {
    return 0;
}

int inst_143_values_var_0() {
    return 0;
}

int inst_144_flags_var_0() {
    return 0;
}

int inst_144_values_var_0() {
    return 0;
}

int inst_145_flags_var_0() {
    return 0;
}

int inst_145_values_var_0() {
    return 0;
}

int inst_146_flags_var_0() {
    return 0;
}

int inst_146_values_var_0() {
    return 0;
}

int inst_147_flags_var_0() {
    return 0;
}

int inst_147_values_var_0() {
    return 0;
}

int inst_148_flags_var_0() {
    return 0;
}

int inst_148_values_var_0() {
    return 0;
}

int inst_149_flags_var_0() {
    return 0;
}

int inst_149_values_var_0() {
    return 0;
}

int inst_14_flags_var_0() {
    return 0;
}

int inst_14_values_var_0() {
    return 0;
}

int inst_150_flags_var_0() {
    return 0;
}

int inst_150_values_var_0() {
    return 0;
}

int inst_151_flags_var_0() {
    return 0;
}

int inst_151_values_var_0() {
    return 0;
}

int inst_152_flags_var_0() {
    return 0;
}

int inst_152_values_var_0() {
    return 0;
}

int inst_153_flags_var_0() {
    return 0;
}

int inst_153_values_var_0() {
    return 0;
}

int inst_154_flags_var_0() {
    return 0;
}

int inst_154_values_var_0() {
    return 0;
}

int inst_155_flags_var_0() {
    return 0;
}

int inst_155_values_var_0() {
    return 0;
}

int inst_156_flags_var_0() {
    return 0;
}

int inst_156_values_var_0() {
    return 0;
}

int inst_157_flags_var_0() {
    return 0;
}

int inst_157_values_var_0() {
    return 0;
}

int inst_158_flags_var_0() {
    return 0;
}

int inst_158_values_var_0() {
    return 0;
}

int inst_159_flags_var_0() {
    return 0;
}

int inst_159_values_var_0() {
    return 0;
}

int inst_15_flags_var_0() {
    return 0;
}

int inst_15_values_var_0() {
    return 0;
}

int inst_160_flags_var_0() {
    return 0;
}

int inst_160_values_var_0() {
    return 0;
}

int inst_161_flags_var_0() {
    return 0;
}

int inst_161_values_var_0() {
    return 0;
}

int inst_162_flags_var_0() {
    return 0;
}

int inst_162_values_var_0() {
    return 0;
}

int inst_163_flags_var_0() {
    return 0;
}

int inst_163_values_var_0() {
    return 0;
}

int inst_164_flags_var_0() {
    return 0;
}

int inst_164_values_var_0() {
    return 0;
}

int inst_165_flags_var_0() {
    return 0;
}

int inst_165_values_var_0() {
    return 0;
}

int inst_166_flags_var_0() {
    return 0;
}

int inst_166_values_var_0() {
    return 0;
}

int inst_167_flags_var_0() {
    return 0;
}

int inst_167_values_var_0() {
    return 0;
}

int inst_168_flags_var_0() {
    return 0;
}

int inst_168_values_var_0() {
    return 0;
}

int inst_169_flags_var_0() {
    return 0;
}

int inst_169_values_var_0() {
    return 0;
}

int inst_16_flags_var_0() {
    return 0;
}

int inst_16_values_var_0() {
    return 0;
}

int inst_170_flags_var_0() {
    return 0;
}

int inst_170_values_var_0() {
    return 0;
}

int inst_171_flags_var_0() {
    return 0;
}

int inst_171_values_var_0() {
    return 0;
}

int inst_172_flags_var_0() {
    return 0;
}

int inst_172_values_var_0() {
    return 0;
}

int inst_173_flags_var_0() {
    return 0;
}

int inst_173_values_var_0() {
    return 0;
}

int inst_174_flags_var_0() {
    return 0;
}

int inst_174_values_var_0() {
    return 0;
}

int inst_175_flags_var_0() {
    return 0;
}

int inst_175_values_var_0() {
    return 0;
}

int inst_176_flags_var_0() {
    return 0;
}

int inst_176_values_var_0() {
    return 0;
}

int inst_177_flags_var_0() {
    return 0;
}

int inst_177_values_var_0() {
    return 0;
}

int inst_178_flags_var_0() {
    return 0;
}

int inst_178_values_var_0() {
    return 0;
}

int inst_179_flags_var_0() {
    return 0;
}

int inst_179_values_var_0() {
    return 0;
}

int inst_17_flags_var_0() {
    return 0;
}

int inst_17_values_var_0() {
    return 0;
}

int inst_180_flags_var_0() {
    return 0;
}

int inst_180_values_var_0() {
    return 0;
}

int inst_181_flags_var_0() {
    return 0;
}

int inst_181_values_var_0() {
    return 0;
}

int inst_182_flags_var_0() {
    return 0;
}

int inst_182_values_var_0() {
    return 0;
}

int inst_183_flags_var_0() {
    return 0;
}

int inst_183_values_var_0() {
    return 0;
}

int inst_184_flags_var_0() {
    return 0;
}

int inst_184_values_var_0() {
    return 0;
}

int inst_185_flags_var_0() {
    return 0;
}

int inst_185_values_var_0() {
    return 0;
}

int inst_186_flags_var_0() {
    return 0;
}

int inst_186_values_var_0() {
    return 0;
}

int inst_187_flags_var_0() {
    return 0;
}

int inst_187_values_var_0() {
    return 0;
}

int inst_188_flags_var_0() {
    return 0;
}

int inst_188_values_var_0() {
    return 0;
}

int inst_189_flags_var_0() {
    return 0;
}

int inst_189_values_var_0() {
    return 0;
}

int inst_18_flags_var_0() {
    return 0;
}

int inst_18_values_var_0() {
    return 0;
}

int inst_190_flags_var_0() {
    return 0;
}

int inst_190_values_var_0() {
    return 0;
}

int inst_191_flags_var_0() {
    return 0;
}

int inst_191_values_var_0() {
    return 0;
}

int inst_192_flags_var_0() {
    return 0;
}

int inst_192_values_var_0() {
    return 0;
}

int inst_193_flags_var_0() {
    return 0;
}

int inst_193_values_var_0() {
    return 0;
}

int inst_194_flags_var_0() {
    return 0;
}

int inst_194_values_var_0() {
    return 0;
}

int inst_195_flags_var_0() {
    return 0;
}

int inst_195_values_var_0() {
    return 0;
}

int inst_196_flags_var_0() {
    return 0;
}

int inst_196_values_var_0() {
    return 0;
}

int inst_197_flags_var_0() {
    return 0;
}

int inst_197_values_var_0() {
    return 0;
}

int inst_198_flags_var_0() {
    return 0;
}

int inst_198_values_var_0() {
    return 0;
}

int inst_199_flags_var_0() {
    return 0;
}

int inst_199_values_var_0() {
    return 0;
}

int inst_19_flags_var_0() {
    return 0;
}

int inst_19_values_var_0() {
    return 0;
}

int inst_1_flags_var_0() {
    return 0;
}

int inst_1_values_var_0() {
    return 0;
}

int inst_200_flags_var_0() {
    return 0;
}

int inst_200_values_var_0() {
    return 0;
}

int inst_201_flags_var_0() {
    return 0;
}

int inst_201_values_var_0() {
    return 0;
}

int inst_202_flags_var_0() {
    return 0;
}

int inst_202_values_var_0() {
    return 0;
}

int inst_203_flags_var_0() {
    return 0;
}

int inst_203_values_var_0() {
    return 0;
}

int inst_204_flags_var_0() {
    return 0;
}

int inst_204_values_var_0() {
    return 0;
}

int inst_205_flags_var_0() {
    return 0;
}

int inst_205_values_var_0() {
    return 0;
}

int inst_206_flags_var_0() {
    return 0;
}

int inst_206_values_var_0() {
    return 0;
}

int inst_207_flags_var_0() {
    return 0;
}

int inst_207_values_var_0() {
    return 0;
}

int inst_208_flags_var_0() {
    return 0;
}

int inst_208_values_var_0() {
    return 0;
}

int inst_209_flags_var_0() {
    return 0;
}

int inst_209_values_var_0() {
    return 0;
}

int inst_20_flags_var_0() {
    return 0;
}

int inst_20_values_var_0() {
    return 0;
}

int inst_210_flags_var_0() {
    return 0;
}

int inst_210_values_var_0() {
    return 0;
}

int inst_211_flags_var_0() {
    return 0;
}

int inst_211_values_var_0() {
    return 0;
}

int inst_212_flags_var_0() {
    return 0;
}

int inst_212_values_var_0() {
    return 0;
}

int inst_213_flags_var_0() {
    return 0;
}

int inst_213_values_var_0() {
    return 0;
}

int inst_214_flags_var_0() {
    return 0;
}

int inst_214_values_var_0() {
    return 0;
}

int inst_215_flags_var_0() {
    return 0;
}

int inst_215_values_var_0() {
    return 0;
}

int inst_216_flags_var_0() {
    return 0;
}

int inst_216_values_var_0() {
    return 0;
}

int inst_217_flags_var_0() {
    return 0;
}

int inst_217_values_var_0() {
    return 0;
}

int inst_218_flags_var_0() {
    return 0;
}

int inst_218_values_var_0() {
    return 0;
}

int inst_219_flags_var_0() {
    return 0;
}

int inst_219_values_var_0() {
    return 0;
}

int inst_21_flags_var_0() {
    return 0;
}

int inst_21_values_var_0() {
    return 0;
}

int inst_220_flags_var_0() {
    return 0;
}

int inst_220_values_var_0() {
    return 0;
}

int inst_221_flags_var_0() {
    return 0;
}

int inst_221_values_var_0() {
    return 0;
}

int inst_222_flags_var_0() {
    return 0;
}

int inst_222_values_var_0() {
    return 0;
}

int inst_223_flags_var_0() {
    return 0;
}

int inst_223_values_var_0() {
    return 0;
}

int inst_224_flags_var_0() {
    return 0;
}

int inst_224_values_var_0() {
    return 0;
}

int inst_225_flags_var_0() {
    return 0;
}

int inst_225_values_var_0() {
    return 0;
}

int inst_226_flags_var_0() {
    return 0;
}

int inst_226_values_var_0() {
    return 0;
}

int inst_227_flags_var_0() {
    return 0;
}

int inst_227_values_var_0() {
    return 0;
}

int inst_228_flags_var_0() {
    return 0;
}

int inst_228_values_var_0() {
    return 0;
}

int inst_229_flags_var_0() {
    return 0;
}

int inst_229_values_var_0() {
    return 0;
}

int inst_22_flags_var_0() {
    return 0;
}

int inst_22_values_var_0() {
    return 0;
}

int inst_230_flags_var_0() {
    return 0;
}

int inst_230_values_var_0() {
    return 0;
}

int inst_231_flags_var_0() {
    return 0;
}

int inst_231_values_var_0() {
    return 0;
}

int inst_232_flags_var_0() {
    return 0;
}

int inst_232_values_var_0() {
    return 0;
}

int inst_233_flags_var_0() {
    return 0;
}

int inst_233_values_var_0() {
    return 0;
}

int inst_234_flags_var_0() {
    return 0;
}

int inst_234_values_var_0() {
    return 0;
}

int inst_235_flags_var_0() {
    return 0;
}

int inst_235_values_var_0() {
    return 0;
}

int inst_236_flags_var_0() {
    return 0;
}

int inst_236_values_var_0() {
    return 0;
}

int inst_237_flags_var_0() {
    return 0;
}

int inst_237_values_var_0() {
    return 0;
}

int inst_238_flags_var_0() {
    return 18;
}

int inst_238_values_var_0() {
    return 0;
}

int inst_239_flags_var_0() {
    return 0;
}

int inst_239_values_var_0() {
    return 0;
}

int inst_23_flags_var_0() {
    return 14;
}

int inst_23_values_var_0() {
    return 0;
}

int inst_240_flags_var_0() {
    return 0;
}

int inst_240_values_var_0() {
    return 0;
}

int inst_241_flags_var_0() {
    return 0;
}

int inst_241_values_var_0() {
    return 0;
}

int inst_242_flags_var_0() {
    return 0;
}

int inst_242_values_var_0() {
    return 0;
}

int inst_243_flags_var_0() {
    return 0;
}

int inst_243_values_var_0() {
    return 0;
}

int inst_244_flags_var_0() {
    return 0;
}

int inst_244_values_var_0() {
    return 0;
}

int inst_245_flags_var_0() {
    return 0;
}

int inst_245_values_var_0() {
    return 0;
}

int inst_246_flags_var_0() {
    return 0;
}

int inst_246_values_var_0() {
    return 0;
}

int inst_247_flags_var_0() {
    return 0;
}

int inst_247_values_var_0() {
    return 0;
}

int inst_248_flags_var_0() {
    return 0;
}

int inst_248_values_var_0() {
    return 0;
}

int inst_249_flags_var_0() {
    return 0;
}

int inst_249_values_var_0() {
    return 0;
}

int inst_24_flags_var_0() {
    return 0;
}

int inst_24_values_var_0() {
    return 0;
}

int inst_250_flags_var_0() {
    return 0;
}

int inst_250_values_var_0() {
    return 0;
}

int inst_251_flags_var_0() {
    return 0;
}

int inst_251_values_var_0() {
    return 0;
}

int inst_252_flags_var_0() {
    return 0;
}

int inst_252_values_var_0() {
    return 0;
}

int inst_253_flags_var_0() {
    return 0;
}

int inst_253_values_var_0() {
    return 0;
}

int inst_254_flags_var_0() {
    return 0;
}

int inst_254_values_var_0() {
    return 0;
}

int inst_255_flags_var_0() {
    return 0;
}

int inst_255_values_var_0() {
    return 0;
}

int inst_256_flags_var_0() {
    return 0;
}

int inst_256_values_var_0() {
    return 0;
}

int inst_257_flags_var_0() {
    return 0;
}

int inst_257_values_var_0() {
    return 0;
}

int inst_258_flags_var_0() {
    return 0;
}

int inst_258_values_var_0() {
    return 0;
}

int inst_259_flags_var_0() {
    return 0;
}

int inst_259_values_var_0() {
    return 0;
}

int inst_25_flags_var_0() {
    return 0;
}

int inst_25_values_var_0() {
    return 0;
}

int inst_260_flags_var_0() {
    return 0;
}

int inst_260_values_var_0() {
    return 0;
}

int inst_261_flags_var_0() {
    return -2;
}

int inst_261_values_var_0() {
    return 0;
}

int inst_262_flags_var_0() {
    return 0;
}

int inst_262_values_var_0() {
    return 0;
}

int inst_263_flags_var_0() {
    return 0;
}

int inst_263_values_var_0() {
    return 0;
}

int inst_264_flags_var_0() {
    return 0;
}

int inst_264_values_var_0() {
    return 0;
}

int inst_265_flags_var_0() {
    return 0;
}

int inst_265_values_var_0() {
    return 0;
}

int inst_266_flags_var_0() {
    return 0;
}

int inst_266_values_var_0() {
    return 0;
}

int inst_267_flags_var_0() {
    return 0;
}

int inst_267_values_var_0() {
    return 0;
}

int inst_268_flags_var_0() {
    return 0;
}

int inst_268_values_var_0() {
    return 0;
}

int inst_269_flags_var_0() {
    return 0;
}

int inst_269_values_var_0() {
    return 0;
}

int inst_26_flags_var_0() {
    return 0;
}

int inst_26_values_var_0() {
    return 0;
}

int inst_270_flags_var_0() {
    return 0;
}

int inst_270_values_var_0() {
    return 0;
}

int inst_271_flags_var_0() {
    return 0;
}

int inst_271_values_var_0() {
    return 0;
}

int inst_272_flags_var_0() {
    return 0;
}

int inst_272_values_var_0() {
    return 0;
}

int inst_273_flags_var_0() {
    return 0;
}

int inst_273_values_var_0() {
    return 0;
}

int inst_274_flags_var_0() {
    return 0;
}

int inst_274_values_var_0() {
    return 0;
}

int inst_275_flags_var_0() {
    return 0;
}

int inst_275_values_var_0() {
    return 0;
}

int inst_276_flags_var_0() {
    return 0;
}

int inst_276_values_var_0() {
    return 0;
}

int inst_277_flags_var_0() {
    return 0;
}

int inst_277_values_var_0() {
    return 0;
}

int inst_278_flags_var_0() {
    return 0;
}

int inst_278_values_var_0() {
    return 0;
}

int inst_279_flags_var_0() {
    return 0;
}

int inst_279_values_var_0() {
    return 0;
}

int inst_27_flags_var_0() {
    return 0;
}

int inst_27_values_var_0() {
    return 0;
}

int inst_280_flags_var_0() {
    return 0;
}

int inst_280_values_var_0() {
    return 0;
}

int inst_281_flags_var_0() {
    return 0;
}

int inst_281_values_var_0() {
    return 0;
}

int inst_282_flags_var_0() {
    return 0;
}

int inst_282_values_var_0() {
    return 0;
}

int inst_283_flags_var_0() {
    return 0;
}

int inst_283_values_var_0() {
    return 0;
}

int inst_284_flags_var_0() {
    return 0;
}

int inst_284_values_var_0() {
    return 0;
}

int inst_285_flags_var_0() {
    return 0;
}

int inst_285_values_var_0() {
    return 0;
}

int inst_286_flags_var_0() {
    return 0;
}

int inst_286_values_var_0() {
    return 0;
}

int inst_287_flags_var_0() {
    return 0;
}

int inst_287_values_var_0() {
    return 0;
}

int inst_288_flags_var_0() {
    return 0;
}

int inst_288_values_var_0() {
    return 0;
}

int inst_289_flags_var_0() {
    return 0;
}

int inst_289_values_var_0() {
    return 0;
}

int inst_28_flags_var_0() {
    return 0;
}

int inst_28_values_var_0() {
    return 0;
}

int inst_290_flags_var_0() {
    return 0;
}

int inst_290_values_var_0() {
    return 0;
}

int inst_291_flags_var_0() {
    return 0;
}

int inst_291_values_var_0() {
    return 0;
}

int inst_292_flags_var_0() {
    return 0;
}

int inst_292_values_var_0() {
    return 0;
}

int inst_293_flags_var_0() {
    return 0;
}

int inst_293_values_var_0() {
    return 0;
}

int inst_294_flags_var_0() {
    return 0;
}

int inst_294_values_var_0() {
    return 0;
}

int inst_29_flags_var_0() {
    return 0;
}

int inst_29_values_var_0() {
    return 0;
}

int inst_2_flags_var_0() {
    return 0;
}

int inst_2_values_var_0() {
    return 0;
}

int inst_30_flags_var_0() {
    return 0;
}

int inst_30_values_var_0() {
    return 0;
}

int inst_31_flags_var_0() {
    return 0;
}

int inst_31_values_var_0() {
    return 0;
}

int inst_32_flags_var_0() {
    return 0;
}

int inst_32_values_var_0() {
    return 0;
}

int inst_33_flags_var_0() {
    return 0;
}

int inst_33_values_var_0() {
    return 0;
}

int inst_34_flags_var_0() {
    for(int i = 0; !((225848144 >>> i) & 0x1); ++i) {
    }
    return 0;
}

int inst_34_values_var_0() {
    int i;
    for(i = 0; !((-1010394250 >>> i) & 0x1); ++i) {
    }
    return i - 1;
}

int inst_35_flags_var_0() {
    for(int i = 31; !(0xc5f16c34 >>> i); --i) {
    }
    return 0;
}

int inst_35_values_var_0() {
    int i;
    for(i = 31; !(502850613 >>> i); --i) {
    }
    return i - 28;
}

int inst_36_flags_var_0() {
    return 0;
}

int inst_36_values_var_0() {
    return 0;
}

int inst_37_flags_var_0() {
    return 0;
}

int inst_37_values_var_0() {
    return 0;
}

int inst_38_flags_var_0() {
    return 0;
}

int inst_38_values_var_0() {
    return 0;
}

int inst_39_flags_var_0() {
    return 0;
}

int inst_39_values_var_0() {
    return 0;
}

int inst_3_flags_var_0() {
    return 0;
}

int inst_3_values_var_0() {
    return 0;
}

int inst_40_flags_var_0() {
    return 0;
}

int inst_40_values_var_0() {
    return 0;
}

int inst_41_flags_var_0() {
    return 0;
}

int inst_41_values_var_0() {
    return 0;
}

int inst_42_flags_var_0() {
    return 0;
}

int inst_42_values_var_0() {
    return 0;
}

int inst_43_flags_var_0() {
    return 0;
}

int inst_43_values_var_0() {
    return 0;
}

int inst_44_flags_var_0() {
    return 0;
}

int inst_44_values_var_0() {
    return 0;
}

int inst_45_flags_var_0() {
    return 0;
}

int inst_45_values_var_0() {
    return 0;
}

int inst_46_flags_var_0() {
    return 0;
}

int inst_46_values_var_0() {
    return 0;
}

int inst_47_flags_var_0() {
    return 0;
}

int inst_47_values_var_0() {
    return 0;
}

int inst_48_flags_var_0() {
    return 0;
}

int inst_48_values_var_0() {
    return 0;
}

int inst_49_flags_var_0() {
    return 0;
}

int inst_49_values_var_0() {
    return 0;
}

int inst_4_flags_var_0() {
    return 0;
}

int inst_4_values_var_0() {
    return 0;
}

int inst_50_flags_var_0() {
    return 0;
}

int inst_50_values_var_0() {
    return 0;
}

int inst_51_flags_var_0() {
    return 0;
}

int inst_51_values_var_0() {
    return 0;
}

int inst_52_flags_var_0() {
    return 0;
}

int inst_52_values_var_0() {
    return 0;
}

int inst_53_flags_var_0() {
    return 0;
}

int inst_53_values_var_0() {
    return 0;
}

int inst_54_flags_var_0() {
    return 0;
}

int inst_54_values_var_0() {
    return 0;
}

int inst_55_flags_var_0() {
    return 0;
}

int inst_55_values_var_0() {
    return 0;
}

int inst_56_flags_var_0() {
    return 0;
}

int inst_56_values_var_0() {
    return 0;
}

int inst_57_flags_var_0() {
    return 0;
}

int inst_57_values_var_0() {
    return 0;
}

int inst_58_flags_var_0() {
    return 0;
}

int inst_58_values_var_0() {
    return 0;
}

int inst_59_flags_var_0() {
    return 0;
}

int inst_59_values_var_0() {
    return 0;
}

int inst_5_flags_var_0() {
    return 0;
}

int inst_5_values_var_0() {
    return 0;
}

int inst_60_flags_var_0() {
    return 0;
}

int inst_60_values_var_0() {
    return 0;
}

int inst_61_flags_var_0() {
    return 0;
}

int inst_61_values_var_0() {
    return 0;
}

int inst_62_flags_var_0() {
    return 0;
}

int inst_62_values_var_0() {
    return 0;
}

int inst_63_flags_var_0() {
    return 0;
}

int inst_63_values_var_0() {
    return 0;
}

int inst_64_flags_var_0() {
    return 0;
}

int inst_64_values_var_0() {
    return 0;
}

int inst_65_flags_var_0() {
    return 0;
}

int inst_65_values_var_0() {
    return 0;
}

int inst_66_flags_var_0() {
    return 0;
}

int inst_66_values_var_0() {
    return 0;
}

int inst_67_flags_var_0() {
    return 0;
}

int inst_67_values_var_0() {
    return 0;
}

int inst_68_flags_var_0() {
    return 0;
}

int inst_68_values_var_0() {
    return 0;
}

int inst_69_flags_var_0() {
    return 0;
}

int inst_69_values_var_0() {
    return 0;
}

int inst_6_flags_var_0() {
    return 0;
}

int inst_6_values_var_0() {
    return 0;
}

int inst_70_flags_var_0() {
    return 0;
}

int inst_70_values_var_0() {
    return 0;
}

int inst_71_flags_var_0() {
    return 0;
}

int inst_71_values_var_0() {
    return 0;
}

int inst_72_flags_var_0() {
    return 0;
}

int inst_72_values_var_0() {
    return 0;
}

int inst_73_flags_var_0() {
    return 0;
}

int inst_73_values_var_0() {
    return 0;
}

int inst_74_flags_var_0() {
    return 0;
}

int inst_74_values_var_0() {
    return 0;
}

int inst_75_flags_var_0() {
    return 0;
}

int inst_75_values_var_0() {
    return 0;
}

int inst_76_flags_var_0() {
    return 0;
}

int inst_76_values_var_0() {
    return 0;
}

int inst_77_flags_var_0() {
    return 0;
}

int inst_77_values_var_0() {
    return 0;
}

int inst_78_flags_var_0() {
    return 0;
}

int inst_78_values_var_0() {
    return 0;
}

int inst_79_flags_var_0() {
    return 0;
}

int inst_79_values_var_0() {
    return 0;
}

int inst_7_flags_var_0() {
    return 0;
}

int inst_7_values_var_0() {
    return 0;
}

int inst_80_flags_var_0() {
    return 0;
}

int inst_80_values_var_0() {
    return 0;
}

int inst_81_flags_var_0() {
    return 0;
}

int inst_81_values_var_0() {
    return 0;
}

int inst_82_flags_var_0() {
    return 0;
}

int inst_82_values_var_0() {
    return 0;
}

int inst_83_flags_var_0() {
    return 0;
}

int inst_83_values_var_0() {
    return 0;
}

int inst_84_flags_var_0() {
    return 0;
}

int inst_84_values_var_0() {
    return 0;
}

int inst_85_flags_var_0() {
    return 0;
}

int inst_85_values_var_0() {
    return 0;
}

int inst_86_flags_var_0() {
    return 0;
}

int inst_86_values_var_0() {
    return 0;
}

int inst_87_flags_var_0() {
    return 0;
}

int inst_87_values_var_0() {
    return 0;
}

int inst_88_flags_var_0() {
    return 0;
}

int inst_88_values_var_0() {
    return 0;
}

int inst_89_flags_var_0() {
    return 0;
}

int inst_89_values_var_0() {
    return 0;
}

int inst_8_flags_var_0() {
    return 0;
}

int inst_8_values_var_0() {
    return 0;
}

int inst_90_flags_var_0() {
    return 0;
}

int inst_90_values_var_0() {
    return 0;
}

int inst_91_flags_var_0() {
    return 0;
}

int inst_91_values_var_0() {
    return 0;
}

int inst_92_flags_var_0() {
    return 0;
}

int inst_92_values_var_0() {
    return 0;
}

int inst_93_flags_var_0() {
    return 0;
}

int inst_93_values_var_0() {
    return 0;
}

int inst_94_flags_var_0() {
    return 0;
}

int inst_94_values_var_0() {
    return 0;
}

int inst_95_flags_var_0() {
    return 0;
}

int inst_95_values_var_0() {
    return 0;
}

int inst_96_flags_var_0() {
    return 0;
}

int inst_96_values_var_0() {
    return 0;
}

int inst_97_flags_var_0() {
    return 0;
}

int inst_97_values_var_0() {
    return 0;
}

int inst_98_flags_var_0() {
    return 0;
}

int inst_98_values_var_0() {
    return 0;
}

int inst_99_flags_var_0() {
    return 0;
}

int inst_99_values_var_0() {
    return 0;
}

int inst_9_flags_var_0() {
    return 0;
}

int inst_9_values_var_0() {
    return 0;
}

void main() {
    // Decompilation error
}

int register_tm_clones() {
    return 0;
}

void r→__assert_fail(char* __assertion, char* __file, unsigned int __line, char* __function) {
    /*BAD_CALL!*/ sub_8049030();
}

int r→__libc_start_main() {
    /*BAD_CALL!*/ sub_8049030();
}

void sub_8049030() {
    jump gvar_805A008;
}

void sub_804A0F7() {
}

void →__assert_fail(char* __assertion, char* __file, unsigned int __line, char* __function) {
    ptr___assert_fail[0]{r→__assert_fail}(__assertion, __file, __line, __function);
}

int →__libc_start_main() {
    return ptr___libc_start_main{r→__libc_start_main}();
}
