
void __libc_csu_fini() {
}

int __libc_csu_init(int param0, int param1, int param2) {
    int result;
    initializer_0();
    unsigned int v0 = 0;
    do {
        result = *(int*)(v0 * 4 + (int)&__frame_dummy_init_array_entry){initializer_1}();
        ++v0;
    }
    while(v0 != 1);
    return result;
}

void __x86.get_pc_thunk.bx() {
}

void _dl_relocate_static_pie() {
}

int _start(int param0, int param1) {
    int v0;
    char v1;
    void* ptr0;
    int v2;
    int v3 = 0;
    char v4 = 1;
    char v5 = 0;
    char v6 = 1;
    char v7 = 0;
    char v8 = 0;
    int v9 = v0;
    int* ptr1 = &v1;
    char v10 = &v0 ? 0: 1;
    char v11 = (int)&v0 < 0;
    char v12 = __parity__((unsigned char)&v0);
    char v13 = 0;
    char v14 = 0;
    int v15 = v2;
    int* ptr2 = &v15;
    int* ptr3 = &v15;
    int v16 = param1;
    int v17 = &loc_8049CB4;
    int v18 = &loc_8049CB4;
    int v19 = &_GLOBAL_OFFSET_TABLE_;
    char v20 = 0;
    char v21 = 0;
    char v22 = 1;
    char v23 = 1;
    char v24 = 0;
    char v25 = 0;
    int v26 = &__libc_csu_fini;
    int v27 = &__libc_csu_fini;
    int v28 = &__libc_csu_init;
    int v29 = &__libc_csu_init;
    int* ptr4 = &v1;
    int v30 = &main;
    int v31 = &main;
    int* ptr5 = &ptr0;
    →__libc_start_main();
    hlt();
}

int deregister_tm_clones() {
    return &completed.6844;
}

void finalizer_0() {
}

void finalizer_1() {
    char v0 = completed.6844 ? 0: 1;
    char v1 = completed.6844 >= 128;
    char v2 = __parity__(completed.6844);
    char v3 = completed.6844 < 0;
    char v4 = 0;
    char v5 = 0;
    jump v0 ? &sub_8049D8D: &sub_8049DA8;
}

void* initializer_0() {
    void* result = __gmon_start__;
    if(result) {
        result = (void*)result();
    }
    return result;
}

int initializer_1() {
    return register_tm_clones();
}

unsigned int inst_0_flags_var_0() {
    short v0;
    short v1;
    char v2;
    *(int*)&v0 = (unsigned int)v1;
    (unsigned short)v3 = tzcnt(4335);
    return v2 ? 1: 0;
}

unsigned int inst_0_flags_var_1() {
    short v0;
    short v1;
    char v2;
    *(int*)&v0 = (unsigned int)v1;
    (unsigned short)v3 = tzcnt(2416);
    return v2 ? 1: 0;
}

unsigned int inst_0_flags_var_2() {
    short v0;
    short v1;
    char v2;
    *(int*)&v0 = (unsigned int)v1;
    short v3 = tzcnt(33240);
    return v2 ? 1: 0;
}

unsigned int inst_0_flags_var_3() {
    short v0;
    short v1;
    char v2;
    *(int*)&v0 = (unsigned int)v1;
    short v3 = tzcnt(57849);
    return v2 ? 1: 0;
}

unsigned int inst_0_flags_var_4() {
    short v0;
    short v1;
    char v2;
    *(int*)&v0 = (unsigned int)v1;
    (unsigned short)v3 = tzcnt(65053);
    return v2 ? 1: 0;
}

unsigned int inst_0_flags_var_5() {
    short v0;
    short v1;
    char v2;
    *(int*)&v0 = (unsigned int)v1;
    (unsigned short)v3 = tzcnt(38112);
    return v2 ? 1: 0;
}

unsigned int inst_0_flags_var_6() {
    short v0;
    short v1;
    char v2;
    *(int*)&v0 = (unsigned int)v1;
    (unsigned short)v3 = tzcnt(29390);
    return v2 ? 1: 0;
}

unsigned int inst_0_flags_var_7() {
    short v0;
    short v1;
    char v2;
    *(int*)&v0 = (unsigned int)v1;
    (unsigned short)v3 = tzcnt(45076);
    return v2 ? 1: 0;
}

unsigned int inst_0_flags_var_8() {
    short v0;
    short v1;
    char v2;
    *(int*)&v0 = (unsigned int)v1;
    (unsigned short)v3 = tzcnt(38158);
    return v2 ? 1: 0;
}

unsigned int inst_0_flags_var_9() {
    short v0;
    short v1;
    char v2;
    *(int*)&v0 = (unsigned int)v1;
    (unsigned short)v3 = tzcnt(7550);
    return v2 ? 1: 0;
}

int inst_0_values_var_0() {
    short v0;
    short v1;
    int v2;
    *(int*)&v0 = (unsigned int)v1;
    (unsigned short)v3 = tzcnt(42631);
    return v2 - 0x76710000;
}

int inst_0_values_var_1(int param0) {
    short v0;
    short v1;
    *(int*)&v0 = (unsigned int)v1;
    short v2 = tzcnt(8873);
    return param0 - 0xc2e0000;
}

int inst_0_values_var_2() {
    short v0;
    short v1;
    int v2;
    *(int*)&v0 = (unsigned int)v1;
    (unsigned short)v3 = tzcnt(0x2077);
    return v2 + 0x61530000;
}

int inst_0_values_var_3(int param0) {
    short v0;
    short v1;
    *(int*)&v0 = (unsigned int)v1;
    short v2 = tzcnt(0x6764);
    return param0 + 0x7c7ffffe;
}

int inst_0_values_var_4() {
    short v0;
    short v1;
    int v2;
    *(int*)&v0 = (unsigned int)v1;
    (unsigned short)v3 = tzcnt(0x50cc);
    return v2 - 0x75310002;
}

int inst_0_values_var_5() {
    short v0;
    short v1;
    int v2;
    *(int*)&v0 = (unsigned int)v1;
    (unsigned short)v3 = tzcnt(0xe7e4);
    return v2 + 0x178cfffe;
}

int inst_0_values_var_6() {
    short v0;
    short v1;
    int v2;
    *(int*)&v0 = (unsigned int)v1;
    (unsigned short)v3 = tzcnt(23992);
    return v2 + 0x16eafffd;
}

int inst_0_values_var_7() {
    short v0;
    short v1;
    int v2;
    *(int*)&v0 = (unsigned int)v1;
    (unsigned short)v3 = tzcnt(29194);
    return v2 - 0x4dbf0001;
}

int inst_0_values_var_8() {
    short v0;
    short v1;
    int v2;
    *(int*)&v0 = (unsigned int)v1;
    (unsigned short)v3 = tzcnt(27011);
    return v2 + 0x1f350000;
}

int inst_0_values_var_9(int param0, int param1) {
    short v0;
    short v1;
    *(int*)&v0 = (unsigned int)v1;
    short v2 = tzcnt(14172);
    return param1 - 0x3b910002;
}

int inst_10_flags_var_0() {
    short v0;
    short v1;
    *(int*)&v0 = (unsigned int)v1;
    int v2 = pext(-2055120892, 452085110);
    return 0;
}

int inst_10_flags_var_1() {
    short v0;
    short v1;
    *(int*)&v0 = (unsigned int)v1;
    int v2 = pext(-1790431553, -1593209170);
    return 0;
}

int inst_10_flags_var_2() {
    short v0;
    short v1;
    *(int*)&v0 = (unsigned int)v1;
    int v2 = pext(-1254945304, -38603824);
    return 0;
}

int inst_10_flags_var_3() {
    short v0;
    short v1;
    *(int*)&v0 = (unsigned int)v1;
    int v2 = pext(-1699898906, 0xacd3cee2);
    return 0;
}

int inst_10_flags_var_4() {
    short v0;
    short v1;
    *(int*)&v0 = (unsigned int)v1;
    int v2 = pext(-170558444, 1946245896);
    return 0;
}

int inst_10_flags_var_5() {
    short v0;
    short v1;
    *(int*)&v0 = (unsigned int)v1;
    int v2 = pext(0x5f9a97b1, 0x14bf1474);
    return 0;
}

int inst_10_flags_var_6() {
    short v0;
    short v1;
    *(int*)&v0 = (unsigned int)v1;
    int v2 = pext(-1031029108, -846087814);
    return 0;
}

int inst_10_flags_var_7() {
    short v0;
    short v1;
    *(int*)&v0 = (unsigned int)v1;
    int v2 = pext(0x6108e345, -39905867);
    return 0;
}

int inst_10_flags_var_8() {
    short v0;
    short v1;
    *(int*)&v0 = (unsigned int)v1;
    int v2 = pext(0xf5fa5959, -1679171081);
    return 0;
}

int inst_10_flags_var_9() {
    short v0;
    short v1;
    *(int*)&v0 = (unsigned int)v1;
    int v2 = pext(-986308641, -986308641);
    return 0;
}

int inst_10_values_var_0() {
    short v0;
    short v1;
    int v2;
    *(int*)&v0 = (unsigned int)v1;
    int v2 = pext(1762968426, 1668529281);
    return v2 - 53824;
}

int inst_10_values_var_1() {
    short v0;
    short v1;
    int v2;
    *(int*)&v0 = (unsigned int)v1;
    int v2 = pext(1230761140, 0xadac7378);
    return v2 - 42374;
}

int inst_10_values_var_2() {
    short v0;
    short v1;
    int v2;
    *(int*)&v0 = (unsigned int)v1;
    int v2 = pext(0x8e28969a, -2085116616);
    return v2 - 51283;
}

int inst_10_values_var_3() {
    short v0;
    short v1;
    int v2;
    *(int*)&v0 = (unsigned int)v1;
    int v2 = pext(-1941075087, 0xda5b3677);
    return v2 - 611449;
}

int inst_10_values_var_4() {
    short v0;
    short v1;
    int v2;
    *(int*)&v0 = (unsigned int)v1;
    int v2 = pext(-787990404, -787990404);
    return v2 - 0x1fff;
}

int inst_10_values_var_5() {
    short v0;
    short v1;
    int v2;
    *(int*)&v0 = (unsigned int)v1;
    int v2 = pext(-1686629526, -1696652911);
    return v2 - 63240;
}

int inst_10_values_var_6() {
    short v0;
    short v1;
    int v2;
    *(int*)&v0 = (unsigned int)v1;
    int v2 = pext(1182671937, -1484575175);
    return v2 - 12961;
}

int inst_10_values_var_7() {
    short v0;
    short v1;
    int v2;
    *(int*)&v0 = (unsigned int)v1;
    int v2 = pext(0xa43d3728, 794327630);
    return v2 - 83668;
}

int inst_10_values_var_8() {
    short v0;
    short v1;
    int v2;
    *(int*)&v0 = (unsigned int)v1;
    int v2 = pext(-444628750, 1681112373);
    return v2 - 130572;
}

int inst_10_values_var_9() {
    short v0;
    short v1;
    int v2;
    *(int*)&v0 = (unsigned int)v1;
    int v2 = pext(-505232365, 0x24313861);
    return v2 - 1281;
}

int inst_11_flags_var_0() {
    short v0;
    short v1;
    *(int*)&v0 = (unsigned int)v1;
    int v2 = rorx(791217770, 48);
    return 0;
}

int inst_11_flags_var_1() {
    short v0;
    short v1;
    *(int*)&v0 = (unsigned int)v1;
    int v2 = rorx(1563318186, 175);
    return 0;
}

int inst_11_flags_var_2() {
    short v0;
    short v1;
    *(int*)&v0 = (unsigned int)v1;
    int v2 = rorx(756535360, 27);
    return 0;
}

int inst_11_flags_var_3() {
    short v0;
    short v1;
    *(int*)&v0 = (unsigned int)v1;
    int v2 = rorx(2045245946, 61);
    return 0;
}

int inst_11_flags_var_4() {
    short v0;
    short v1;
    *(int*)&v0 = (unsigned int)v1;
    int v2 = rorx(-566220227, 253);
    return 0;
}

int inst_11_flags_var_5() {
    short v0;
    short v1;
    *(int*)&v0 = (unsigned int)v1;
    int v2 = rorx(2026154275, 98);
    return 0;
}

int inst_11_flags_var_6() {
    short v0;
    short v1;
    *(int*)&v0 = (unsigned int)v1;
    int v2 = rorx(-215248950, 171);
    return 0;
}

int inst_11_flags_var_7() {
    short v0;
    short v1;
    *(int*)&v0 = (unsigned int)v1;
    int v2 = rorx(-1490672704, 117);
    return 0;
}

int inst_11_flags_var_8() {
    short v0;
    short v1;
    *(int*)&v0 = (unsigned int)v1;
    int v2 = rorx(-306083654, 127);
    return 0;
}

int inst_11_flags_var_9() {
    short v0;
    short v1;
    *(int*)&v0 = (unsigned int)v1;
    int v2 = rorx(-1886514143, 133);
    return 0;
}

int inst_11_values_var_0() {
    short v0;
    short v1;
    int v2;
    *(int*)&v0 = (unsigned int)v1;
    int v2 = rorx(0x8ddd8b04, 231);
    return v2 - 0x91bbb16;
}

int inst_11_values_var_1() {
    short v0;
    short v1;
    int v2;
    *(int*)&v0 = (unsigned int)v1;
    int v2 = rorx(-451963335, 227);
    return v2 - 1017246407;
}

int inst_11_values_var_2() {
    short v0;
    short v1;
    int v2;
    *(int*)&v0 = (unsigned int)v1;
    int v2 = rorx(1561684145, 27);
    return v2 + 1565714901;
}

int inst_11_values_var_3() {
    short v0;
    short v1;
    int v2;
    *(int*)&v0 = (unsigned int)v1;
    int v2 = rorx(-1176159040, 52);
    return v2 - 1405881246;
}

int inst_11_values_var_4() {
    short v0;
    short v1;
    int v2;
    *(int*)&v0 = (unsigned int)v1;
    int v2 = rorx(9729078, 0xaa);
    return v2 - 226501917;
}

int inst_11_values_var_5() {
    short v0;
    short v1;
    int v2;
    *(int*)&v0 = (unsigned int)v1;
    int v2 = rorx(483342351, 208);
    return v2 - 940514511;
}

int inst_11_values_var_6() {
    short v0;
    short v1;
    int v2;
    *(int*)&v0 = (unsigned int)v1;
    int v2 = rorx(0xeca9e19, 112);
    return v2 + 0x61e6f136;
}

int inst_11_values_var_7() {
    short v0;
    short v1;
    int v2;
    *(int*)&v0 = (unsigned int)v1;
    int v2 = rorx(-778493540, 227);
    return v2 + 0x65ccdbcd;
}

int inst_11_values_var_8() {
    short v0;
    short v1;
    int v2;
    *(int*)&v0 = (unsigned int)v1;
    int v2 = rorx(705535203, 174);
    return v2 - 0x738ca836;
}

int inst_11_values_var_9() {
    short v0;
    short v1;
    int v2;
    *(int*)&v0 = (unsigned int)v1;
    int v2 = rorx(0x1c83bc80, 93);
    return v2 + 467803136;
}

int inst_12_flags_var_0() {
    short v0;
    short v1;
    *(int*)&v0 = (unsigned int)v1;
    int v2 = sarx(0xce1c1766, 0xce1c1766);
    return 0;
}

int inst_12_flags_var_1() {
    short v0;
    short v1;
    *(int*)&v0 = (unsigned int)v1;
    int v2 = sarx(-1483328310, -1483328310);
    return 0;
}

int inst_12_flags_var_2() {
    short v0;
    short v1;
    *(int*)&v0 = (unsigned int)v1;
    int v2 = sarx(1409890689, 1460586743);
    return 0;
}

int inst_12_flags_var_3() {
    short v0;
    short v1;
    *(int*)&v0 = (unsigned int)v1;
    int v2 = sarx(1271515703, 0xfa4425a9);
    return 0;
}

int inst_12_flags_var_4() {
    short v0;
    short v1;
    *(int*)&v0 = (unsigned int)v1;
    int v2 = sarx(0xadefd0da, -1022514849);
    return 0;
}

int inst_12_flags_var_5() {
    short v0;
    short v1;
    *(int*)&v0 = (unsigned int)v1;
    int v2 = sarx(0xc7a778b7, 105446866);
    return 0;
}

int inst_12_flags_var_6() {
    short v0;
    short v1;
    *(int*)&v0 = (unsigned int)v1;
    int v2 = sarx(50145679, -1155114135);
    return 0;
}

int inst_12_flags_var_7() {
    short v0;
    short v1;
    *(int*)&v0 = (unsigned int)v1;
    int v2 = sarx(1025114071, 423385858);
    return 0;
}

int inst_12_flags_var_8() {
    short v0;
    short v1;
    *(int*)&v0 = (unsigned int)v1;
    int v2 = sarx(-556133123, -556133123);
    return 0;
}

int inst_12_flags_var_9() {
    short v0;
    short v1;
    *(int*)&v0 = (unsigned int)v1;
    int v2 = sarx(-1880037206, -1555379585);
    return 0;
}

int inst_12_values_var_0() {
    short v0;
    short v1;
    int v2;
    *(int*)&v0 = (unsigned int)v1;
    int v2 = sarx(0xebc13cd2, 383136334);
    return v2 + 20732;
}

int inst_12_values_var_1() {
    short v0;
    short v1;
    int v2;
    *(int*)&v0 = (unsigned int)v1;
    int v2 = sarx(227819983, -727402870);
    return v2 - 222480;
}

int inst_12_values_var_2() {
    short v0;
    short v1;
    int v2;
    *(int*)&v0 = (unsigned int)v1;
    int v2 = sarx(-849670622, 1330863701);
    return v2 + 406;
}

int inst_12_values_var_3() {
    short v0;
    short v1;
    int v2;
    *(int*)&v0 = (unsigned int)v1;
    int v2 = sarx(850822812, -399540725);
    return v2 - 0x656d0;
}

int inst_12_values_var_4() {
    short v0;
    short v1;
    int v2;
    *(int*)&v0 = (unsigned int)v1;
    int v2 = sarx(-333162186, 378432829);
    return v2 + 1;
}

int inst_12_values_var_5() {
    short v0;
    short v1;
    int v2;
    *(int*)&v0 = (unsigned int)v1;
    int v2 = sarx(-1085266451, -442502155);
    return v2 + 518;
}

int inst_12_values_var_6() {
    short v0;
    short v1;
    int v2;
    *(int*)&v0 = (unsigned int)v1;
    int v2 = sarx(-1982898954, -1930842749);
    return v2 + 247862370;
}

int inst_12_values_var_7() {
    short v0;
    short v1;
    int v2;
    *(int*)&v0 = (unsigned int)v1;
    int v2 = sarx(0x67829c32, -1169918117);
    return v2 - 12;
}

int inst_12_values_var_8() {
    short v0;
    short v1;
    int v2;
    *(int*)&v0 = (unsigned int)v1;
    int v2 = sarx(610576373, -1801146015);
    return v2 - 0x123253fa;
}

int inst_12_values_var_9() {
    short v0;
    short v1;
    int v2;
    *(int*)&v0 = (unsigned int)v1;
    int v2 = sarx(750257426, 750257426);
    return v2 - 2862;
}

int inst_13_flags_var_0() {
    short v0;
    short v1;
    *(int*)&v0 = (unsigned int)v1;
    int v2 = shlx(0x524d5002, 0x524d5002);
    return 0;
}

int inst_13_flags_var_1() {
    short v0;
    short v1;
    *(int*)&v0 = (unsigned int)v1;
    int v2 = shlx(1463000842, 1891415676);
    return 0;
}

int inst_13_flags_var_2() {
    short v0;
    short v1;
    *(int*)&v0 = (unsigned int)v1;
    int v2 = shlx(-2109057769, 0x31a33866);
    return 0;
}

int inst_13_flags_var_3() {
    short v0;
    short v1;
    *(int*)&v0 = (unsigned int)v1;
    int v2 = shlx(0x6d8e6e92, 1755299852);
    return 0;
}

int inst_13_flags_var_4() {
    short v0;
    short v1;
    *(int*)&v0 = (unsigned int)v1;
    int v2 = shlx(-1210723727, 1675133558);
    return 0;
}

int inst_13_flags_var_5() {
    short v0;
    short v1;
    *(int*)&v0 = (unsigned int)v1;
    int v2 = shlx(0xc88991a, 0xc88991a);
    return 0;
}

int inst_13_flags_var_6() {
    short v0;
    short v1;
    *(int*)&v0 = (unsigned int)v1;
    int v2 = shlx(335361602, 0xdccb78e0);
    return 0;
}

int inst_13_flags_var_7() {
    short v0;
    short v1;
    *(int*)&v0 = (unsigned int)v1;
    int v2 = shlx(-1064844691, -823595224);
    return 0;
}

int inst_13_flags_var_8() {
    short v0;
    short v1;
    *(int*)&v0 = (unsigned int)v1;
    int v2 = shlx(501258026, 692885557);
    return 0;
}

int inst_13_flags_var_9() {
    short v0;
    short v1;
    *(int*)&v0 = (unsigned int)v1;
    int v2 = shlx(1990687555, 1116963066);
    return 0;
}

int inst_13_values_var_0() {
    short v0;
    short v1;
    int v2;
    *(int*)&v0 = (unsigned int)v1;
    int v2 = shlx(-189994739, -2068995137);
    return v2 + 0x80000000;
}

int inst_13_values_var_1() {
    short v0;
    short v1;
    int v2;
    *(int*)&v0 = (unsigned int)v1;
    int v2 = shlx(1847510208, 1388453443);
    return v2 - 1895179776;
}

int inst_13_values_var_2() {
    short v0;
    short v1;
    int v2;
    *(int*)&v0 = (unsigned int)v1;
    int v2 = shlx(-884507854, -884507854);
    return v2 + 0x13380000;
}

int inst_13_values_var_3() {
    short v0;
    short v1;
    int v2;
    *(int*)&v0 = (unsigned int)v1;
    int v2 = shlx(1684066975, 0xb410049f);
    return v2 + 0x80000000;
}

int inst_13_values_var_4() {
    short v0;
    short v1;
    int v2;
    *(int*)&v0 = (unsigned int)v1;
    int v2 = shlx(1250472528, -47244049);
    return v2 - 0x59280000;
}

int inst_13_values_var_5() {
    short v0;
    short v1;
    int v2;
    *(int*)&v0 = (unsigned int)v1;
    int v2 = shlx(1886636564, 0xed0210c5);
    return v2 - 242827904;
}

int inst_13_values_var_6() {
    short v0;
    short v1;
    int v2;
    *(int*)&v0 = (unsigned int)v1;
    int v2 = shlx(1426518199, -609964017);
    return v2 - 0x785b8000;
}

int inst_13_values_var_7() {
    short v0;
    short v1;
    int v2;
    *(int*)&v0 = (unsigned int)v1;
    int v2 = shlx(0xbaac9561, -1550506832);
    return v2 + 0x6a9f0000;
}

int inst_13_values_var_8() {
    short v0;
    short v1;
    int v2;
    *(int*)&v0 = (unsigned int)v1;
    int v2 = shlx(-1108246737, 0x9294a94d);
    return v2 - 0x2fe5e000;
}

int inst_13_values_var_9() {
    short v0;
    short v1;
    int v2;
    *(int*)&v0 = (unsigned int)v1;
    int v2 = shlx(-173612166, 242741746);
    return v2 + 0x72180000;
}

int inst_14_flags_var_0() {
    short v0;
    short v1;
    *(int*)&v0 = (unsigned int)v1;
    int v2 = shrx(1211086396, -633191732);
    return 0;
}

int inst_14_flags_var_1() {
    short v0;
    short v1;
    *(int*)&v0 = (unsigned int)v1;
    int v2 = shrx(487407864, -1693197014);
    return 0;
}

int inst_14_flags_var_2() {
    short v0;
    short v1;
    *(int*)&v0 = (unsigned int)v1;
    int v2 = shrx(-854685950, -1669501189);
    return 0;
}

int inst_14_flags_var_3() {
    short v0;
    short v1;
    *(int*)&v0 = (unsigned int)v1;
    int v2 = shrx(749149621, 22151327);
    return 0;
}

int inst_14_flags_var_4() {
    short v0;
    short v1;
    *(int*)&v0 = (unsigned int)v1;
    int v2 = shrx(0x38dd3ea3, 722925279);
    return 0;
}

int inst_14_flags_var_5() {
    short v0;
    short v1;
    *(int*)&v0 = (unsigned int)v1;
    int v2 = shrx(0xaab0e1e0, 1581266997);
    return 0;
}

int inst_14_flags_var_6() {
    short v0;
    short v1;
    *(int*)&v0 = (unsigned int)v1;
    int v2 = shrx(-102237385, -1555121865);
    return 0;
}

int inst_14_flags_var_7() {
    short v0;
    short v1;
    *(int*)&v0 = (unsigned int)v1;
    int v2 = shrx(-1091432292, 92031196);
    return 0;
}

int inst_14_flags_var_8() {
    short v0;
    short v1;
    *(int*)&v0 = (unsigned int)v1;
    int v2 = shrx(0x6d1c5aaa, 0x6d1c5aaa);
    return 0;
}

int inst_14_flags_var_9() {
    short v0;
    short v1;
    *(int*)&v0 = (unsigned int)v1;
    int v2 = shrx(-663605155, 547305600);
    return 0;
}

int inst_14_values_var_0() {
    short v0;
    short v1;
    int v2;
    *(int*)&v0 = (unsigned int)v1;
    int v2 = shrx(-622290496, -908753075);
    return v2 - 448324;
}

int inst_14_values_var_1() {
    short v0;
    short v1;
    int v2;
    *(int*)&v0 = (unsigned int)v1;
    int v2 = shrx(-1797435201, -935353722);
    return v2 - 39023938;
}

int inst_14_values_var_2() {
    short v0;
    short v1;
    int v2;
    *(int*)&v0 = (unsigned int)v1;
    int v2 = shrx(0xfbaaa879, -1093375953);
    return v2 - 0x1f755;
}

int inst_14_values_var_3() {
    short v0;
    short v1;
    int v2;
    *(int*)&v0 = (unsigned int)v1;
    int v2 = shrx(1583725550, 0x2f828e3a);
    return v2 - 23;
}

int inst_14_values_var_4() {
    short v0;
    short v1;
    int v2;
    *(int*)&v0 = (unsigned int)v1;
    int v2 = shrx(-689855870, 0xbfbb36e5);
    return v2 - 112659732;
}

int inst_14_values_var_5() {
    short v0;
    short v1;
    int v2;
    *(int*)&v0 = (unsigned int)v1;
    int v2 = shrx(1686027328, 712429275);
    return v2 - 12;
}

int inst_14_values_var_6() {
    short v0;
    short v1;
    int v2;
    *(int*)&v0 = (unsigned int)v1;
    int v2 = shrx(532396544, 1580164441);
    return v2 - 15;
}

int inst_14_values_var_7() {
    short v0;
    short v1;
    int v2;
    *(int*)&v0 = (unsigned int)v1;
    int v2 = shrx(1525987144, 2142152408);
    return v2 - 90;
}

int inst_14_values_var_8() {
    short v0;
    short v1;
    int v2;
    *(int*)&v0 = (unsigned int)v1;
    int v2 = shrx(-2119179658, -2119179658);
    return v2 - 518;
}

int inst_14_values_var_9() {
    short v0;
    short v1;
    int v2;
    *(int*)&v0 = (unsigned int)v1;
    int v2 = shrx(0x110f7c66, 0x7b6072b2);
    return v2 - 0x443;
}

int inst_15_flags_var_0() {
    short v0;
    short v1;
    *(int*)&v0 = (unsigned int)v1;
    adox(1909777996, -1278062750);
    return -2;
}

int inst_15_flags_var_1() {
    short v0;
    short v1;
    *(int*)&v0 = (unsigned int)v1;
    adox(-241784897, 0xbc47b0a8);
    return -2;
}

int inst_15_flags_var_2() {
    short v0;
    short v1;
    *(int*)&v0 = (unsigned int)v1;
    adox(0xa91ede05, 0xa91ede05);
    return -2;
}

int inst_15_flags_var_3() {
    short v0;
    short v1;
    *(int*)&v0 = (unsigned int)v1;
    adox(-1566700073, 0x5a6f4225);
    return 0;
}

int inst_15_flags_var_4() {
    short v0;
    short v1;
    *(int*)&v0 = (unsigned int)v1;
    adox(-26599303, -1006376182);
    return -2;
}

int inst_15_flags_var_5() {
    short v0;
    short v1;
    *(int*)&v0 = (unsigned int)v1;
    adox(16335225, -1576461106);
    return 0;
}

int inst_15_flags_var_6() {
    short v0;
    short v1;
    *(int*)&v0 = (unsigned int)v1;
    adox(-846856631, -2063190677);
    return -2;
}

int inst_15_flags_var_7() {
    short v0;
    short v1;
    *(int*)&v0 = (unsigned int)v1;
    adox(-332253926, 1588536061);
    return -2;
}

int inst_15_flags_var_8() {
    short v0;
    short v1;
    *(int*)&v0 = (unsigned int)v1;
    adox(-1864117703, 1823000667);
    return 0;
}

int inst_15_flags_var_9() {
    short v0;
    short v1;
    *(int*)&v0 = (unsigned int)v1;
    adox(-2027546673, -901092588);
    return -2;
}

int inst_15_values_var_0() {
    short v0;
    short v1;
    *(int*)&v0 = (unsigned int)v1;
    adox(1194453572, -1894381847);
    return 1894381847;
}

int inst_15_values_var_1() {
    short v0;
    short v1;
    *(int*)&v0 = (unsigned int)v1;
    adox(-1097794928, 1460124667);
    return -1460124667;
}

int inst_15_values_var_2() {
    short v0;
    short v1;
    *(int*)&v0 = (unsigned int)v1;
    adox(2146149235, 2146149235);
    return -2146149235;
}

int inst_15_values_var_3() {
    short v0;
    short v1;
    *(int*)&v0 = (unsigned int)v1;
    adox(1299056513, -1508692084);
    return 1508692084;
}

int inst_15_values_var_4() {
    short v0;
    short v1;
    *(int*)&v0 = (unsigned int)v1;
    adox(0x4be645b, 58467584);
    return -58467584;
}

int inst_15_values_var_5() {
    short v0;
    short v1;
    *(int*)&v0 = (unsigned int)v1;
    adox(-2126934686, 550676471);
    return -550676471;
}

int inst_15_values_var_6() {
    short v0;
    short v1;
    *(int*)&v0 = (unsigned int)v1;
    adox(-173871022, -1726092541);
    return 1726092541;
}

int inst_15_values_var_7() {
    short v0;
    short v1;
    *(int*)&v0 = (unsigned int)v1;
    adox(0x24d609ab, 2112105206);
    return -2112105206;
}

int inst_15_values_var_8() {
    short v0;
    short v1;
    *(int*)&v0 = (unsigned int)v1;
    adox(1966328308, 1966328308);
    return -1966328308;
}

int inst_15_values_var_9() {
    short v0;
    short v1;
    *(int*)&v0 = (unsigned int)v1;
    adox(2120059850, -888618332);
    return 888618332;
}

int inst_16_flags_var_0() {
    short v0;
    short v1;
    *(int*)&v0 = (unsigned int)v1;
    adcx(-258461112, 1087454374);
    return 0;
}

int inst_16_flags_var_1() {
    short v0;
    short v1;
    *(int*)&v0 = (unsigned int)v1;
    adcx(1593455677, -1118413764);
    return 0;
}

int inst_16_flags_var_2() {
    short v0;
    short v1;
    *(int*)&v0 = (unsigned int)v1;
    adcx(0x284aab28, -1810340071);
    return 1;
}

int inst_16_flags_var_3() {
    short v0;
    short v1;
    *(int*)&v0 = (unsigned int)v1;
    adcx(-1009153517, -391910429);
    return 0;
}

int inst_16_flags_var_4() {
    short v0;
    short v1;
    *(int*)&v0 = (unsigned int)v1;
    adcx(-560858935, 0xabb5d5dd);
    return 0;
}

int inst_16_flags_var_5() {
    short v0;
    short v1;
    *(int*)&v0 = (unsigned int)v1;
    adcx(0x74def75f, 0xcd2404c9);
    return 0;
}

int inst_16_flags_var_6() {
    short v0;
    short v1;
    *(int*)&v0 = (unsigned int)v1;
    adcx(-53434219, 2089424482);
    return 0;
}

int inst_16_flags_var_7() {
    short v0;
    short v1;
    *(int*)&v0 = (unsigned int)v1;
    adcx(0x50edf33, 508260864);
    return 1;
}

int inst_16_flags_var_8() {
    short v0;
    short v1;
    *(int*)&v0 = (unsigned int)v1;
    adcx(0xcedd550e, -1309411617);
    return 0;
}

int inst_16_flags_var_9() {
    short v0;
    short v1;
    *(int*)&v0 = (unsigned int)v1;
    adcx(-1804068417, -153969881);
    return 0;
}

int inst_16_values_var_0() {
    short v0;
    short v1;
    *(int*)&v0 = (unsigned int)v1;
    adcx(293656913, -884834407);
    return 884834406;
}

int inst_16_values_var_1() {
    short v0;
    short v1;
    *(int*)&v0 = (unsigned int)v1;
    adcx(1080488984, 0xde99ba9c);
    return 0x21664563;
}

int inst_16_values_var_2() {
    short v0;
    short v1;
    *(int*)&v0 = (unsigned int)v1;
    adcx(282539375, 282539375);
    return 0xef28ca90;
}

int inst_16_values_var_3() {
    short v0;
    short v1;
    *(int*)&v0 = (unsigned int)v1;
    adcx(1213280651, 502643028);
    return 0xe20a46ab;
}

int inst_16_values_var_4() {
    short v0;
    short v1;
    *(int*)&v0 = (unsigned int)v1;
    adcx(0x1121a5f1, -1389566243);
    return 1389566242;
}

int inst_16_values_var_5() {
    short v0;
    short v1;
    *(int*)&v0 = (unsigned int)v1;
    adcx(-630837646, 0x12ccb356);
    return 0xed334ca9;
}

int inst_16_values_var_6() {
    short v0;
    short v1;
    *(int*)&v0 = (unsigned int)v1;
    adcx(1556860994, -1150999344);
    return 1150999343;
}

int inst_16_values_var_7() {
    short v0;
    short v1;
    *(int*)&v0 = (unsigned int)v1;
    adcx(-1603283321, -1603283321);
    return 1603283320;
}

int inst_16_values_var_8() {
    short v0;
    short v1;
    *(int*)&v0 = (unsigned int)v1;
    adcx(0xcec9cf66, 0x5987cb2c);
    return 0xa67834d3;
}

int inst_16_values_var_9() {
    short v0;
    short v1;
    *(int*)&v0 = (unsigned int)v1;
    adcx(-1578658500, 1097149250);
    return -1097149251;
}

int inst_17_flags_var_0() {
    short v0;
    short v1;
    *(int*)&v0 = (unsigned int)v1;
    crc32(1957160080, 232);
    return 0;
}

int inst_17_flags_var_1() {
    short v0;
    short v1;
    *(int*)&v0 = (unsigned int)v1;
    crc32(-1887259254, 0xcc);
    return 0;
}

int inst_17_flags_var_2() {
    short v0;
    short v1;
    *(int*)&v0 = (unsigned int)v1;
    crc32(0x68989a18, 154);
    return 0;
}

int inst_17_flags_var_3() {
    short v0;
    short v1;
    *(int*)&v0 = (unsigned int)v1;
    crc32(-1853554265, 215);
    return 0;
}

int inst_17_flags_var_4() {
    short v0;
    short v1;
    *(int*)&v0 = (unsigned int)v1;
    crc32(0x67cde30a, 248);
    return 0;
}

int inst_17_flags_var_5() {
    short v0;
    short v1;
    *(int*)&v0 = (unsigned int)v1;
    crc32(0xd1dd3802, 158);
    return 0;
}

int inst_17_flags_var_6() {
    short v0;
    short v1;
    *(int*)&v0 = (unsigned int)v1;
    crc32(-2137724238, 250);
    return 0;
}

int inst_17_flags_var_7() {
    short v0;
    short v1;
    *(int*)&v0 = (unsigned int)v1;
    crc32(-1422319274, 11);
    return 0;
}

int inst_17_flags_var_8() {
    short v0;
    short v1;
    *(int*)&v0 = (unsigned int)v1;
    crc32(-1840050627, 246);
    return 0;
}

int inst_17_flags_var_9() {
    short v0;
    short v1;
    *(int*)&v0 = (unsigned int)v1;
    crc32(920079420, 184);
    return 0;
}

int inst_17_values_var_0() {
    short v0;
    short v1;
    *(int*)&v0 = (unsigned int)v1;
    crc32(1253600531, 157);
    return 468988129;
}

int inst_17_values_var_1() {
    short v0;
    short v1;
    *(int*)&v0 = (unsigned int)v1;
    crc32(-109193720, 22);
    return 1017041002;
}

int inst_17_values_var_2() {
    short v0;
    short v1;
    *(int*)&v0 = (unsigned int)v1;
    crc32(0xe00c88a3, 0xaa);
    return 1740222815;
}

int inst_17_values_var_3() {
    short v0;
    short v1;
    *(int*)&v0 = (unsigned int)v1;
    crc32(2083812808, 179);
    return -1815696763;
}

int inst_17_values_var_4() {
    short v0;
    short v1;
    *(int*)&v0 = (unsigned int)v1;
    crc32(756764133, 188);
    return 56701843;
}

int inst_17_values_var_5() {
    short v0;
    short v1;
    *(int*)&v0 = (unsigned int)v1;
    crc32(1829036936, 41);
    return 481800514;
}

int inst_17_values_var_6() {
    short v0;
    short v1;
    *(int*)&v0 = (unsigned int)v1;
    crc32(-1238184810, 241);
    return 0x780751;
}

int inst_17_values_var_7() {
    short v0;
    short v1;
    *(int*)&v0 = (unsigned int)v1;
    crc32(673700031, 97);
    return -1465622677;
}

int inst_17_values_var_8() {
    short v0;
    short v1;
    *(int*)&v0 = (unsigned int)v1;
    crc32(0x9db0968a, 66);
    return 1407633389;
}

int inst_17_values_var_9() {
    short v0;
    short v1;
    *(int*)&v0 = (unsigned int)v1;
    crc32(-1394970927, 142);
    return -1656737224;
}

int inst_18_flags_var_0() {
    short v0;
    short v1;
    *(int*)&v0 = (unsigned int)v1;
    crc32(1297797813, 28974);
    return 0;
}

int inst_18_flags_var_1() {
    short v0;
    short v1;
    *(int*)&v0 = (unsigned int)v1;
    crc32(-170968771, 0x6e65);
    return 0;
}

int inst_18_flags_var_2() {
    short v0;
    short v1;
    *(int*)&v0 = (unsigned int)v1;
    crc32(1913190991, 0x212c);
    return 0;
}

int inst_18_flags_var_3() {
    short v0;
    short v1;
    *(int*)&v0 = (unsigned int)v1;
    crc32(-432575721, 45015);
    return 0;
}

int inst_18_flags_var_4() {
    short v0;
    short v1;
    *(int*)&v0 = (unsigned int)v1;
    crc32(0x57850a45, 30411);
    return 0;
}

int inst_18_flags_var_5() {
    short v0;
    short v1;
    *(int*)&v0 = (unsigned int)v1;
    crc32(-1910067750, 64940);
    return 0;
}

int inst_18_flags_var_6() {
    short v0;
    short v1;
    *(int*)&v0 = (unsigned int)v1;
    crc32(0xe9c8e7e2, 46414);
    return 0;
}

int inst_18_flags_var_7() {
    short v0;
    short v1;
    *(int*)&v0 = (unsigned int)v1;
    crc32(1435113790, 0x5566);
    return 0;
}

int inst_18_flags_var_8() {
    short v0;
    short v1;
    *(int*)&v0 = (unsigned int)v1;
    crc32(0x160ac8c8, 52774);
    return 0;
}

int inst_18_flags_var_9() {
    short v0;
    short v1;
    *(int*)&v0 = (unsigned int)v1;
    crc32(0xd285eebd, 51377);
    return 0;
}

int inst_18_values_var_0() {
    short v0;
    short v1;
    *(int*)&v0 = (unsigned int)v1;
    crc32(0xb263322b, 0x322b);
    return -1302167608;
}

int inst_18_values_var_1() {
    short v0;
    short v1;
    *(int*)&v0 = (unsigned int)v1;
    crc32(0x3910e455, 0xe455);
    return 957393733;
}

int inst_18_values_var_2() {
    short v0;
    short v1;
    *(int*)&v0 = (unsigned int)v1;
    crc32(-190822688, 22107);
    return -226519476;
}

int inst_18_values_var_3() {
    short v0;
    short v1;
    *(int*)&v0 = (unsigned int)v1;
    crc32(0xbcc6137b, 54780);
    return 1480836389;
}

int inst_18_values_var_4() {
    short v0;
    short v1;
    *(int*)&v0 = (unsigned int)v1;
    crc32(0x32176262, 54667);
    return -1629437347;
}

int inst_18_values_var_5() {
    short v0;
    short v1;
    *(int*)&v0 = (unsigned int)v1;
    crc32(-1121230284, 62006);
    return 121499746;
}

int inst_18_values_var_6() {
    short v0;
    short v1;
    *(int*)&v0 = (unsigned int)v1;
    crc32(188540335, 37987);
    return -1232887036;
}

int inst_18_values_var_7() {
    short v0;
    short v1;
    *(int*)&v0 = (unsigned int)v1;
    crc32(1639554169, 45271);
    return 0x444bf0b3;
}

int inst_18_values_var_8() {
    short v0;
    short v1;
    *(int*)&v0 = (unsigned int)v1;
    crc32(1777439530, 48163);
    return 0x79d91266;
}

int inst_18_values_var_9() {
    short v0;
    short v1;
    *(int*)&v0 = (unsigned int)v1;
    crc32(-1894717598, 5797);
    return 0xf545084;
}

int inst_19_flags_var_0() {
    short v0;
    short v1;
    *(int*)&v0 = (unsigned int)v1;
    crc32(1087415724, 0xdefd415e);
    return 0;
}

int inst_19_flags_var_1() {
    short v0;
    short v1;
    *(int*)&v0 = (unsigned int)v1;
    crc32(-2143054082, 162461048);
    return 0;
}

int inst_19_flags_var_2() {
    short v0;
    short v1;
    *(int*)&v0 = (unsigned int)v1;
    crc32(-888146139, 1420566324);
    return 0;
}

int inst_19_flags_var_3() {
    short v0;
    short v1;
    *(int*)&v0 = (unsigned int)v1;
    crc32(742270066, 1527445682);
    return 0;
}

int inst_19_flags_var_4() {
    short v0;
    short v1;
    *(int*)&v0 = (unsigned int)v1;
    crc32(951589553, 828485703);
    return 0;
}

int inst_19_flags_var_5() {
    short v0;
    short v1;
    *(int*)&v0 = (unsigned int)v1;
    crc32(-495037875, -279661009);
    return 0;
}

int inst_19_flags_var_6() {
    short v0;
    short v1;
    *(int*)&v0 = (unsigned int)v1;
    crc32(-2054345493, 2137457854);
    return 0;
}

int inst_19_flags_var_7() {
    short v0;
    short v1;
    *(int*)&v0 = (unsigned int)v1;
    crc32(317841334, -2093063404);
    return 0;
}

int inst_19_flags_var_8() {
    short v0;
    short v1;
    *(int*)&v0 = (unsigned int)v1;
    crc32(222380478, -1859845549);
    return 0;
}

int inst_19_flags_var_9() {
    short v0;
    short v1;
    *(int*)&v0 = (unsigned int)v1;
    crc32(174538254, 991257227);
    return 0;
}

int inst_19_values_var_0() {
    short v0;
    short v1;
    *(int*)&v0 = (unsigned int)v1;
    crc32(-1366144916, 2060790120);
    return 1159767735;
}

int inst_19_values_var_1() {
    short v0;
    short v1;
    *(int*)&v0 = (unsigned int)v1;
    crc32(126139455, 126139455);
    return 126139455;
}

int inst_19_values_var_2() {
    short v0;
    short v1;
    *(int*)&v0 = (unsigned int)v1;
    crc32(1878175054, 696322509);
    return 1201061709;
}

int inst_19_values_var_3() {
    short v0;
    short v1;
    *(int*)&v0 = (unsigned int)v1;
    crc32(-148469989, -1617484958);
    return 0xedbae639;
}

int inst_19_values_var_4() {
    short v0;
    short v1;
    *(int*)&v0 = (unsigned int)v1;
    crc32(-444343991, -298859394);
    return 1259429974;
}

int inst_19_values_var_5() {
    short v0;
    short v1;
    *(int*)&v0 = (unsigned int)v1;
    crc32(139152320, -1137585428);
    return -1141233451;
}

int inst_19_values_var_6() {
    short v0;
    short v1;
    *(int*)&v0 = (unsigned int)v1;
    crc32(450325533, 1427999362);
    return -1862486887;
}

int inst_19_values_var_7() {
    short v0;
    short v1;
    *(int*)&v0 = (unsigned int)v1;
    crc32(1256911427, 1256911427);
    return 1256911427;
}

int inst_19_values_var_8() {
    short v0;
    short v1;
    *(int*)&v0 = (unsigned int)v1;
    crc32(1068559233, 0x8b14bc15);
    return -2095800761;
}

int inst_19_values_var_9() {
    short v0;
    short v1;
    *(int*)&v0 = (unsigned int)v1;
    crc32(0xb443efa1, -962202063);
    return 0xdffeec9d;
}

unsigned int inst_1_flags_var_0() {
    short v0;
    short v1;
    char v2;
    *(int*)&v0 = (unsigned int)v1;
    int v3 = tzcnt(254618161);
    return v2 ? 1: 0;
}

unsigned int inst_1_flags_var_1() {
    short v0;
    short v1;
    char v2;
    *(int*)&v0 = (unsigned int)v1;
    int v3 = tzcnt(730644315);
    return v2 ? 1: 0;
}

unsigned int inst_1_flags_var_2() {
    short v0;
    short v1;
    char v2;
    *(int*)&v0 = (unsigned int)v1;
    int v3 = tzcnt(240633786);
    return v2 ? 1: 0;
}

unsigned int inst_1_flags_var_3() {
    short v0;
    short v1;
    char v2;
    *(int*)&v0 = (unsigned int)v1;
    int v3 = tzcnt(0xa1e08aa);
    return v2 ? 1: 0;
}

unsigned int inst_1_flags_var_4() {
    short v0;
    short v1;
    char v2;
    *(int*)&v0 = (unsigned int)v1;
    int v3 = tzcnt(-236713867);
    return v2 ? 1: 0;
}

unsigned int inst_1_flags_var_5() {
    short v0;
    short v1;
    char v2;
    *(int*)&v0 = (unsigned int)v1;
    int v3 = tzcnt(212912351);
    return v2 ? 1: 0;
}

unsigned int inst_1_flags_var_6() {
    short v0;
    short v1;
    char v2;
    *(int*)&v0 = (unsigned int)v1;
    int v3 = tzcnt(1733378162);
    return v2 ? 1: 0;
}

unsigned int inst_1_flags_var_7() {
    short v0;
    short v1;
    char v2;
    *(int*)&v0 = (unsigned int)v1;
    int v3 = tzcnt(1226576686);
    return v2 ? 1: 0;
}

unsigned int inst_1_flags_var_8() {
    short v0;
    short v1;
    char v2;
    *(int*)&v0 = (unsigned int)v1;
    int v3 = tzcnt(-691499111);
    return v2 ? 1: 0;
}

unsigned int inst_1_flags_var_9() {
    short v0;
    short v1;
    char v2;
    *(int*)&v0 = (unsigned int)v1;
    int v3 = tzcnt(-1467881017);
    return v2 ? 1: 0;
}

int inst_1_values_var_0() {
    short v0;
    short v1;
    int result;
    *(int*)&v0 = (unsigned int)v1;
    int result = tzcnt(0x10632017);
    return result;
}

int inst_1_values_var_1() {
    short v0;
    short v1;
    int v2;
    *(int*)&v0 = (unsigned int)v1;
    int v2 = tzcnt(340777174);
    return v2 - 1;
}

int inst_1_values_var_2() {
    short v0;
    short v1;
    int v2;
    *(int*)&v0 = (unsigned int)v1;
    int v2 = tzcnt(-431313248);
    return v2 - 5;
}

int inst_1_values_var_3() {
    short v0;
    short v1;
    int result;
    *(int*)&v0 = (unsigned int)v1;
    int result = tzcnt(255251217);
    return result;
}

int inst_1_values_var_4() {
    short v0;
    short v1;
    int result;
    *(int*)&v0 = (unsigned int)v1;
    int result = tzcnt(-1264045333);
    return result;
}

int inst_1_values_var_5() {
    short v0;
    short v1;
    int result;
    *(int*)&v0 = (unsigned int)v1;
    int result = tzcnt(0xe3626229);
    return result;
}

int inst_1_values_var_6() {
    short v0;
    short v1;
    int v2;
    *(int*)&v0 = (unsigned int)v1;
    int v2 = tzcnt(2014030982);
    return v2 - 1;
}

int inst_1_values_var_7() {
    short v0;
    short v1;
    int result;
    *(int*)&v0 = (unsigned int)v1;
    int result = tzcnt(-1034133);
    return result;
}

int inst_1_values_var_8() {
    short v0;
    short v1;
    int v2;
    *(int*)&v0 = (unsigned int)v1;
    int v2 = tzcnt(-5609698);
    return v2 - 1;
}

int inst_1_values_var_9() {
    short v0;
    short v1;
    int v2;
    *(int*)&v0 = (unsigned int)v1;
    int v2 = tzcnt(1298586160);
    return v2 - 4;
}

int inst_20_flags_var_0() {
    short v0;
    short v1;
    *(int*)&v0 = (unsigned int)v1;
    (unsigned short)v2 = lzcnt(3769);
    return 0;
}

int inst_20_flags_var_1() {
    short v0;
    short v1;
    *(int*)&v0 = (unsigned int)v1;
    (unsigned short)v2 = lzcnt(2635);
    return 0;
}

int inst_20_flags_var_2() {
    short v0;
    short v1;
    *(int*)&v0 = (unsigned int)v1;
    (unsigned short)v2 = lzcnt(60754);
    return 0;
}

int inst_20_flags_var_3() {
    short v0;
    short v1;
    *(int*)&v0 = (unsigned int)v1;
    (unsigned short)v2 = lzcnt(0x7900);
    return 0;
}

int inst_20_flags_var_4() {
    short v0;
    short v1;
    *(int*)&v0 = (unsigned int)v1;
    (unsigned short)v2 = lzcnt(0xb5b9);
    return 0;
}

int inst_20_flags_var_5() {
    short v0;
    short v1;
    *(int*)&v0 = (unsigned int)v1;
    (unsigned short)v2 = lzcnt(0x2f1f);
    return 0;
}

int inst_20_flags_var_6() {
    short v0;
    short v1;
    *(int*)&v0 = (unsigned int)v1;
    (unsigned short)v2 = lzcnt(13555);
    return 0;
}

int inst_20_flags_var_7() {
    short v0;
    short v1;
    *(int*)&v0 = (unsigned int)v1;
    short v2 = lzcnt(3145);
    return 0;
}

int inst_20_flags_var_8() {
    short v0;
    short v1;
    *(int*)&v0 = (unsigned int)v1;
    (unsigned short)v2 = lzcnt(61127);
    return 0;
}

int inst_20_flags_var_9() {
    short v0;
    short v1;
    *(int*)&v0 = (unsigned int)v1;
    short v2 = lzcnt(0x334d);
    return 0;
}

int inst_20_values_var_0() {
    short v0;
    short v1;
    int v2;
    *(int*)&v0 = (unsigned int)v1;
    short v3 = lzcnt(0xd24d);
    return v2 - 7667712;
}

int inst_20_values_var_1(int param0) {
    short v0;
    short v1;
    *(int*)&v0 = (unsigned int)v1;
    short v2 = lzcnt(58276);
    return param0 - 0x637b0000;
}

int inst_20_values_var_2(int param0, int param1) {
    short v0;
    short v1;
    *(int*)&v0 = (unsigned int)v1;
    short v2 = lzcnt(23331);
    return param1 + 0x2552ffff;
}

int inst_20_values_var_3(int param0, int param1) {
    short v0;
    short v1;
    *(int*)&v0 = (unsigned int)v1;
    short v2 = lzcnt(0x6fdf);
    return param1 - 0x7ec80001;
}

int inst_20_values_var_4() {
    short v0;
    short v1;
    int v2;
    *(int*)&v0 = (unsigned int)v1;
    (unsigned short)v3 = lzcnt(0x32c2);
    return v2 + 1999241214;
}

int inst_20_values_var_5() {
    short v0;
    short v1;
    int v2;
    *(int*)&v0 = (unsigned int)v1;
    (unsigned short)v3 = lzcnt(0x6a2a);
    return v2 + 2125987839;
}

int inst_20_values_var_6(int param0) {
    short v0;
    short v1;
    *(int*)&v0 = (unsigned int)v1;
    short v2 = lzcnt(48192);
    return param0 - 0xcb60000;
}

int inst_20_values_var_7() {
    short v0;
    short v1;
    int v2;
    *(int*)&v0 = (unsigned int)v1;
    short v3 = lzcnt(54478);
    return v2 + 0x332f0000;
}

int inst_20_values_var_8() {
    short v0;
    short v1;
    int v2;
    *(int*)&v0 = (unsigned int)v1;
    (unsigned short)v3 = lzcnt(32179);
    return v2 - 0x44420001;
}

int inst_20_values_var_9() {
    short v0;
    short v1;
    int v2;
    *(int*)&v0 = (unsigned int)v1;
    (unsigned short)v3 = lzcnt(17);
    return v2 - 0x64d5000b;
}

int inst_21_flags_var_0() {
    short v0;
    short v1;
    *(int*)&v0 = (unsigned int)v1;
    int v2 = lzcnt(0x60ae955e);
    return 0;
}

int inst_21_flags_var_1() {
    short v0;
    short v1;
    *(int*)&v0 = (unsigned int)v1;
    int v2 = lzcnt(0x6aea696c);
    return 0;
}

int inst_21_flags_var_2() {
    short v0;
    short v1;
    *(int*)&v0 = (unsigned int)v1;
    int v2 = lzcnt(-1235679510);
    return 0;
}

int inst_21_flags_var_3() {
    short v0;
    short v1;
    *(int*)&v0 = (unsigned int)v1;
    int v2 = lzcnt(0xcc0c6e6a);
    return 0;
}

int inst_21_flags_var_4() {
    short v0;
    short v1;
    *(int*)&v0 = (unsigned int)v1;
    int v2 = lzcnt(-1563899118);
    return 0;
}

int inst_21_flags_var_5() {
    short v0;
    short v1;
    *(int*)&v0 = (unsigned int)v1;
    int v2 = lzcnt(0x43345034);
    return 0;
}

int inst_21_flags_var_6() {
    short v0;
    short v1;
    *(int*)&v0 = (unsigned int)v1;
    int v2 = lzcnt(-1906804455);
    return 0;
}

int inst_21_flags_var_7() {
    short v0;
    short v1;
    *(int*)&v0 = (unsigned int)v1;
    int v2 = lzcnt(932408983);
    return 0;
}

int inst_21_flags_var_8() {
    short v0;
    short v1;
    *(int*)&v0 = (unsigned int)v1;
    int v2 = lzcnt(597021142);
    return 0;
}

int inst_21_flags_var_9() {
    short v0;
    short v1;
    *(int*)&v0 = (unsigned int)v1;
    int v2 = lzcnt(574898942);
    return 0;
}

int inst_21_values_var_0() {
    short v0;
    short v1;
    int result;
    *(int*)&v0 = (unsigned int)v1;
    int result = lzcnt(-819561136);
    return result;
}

int inst_21_values_var_1() {
    short v0;
    short v1;
    int v2;
    *(int*)&v0 = (unsigned int)v1;
    int v2 = lzcnt(1317749925);
    return v2 - 1;
}

int inst_21_values_var_2() {
    short v0;
    short v1;
    int v2;
    *(int*)&v0 = (unsigned int)v1;
    int v2 = lzcnt(1220872801);
    return v2 - 1;
}

int inst_21_values_var_3() {
    short v0;
    short v1;
    int v2;
    *(int*)&v0 = (unsigned int)v1;
    int v2 = lzcnt(1054475063);
    return v2 - 2;
}

int inst_21_values_var_4() {
    short v0;
    short v1;
    int v2;
    *(int*)&v0 = (unsigned int)v1;
    int v2 = lzcnt(1459610);
    return v2 - 11;
}

int inst_21_values_var_5() {
    short v0;
    short v1;
    int v2;
    *(int*)&v0 = (unsigned int)v1;
    int v2 = lzcnt(0xb03bb59);
    return v2 - 4;
}

int inst_21_values_var_6() {
    short v0;
    short v1;
    int result;
    *(int*)&v0 = (unsigned int)v1;
    int result = lzcnt(-378679385);
    return result;
}

int inst_21_values_var_7() {
    short v0;
    short v1;
    int v2;
    *(int*)&v0 = (unsigned int)v1;
    int v2 = lzcnt(31108367);
    return v2 - 7;
}

int inst_21_values_var_8() {
    short v0;
    short v1;
    int result;
    *(int*)&v0 = (unsigned int)v1;
    int result = lzcnt(0x8f92b9db);
    return result;
}

int inst_21_values_var_9() {
    short v0;
    short v1;
    int result;
    *(int*)&v0 = (unsigned int)v1;
    int result = lzcnt(0xe1d0d1b2);
    return result;
}

int inst_2_flags_var_0() {
    short v0;
    char v1;
    char v2;
    short v3;
    char v4;
    *(int*)&v0 = (unsigned int)v3;
    int v5 = andn(1957773953, 0xc9b8aec9);
    return (unsigned int)((v4 ? 1: 0) + (v1 ? 8: 0) + (v2 ? 2: 0)) - 8;
}

int inst_2_flags_var_1() {
    short v0;
    char v1;
    char v2;
    short v3;
    char v4;
    *(int*)&v0 = (unsigned int)v3;
    int v5 = andn(0x728c5a27, -2061246885);
    return (unsigned int)((v4 ? 1: 0) + (v1 ? 8: 0) + (v2 ? 2: 0)) - 8;
}

unsigned int inst_2_flags_var_2() {
    short v0;
    char v1;
    char v2;
    short v3;
    char v4;
    *(int*)&v0 = (unsigned int)v3;
    int v5 = andn(1888093876, 0x753dee3d);
    return (unsigned int)((v4 ? 1: 0) + (v1 ? 8: 0) + (v2 ? 2: 0));
}

int inst_2_flags_var_3() {
    short v0;
    char v1;
    char v2;
    short v3;
    char v4;
    *(int*)&v0 = (unsigned int)v3;
    int v5 = andn(38342744, 0xfb1a6a8c);
    return (unsigned int)((v4 ? 1: 0) + (v1 ? 8: 0) + (v2 ? 2: 0)) - 8;
}

unsigned int inst_2_flags_var_4() {
    short v0;
    char v1;
    char v2;
    short v3;
    char v4;
    *(int*)&v0 = (unsigned int)v3;
    int v5 = andn(-1400289966, 0xf73a870a);
    return (unsigned int)((v4 ? 1: 0) + (v1 ? 8: 0) + (v2 ? 2: 0));
}

unsigned int inst_2_flags_var_5() {
    short v0;
    char v1;
    char v2;
    short v3;
    char v4;
    *(int*)&v0 = (unsigned int)v3;
    int v5 = andn(1055136761, 890473597);
    return (unsigned int)((v4 ? 1: 0) + (v1 ? 8: 0) + (v2 ? 2: 0));
}

unsigned int inst_2_flags_var_6() {
    short v0;
    char v1;
    char v2;
    short v3;
    char v4;
    *(int*)&v0 = (unsigned int)v3;
    int v5 = andn(0x89a048ce, 0x89a048ce);
    return (unsigned int)((v4 ? 1: 0) + (v1 ? 8: 0) + (v2 ? 2: 0));
}

unsigned int inst_2_flags_var_7() {
    short v0;
    char v1;
    char v2;
    short v3;
    char v4;
    *(int*)&v0 = (unsigned int)v3;
    int v5 = andn(2072682762, 0x39d4d5df);
    return (unsigned int)((v4 ? 1: 0) + (v1 ? 8: 0) + (v2 ? 2: 0));
}

unsigned int inst_2_flags_var_8() {
    short v0;
    char v1;
    char v2;
    short v3;
    char v4;
    *(int*)&v0 = (unsigned int)v3;
    int v5 = andn(0xbae5c3b0, 0xbae5c3b0);
    return (unsigned int)((v4 ? 1: 0) + (v1 ? 8: 0) + (v2 ? 2: 0));
}

unsigned int inst_2_flags_var_9() {
    short v0;
    char v1;
    char v2;
    short v3;
    char v4;
    *(int*)&v0 = (unsigned int)v3;
    int v5 = andn(-527215740, -1979033810);
    return (unsigned int)((v4 ? 1: 0) + (v1 ? 8: 0) + (v2 ? 2: 0));
}

int inst_2_values_var_0() {
    short v0;
    short v1;
    int v2;
    *(int*)&v0 = (unsigned int)v1;
    int v2 = andn(550458188, -981264286);
    return v2 + 989853662;
}

int inst_2_values_var_1() {
    short v0;
    short v1;
    int v2;
    *(int*)&v0 = (unsigned int)v1;
    int v2 = andn(1654292738, -446428540);
    return v2 + 2057041276;
}

int inst_2_values_var_2() {
    short v0;
    short v1;
    int v2;
    *(int*)&v0 = (unsigned int)v1;
    int v2 = andn(2095340402, -882186658);
    return v2 + 2096454644;
}

int inst_2_values_var_3() {
    short v0;
    short v1;
    int v2;
    *(int*)&v0 = (unsigned int)v1;
    int v2 = andn(-1410940787, 196028928);
    return v2 - 600576;
}

int inst_2_values_var_4() {
    short v0;
    short v1;
    int v2;
    *(int*)&v0 = (unsigned int)v1;
    int v2 = andn(-686918801, -418155764);
    return v2 - 0x20110000;
}

int inst_2_values_var_5() {
    short v0;
    short v1;
    int v2;
    *(int*)&v0 = (unsigned int)v1;
    int v2 = andn(-1772323385, 0x2f263386);
    return v2 - 0x29220200;
}

int inst_2_values_var_6() {
    short v0;
    short v1;
    int result;
    *(int*)&v0 = (unsigned int)v1;
    int result = andn(0x47ad41aa, 0x47ad41aa);
    return result;
}

int inst_2_values_var_7() {
    short v0;
    short v1;
    int v2;
    *(int*)&v0 = (unsigned int)v1;
    int v2 = andn(0x6c346cac, 1584991345);
    return v2 - 306774097;
}

int inst_2_values_var_8() {
    short v0;
    short v1;
    int result;
    *(int*)&v0 = (unsigned int)v1;
    int result = andn(150196169, 150196169);
    return result;
}

int inst_2_values_var_9() {
    short v0;
    short v1;
    int v2;
    *(int*)&v0 = (unsigned int)v1;
    int v2 = andn(753309782, -454979743);
    return v2 + 0x3ffef8df;
}

int inst_3_flags_var_0() {
    short v0;
    char v1;
    char v2;
    short v3;
    char v4;
    *(int*)&v0 = (unsigned int)v3;
    int v5 = blsi(1030955591);
    return (unsigned int)((v4 ? 1: 0) + (v1 ? 8: 0) + (v2 ? 2: 0)) - 1;
}

int inst_3_flags_var_1() {
    short v0;
    char v1;
    char v2;
    short v3;
    char v4;
    *(int*)&v0 = (unsigned int)v3;
    int v5 = blsi(0xd0171c9d);
    return (unsigned int)((v4 ? 1: 0) + (v1 ? 8: 0) + (v2 ? 2: 0)) - 1;
}

int inst_3_flags_var_2() {
    short v0;
    char v1;
    char v2;
    short v3;
    char v4;
    *(int*)&v0 = (unsigned int)v3;
    int v5 = blsi(0xed5eabbe);
    return (unsigned int)((v4 ? 1: 0) + (v1 ? 8: 0) + (v2 ? 2: 0)) - 1;
}

int inst_3_flags_var_3() {
    short v0;
    char v1;
    char v2;
    short v3;
    char v4;
    *(int*)&v0 = (unsigned int)v3;
    int v5 = blsi(0xc73202bd);
    return (unsigned int)((v4 ? 1: 0) + (v1 ? 8: 0) + (v2 ? 2: 0)) - 1;
}

int inst_3_flags_var_4() {
    short v0;
    char v1;
    char v2;
    short v3;
    char v4;
    *(int*)&v0 = (unsigned int)v3;
    int v5 = blsi(-1320743554);
    return (unsigned int)((v4 ? 1: 0) + (v1 ? 8: 0) + (v2 ? 2: 0)) - 1;
}

int inst_3_flags_var_5() {
    short v0;
    char v1;
    char v2;
    short v3;
    char v4;
    *(int*)&v0 = (unsigned int)v3;
    int v5 = blsi(-759588923);
    return (unsigned int)((v4 ? 1: 0) + (v1 ? 8: 0) + (v2 ? 2: 0)) - 1;
}

int inst_3_flags_var_6() {
    short v0;
    char v1;
    char v2;
    short v3;
    char v4;
    *(int*)&v0 = (unsigned int)v3;
    int v5 = blsi(1946590059);
    return (unsigned int)((v4 ? 1: 0) + (v1 ? 8: 0) + (v2 ? 2: 0)) - 1;
}

int inst_3_flags_var_7() {
    short v0;
    char v1;
    char v2;
    short v3;
    char v4;
    *(int*)&v0 = (unsigned int)v3;
    int v5 = blsi(0x4ad06141);
    return (unsigned int)((v4 ? 1: 0) + (v1 ? 8: 0) + (v2 ? 2: 0)) - 1;
}

int inst_3_flags_var_8() {
    short v0;
    char v1;
    char v2;
    short v3;
    char v4;
    *(int*)&v0 = (unsigned int)v3;
    int v5 = blsi(-139714925);
    return (unsigned int)((v4 ? 1: 0) + (v1 ? 8: 0) + (v2 ? 2: 0)) - 1;
}

int inst_3_flags_var_9() {
    short v0;
    char v1;
    char v2;
    short v3;
    char v4;
    *(int*)&v0 = (unsigned int)v3;
    int v5 = blsi(-598015001);
    return (unsigned int)((v4 ? 1: 0) + (v1 ? 8: 0) + (v2 ? 2: 0)) - 1;
}

int inst_3_values_var_0() {
    short v0;
    short v1;
    int v2;
    *(int*)&v0 = (unsigned int)v1;
    int v2 = blsi(437004800);
    return v2 - 0x200;
}

int inst_3_values_var_1() {
    short v0;
    short v1;
    int v2;
    *(int*)&v0 = (unsigned int)v1;
    int v2 = blsi(1343054428);
    return v2 - 4;
}

int inst_3_values_var_2() {
    short v0;
    short v1;
    int v2;
    *(int*)&v0 = (unsigned int)v1;
    int v2 = blsi(538392238);
    return v2 - 2;
}

int inst_3_values_var_3() {
    short v0;
    short v1;
    int v2;
    *(int*)&v0 = (unsigned int)v1;
    int v2 = blsi(902325075);
    return v2 - 1;
}

int inst_3_values_var_4() {
    short v0;
    short v1;
    int v2;
    *(int*)&v0 = (unsigned int)v1;
    int v2 = blsi(0xc7cccb6c);
    return v2 - 4;
}

int inst_3_values_var_5() {
    short v0;
    short v1;
    int v2;
    *(int*)&v0 = (unsigned int)v1;
    int v2 = blsi(-270889596);
    return v2 - 4;
}

int inst_3_values_var_6() {
    short v0;
    short v1;
    int v2;
    *(int*)&v0 = (unsigned int)v1;
    int v2 = blsi(1060169882);
    return v2 - 2;
}

int inst_3_values_var_7() {
    short v0;
    short v1;
    int v2;
    *(int*)&v0 = (unsigned int)v1;
    int v2 = blsi(1059176992);
    return v2 - 32;
}

int inst_3_values_var_8() {
    short v0;
    short v1;
    int v2;
    *(int*)&v0 = (unsigned int)v1;
    int v2 = blsi(1238122988);
    return v2 - 4;
}

int inst_3_values_var_9() {
    short v0;
    short v1;
    int v2;
    *(int*)&v0 = (unsigned int)v1;
    int v2 = blsi(980152434);
    return v2 - 2;
}

unsigned int inst_4_flags_var_0() {
    short v0;
    char v1;
    char v2;
    short v3;
    char v4;
    *(int*)&v0 = (unsigned int)v3;
    int v5 = blsmsk(1842357483);
    return (unsigned int)((v4 ? 1: 0) + (v1 ? 8: 0) + (v2 ? 2: 0));
}

unsigned int inst_4_flags_var_1() {
    short v0;
    char v1;
    char v2;
    short v3;
    char v4;
    *(int*)&v0 = (unsigned int)v3;
    int v5 = blsmsk(-1873216468);
    return (unsigned int)((v4 ? 1: 0) + (v1 ? 8: 0) + (v2 ? 2: 0));
}

unsigned int inst_4_flags_var_2() {
    short v0;
    char v1;
    char v2;
    short v3;
    char v4;
    *(int*)&v0 = (unsigned int)v3;
    int v5 = blsmsk(0x904454af);
    return (unsigned int)((v4 ? 1: 0) + (v1 ? 8: 0) + (v2 ? 2: 0));
}

unsigned int inst_4_flags_var_3() {
    short v0;
    char v1;
    char v2;
    short v3;
    char v4;
    *(int*)&v0 = (unsigned int)v3;
    int v5 = blsmsk(-1687383045);
    return (unsigned int)((v4 ? 1: 0) + (v1 ? 8: 0) + (v2 ? 2: 0));
}

unsigned int inst_4_flags_var_4() {
    short v0;
    char v1;
    char v2;
    short v3;
    char v4;
    *(int*)&v0 = (unsigned int)v3;
    int v5 = blsmsk(0xa1e71756);
    return (unsigned int)((v4 ? 1: 0) + (v1 ? 8: 0) + (v2 ? 2: 0));
}

unsigned int inst_4_flags_var_5() {
    short v0;
    char v1;
    char v2;
    short v3;
    char v4;
    *(int*)&v0 = (unsigned int)v3;
    int v5 = blsmsk(0xe9b4eef5);
    return (unsigned int)((v4 ? 1: 0) + (v1 ? 8: 0) + (v2 ? 2: 0));
}

unsigned int inst_4_flags_var_6() {
    short v0;
    char v1;
    char v2;
    short v3;
    char v4;
    *(int*)&v0 = (unsigned int)v3;
    int v5 = blsmsk(-850692468);
    return (unsigned int)((v4 ? 1: 0) + (v1 ? 8: 0) + (v2 ? 2: 0));
}

unsigned int inst_4_flags_var_7() {
    short v0;
    char v1;
    char v2;
    short v3;
    char v4;
    *(int*)&v0 = (unsigned int)v3;
    int v5 = blsmsk(-1612268640);
    return (unsigned int)((v4 ? 1: 0) + (v1 ? 8: 0) + (v2 ? 2: 0));
}

unsigned int inst_4_flags_var_8() {
    short v0;
    char v1;
    char v2;
    short v3;
    char v4;
    *(int*)&v0 = (unsigned int)v3;
    int v5 = blsmsk(0xf9aa2c46);
    return (unsigned int)((v4 ? 1: 0) + (v1 ? 8: 0) + (v2 ? 2: 0));
}

unsigned int inst_4_flags_var_9() {
    short v0;
    char v1;
    char v2;
    short v3;
    char v4;
    *(int*)&v0 = (unsigned int)v3;
    int v5 = blsmsk(0xb046a6ec);
    return (unsigned int)((v4 ? 1: 0) + (v1 ? 8: 0) + (v2 ? 2: 0));
}

int inst_4_values_var_0() {
    short v0;
    short v1;
    int v2;
    *(int*)&v0 = (unsigned int)v1;
    int v2 = blsmsk(2120809704);
    return v2 - 15;
}

int inst_4_values_var_1() {
    short v0;
    short v1;
    int v2;
    *(int*)&v0 = (unsigned int)v1;
    int v2 = blsmsk(-332639464);
    return v2 - 15;
}

int inst_4_values_var_2() {
    short v0;
    short v1;
    int v2;
    *(int*)&v0 = (unsigned int)v1;
    int v2 = blsmsk(808388595);
    return v2 - 1;
}

int inst_4_values_var_3() {
    short v0;
    short v1;
    int v2;
    *(int*)&v0 = (unsigned int)v1;
    int v2 = blsmsk(703910125);
    return v2 - 1;
}

int inst_4_values_var_4() {
    short v0;
    short v1;
    int v2;
    *(int*)&v0 = (unsigned int)v1;
    int v2 = blsmsk(-1956667713);
    return v2 - 1;
}

int inst_4_values_var_5() {
    short v0;
    short v1;
    int v2;
    *(int*)&v0 = (unsigned int)v1;
    int v2 = blsmsk(1944871480);
    return v2 - 15;
}

int inst_4_values_var_6() {
    short v0;
    short v1;
    int v2;
    *(int*)&v0 = (unsigned int)v1;
    int v2 = blsmsk(1258183423);
    return v2 - 1;
}

int inst_4_values_var_7() {
    short v0;
    short v1;
    int v2;
    *(int*)&v0 = (unsigned int)v1;
    int v2 = blsmsk(1126924656);
    return v2 - 31;
}

int inst_4_values_var_8() {
    short v0;
    short v1;
    int v2;
    *(int*)&v0 = (unsigned int)v1;
    int v2 = blsmsk(0xfdadb739);
    return v2 - 1;
}

int inst_4_values_var_9() {
    short v0;
    short v1;
    int v2;
    *(int*)&v0 = (unsigned int)v1;
    int v2 = blsmsk(43247894);
    return v2 - 3;
}

unsigned int inst_5_flags_var_0() {
    short v0;
    char v1;
    char v2;
    short v3;
    char v4;
    *(int*)&v0 = (unsigned int)v3;
    int v5 = blsr(255914869);
    return (unsigned int)((v4 ? 1: 0) + (v1 ? 8: 0) + (v2 ? 2: 0));
}

int inst_5_flags_var_1() {
    short v0;
    char v1;
    char v2;
    short v3;
    char v4;
    *(int*)&v0 = (unsigned int)v3;
    int v5 = blsr(0xcadc2224);
    return (unsigned int)((v4 ? 1: 0) + (v1 ? 8: 0) + (v2 ? 2: 0)) - 8;
}

unsigned int inst_5_flags_var_2() {
    short v0;
    char v1;
    char v2;
    short v3;
    char v4;
    *(int*)&v0 = (unsigned int)v3;
    int v5 = blsr(1673750686);
    return (unsigned int)((v4 ? 1: 0) + (v1 ? 8: 0) + (v2 ? 2: 0));
}

unsigned int inst_5_flags_var_3() {
    short v0;
    char v1;
    char v2;
    short v3;
    char v4;
    *(int*)&v0 = (unsigned int)v3;
    int v5 = blsr(1041849970);
    return (unsigned int)((v4 ? 1: 0) + (v1 ? 8: 0) + (v2 ? 2: 0));
}

unsigned int inst_5_flags_var_4() {
    short v0;
    char v1;
    char v2;
    short v3;
    char v4;
    *(int*)&v0 = (unsigned int)v3;
    int v5 = blsr(939280587);
    return (unsigned int)((v4 ? 1: 0) + (v1 ? 8: 0) + (v2 ? 2: 0));
}

unsigned int inst_5_flags_var_5() {
    short v0;
    char v1;
    char v2;
    short v3;
    char v4;
    *(int*)&v0 = (unsigned int)v3;
    int v5 = blsr(762362608);
    return (unsigned int)((v4 ? 1: 0) + (v1 ? 8: 0) + (v2 ? 2: 0));
}

int inst_5_flags_var_6() {
    short v0;
    char v1;
    char v2;
    short v3;
    char v4;
    *(int*)&v0 = (unsigned int)v3;
    int v5 = blsr(-244542924);
    return (unsigned int)((v4 ? 1: 0) + (v1 ? 8: 0) + (v2 ? 2: 0)) - 8;
}

unsigned int inst_5_flags_var_7() {
    short v0;
    char v1;
    char v2;
    short v3;
    char v4;
    *(int*)&v0 = (unsigned int)v3;
    int v5 = blsr(805505110);
    return (unsigned int)((v4 ? 1: 0) + (v1 ? 8: 0) + (v2 ? 2: 0));
}

int inst_5_flags_var_8() {
    short v0;
    char v1;
    char v2;
    short v3;
    char v4;
    *(int*)&v0 = (unsigned int)v3;
    int v5 = blsr(-1662388319);
    return (unsigned int)((v4 ? 1: 0) + (v1 ? 8: 0) + (v2 ? 2: 0)) - 8;
}

unsigned int inst_5_flags_var_9() {
    short v0;
    char v1;
    char v2;
    short v3;
    char v4;
    *(int*)&v0 = (unsigned int)v3;
    int v5 = blsr(0x66805080);
    return (unsigned int)((v4 ? 1: 0) + (v1 ? 8: 0) + (v2 ? 2: 0));
}

int inst_5_values_var_0() {
    short v0;
    short v1;
    int v2;
    *(int*)&v0 = (unsigned int)v1;
    int v2 = blsr(1750657869);
    return v2 - 1750657868;
}

int inst_5_values_var_1() {
    short v0;
    short v1;
    int v2;
    *(int*)&v0 = (unsigned int)v1;
    int v2 = blsr(-674067516);
    return v2 + 674067520;
}

int inst_5_values_var_2() {
    short v0;
    short v1;
    int v2;
    *(int*)&v0 = (unsigned int)v1;
    int v2 = blsr(1636353023);
    return v2 - 1636353022;
}

int inst_5_values_var_3() {
    short v0;
    short v1;
    int v2;
    *(int*)&v0 = (unsigned int)v1;
    int v2 = blsr(1996579571);
    return v2 - 1996579570;
}

int inst_5_values_var_4() {
    short v0;
    short v1;
    int v2;
    *(int*)&v0 = (unsigned int)v1;
    int v2 = blsr(-1939492126);
    return v2 + 1939492128;
}

int inst_5_values_var_5() {
    short v0;
    short v1;
    int v2;
    *(int*)&v0 = (unsigned int)v1;
    int v2 = blsr(0x15bdd91b);
    return v2 - 364763418;
}

int inst_5_values_var_6() {
    short v0;
    short v1;
    int v2;
    *(int*)&v0 = (unsigned int)v1;
    int v2 = blsr(2032375192);
    return v2 - 2032375184;
}

int inst_5_values_var_7() {
    short v0;
    short v1;
    int v2;
    *(int*)&v0 = (unsigned int)v1;
    int v2 = blsr(1530790769);
    return v2 - 0x5b3e0370;
}

int inst_5_values_var_8() {
    short v0;
    short v1;
    int v2;
    *(int*)&v0 = (unsigned int)v1;
    int v2 = blsr(1803027153);
    return v2 - 1803027152;
}

int inst_5_values_var_9() {
    short v0;
    short v1;
    int v2;
    *(int*)&v0 = (unsigned int)v1;
    int v2 = blsr(-1321307520);
    return v2 + 1321307648;
}

unsigned int inst_6_flags_var_0() {
    short v0;
    char v1;
    short v2;
    char v3;
    *(int*)&v0 = (unsigned int)v2;
    int v4 = bextr(-1179826322, 694167435);
    return (unsigned int)((v3 ? 1: 0) + (v1 ? 2: 0));
}

unsigned int inst_6_flags_var_1() {
    short v0;
    char v1;
    short v2;
    char v3;
    *(int*)&v0 = (unsigned int)v2;
    int v4 = bextr(2004323, -1326351268);
    return (unsigned int)((v3 ? 1: 0) + (v1 ? 2: 0));
}

unsigned int inst_6_flags_var_2() {
    short v0;
    char v1;
    short v2;
    char v3;
    *(int*)&v0 = (unsigned int)v2;
    int v4 = bextr(0x988055ee, 1319547959);
    return (unsigned int)((v3 ? 1: 0) + (v1 ? 2: 0));
}

unsigned int inst_6_flags_var_3() {
    short v0;
    char v1;
    short v2;
    char v3;
    *(int*)&v0 = (unsigned int)v2;
    int v4 = bextr(0x668bdb1d, 67001664);
    return (unsigned int)((v3 ? 1: 0) + (v1 ? 2: 0));
}

unsigned int inst_6_flags_var_4() {
    short v0;
    char v1;
    short v2;
    char v3;
    *(int*)&v0 = (unsigned int)v2;
    int v4 = bextr(426724222, -1514787596);
    return (unsigned int)((v3 ? 1: 0) + (v1 ? 2: 0));
}

unsigned int inst_6_flags_var_5() {
    short v0;
    char v1;
    short v2;
    char v3;
    *(int*)&v0 = (unsigned int)v2;
    int v4 = bextr(-1260280127, 594102226);
    return (unsigned int)((v3 ? 1: 0) + (v1 ? 2: 0));
}

unsigned int inst_6_flags_var_6() {
    short v0;
    char v1;
    short v2;
    char v3;
    *(int*)&v0 = (unsigned int)v2;
    int v4 = bextr(-48770598, 0x9ab49b3a);
    return (unsigned int)((v3 ? 1: 0) + (v1 ? 2: 0));
}

unsigned int inst_6_flags_var_7() {
    short v0;
    char v1;
    short v2;
    char v3;
    *(int*)&v0 = (unsigned int)v2;
    int v4 = bextr(981086859, 981086859);
    return (unsigned int)((v3 ? 1: 0) + (v1 ? 2: 0));
}

unsigned int inst_6_flags_var_8() {
    short v0;
    char v1;
    short v2;
    char v3;
    *(int*)&v0 = (unsigned int)v2;
    int v4 = bextr(2138912933, 2099985620);
    return (unsigned int)((v3 ? 1: 0) + (v1 ? 2: 0));
}

unsigned int inst_6_flags_var_9() {
    short v0;
    char v1;
    short v2;
    char v3;
    *(int*)&v0 = (unsigned int)v2;
    int v4 = bextr(-480391534, -1384511415);
    return (unsigned int)((v3 ? 1: 0) + (v1 ? 2: 0));
}

int inst_6_values_var_0() {
    short v0;
    short v1;
    int result;
    *(int*)&v0 = (unsigned int)v1;
    int result = bextr(0x7770aa9e, 1895744606);
    return result;
}

int inst_6_values_var_1() {
    short v0;
    short v1;
    int result;
    *(int*)&v0 = (unsigned int)v1;
    int result = bextr(-1016296040, 564878787);
    return result;
}

int inst_6_values_var_2() {
    short v0;
    short v1;
    int result;
    *(int*)&v0 = (unsigned int)v1;
    int result = bextr(-1296678331, 1459284418);
    return result;
}

int inst_6_values_var_3() {
    short v0;
    short v1;
    int result;
    *(int*)&v0 = (unsigned int)v1;
    int result = bextr(934522178, 0x7c680447);
    return result;
}

int inst_6_values_var_4() {
    short v0;
    short v1;
    int result;
    *(int*)&v0 = (unsigned int)v1;
    int result = bextr(-242389190, 1946386659);
    return result;
}

int inst_6_values_var_5() {
    short v0;
    short v1;
    int v2;
    *(int*)&v0 = (unsigned int)v1;
    int v2 = bextr(0x7d697bcd, 0x282dc11d);
    return v2 - 3;
}

int inst_6_values_var_6() {
    short v0;
    short v1;
    int result;
    *(int*)&v0 = (unsigned int)v1;
    int result = bextr(-2017462060, 0xdd85f664);
    return result;
}

int inst_6_values_var_7() {
    short v0;
    short v1;
    int result;
    *(int*)&v0 = (unsigned int)v1;
    int result = bextr(1185662917, 1438030035);
    return result;
}

int inst_6_values_var_8() {
    short v0;
    short v1;
    int result;
    *(int*)&v0 = (unsigned int)v1;
    int result = bextr(-2000581400, 0x9c956587);
    return result;
}

int inst_6_values_var_9() {
    short v0;
    short v1;
    int result;
    *(int*)&v0 = (unsigned int)v1;
    int result = bextr(330312352, 330312352);
    return result;
}

int inst_7_flags_var_0() {
    short v0;
    char v1;
    char v2;
    short v3;
    char v4;
    *(int*)&v0 = (unsigned int)v3;
    int v5 = bzhi(-1085148093, -1085148093);
    return (unsigned int)((v4 ? 1: 0) + (v1 ? 8: 0) + (v2 ? 2: 0)) - 9;
}

int inst_7_flags_var_1() {
    short v0;
    char v1;
    char v2;
    short v3;
    char v4;
    *(int*)&v0 = (unsigned int)v3;
    int v5 = bzhi(-812203667, 0x9454f9ce);
    return (unsigned int)((v4 ? 1: 0) + (v1 ? 8: 0) + (v2 ? 2: 0)) - 9;
}

int inst_7_flags_var_2() {
    short v0;
    char v1;
    char v2;
    short v3;
    char v4;
    *(int*)&v0 = (unsigned int)v3;
    int v5 = bzhi(-1174035201, 1100954588);
    return (unsigned int)((v4 ? 1: 0) + (v1 ? 8: 0) + (v2 ? 2: 0)) - 9;
}

int inst_7_flags_var_3() {
    short v0;
    char v1;
    char v2;
    short v3;
    char v4;
    *(int*)&v0 = (unsigned int)v3;
    int v5 = bzhi(718085948, 372113305);
    return (unsigned int)((v4 ? 1: 0) + (v1 ? 8: 0) + (v2 ? 2: 0)) - 1;
}

int inst_7_flags_var_4() {
    short v0;
    char v1;
    char v2;
    short v3;
    char v4;
    *(int*)&v0 = (unsigned int)v3;
    int v5 = bzhi(0xf2a2d6d3, -818907063);
    return (unsigned int)((v4 ? 1: 0) + (v1 ? 8: 0) + (v2 ? 2: 0)) - 9;
}

int inst_7_flags_var_5() {
    short v0;
    char v1;
    char v2;
    short v3;
    char v4;
    *(int*)&v0 = (unsigned int)v3;
    int v5 = bzhi(282726464, -822143668);
    return (unsigned int)((v4 ? 1: 0) + (v1 ? 8: 0) + (v2 ? 2: 0)) - 1;
}

int inst_7_flags_var_6() {
    short v0;
    char v1;
    char v2;
    short v3;
    char v4;
    *(int*)&v0 = (unsigned int)v3;
    int v5 = bzhi(0x123c80fd, 1302601816);
    return (unsigned int)((v4 ? 1: 0) + (v1 ? 8: 0) + (v2 ? 2: 0)) - 1;
}

int inst_7_flags_var_7() {
    short v0;
    char v1;
    char v2;
    short v3;
    char v4;
    *(int*)&v0 = (unsigned int)v3;
    int v5 = bzhi(-2108002392, 0x85b5db6e);
    return (unsigned int)((v4 ? 1: 0) + (v1 ? 8: 0) + (v2 ? 2: 0)) - 9;
}

int inst_7_flags_var_8() {
    short v0;
    char v1;
    char v2;
    short v3;
    char v4;
    *(int*)&v0 = (unsigned int)v3;
    int v5 = bzhi(0x9aa754cf, 529022561);
    return (unsigned int)((v4 ? 1: 0) + (v1 ? 8: 0) + (v2 ? 2: 0)) - 9;
}

int inst_7_flags_var_9() {
    short v0;
    char v1;
    char v2;
    short v3;
    char v4;
    *(int*)&v0 = (unsigned int)v3;
    int v5 = bzhi(-1231270776, 564005748);
    return (unsigned int)((v4 ? 1: 0) + (v1 ? 8: 0) + (v2 ? 2: 0)) - 9;
}

int inst_7_values_var_0() {
    short v0;
    short v1;
    int v2;
    *(int*)&v0 = (unsigned int)v1;
    int v2 = bzhi(79388349, 79388349);
    return v2 - 79388349;
}

int inst_7_values_var_1() {
    short v0;
    short v1;
    int v2;
    *(int*)&v0 = (unsigned int)v1;
    int v2 = bzhi(1359105087, -967814665);
    return v2 - 1359105087;
}

int inst_7_values_var_2() {
    short v0;
    short v1;
    int v2;
    *(int*)&v0 = (unsigned int)v1;
    int v2 = bzhi(0xf8f04766, -1161608887);
    return v2 + 0x70fb89a;
}

int inst_7_values_var_3() {
    short v0;
    short v1;
    int v2;
    *(int*)&v0 = (unsigned int)v1;
    int v2 = bzhi(-1026125770, -526142712);
    return v2 - 54;
}

int inst_7_values_var_4() {
    short v0;
    short v1;
    int v2;
    *(int*)&v0 = (unsigned int)v1;
    int v2 = bzhi(-1173334250, 0xb24ffed8);
    return v2 + 1173334250;
}

int inst_7_values_var_5() {
    short v0;
    short v1;
    int v2;
    *(int*)&v0 = (unsigned int)v1;
    int v2 = bzhi(1362578725, 1189559589);
    return v2 - 1362578725;
}

int inst_7_values_var_6() {
    short v0;
    short v1;
    int v2;
    *(int*)&v0 = (unsigned int)v1;
    int v2 = bzhi(0xdf6198f2, 0xa44aadc1);
    return v2 + 0x209e670e;
}

int inst_7_values_var_7() {
    short v0;
    short v1;
    int v2;
    *(int*)&v0 = (unsigned int)v1;
    int v2 = bzhi(-2111262161, -428628468);
    return v2 - 0x22f;
}

int inst_7_values_var_8() {
    short v0;
    short v1;
    int v2;
    *(int*)&v0 = (unsigned int)v1;
    int v2 = bzhi(-1715693770, 385455751);
    return v2 + 1715693770;
}

int inst_7_values_var_9() {
    short v0;
    short v1;
    int v2;
    *(int*)&v0 = (unsigned int)v1;
    int v2 = bzhi(-777809247, 1759999273);
    return v2 + 777809247;
}

int inst_8_flags_var_0() {
    short v0;
    short v1;
    *(int*)&v0 = (unsigned int)v1;
    (int v2, int v3) = mulx(-53022491, -53022491);
    return 0;
}

int inst_8_flags_var_1() {
    short v0;
    short v1;
    *(int*)&v0 = (unsigned int)v1;
    (int v2, int v3) = mulx(1098341879, 1174986949);
    return 0;
}

int inst_8_flags_var_2() {
    short v0;
    short v1;
    *(int*)&v0 = (unsigned int)v1;
    (int v2, int v3) = mulx(1933729674, -1514803999);
    return 0;
}

int inst_8_flags_var_3() {
    short v0;
    short v1;
    *(int*)&v0 = (unsigned int)v1;
    (int v2, int v3) = mulx(1588786028, 613713979);
    return 0;
}

int inst_8_flags_var_4() {
    short v0;
    short v1;
    *(int*)&v0 = (unsigned int)v1;
    (int v2, int v3) = mulx(0xa32212c6, 0xe13b83e2);
    return 0;
}

int inst_8_flags_var_5() {
    short v0;
    short v1;
    *(int*)&v0 = (unsigned int)v1;
    (int v2, int v3) = mulx(821530981, -384360573);
    return 0;
}

int inst_8_flags_var_6() {
    short v0;
    short v1;
    *(int*)&v0 = (unsigned int)v1;
    (int v2, int v3) = mulx(-1976861742, 0x5863abca);
    return 0;
}

int inst_8_flags_var_7() {
    short v0;
    short v1;
    *(int*)&v0 = (unsigned int)v1;
    (int v2, v2) = mulx(0x89998dd2, 610139512);
    return 0;
}

int inst_8_flags_var_8() {
    short v0;
    short v1;
    *(int*)&v0 = (unsigned int)v1;
    (int v2, int v3) = mulx(1437352552, 1614996729);
    return 0;
}

int inst_8_flags_var_9() {
    short v0;
    short v1;
    *(int*)&v0 = (unsigned int)v1;
    (int v2, int v3) = mulx(1101146658, -155275512);
    return 0;
}

int inst_8_values_var_0() {
    short v0;
    short v1;
    int v2;
    int v3;
    *(int*)&v0 = (unsigned int)v1;
    (int v3, int v2) = mulx(15805272, 1570114582);
    return v3 + v2 + 1062599767;
}

int inst_8_values_var_1() {
    short v0;
    short v1;
    int v2;
    int v3;
    *(int*)&v0 = (unsigned int)v1;
    (int v2, int v3) = mulx(0xfad801fb, 0xe6bcc822);
    return v2 + v3 + 358127655;
}

int inst_8_values_var_2() {
    short v0;
    short v1;
    int v2;
    int v3;
    *(int*)&v0 = (unsigned int)v1;
    (int v2, int v3) = mulx(1226395098, 1226395098);
    return v2 + v3 + 1256173942;
}

int inst_8_values_var_3() {
    short v0;
    short v1;
    int v2;
    int v3;
    *(int*)&v0 = (unsigned int)v1;
    (int v2, int v3) = mulx(1612234661, 0xd1fc2779);
    return v3 + v2 + 618425440;
}

int inst_8_values_var_4() {
    short v0;
    short v1;
    int v2;
    int v3;
    *(int*)&v0 = (unsigned int)v1;
    (int v2, int v3) = mulx(1087955994, 2085392102);
    return v2 + v3 - 9948782;
}

int inst_8_values_var_5() {
    short v0;
    short v1;
    int v2;
    *(int*)&v0 = (unsigned int)v1;
    (int v2, v2) = mulx(1764233000, 1764233000);
    return v2 - 0x2b31e2b3;
}

int inst_8_values_var_6() {
    short v0;
    short v1;
    int v2;
    int v3;
    *(int*)&v0 = (unsigned int)v1;
    (int v2, int v3) = mulx(-2053839315, 153469715);
    return v2 + v3 - 866667710;
}

int inst_8_values_var_7() {
    short v0;
    short v1;
    int v2;
    *(int*)&v0 = (unsigned int)v1;
    (int v2, v2) = mulx(-1891800769, 1225906289);
    return v2 - 685932337;
}

int inst_8_values_var_8() {
    short v0;
    short v1;
    int v2;
    int v3;
    *(int*)&v0 = (unsigned int)v1;
    (int v3, int v2) = mulx(0x76454be5, 0x72344d4e);
    return v3 + v2 - 2050491996;
}

int inst_8_values_var_9() {
    short v0;
    short v1;
    int v2;
    int v3;
    *(int*)&v0 = (unsigned int)v1;
    (int v2, int v3) = mulx(1981759782, 0x2bdb15a);
    return v2 + v3 + 1990593850;
}

int inst_9_flags_var_0() {
    short v0;
    short v1;
    *(int*)&v0 = (unsigned int)v1;
    int v2 = pdep(-1491517954, -1491517954);
    return 0;
}

int inst_9_flags_var_1() {
    short v0;
    short v1;
    *(int*)&v0 = (unsigned int)v1;
    int v2 = pdep(1351319167, -873885173);
    return 0;
}

int inst_9_flags_var_2() {
    short v0;
    short v1;
    *(int*)&v0 = (unsigned int)v1;
    int v2 = pdep(1523624175, -694885199);
    return 0;
}

int inst_9_flags_var_3() {
    short v0;
    short v1;
    *(int*)&v0 = (unsigned int)v1;
    int v2 = pdep(-1312818616, -1312818616);
    return 0;
}

int inst_9_flags_var_4() {
    short v0;
    short v1;
    *(int*)&v0 = (unsigned int)v1;
    int v2 = pdep(1899474334, -614718818);
    return 0;
}

int inst_9_flags_var_5() {
    short v0;
    short v1;
    *(int*)&v0 = (unsigned int)v1;
    int v2 = pdep(0x60a6888e, 723882488);
    return 0;
}

int inst_9_flags_var_6() {
    short v0;
    short v1;
    *(int*)&v0 = (unsigned int)v1;
    int v2 = pdep(935824922, -378678104);
    return 0;
}

int inst_9_flags_var_7() {
    short v0;
    short v1;
    *(int*)&v0 = (unsigned int)v1;
    int v2 = pdep(241885779, 1555957231);
    return 0;
}

int inst_9_flags_var_8() {
    short v0;
    short v1;
    *(int*)&v0 = (unsigned int)v1;
    int v2 = pdep(0x56b9999b, 0x183fd828);
    return 0;
}

int inst_9_flags_var_9() {
    short v0;
    short v1;
    *(int*)&v0 = (unsigned int)v1;
    int v2 = pdep(-1464966154, -119123428);
    return 0;
}

int inst_9_values_var_0() {
    short v0;
    short v1;
    int v2;
    *(int*)&v0 = (unsigned int)v1;
    int v2 = pdep(810472581, 0xe131999e);
    return v2 + 0x3eefeff6;
}

int inst_9_values_var_1() {
    short v0;
    short v1;
    int v2;
    *(int*)&v0 = (unsigned int)v1;
    int v2 = pdep(40225343, -1956161676);
    return v2 - 184877940;
}

int inst_9_values_var_2() {
    short v0;
    short v1;
    int v2;
    *(int*)&v0 = (unsigned int)v1;
    int v2 = pdep(-886848968, -886848968);
    return v2 - 0x100c200;
}

int inst_9_values_var_3() {
    short v0;
    short v1;
    int v2;
    *(int*)&v0 = (unsigned int)v1;
    int v2 = pdep(1592238105, 1975984891);
    return v2 - 1954545713;
}

int inst_9_values_var_4() {
    short v0;
    short v1;
    int v2;
    *(int*)&v0 = (unsigned int)v1;
    int v2 = pdep(639118170, 908879221);
    return v2 - 0x4244464;
}

int inst_9_values_var_5() {
    short v0;
    short v1;
    int v2;
    *(int*)&v0 = (unsigned int)v1;
    int v2 = pdep(-1803723064, 135702290);
    return v2 - 135430656;
}

int inst_9_values_var_6() {
    short v0;
    short v1;
    int v2;
    *(int*)&v0 = (unsigned int)v1;
    int v2 = pdep(1217970998, -741611363);
    return v2 - 50432140;
}

int inst_9_values_var_7() {
    short v0;
    short v1;
    int v2;
    *(int*)&v0 = (unsigned int)v1;
    int v2 = pdep(-1982522562, -1982522562);
    return v2 + 0x7faeeec4;
}

int inst_9_values_var_8() {
    short v0;
    short v1;
    int v2;
    *(int*)&v0 = (unsigned int)v1;
    int v2 = pdep(719069503, -1588215896);
    return v2 - 4204456;
}

int inst_9_values_var_9() {
    short v0;
    short v1;
    int v2;
    *(int*)&v0 = (unsigned int)v1;
    int v2 = pdep(-932340681, -932340681);
    return v2 + 1070857177;
}

void main() {
    // Decompilation error
}

int register_tm_clones() {
    return 0;
}

int sub_8049036() {
    return gvar_8056008();
}

void sub_8049CD7() {
}

int sub_8049D0C() {
    return 0;
}

void sub_8049D58() {
}

int sub_8049D8D() {
    int result = deregister_tm_clones();
    completed.6844 = 1;
    return result;
}

void sub_8049DA8() {
}

void →__assert_fail(char* __assertion, char* __file, unsigned int __line, char* __function) {
    while(1) {
        /*NO_RETURN*/ __assert_fail(__assertion, __file, __line, __function);
        unsigned int* ptr0 = ptr0 - 1;
        *ptr0 = 8;
        --ptr0;
        *ptr0 = gvar_8056004;
    }
}

void →__libc_start_main() {
    while(1) {
        /*BAD_CALL!*/ __libc_start_main();
        unsigned int* ptr0 = ptr0 - 1;
        *ptr0 = 0;
        --ptr0;
        *ptr0 = gvar_8056004;
    }
}
