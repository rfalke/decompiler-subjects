
void __libc_csu_fini() {
}

int __libc_csu_init(int param0, int param1, int param2) {
    int result;
    initializer_0();
    int v0 = 0;
    do {
        result = *(int*)(v0 * 4 + (int)&__frame_dummy_init_array_entry){initializer_1}();
        ++v0;
    }
    while(v0 != 1);
    return result;
}

void __x86.get_pc_thunk.bx() {
}

void _dl_relocate_static_pie() {
}

int _start(int param0, int param1) {
    →__libc_start_main();
    hlt();
}

// Stale decompilation - Refresh this view to re-decompile this code
int deregister_tm_clones() {
    return &completed.6844;
}

void finalizer_0() {
}

void finalizer_1() {
    if(!completed.6844) {
        deregister_tm_clones();
        completed.6844 = 1;
    }
}

void* initializer_0() {
    void* result = __gmon_start__;
    if(result) {
        result = (void*)result();
    }
    return result;
}

int initializer_1() {
    return register_tm_clones();
}

int inst_0_flags_var_0() {
    for(short i = 0; !((4335 >>> i) & 0x1); ++i) {
    }
    return 1;
}

int inst_0_flags_var_1() {
    for(short i = 0; !((2416 >>> i) & 0x1); ++i) {
    }
    return 1;
}

int inst_0_flags_var_2() {
    for(short i = 0; !((33240 >>> i) & 0x1); ++i) {
    }
    return 1;
}

int inst_0_flags_var_3() {
    for(short i = 0; !((57849 >>> i) & 0x1); ++i) {
    }
    return 1;
}

int inst_0_flags_var_4() {
    for(short i = 0; !((65053 >>> i) & 0x1); ++i) {
    }
    return 1;
}

int inst_0_flags_var_5() {
    for(short i = 0; !((38112 >>> i) & 0x1); ++i) {
    }
    return 1;
}

int inst_0_flags_var_6() {
    for(short i = 0; !((29390 >>> i) & 0x1); ++i) {
    }
    return 1;
}

int inst_0_flags_var_7() {
    for(short i = 0; !((45076 >>> i) & 0x1); ++i) {
    }
    return 1;
}

int inst_0_flags_var_8() {
    for(short i = 0; !((38158 >>> i) & 0x1); ++i) {
    }
    return 1;
}

int inst_0_flags_var_9() {
    for(short i = 0; !((7550 >>> i) & 0x1); ++i) {
    }
    return 1;
}

int inst_0_values_var_0() {
    short i;
    for(i = 0; !((42631 >>> i) & 0x1); ++i) {
    }
    return ((unsigned int)i | ((unsigned int)0x7671 << 16)) - 0x76710000;
}

int inst_0_values_var_1() {
    short i;
    for(i = 0; !((8873 >>> i) & 0x1); ++i) {
    }
    return ((unsigned int)i | ((unsigned int)3118 << 16)) - 0xc2e0000;
}

int inst_0_values_var_2() {
    short i;
    for(i = 0; !((0x2077 >>> i) & 0x1); ++i) {
    }
    return ((unsigned int)i | ((unsigned int)40621 << 16)) + 0x61530000;
}

int inst_0_values_var_3() {
    short i;
    for(i = 0; !((0x6764 >>> i) & 0x1); ++i) {
    }
    return ((unsigned int)i | ((unsigned int)33664 << 16)) + 0x7c7ffffe;
}

int inst_0_values_var_4() {
    short i;
    for(i = 0; !((0x50cc >>> i) & 0x1); ++i) {
    }
    return ((unsigned int)i | ((unsigned int)30001 << 16)) - 0x75310002;
}

int inst_0_values_var_5() {
    short i;
    for(i = 0; !((0xe7e4 >>> i) & 0x1); ++i) {
    }
    return ((unsigned int)i | ((unsigned int)59507 << 16)) + 0x178cfffe;
}

int inst_0_values_var_6() {
    short i;
    for(i = 0; !((23992 >>> i) & 0x1); ++i) {
    }
    return ((unsigned int)i | ((unsigned int)59669 << 16)) + 0x16eafffd;
}

int inst_0_values_var_7() {
    short i;
    for(i = 0; !((29194 >>> i) & 0x1); ++i) {
    }
    return ((unsigned int)i | ((unsigned int)19903 << 16)) - 0x4dbf0001;
}

int inst_0_values_var_8() {
    short i;
    for(i = 0; !((27011 >>> i) & 0x1); ++i) {
    }
    return ((unsigned int)i | ((unsigned int)57547 << 16)) + 0x1f350000;
}

int inst_0_values_var_9() {
    short i;
    for(i = 0; !((14172 >>> i) & 0x1); ++i) {
    }
    return ((unsigned int)i | ((unsigned int)15249 << 16)) - 0x3b910002;
}

int inst_10_flags_var_0() {
    int v0 = pext(452085110, -2055120892, 452085110);
    return 0;
}

int inst_10_flags_var_1() {
    int v0 = pext(-1790431553, -1790431553, -1593209170);
    return 0;
}

int inst_10_flags_var_2() {
    int v0 = pext(0x7b899178, -1254945304, -38603824);
    return 0;
}

int inst_10_flags_var_3() {
    int v0 = pext(-2064904775, -1699898906, 0xacd3cee2);
    return 0;
}

int inst_10_flags_var_4() {
    int v0 = pext(1833509804, -170558444, 1946245896);
    return 0;
}

int inst_10_flags_var_5() {
    int v0 = pext(0xe38668a, 0x5f9a97b1, 0x14bf1474);
    return 0;
}

int inst_10_flags_var_6() {
    int v0 = pext(-1031029108, -1031029108, -846087814);
    return 0;
}

int inst_10_flags_var_7() {
    int v0 = pext(-1972161565, 0x6108e345, -39905867);
    return 0;
}

int inst_10_flags_var_8() {
    int v0 = pext(-1679171081, 0xf5fa5959, -1679171081);
    return 0;
}

int inst_10_flags_var_9() {
    int v0 = pext(257188353, -986308641, -986308641);
    return 0;
}

int inst_10_values_var_0() {
    int v0;
    int v0 = pext(-1782073326, 1762968426, 1668529281);
    return v0 - 53824;
}

int inst_10_values_var_1() {
    int v0;
    int v0 = pext(0xed137113, 1230761140, 0xadac7378);
    return v0 - 42374;
}

int inst_10_values_var_2() {
    int v0;
    int v0 = pext(-1521333236, 0x8e28969a, -2085116616);
    return v0 - 51283;
}

int inst_10_values_var_3() {
    int v0;
    int v0 = pext(0xda5b3677, -1941075087, 0xda5b3677);
    return v0 - 611449;
}

int inst_10_values_var_4() {
    int v0;
    int v0 = pext(163397628, -787990404, -787990404);
    return v0 - 0x1fff;
}

int inst_10_values_var_5() {
    int v0;
    int v0 = pext(-1256530960, -1686629526, -1696652911);
    return v0 - 63240;
}

int inst_10_values_var_6() {
    int v0;
    int v0 = pext(0x3e5b2117, 1182671937, -1484575175);
    return v0 - 12961;
}

int inst_10_values_var_7() {
    int v0;
    int v0 = pext(0x4c66a998, 0xa43d3728, 794327630);
    return v0 - 83668;
}

int inst_10_values_var_8() {
    int v0;
    int v0 = pext(1681112373, -444628750, 1681112373);
    return v0 - 130572;
}

int inst_10_values_var_9() {
    int v0;
    int v0 = pext(0x24313861, -505232365, 0x24313861);
    return v0 - 1281;
}

int inst_11_flags_var_0() {
    int v0 = rorx(-1817406722, 791217770, 48);
    return 0;
}

int inst_11_flags_var_1() {
    int v0 = rorx(0x3d4e34af, 1563318186, 175);
    return 0;
}

int inst_11_flags_var_2() {
    int v0 = rorx(1042861801, 756535360, 27);
    return 0;
}

int inst_11_flags_var_3() {
    int v0 = rorx(-770099649, 2045245946, 61);
    return 0;
}

int inst_11_flags_var_4() {
    int v0 = rorx(-1028704844, -566220227, 253);
    return 0;
}

int inst_11_flags_var_5() {
    int v0 = rorx(-1973573331, 2026154275, 98);
    return 0;
}

int inst_11_flags_var_6() {
    int v0 = rorx(-1086426559, -215248950, 171);
    return 0;
}

int inst_11_flags_var_7() {
    int v0 = rorx(-1490672704, -1490672704, 117);
    return 0;
}

int inst_11_flags_var_8() {
    int v0 = rorx(-306083654, -306083654, 127);
    return 0;
}

int inst_11_flags_var_9() {
    int v0 = rorx(0xce6a99e4, -1886514143, 133);
    return 0;
}

int inst_11_values_var_0() {
    int v0;
    int v0 = rorx(0x8ddd8b04, 0x8ddd8b04, 231);
    return v0 - 0x91bbb16;
}

int inst_11_values_var_1() {
    int v0;
    int v0 = rorx(0x1cfaaa30, -451963335, 227);
    return v0 - 1017246407;
}

int inst_11_values_var_2() {
    int v0;
    int v0 = rorx(-1870195157, 1561684145, 27);
    return v0 + 1565714901;
}

int inst_11_values_var_3() {
    int v0;
    int v0 = rorx(-1176159040, -1176159040, 52);
    return v0 - 1405881246;
}

int inst_11_values_var_4() {
    int v0;
    int v0 = rorx(2075539620, 9729078, 0xaa);
    return v0 - 226501917;
}

int inst_11_values_var_5() {
    int v0;
    int v0 = rorx(797983777, 483342351, 208);
    return v0 - 940514511;
}

int inst_11_values_var_6() {
    int v0;
    int v0 = rorx(38288706, 0xeca9e19, 112);
    return v0 + 0x61e6f136;
}

int inst_11_values_var_7() {
    int v0;
    int v0 = rorx(-778493540, -778493540, 227);
    return v0 + 0x65ccdbcd;
}

int inst_11_values_var_8() {
    int v0;
    int v0 = rorx(0xdfd7cfa9, 705535203, 174);
    return v0 - 0x738ca836;
}

int inst_11_values_var_9() {
    int v0;
    int v0 = rorx(1739991917, 0x1c83bc80, 93);
    return v0 + 467803136;
}

int inst_12_flags_var_0() {
    int v0 = sarx(-90906031, 0xce1c1766, 0xce1c1766);
    return 0;
}

int inst_12_flags_var_1() {
    int v0 = sarx(-1483328310, -1483328310, -1483328310);
    return 0;
}

int inst_12_flags_var_2() {
    int v0 = sarx(1460586743, 1409890689, 1460586743);
    return 0;
}

int inst_12_flags_var_3() {
    int v0 = sarx(0xfa4425a9, 1271515703, 0xfa4425a9);
    return 0;
}

int inst_12_flags_var_4() {
    int v0 = sarx(0x74fa9c94, 0xadefd0da, -1022514849);
    return 0;
}

int inst_12_flags_var_5() {
    int v0 = sarx(38277958, 0xc7a778b7, 105446866);
    return 0;
}

int inst_12_flags_var_6() {
    int v0 = sarx(-1402060906, 50145679, -1155114135);
    return 0;
}

int inst_12_flags_var_7() {
    int v0 = sarx(423385858, 1025114071, 423385858);
    return 0;
}

int inst_12_flags_var_8() {
    int v0 = sarx(-220784068, -556133123, -556133123);
    return 0;
}

int inst_12_flags_var_9() {
    int v0 = sarx(-1532006115, -1880037206, -1555379585);
    return 0;
}

int inst_12_values_var_0() {
    int v0;
    int v0 = sarx(0xebc13cd2, 0xebc13cd2, 383136334);
    return v0 + 20732;
}

int inst_12_values_var_1() {
    int v0;
    int v0 = sarx(138367704, 227819983, -727402870);
    return v0 - 222480;
}

int inst_12_values_var_2() {
    int v0;
    int v0 = sarx(0xa7afb1a0, -849670622, 1330863701);
    return v0 + 406;
}

int inst_12_values_var_3() {
    int v0;
    int v0 = sarx(-399540725, 850822812, -399540725);
    return v0 - 0x656d0;
}

int inst_12_values_var_4() {
    int v0;
    int v0 = sarx(1516661899, -333162186, 378432829);
    return v0 + 1;
}

int inst_12_values_var_5() {
    int v0;
    int v0 = sarx(-1085266451, -1085266451, -442502155);
    return v0 + 518;
}

int inst_12_values_var_6() {
    int v0;
    int v0 = sarx(-1982898954, -1982898954, -1930842749);
    return v0 + 247862370;
}

int inst_12_values_var_7() {
    int v0;
    int v0 = sarx(-1342444660, 0x67829c32, -1169918117);
    return v0 - 12;
}

int inst_12_values_var_8() {
    int v0;
    int v0 = sarx(-145499195, 610576373, -1801146015);
    return v0 - 0x123253fa;
}

int inst_12_values_var_9() {
    int v0;
    int v0 = sarx(-1789688565, 750257426, 750257426);
    return v0 - 2862;
}

int inst_13_flags_var_0() {
    int v0 = shlx(0x8b304124, 0x524d5002, 0x524d5002);
    return 0;
}

int inst_13_flags_var_1() {
    int v0 = shlx(-528893632, 1463000842, 1891415676);
    return 0;
}

int inst_13_flags_var_2() {
    int v0 = shlx(2051838691, -2109057769, 0x31a33866);
    return 0;
}

int inst_13_flags_var_3() {
    int v0 = shlx(302986762, 0x6d8e6e92, 1755299852);
    return 0;
}

int inst_13_flags_var_4() {
    int v0 = shlx(488869702, -1210723727, 1675133558);
    return 0;
}

int inst_13_flags_var_5() {
    int v0 = shlx(1294045014, 0xc88991a, 0xc88991a);
    return 0;
}

int inst_13_flags_var_6() {
    int v0 = shlx(335361602, 335361602, 0xdccb78e0);
    return 0;
}

int inst_13_flags_var_7() {
    int v0 = shlx(-823595224, -1064844691, -823595224);
    return 0;
}

int inst_13_flags_var_8() {
    int v0 = shlx(34337435, 501258026, 692885557);
    return 0;
}

int inst_13_flags_var_9() {
    int v0 = shlx(-1147865614, 1990687555, 1116963066);
    return 0;
}

int inst_13_values_var_0() {
    int v0;
    int v0 = shlx(-2068995137, -189994739, -2068995137);
    return v0 - 0x80000000;
}

int inst_13_values_var_1() {
    int v0;
    int v0 = shlx(0xf6ee77fd, 1847510208, 1388453443);
    return v0 - 1895179776;
}

int inst_13_values_var_2() {
    int v0;
    int v0 = shlx(-2032045022, -884507854, -884507854);
    return v0 + 0x13380000;
}

int inst_13_values_var_3() {
    int v0;
    int v0 = shlx(485415441, 1684066975, 0xb410049f);
    return v0 - 0x80000000;
}

int inst_13_values_var_4() {
    int v0;
    int v0 = shlx(-1523981855, 1250472528, -47244049);
    return v0 - 0x59280000;
}

int inst_13_values_var_5() {
    int v0;
    int v0 = shlx(1662082970, 1886636564, 0xed0210c5);
    return v0 - 242827904;
}

int inst_13_values_var_6() {
    int v0;
    int v0 = shlx(1995814910, 1426518199, -609964017);
    return v0 - 0x785b8000;
}

int inst_13_values_var_7() {
    int v0;
    int v0 = shlx(-1550506832, 0xbaac9561, -1550506832);
    return v0 + 0x6a9f0000;
}

int inst_13_values_var_8() {
    int v0;
    int v0 = shlx(-1108246737, -1108246737, 0x9294a94d);
    return v0 - 0x2fe5e000;
}

int inst_13_values_var_9() {
    int v0;
    int v0 = shlx(-1660426296, -173612166, 242741746);
    return v0 + 0x72180000;
}

int inst_14_flags_var_0() {
    int v0 = shrx(-633191732, 1211086396, -633191732);
    return 0;
}

int inst_14_flags_var_1() {
    int v0 = shrx(1631491618, 487407864, -1693197014);
    return 0;
}

int inst_14_flags_var_2() {
    int v0 = shrx(-854685950, -854685950, -1669501189);
    return 0;
}

int inst_14_flags_var_3() {
    int v0 = shrx(-1921982318, 749149621, 22151327);
    return 0;
}

int inst_14_flags_var_4() {
    int v0 = shrx(419377555, 0x38dd3ea3, 722925279);
    return 0;
}

int inst_14_flags_var_5() {
    int v0 = shrx(-592987707, 0xaab0e1e0, 1581266997);
    return 0;
}

int inst_14_flags_var_6() {
    int v0 = shrx(0x9a1cad99, -102237385, -1555121865);
    return 0;
}

int inst_14_flags_var_7() {
    int v0 = shrx(-1668408004, -1091432292, 92031196);
    return 0;
}

int inst_14_flags_var_8() {
    int v0 = shrx(-230327553, 0x6d1c5aaa, 0x6d1c5aaa);
    return 0;
}

int inst_14_flags_var_9() {
    int v0 = shrx(-337511704, -663605155, 547305600);
    return 0;
}

int inst_14_values_var_0() {
    int v0;
    int v0 = shrx(-908753075, -622290496, -908753075);
    return v0 - 448324;
}

int inst_14_values_var_1() {
    int v0;
    int v0 = shrx(-1797435201, -1797435201, -935353722);
    return v0 - 39023938;
}

int inst_14_values_var_2() {
    int v0;
    int v0 = shrx(-1093375953, 0xfbaaa879, -1093375953);
    return v0 - 0x1f755;
}

int inst_14_values_var_3() {
    int v0;
    int v0 = shrx(-647881022, 1583725550, 0x2f828e3a);
    return v0 - 23;
}

int inst_14_values_var_4() {
    int v0;
    int v0 = shrx(-689855870, -689855870, 0xbfbb36e5);
    return v0 - 112659732;
}

int inst_14_values_var_5() {
    int v0;
    int v0 = shrx(1630939713, 1686027328, 712429275);
    return v0 - 12;
}

int inst_14_values_var_6() {
    int v0;
    int v0 = shrx(0x43e543e8, 532396544, 1580164441);
    return v0 - 15;
}

int inst_14_values_var_7() {
    int v0;
    int v0 = shrx(-99224023, 1525987144, 2142152408);
    return v0 - 90;
}

int inst_14_values_var_8() {
    int v0;
    int v0 = shrx(-1263124015, -2119179658, -2119179658);
    return v0 - 518;
}

int inst_14_values_var_9() {
    int v0;
    int v0 = shrx(0x7b6072b2, 0x110f7c66, 0x7b6072b2);
    return v0 - 0x443;
}

int inst_15_flags_var_0() {
    int v0 = adox(1909777996, -1278062750);
    return -2;
}

int inst_15_flags_var_1() {
    int v0 = adox(-241784897, 0xbc47b0a8);
    return -2;
}

int inst_15_flags_var_2() {
    int v0 = adox(0xa91ede05, 0xa91ede05);
    return -2;
}

int inst_15_flags_var_3() {
    int v0 = adox(-1566700073, 0x5a6f4225);
    return 0;
}

int inst_15_flags_var_4() {
    int v0 = adox(-26599303, -1006376182);
    return -2;
}

int inst_15_flags_var_5() {
    int v0 = adox(16335225, -1576461106);
    return 0;
}

int inst_15_flags_var_6() {
    int v0 = adox(-846856631, -2063190677);
    return -2;
}

int inst_15_flags_var_7() {
    int v0 = adox(-332253926, 1588536061);
    return -2;
}

int inst_15_flags_var_8() {
    int v0 = adox(-1864117703, 1823000667);
    return 0;
}

int inst_15_flags_var_9() {
    int v0 = adox(-2027546673, -901092588);
    return -2;
}

int inst_15_values_var_0() {
    int v0;
    int v0 = adox(1194453572, -1894381847);
    return v0 + 699928275;
}

int inst_15_values_var_1() {
    int v0;
    int v0 = adox(-1097794928, 1460124667);
    return v0 - 362329739;
}

int inst_15_values_var_2() {
    int v0;
    int v0 = adox(2146149235, 2146149235);
    return v0 + 2668826;
}

int inst_15_values_var_3() {
    int v0;
    int v0 = adox(1299056513, -1508692084);
    return v0 + 0xc7ec8f3;
}

int inst_15_values_var_4() {
    int v0;
    int v0 = adox(0x4be645b, 58467584);
    return v0 - 138053979;
}

int inst_15_values_var_5() {
    int v0;
    int v0 = adox(-2126934686, 550676471);
    return v0 + 1576258215;
}

int inst_15_values_var_6() {
    int v0;
    int v0 = adox(-173871022, -1726092541);
    return v0 + 1899963563;
}

int inst_15_values_var_7() {
    int v0;
    int v0 = adox(0x24d609ab, 2112105206);
    return v0 + 1564855135;
}

int inst_15_values_var_8() {
    int v0;
    int v0 = adox(1966328308, 1966328308);
    return v0 + 362310680;
}

int inst_15_values_var_9() {
    int v0;
    int v0 = adox(2120059850, -888618332);
    return v0 - 1231441518;
}

int inst_16_flags_var_0() {
    int v0 = adcx(-258461112, 1087454374);
    return 0;
}

int inst_16_flags_var_1() {
    int v0 = adcx(1593455677, -1118413764);
    return 0;
}

int inst_16_flags_var_2() {
    int v0 = adcx(0x284aab28, -1810340071);
    return 1;
}

int inst_16_flags_var_3() {
    int v0 = adcx(-1009153517, -391910429);
    return 0;
}

int inst_16_flags_var_4() {
    int v0 = adcx(-560858935, 0xabb5d5dd);
    return 0;
}

int inst_16_flags_var_5() {
    int v0 = adcx(0x74def75f, 0xcd2404c9);
    return 0;
}

int inst_16_flags_var_6() {
    int v0 = adcx(-53434219, 2089424482);
    return 0;
}

int inst_16_flags_var_7() {
    int v0 = adcx(0x50edf33, 508260864);
    return 1;
}

int inst_16_flags_var_8() {
    int v0 = adcx(0xcedd550e, -1309411617);
    return 0;
}

int inst_16_flags_var_9() {
    int v0 = adcx(-1804068417, -153969881);
    return 0;
}

int inst_16_values_var_0() {
    int v0;
    int v0 = adcx(293656913, -884834407);
    return v0 + 0x233ca715;
}

int inst_16_values_var_1() {
    int v0;
    int v0 = adcx(1080488984, 0xde99ba9c);
    return v0 - 520138421;
}

int inst_16_values_var_2() {
    int v0;
    int v0 = adcx(282539375, 282539375);
    return v0 - 565078751;
}

int inst_16_values_var_3() {
    int v0;
    int v0 = adcx(1213280651, 502643028);
    return v0 - 0x6646eae0;
}

int inst_16_values_var_4() {
    int v0;
    int v0 = adcx(0x1121a5f1, -1389566243);
    return v0 + 1102148401;
}

int inst_16_values_var_5() {
    int v0;
    int v0 = adcx(-630837646, 0x12ccb356);
    return v0 + 315432503;
}

int inst_16_values_var_6() {
    int v0;
    int v0 = adcx(1556860994, -1150999344);
    return v0 - 405861651;
}

int inst_16_values_var_7() {
    int v0;
    int v0 = adcx(-1603283321, -1603283321);
    return v0 - 1088400655;
}

int inst_16_values_var_8() {
    int v0;
    int v0 = adcx(0xcec9cf66, 0x5987cb2c);
    return v0 - 676436627;
}

int inst_16_values_var_9() {
    int v0;
    int v0 = adcx(-1578658500, 1097149250);
    return v0 + 0x1cb33f81;
}

int inst_17_flags_var_0() {
    int v0 = crc32(1957160080, 232);
    return 0;
}

int inst_17_flags_var_1() {
    int v0 = crc32(-1887259254, 0xcc);
    return 0;
}

int inst_17_flags_var_2() {
    int v0 = crc32(0x68989a18, 154);
    return 0;
}

int inst_17_flags_var_3() {
    int v0 = crc32(-1853554265, 215);
    return 0;
}

int inst_17_flags_var_4() {
    int v0 = crc32(0x67cde30a, 248);
    return 0;
}

int inst_17_flags_var_5() {
    int v0 = crc32(0xd1dd3802, 158);
    return 0;
}

int inst_17_flags_var_6() {
    int v0 = crc32(-2137724238, 250);
    return 0;
}

int inst_17_flags_var_7() {
    int v0 = crc32(-1422319274, 11);
    return 0;
}

int inst_17_flags_var_8() {
    int v0 = crc32(-1840050627, 246);
    return 0;
}

int inst_17_flags_var_9() {
    int v0 = crc32(920079420, 184);
    return 0;
}

int inst_17_values_var_0() {
    int v0;
    int v0 = crc32(1253600531, 157);
    return v0 - 0x2ec43c32;
}

int inst_17_values_var_1() {
    int v0;
    int v0 = crc32(-109193720, 22);
    return v0 + 1126234722;
}

int inst_17_values_var_2() {
    int v0;
    int v0 = crc32(0xe00c88a3, 0xaa);
    return v0 - 2018694980;
}

int inst_17_values_var_3() {
    int v0;
    int v0 = crc32(2083812808, 179);
    return v0 + 395457725;
}

int inst_17_values_var_4() {
    int v0;
    int v0 = crc32(756764133, 188);
    return v0 - 700062290;
}

int inst_17_values_var_5() {
    int v0;
    int v0 = crc32(1829036936, 41);
    return v0 - 1347236422;
}

int inst_17_values_var_6() {
    int v0;
    int v0 = crc32(-1238184810, 241);
    return v0 + 0x4a453abb;
}

int inst_17_values_var_7() {
    int v0;
    int v0 = crc32(673700031, 97);
    return v0 - 2139322708;
}

int inst_17_values_var_8() {
    int v0;
    int v0 = crc32(0x9db0968a, 66);
    return v0 - 1237962397;
}

int inst_17_values_var_9() {
    int v0;
    int v0 = crc32(-1394970927, 142);
    return v0 - 261766297;
}

int inst_18_flags_var_0() {
    int v0 = crc32(1297797813, 28974);
    return 0;
}

int inst_18_flags_var_1() {
    int v0 = crc32(-170968771, 0x6e65);
    return 0;
}

int inst_18_flags_var_2() {
    int v0 = crc32(1913190991, 0x212c);
    return 0;
}

int inst_18_flags_var_3() {
    int v0 = crc32(-432575721, 45015);
    return 0;
}

int inst_18_flags_var_4() {
    int v0 = crc32(0x57850a45, 30411);
    return 0;
}

int inst_18_flags_var_5() {
    int v0 = crc32(-1910067750, 64940);
    return 0;
}

int inst_18_flags_var_6() {
    int v0 = crc32(0xe9c8e7e2, 46414);
    return 0;
}

int inst_18_flags_var_7() {
    int v0 = crc32(1435113790, 0x5566);
    return 0;
}

int inst_18_flags_var_8() {
    int v0 = crc32(0x160ac8c8, 52774);
    return 0;
}

int inst_18_flags_var_9() {
    int v0 = crc32(0xd285eebd, 51377);
    return 0;
}

int inst_18_values_var_0() {
    int v0;
    int v0 = crc32(0xb263322b, 0x322b);
    return v0 - 45667;
}

int inst_18_values_var_1() {
    int v0;
    int v0 = crc32(0x3910e455, 0xe455);
    return v0 - 14608;
}

int inst_18_values_var_2() {
    int v0;
    int v0 = crc32(-190822688, 22107);
    return v0 - 35696788;
}

int inst_18_values_var_3() {
    int v0;
    int v0 = crc32(0xbcc6137b, 54780);
    return v0 - 1686261334;
}

int inst_18_values_var_4() {
    int v0;
    int v0 = crc32(0x32176262, 54667);
    return v0 + 1825136635;
}

int inst_18_values_var_5() {
    int v0;
    int v0 = crc32(-1121230284, 62006);
    return v0 + 1242730030;
}

int inst_18_values_var_6() {
    int v0;
    int v0 = crc32(188540335, 37987);
    return v0 - 1421427371;
}

int inst_18_values_var_7() {
    int v0;
    int v0 = crc32(1639554169, 45271);
    return v0 - 0x1d6dabc6;
}

int inst_18_values_var_8() {
    int v0;
    int v0 = crc32(1777439530, 48163);
    return v0 + 266829628;
}

int inst_18_values_var_9() {
    int v0;
    int v0 = crc32(-1894717598, 5797);
    return v0 - 2143065822;
}

int inst_19_flags_var_0() {
    int v0 = crc32(1087415724, 0xdefd415e);
    return 0;
}

int inst_19_flags_var_1() {
    int v0 = crc32(-2143054082, 162461048);
    return 0;
}

int inst_19_flags_var_2() {
    int v0 = crc32(-888146139, 1420566324);
    return 0;
}

int inst_19_flags_var_3() {
    int v0 = crc32(742270066, 1527445682);
    return 0;
}

int inst_19_flags_var_4() {
    int v0 = crc32(951589553, 828485703);
    return 0;
}

int inst_19_flags_var_5() {
    int v0 = crc32(-495037875, -279661009);
    return 0;
}

int inst_19_flags_var_6() {
    int v0 = crc32(-2054345493, 2137457854);
    return 0;
}

int inst_19_flags_var_7() {
    int v0 = crc32(317841334, -2093063404);
    return 0;
}

int inst_19_flags_var_8() {
    int v0 = crc32(222380478, -1859845549);
    return 0;
}

int inst_19_flags_var_9() {
    int v0 = crc32(174538254, 991257227);
    return 0;
}

int inst_19_values_var_0() {
    int v0;
    int v0 = crc32(-1366144916, 2060790120);
    return v0 - 1769054645;
}

int inst_19_values_var_1() {
    int result;
    int result = crc32(126139455, 126139455);
    return result;
}

int inst_19_values_var_2() {
    int v0;
    int v0 = crc32(1878175054, 696322509);
    return v0 - 677113345;
}

int inst_19_values_var_3() {
    int v0;
    int v0 = crc32(-148469989, -1617484958);
    return v0 - 158048482;
}

int inst_19_values_var_4() {
    int v0;
    int v0 = crc32(-444343991, -298859394);
    return v0 + 1703773965;
}

int inst_19_values_var_5() {
    int v0;
    int v0 = crc32(139152320, -1137585428);
    return v0 - 0x4c5122eb;
}

int inst_19_values_var_6() {
    int v0;
    int v0 = crc32(450325533, 1427999362);
    return v0 + 1982154876;
}

int inst_19_values_var_7() {
    int result;
    int result = crc32(1256911427, 1256911427);
    return result;
}

int inst_19_values_var_8() {
    int v0;
    int v0 = crc32(1068559233, 0x8b14bc15);
    return v0 + 1130607302;
}

int inst_19_values_var_9() {
    int v0;
    int v0 = crc32(0xb443efa1, -962202063);
    return v0 + 0x2bbafcfc;
}

int inst_1_flags_var_0() {
    int v0 = tzcnt(1677974700, 254618161);
    return 1;
}

int inst_1_flags_var_1() {
    int v0 = tzcnt(-2128179824, 730644315);
    return 1;
}

int inst_1_flags_var_2() {
    int v0 = tzcnt(1780466629, 240633786);
    return 1;
}

int inst_1_flags_var_3() {
    int v0 = tzcnt(372815352, 0xa1e08aa);
    return 1;
}

int inst_1_flags_var_4() {
    int v0 = tzcnt(-1099582407, -236713867);
    return 1;
}

int inst_1_flags_var_5() {
    int v0 = tzcnt(-1032625444, 212912351);
    return 1;
}

int inst_1_flags_var_6() {
    int v0 = tzcnt(212056016, 1733378162);
    return 1;
}

int inst_1_flags_var_7() {
    int v0 = tzcnt(1864748371, 1226576686);
    return 1;
}

int inst_1_flags_var_8() {
    int v0 = tzcnt(-691499111, -691499111);
    return 1;
}

int inst_1_flags_var_9() {
    int v0 = tzcnt(-1467881017, -1467881017);
    return 1;
}

int inst_1_values_var_0() {
    int result;
    int result = tzcnt(559544181, 0x10632017);
    return result;
}

int inst_1_values_var_1() {
    int v0;
    int v0 = tzcnt(0x86a2e13f, 340777174);
    return v0 - 1;
}

int inst_1_values_var_2() {
    int v0;
    int v0 = tzcnt(-431313248, -431313248);
    return v0 - 5;
}

int inst_1_values_var_3() {
    int result;
    int result = tzcnt(-1492275047, 255251217);
    return result;
}

int inst_1_values_var_4() {
    int result;
    int result = tzcnt(-1605010242, -1264045333);
    return result;
}

int inst_1_values_var_5() {
    int result;
    int result = tzcnt(1592101178, 0xe3626229);
    return result;
}

int inst_1_values_var_6() {
    int v0;
    int v0 = tzcnt(1995195195, 2014030982);
    return v0 - 1;
}

int inst_1_values_var_7() {
    int result;
    int result = tzcnt(1958898992, -1034133);
    return result;
}

int inst_1_values_var_8() {
    int v0;
    int v0 = tzcnt(0xe4f470e1, -5609698);
    return v0 - 1;
}

int inst_1_values_var_9() {
    int v0;
    int v0 = tzcnt(1298586160, 1298586160);
    return v0 - 4;
}

int inst_20_flags_var_0() {
    for(short i = 15; !(3769 >>> i); --i) {
    }
    return 0;
}

int inst_20_flags_var_1() {
    for(short i = 15; !(2635 >>> i); --i) {
    }
    return 0;
}

int inst_20_flags_var_2() {
    for(short i = 15; !(60754 >>> i); --i) {
    }
    return 0;
}

int inst_20_flags_var_3() {
    for(short i = 15; !(0x7900 >>> i); --i) {
    }
    return 0;
}

int inst_20_flags_var_4() {
    for(short i = 15; !(0xb5b9 >>> i); --i) {
    }
    return 0;
}

int inst_20_flags_var_5() {
    for(short i = 15; !(0x2f1f >>> i); --i) {
    }
    return 0;
}

int inst_20_flags_var_6() {
    for(short i = 15; !(13555 >>> i); --i) {
    }
    return 0;
}

int inst_20_flags_var_7() {
    for(short i = 15; !(3145 >>> i); --i) {
    }
    return 0;
}

int inst_20_flags_var_8() {
    for(short i = 15; !(61127 >>> i); --i) {
    }
    return 0;
}

int inst_20_flags_var_9() {
    for(short i = 15; !(0x334d >>> i); --i) {
    }
    return 0;
}

int inst_20_values_var_0() {
    short i;
    for(i = 15; !(0xd24d >>> i); --i) {
    }
    return ((unsigned int)i | ((unsigned int)117 << 16)) - 7667712;
}

int inst_20_values_var_1() {
    short i;
    for(i = 15; !(58276 >>> i); --i) {
    }
    return ((unsigned int)i | ((unsigned int)25467 << 16)) - 0x637b0000;
}

int inst_20_values_var_2() {
    short i;
    for(i = 15; !(23331 >>> i); --i) {
    }
    return ((unsigned int)i | ((unsigned int)0xdaad << 16)) + 0x2552ffff;
}

int inst_20_values_var_3() {
    short i;
    for(i = 15; !(0x6fdf >>> i); --i) {
    }
    return ((unsigned int)i | ((unsigned int)32456 << 16)) - 0x7ec80001;
}

int inst_20_values_var_4() {
    short i;
    for(i = 15; !(0x32c2 >>> i); --i) {
    }
    return ((unsigned int)i | ((unsigned int)35030 << 16)) + 1999241214;
}

int inst_20_values_var_5() {
    short i;
    for(i = 15; !(0x6a2a >>> i); --i) {
    }
    return ((unsigned int)i | ((unsigned int)0x8148 << 16)) + 2125987839;
}

int inst_20_values_var_6() {
    short i;
    for(i = 15; !(48192 >>> i); --i) {
    }
    return ((unsigned int)i | ((unsigned int)3254 << 16)) - 0xcb60000;
}

int inst_20_values_var_7() {
    short i;
    for(i = 15; !(54478 >>> i); --i) {
    }
    return ((unsigned int)i | ((unsigned int)0xccd1 << 16)) + 0x332f0000;
}

int inst_20_values_var_8() {
    short i;
    for(i = 15; !(32179 >>> i); --i) {
    }
    return ((unsigned int)i | ((unsigned int)0x4442 << 16)) - 0x44420001;
}

int inst_20_values_var_9() {
    short i;
    for(i = 15; !(17 >>> i); --i) {
    }
    return ((unsigned int)i | ((unsigned int)25813 << 16)) - 0x64d5000b;
}

int inst_21_flags_var_0() {
    int v0 = lzcnt(0x60ae955e, 0x60ae955e);
    return 0;
}

int inst_21_flags_var_1() {
    int v0 = lzcnt(48761304, 0x6aea696c);
    return 0;
}

int inst_21_flags_var_2() {
    int v0 = lzcnt(-688879285, -1235679510);
    return 0;
}

int inst_21_flags_var_3() {
    int v0 = lzcnt(-211241499, 0xcc0c6e6a);
    return 0;
}

int inst_21_flags_var_4() {
    int v0 = lzcnt(-1524610451, -1563899118);
    return 0;
}

int inst_21_flags_var_5() {
    int v0 = lzcnt(-1497110926, 0x43345034);
    return 0;
}

int inst_21_flags_var_6() {
    int v0 = lzcnt(-2120953798, -1906804455);
    return 0;
}

int inst_21_flags_var_8() {
    int v0 = lzcnt(-284232246, 597021142);
    return 0;
}

int inst_21_flags_var_9() {
    int v0 = lzcnt(574898942, 574898942);
    return 0;
}

int inst_21_values_var_0() {
    int result;
    int result = lzcnt(-38916796, -819561136);
    return result;
}

int inst_21_values_var_1() {
    int v0;
    int v0 = lzcnt(-1082795685, 1317749925);
    return v0 - 1;
}

int inst_21_values_var_2() {
    int v0;
    int v0 = lzcnt(1030407393, 1220872801);
    return v0 - 1;
}

int inst_21_values_var_3() {
    int v0;
    int v0 = lzcnt(329568266, 1054475063);
    return v0 - 2;
}

int inst_21_values_var_4() {
    int v0;
    int v0 = lzcnt(-1109543409, 1459610);
    return v0 - 11;
}

int inst_21_values_var_5() {
    int v0;
    int v0 = lzcnt(906987219, 0xb03bb59);
    return v0 - 4;
}

int inst_21_values_var_6() {
    int result;
    int result = lzcnt(-1021981401, -378679385);
    return result;
}

int inst_21_values_var_7() {
    int v0;
    int v0 = lzcnt(1070337778, 31108367);
    return v0 - 7;
}

int inst_21_values_var_8() {
    int result;
    int result = lzcnt(0x5b455998, 0x8f92b9db);
    return result;
}

int inst_21_values_var_9() {
    int result;
    int result = lzcnt(874770533, 0xe1d0d1b2);
    return result;
}

int inst_2_flags_var_0() {
    int v0 = andn(-1226908676, 1957773953, 0xc9b8aec9);
    return 1;
}

int inst_2_flags_var_1() {
    int v0 = andn(973696718, 0x728c5a27, -2061246885);
    return 1;
}

int inst_2_flags_var_2() {
    int v0 = andn(1888093876, 1888093876, 0x753dee3d);
    return 1;
}

int inst_2_flags_var_3() {
    int v0 = andn(-159056107, 38342744, 0xfb1a6a8c);
    return 1;
}

int inst_2_flags_var_4() {
    int v0 = andn(0xf73a870a, -1400289966, 0xf73a870a);
    return 9;
}

int inst_2_flags_var_5() {
    int v0 = andn(890473597, 1055136761, 890473597);
    return 1;
}

int inst_2_flags_var_6() {
    int v0 = andn(1240401232, 0x89a048ce, 0x89a048ce);
    return 9;
}

int inst_2_flags_var_7() {
    int v0 = andn(1667896932, 2072682762, 0x39d4d5df);
    return 1;
}

int inst_2_flags_var_8() {
    int v0 = andn(-396643591, 0xbae5c3b0, 0xbae5c3b0);
    return 9;
}

int inst_2_flags_var_9() {
    int v0 = andn(-1988179802, -527215740, -1979033810);
    return 1;
}

int inst_2_values_var_0() {
    int v0;
    int v0 = andn(-930177673, 550458188, -981264286);
    return v0 + 989853662;
}

int inst_2_values_var_1() {
    int v0;
    int v0 = andn(-463324247, 1654292738, -446428540);
    return v0 + 2057041276;
}

int inst_2_values_var_2() {
    int v0;
    int v0 = andn(-982103428, 2095340402, -882186658);
    return v0 + 2096454644;
}

int inst_2_values_var_3() {
    int v0;
    int v0 = andn(-24575100, -1410940787, 196028928);
    return v0 - 600576;
}

int inst_2_values_var_4() {
    int v0;
    int v0 = andn(-686918801, -686918801, -418155764);
    return v0 - 0x20110000;
}

int inst_2_values_var_5() {
    int v0;
    int v0 = andn(699987827, -1772323385, 0x2f263386);
    return v0 - 0x29220200;
}

int inst_2_values_var_6() {
    int result;
    int result = andn(0x47ad41aa, 0x47ad41aa, 0x47ad41aa);
    return result;
}

int inst_2_values_var_7() {
    int v0;
    int v0 = andn(215163929, 0x6c346cac, 1584991345);
    return v0 - 306774097;
}

int inst_2_values_var_8() {
    int result;
    int result = andn(0x12495447, 150196169, 150196169);
    return result;
}

int inst_2_values_var_9() {
    int v0;
    int v0 = andn(753309782, 753309782, -454979743);
    return v0 + 0x3ffef8df;
}

int inst_3_flags_var_0() {
    int v0 = blsi(-1807747389, 1030955591);
    return 0;
}

int inst_3_flags_var_1() {
    int v0 = blsi(1066564479, 0xd0171c9d);
    return 0;
}

int inst_3_flags_var_2() {
    int v0 = blsi(0x12126ea7, 0xed5eabbe);
    return 8;
}

int inst_3_flags_var_3() {
    int v0 = blsi(498316846, 0xc73202bd);
    return 8;
}

int inst_3_flags_var_4() {
    int v0 = blsi(808261993, -1320743554);
    return 8;
}

int inst_3_flags_var_5() {
    int v0 = blsi(0x84ed321e, -759588923);
    return 8;
}

int inst_3_flags_var_6() {
    int v0 = blsi(0x88158a, 1946590059);
    return 0;
}

int inst_3_flags_var_7() {
    int v0 = blsi(1363662653, 0x4ad06141);
    return 8;
}

int inst_3_flags_var_8() {
    int v0 = blsi(-139714925, -139714925);
    return 0;
}

int inst_3_flags_var_9() {
    int v0 = blsi(-598015001, -598015001);
    return 8;
}

int inst_3_values_var_0() {
    int v0;
    int v0 = blsi(0xebfee2b8, 437004800);
    return v0 - 0x200;
}

int inst_3_values_var_1() {
    int v0;
    int v0 = blsi(-933029198, 1343054428);
    return v0 - 4;
}

int inst_3_values_var_2() {
    int v0;
    int v0 = blsi(538392238, 538392238);
    return v0 - 2;
}

int inst_3_values_var_3() {
    int v0;
    int v0 = blsi(215122495, 902325075);
    return v0 - 1;
}

int inst_3_values_var_4() {
    int v0;
    int v0 = blsi(0xa739881d, 0xc7cccb6c);
    return v0 - 4;
}

int inst_3_values_var_5() {
    int v0;
    int v0 = blsi(-734989070, -270889596);
    return v0 - 4;
}

int inst_3_values_var_6() {
    int v0;
    int v0 = blsi(1169696927, 1060169882);
    return v0 - 2;
}

int inst_3_values_var_7() {
    int v0;
    int v0 = blsi(-681047177, 1059176992);
    return v0 - 32;
}

int inst_3_values_var_8() {
    int v0;
    int v0 = blsi(1238122988, 1238122988);
    return v0 - 4;
}

int inst_3_values_var_9() {
    int v0;
    int v0 = blsi(952452799, 980152434);
    return v0 - 2;
}

int inst_4_flags_var_0() {
    int v0 = blsmsk(-1322116069, 1842357483);
    return 1;
}

int inst_4_flags_var_1() {
    int v0 = blsmsk(-1703365351, -1873216468);
    return 1;
}

int inst_4_flags_var_2() {
    int v0 = blsmsk(0xde0128d6, 0x904454af);
    return 1;
}

int inst_4_flags_var_3() {
    int v0 = blsmsk(-1882985646, -1687383045);
    return 1;
}

int inst_4_flags_var_4() {
    int v0 = blsmsk(0xfd274276, 0xa1e71756);
    return 9;
}

int inst_4_flags_var_5() {
    int v0 = blsmsk(0xe9b4eef5, 0xe9b4eef5);
    return 1;
}

int inst_4_flags_var_6() {
    int v0 = blsmsk(0x590cbc3e, -850692468);
    return 1;
}

int inst_4_flags_var_7() {
    int v0 = blsmsk(-1612268640, -1612268640);
    return 9;
}

int inst_4_flags_var_8() {
    int v0 = blsmsk(2034290544, 0xf9aa2c46);
    return 1;
}

int inst_4_flags_var_9() {
    int v0 = blsmsk(-1999540009, 0xb046a6ec);
    return 1;
}

int inst_4_values_var_0() {
    int v0;
    int v0 = blsmsk(530892275, 2120809704);
    return v0 - 15;
}

int inst_4_values_var_1() {
    int v0;
    int v0 = blsmsk(158087119, -332639464);
    return v0 - 15;
}

int inst_4_values_var_2() {
    int v0;
    int v0 = blsmsk(481028722, 808388595);
    return v0 - 1;
}

int inst_4_values_var_3() {
    int v0;
    int v0 = blsmsk(1927176260, 703910125);
    return v0 - 1;
}

int inst_4_values_var_4() {
    int v0;
    int v0 = blsmsk(-1956667713, -1956667713);
    return v0 - 1;
}

int inst_4_values_var_5() {
    int v0;
    int v0 = blsmsk(-753136841, 1944871480);
    return v0 - 15;
}

int inst_4_values_var_6() {
    int v0;
    int v0 = blsmsk(0x56555c06, 1258183423);
    return v0 - 1;
}

int inst_4_values_var_7() {
    int v0;
    int v0 = blsmsk(-1221675917, 1126924656);
    return v0 - 31;
}

int inst_4_values_var_8() {
    int v0;
    int v0 = blsmsk(-1253963399, 0xfdadb739);
    return v0 - 1;
}

int inst_4_values_var_9() {
    int v0;
    int v0 = blsmsk(0x443eaeb4, 43247894);
    return v0 - 3;
}

int inst_5_flags_var_0() {
    int v0 = blsr(1151943019, 255914869);
    return 9;
}

int inst_5_flags_var_1() {
    int v0 = blsr(-780928624, 0xcadc2224);
    return -7;
}

int inst_5_flags_var_2() {
    int v0 = blsr(1673750686, 1673750686);
    return 1;
}

int inst_5_flags_var_3() {
    int v0 = blsr(171917133, 1041849970);
    return 1;
}

int inst_5_flags_var_4() {
    int v0 = blsr(-1194443227, 939280587);
    return 9;
}

int inst_5_flags_var_5() {
    int v0 = blsr(29544238, 762362608);
    return 9;
}

int inst_5_flags_var_6() {
    int v0 = blsr(-312432251, -244542924);
    return 1;
}

int inst_5_flags_var_7() {
    int v0 = blsr(0xccf66f44, 805505110);
    return 1;
}

int inst_5_flags_var_8() {
    int v0 = blsr(-1662388319, -1662388319);
    return 1;
}

int inst_5_flags_var_9() {
    int v0 = blsr(1648787946, 0x66805080);
    return 9;
}

int inst_5_values_var_0() {
    int v0;
    int v0 = blsr(2045772907, 1750657869);
    return v0 - 1750657868;
}

int inst_5_values_var_1() {
    int v0;
    int v0 = blsr(1306237287, -674067516);
    return v0 + 674067520;
}

int inst_5_values_var_2() {
    int v0;
    int v0 = blsr(1193946833, 1636353023);
    return v0 - 1636353022;
}

int inst_5_values_var_3() {
    int v0;
    int v0 = blsr(1074644795, 1996579571);
    return v0 - 1996579570;
}

int inst_5_values_var_4() {
    int v0;
    int v0 = blsr(1723709377, -1939492126);
    return v0 + 1939492128;
}

int inst_5_values_var_5() {
    int v0;
    int v0 = blsr(0x15bdd91b, 0x15bdd91b);
    return v0 - 364763418;
}

int inst_5_values_var_6() {
    int v0;
    int v0 = blsr(1408072877, 2032375192);
    return v0 - 2032375184;
}

int inst_5_values_var_7() {
    int v0;
    int v0 = blsr(-1094474362, 1530790769);
    return v0 - 0x5b3e0370;
}

int inst_5_values_var_8() {
    int v0;
    int v0 = blsr(1339912758, 1803027153);
    return v0 - 1803027152;
}

int inst_5_values_var_9() {
    int v0;
    int v0 = blsr(-1321307520, -1321307520);
    return v0 + 1321307648;
}

int inst_6_flags_var_0() {
    int v0 = bextr(694167435, -1179826322, 694167435);
    return 1;
}

int inst_6_flags_var_1() {
    int v0 = bextr(-1676578967, 2004323, -1326351268);
    return 1;
}

int inst_6_flags_var_2() {
    int v0 = bextr(0x988055ee, 0x988055ee, 1319547959);
    return 1;
}

int inst_6_flags_var_3() {
    int v0 = bextr(0xac6a6701, 0x668bdb1d, 67001664);
    return 1;
}

int inst_6_flags_var_4() {
    int v0 = bextr(805616145, 426724222, -1514787596);
    return 1;
}

int inst_6_flags_var_5() {
    int v0 = bextr(-1260280127, -1260280127, 594102226);
    return 1;
}

int inst_6_flags_var_6() {
    int v0 = bextr(-48770598, -48770598, 0x9ab49b3a);
    return 1;
}

int inst_6_flags_var_7() {
    int v0 = bextr(1058407064, 981086859, 981086859);
    return 1;
}

int inst_6_flags_var_8() {
    int v0 = bextr(2099985620, 2138912933, 2099985620);
    return 1;
}

int inst_6_flags_var_9() {
    int v0 = bextr(0x4dd050fe, -480391534, -1384511415);
    return 1;
}

int inst_6_values_var_0() {
    int result;
    int result = bextr(-256767127, 0x7770aa9e, 1895744606);
    return result;
}

int inst_6_values_var_1() {
    int result;
    int result = bextr(-1016296040, -1016296040, 564878787);
    return result;
}

int inst_6_values_var_2() {
    int result;
    int result = bextr(-1869193418, -1296678331, 1459284418);
    return result;
}

int inst_6_values_var_3() {
    int result;
    int result = bextr(-1253447108, 934522178, 0x7c680447);
    return result;
}

int inst_6_values_var_4() {
    int result;
    int result = bextr(367021016, -242389190, 1946386659);
    return result;
}

int inst_6_values_var_5() {
    int v0;
    int v0 = bextr(1958584656, 0x7d697bcd, 0x282dc11d);
    return v0 - 3;
}

int inst_6_values_var_6() {
    int result;
    int result = bextr(766614703, -2017462060, 0xdd85f664);
    return result;
}

int inst_6_values_var_7() {
    int result;
    int result = bextr(1438030035, 1185662917, 1438030035);
    return result;
}

int inst_6_values_var_8() {
    int result;
    int result = bextr(0x9c956587, -2000581400, 0x9c956587);
    return result;
}

int inst_6_values_var_9() {
    int result;
    int result = bextr(246954767, 330312352, 330312352);
    return result;
}

int inst_7_flags_var_0() {
    int v0 = bzhi(1305702530, -1085148093, -1085148093);
    return -8;
}

int inst_7_flags_var_1() {
    int v0 = bzhi(2009320288, -812203667, 0x9454f9ce);
    return 0;
}

int inst_7_flags_var_2() {
    int v0 = bzhi(-1174035201, -1174035201, 1100954588);
    return 0;
}

int inst_7_flags_var_3() {
    int v0 = bzhi(1714311295, 718085948, 372113305);
    return 8;
}

int inst_7_flags_var_4() {
    int v0 = bzhi(0xf2a2d6d3, 0xf2a2d6d3, -818907063);
    return -8;
}

int inst_7_flags_var_5() {
    int v0 = bzhi(0x3e111b13, 282726464, -822143668);
    return 0;
}

int inst_7_flags_var_6() {
    int v0 = bzhi(0xf33b6ca7, 0x123c80fd, 1302601816);
    return 8;
}

int inst_7_flags_var_7() {
    int v0 = bzhi(-59667162, -2108002392, 0x85b5db6e);
    return 0;
}

int inst_7_flags_var_8() {
    int v0 = bzhi(999308937, 0x9aa754cf, 529022561);
    return 0;
}

int inst_7_flags_var_9() {
    int v0 = bzhi(-1613316381, -1231270776, 564005748);
    return 0;
}

int inst_7_values_var_0() {
    int v0;
    int v0 = bzhi(1145667094, 79388349, 79388349);
    return v0 - 79388349;
}

int inst_7_values_var_1() {
    int v0;
    int v0 = bzhi(-1521771793, 1359105087, -967814665);
    return v0 - 1359105087;
}

int inst_7_values_var_2() {
    int v0;
    int v0 = bzhi(0xf8f04766, 0xf8f04766, -1161608887);
    return v0 + 0x70fb89a;
}

int inst_7_values_var_3() {
    int v0;
    int v0 = bzhi(-1263375437, -1026125770, -526142712);
    return v0 - 54;
}

int inst_7_values_var_4() {
    int v0;
    int v0 = bzhi(-1570772981, -1173334250, 0xb24ffed8);
    return v0 + 1173334250;
}

int inst_7_values_var_5() {
    int v0;
    int v0 = bzhi(1161190970, 1362578725, 1189559589);
    return v0 - 1362578725;
}

int inst_7_values_var_6() {
    int v0;
    int v0 = bzhi(382112757, 0xdf6198f2, 0xa44aadc1);
    return v0 + 0x209e670e;
}

int inst_7_values_var_7() {
    int v0;
    int v0 = bzhi(-1713271080, -2111262161, -428628468);
    return v0 - 0x22f;
}

int inst_7_values_var_8() {
    int v0;
    int v0 = bzhi(-727298726, -1715693770, 385455751);
    return v0 + 1715693770;
}

int inst_7_values_var_9() {
    int v0;
    int v0 = bzhi(-1959771373, -777809247, 1759999273);
    return v0 + 777809247;
}

int inst_8_flags_var_0() {
    int v0 = mulx(-284679714, 0x3d122fcd, -53022491, -53022491);
    return 0;
}

int inst_8_flags_var_1() {
    int v0 = mulx(-953092362, 1098341879, 1174986949, 1098341879);
    return 0;
}

int inst_8_flags_var_2() {
    int v0 = mulx(-1634990313, 673388382, -1514803999, 1933729674);
    return 0;
}

int inst_8_flags_var_3() {
    int v0 = mulx(-1546162282, 613713979, 613713979, 1588786028);
    return 0;
}

int inst_8_flags_var_4() {
    int v0 = mulx(0xe13b83e2, 872126115, 0xe13b83e2, 0xa32212c6);
    return 0;
}

int inst_8_flags_var_5() {
    int v0 = mulx(-117796926, -13880156, -384360573, 821530981);
    return 0;
}

int inst_8_flags_var_6() {
    int v0 = mulx(-662963456, 0x5863abca, 0x5863abca, -1976861742);
    return 0;
}

int inst_8_flags_var_7() {
    int v0 = mulx(111255289, 111255289, 610139512, 0x89998dd2);
    return 0;
}

int inst_8_flags_var_8() {
    int v0 = mulx(-1134599381, 1614996729, 1614996729, 1437352552);
    return 0;
}

int inst_8_flags_var_9() {
    int v0 = mulx(1101146658, -155275512, -155275512, 1101146658);
    return 0;
}

int inst_8_values_var_0() {
    int v0;
    int v0 = mulx(1227243339, 15805272, 1570114582, 15805272);
    return v0 + 0x404727af;
}

int inst_8_values_var_1() {
    int v0;
    int v0 = mulx(194655618, -1512957004, 0xe6bcc822, 0xfad801fb);
    return v0 - 0x44d54c25;
}

int inst_8_values_var_2() {
    int v0;
    int v0 = mulx(1226395098, -1865832823, 1226395098, 1226395098);
    return v0 - 609658881;
}

int inst_8_values_var_3() {
    int v0;
    int v0 = mulx(0x39365288, -1259897283, 0xd1fc2779, 1612234661);
    return v0 - 641471843;
}

int inst_8_values_var_4() {
    int v0;
    int v0 = mulx(-2057645707, 1087955994, 2085392102, 1087955994);
    return v0 + 1078007212;
}

int inst_8_values_var_5() {
    int v0;
    int v0 = mulx(1385154031, 1385154031, 1764233000, 1764233000);
    return v0 - 0x2b31e2b3;
}

int inst_8_values_var_6() {
    int v0;
    int v0 = mulx(270513110, -724516344, 153469715, -2053839315);
    return v0 - 1591184054;
}

int inst_8_values_var_7() {
    int v0;
    int v0 = mulx(-395610815, -395610815, 1225906289, -1891800769);
    return v0 - 685932337;
}

int inst_8_values_var_8() {
    int v0;
    int v0 = mulx(1409607103, 895019480, 0x72344d4e, 0x76454be5);
    return v0 - 1155472516;
}

int inst_8_values_var_9() {
    int v0;
    int v0 = mulx(0x2bdb15a, 0x720e0277, 0x2bdb15a, 1981759782);
    return v0 - 0x174bf04f;
}

int inst_9_flags_var_0() {
    int v0 = pdep(-1491517954, -1491517954, -1491517954);
    return 0;
}

int inst_9_flags_var_1() {
    int v0 = pdep(733223230, 1351319167, -873885173);
    return 0;
}

int inst_9_flags_var_2() {
    int v0 = pdep(1523624175, 1523624175, -694885199);
    return 0;
}

int inst_9_flags_var_3() {
    int v0 = pdep(0x49d3565d, -1312818616, -1312818616);
    return 0;
}

int inst_9_flags_var_4() {
    int v0 = pdep(-169842383, 1899474334, -614718818);
    return 0;
}

int inst_9_flags_var_5() {
    int v0 = pdep(-87208366, 0x60a6888e, 723882488);
    return 0;
}

int inst_9_flags_var_6() {
    int v0 = pdep(724644088, 935824922, -378678104);
    return 0;
}

int inst_9_flags_var_7() {
    int v0 = pdep(0x731e9e31, 241885779, 1555957231);
    return 0;
}

int inst_9_flags_var_8() {
    int v0 = pdep(0xe2f9cfcf, 0x56b9999b, 0x183fd828);
    return 0;
}

int inst_9_flags_var_9() {
    int v0 = pdep(-1464966154, -1464966154, -119123428);
    return 0;
}

int inst_9_values_var_0() {
    int v0;
    int v0 = pdep(-883761314, 810472581, 0xe131999e);
    return v0 + 0x3eefeff6;
}

int inst_9_values_var_1() {
    int v0;
    int v0 = pdep(40225343, 40225343, -1956161676);
    return v0 - 184877940;
}

int inst_9_values_var_2() {
    int v0;
    int v0 = pdep(549744318, -886848968, -886848968);
    return v0 - 0x100c200;
}

int inst_9_values_var_3() {
    int v0;
    int v0 = pdep(-1006219089, 1592238105, 1975984891);
    return v0 - 1954545713;
}

int inst_9_values_var_4() {
    int v0;
    int v0 = pdep(347334294, 639118170, 908879221);
    return v0 - 0x4244464;
}

int inst_9_values_var_5() {
    int v0;
    int v0 = pdep(216711758, -1803723064, 135702290);
    return v0 - 135430656;
}

int inst_9_values_var_6() {
    int v0;
    int v0 = pdep(-1530661910, 1217970998, -741611363);
    return v0 - 50432140;
}

int inst_9_values_var_7() {
    int v0;
    int v0 = pdep(0x73c11c21, -1982522562, -1982522562);
    return v0 + 0x7faeeec4;
}

int inst_9_values_var_8() {
    int v0;
    int v0 = pdep(0x2835202a, 719069503, -1588215896);
    return v0 - 4204456;
}

int inst_9_values_var_9() {
    int v0;
    int v0 = pdep(-932340681, -932340681, -932340681);
    return v0 + 1070857177;
}

void main() {
    // Decompilation error
}

int register_tm_clones() {
    return 0;
}

void r→__assert_fail(char* __assertion, char* __file, unsigned int __line, char* __function) {
    /*BAD_CALL!*/ sub_8049030();
}

int r→__libc_start_main() {
    /*BAD_CALL!*/ sub_8049030();
}

void sub_8049030() {
    jump gvar_8056008;
}

void sub_8049CD7() {
}

void →__assert_fail(char* __assertion, char* __file, unsigned int __line, char* __function) {
    ptr___assert_fail[0]{r→__assert_fail}(__assertion, __file, __line, __function);
}

int →__libc_start_main() {
    return ptr___libc_start_main{r→__libc_start_main}();
}
