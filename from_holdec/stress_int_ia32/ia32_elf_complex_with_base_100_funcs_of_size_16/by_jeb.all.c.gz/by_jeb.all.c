
void __libc_csu_fini() {
}

int __libc_csu_init(int param0, int param1, int param2) {
    int result;
    initializer_0();
    unsigned int v0 = 0;
    do {
        result = *(int*)(v0 * 4 + (int)&__frame_dummy_init_array_entry){initializer_1}();
        ++v0;
    }
    while(v0 != 1);
    return result;
}

void __x86.get_pc_thunk.bx() {
}

void _dl_relocate_static_pie() {
}

int _start(int param0, int param1) {
    int v0;
    char v1;
    void* ptr0;
    int v2;
    int v3 = 0;
    char v4 = 1;
    char v5 = 0;
    char v6 = 1;
    char v7 = 0;
    char v8 = 0;
    int v9 = v0;
    int* ptr1 = &v1;
    char v10 = &v0 ? 0: 1;
    char v11 = (int)&v0 < 0;
    char v12 = __parity__((unsigned char)&v0);
    char v13 = 0;
    char v14 = 0;
    int v15 = v2;
    int* ptr2 = &v15;
    int* ptr3 = &v15;
    int v16 = param1;
    int v17 = &loc_8049374;
    int v18 = &loc_8049374;
    int v19 = &_GLOBAL_OFFSET_TABLE_;
    char v20 = 0;
    char v21 = 0;
    char v22 = 1;
    char v23 = 1;
    char v24 = 0;
    char v25 = 0;
    int v26 = &__libc_csu_fini;
    int v27 = &__libc_csu_fini;
    int v28 = &__libc_csu_init;
    int v29 = &__libc_csu_init;
    int* ptr4 = &v1;
    int v30 = &main;
    int v31 = &main;
    int* ptr5 = &ptr0;
    →__libc_start_main();
    hlt();
}

int deregister_tm_clones() {
    return &completed.6844;
}

void finalizer_0() {
}

void finalizer_1() {
    char v0 = completed.6844 ? 0: 1;
    char v1 = completed.6844 >= 128;
    char v2 = __parity__(completed.6844);
    char v3 = completed.6844 < 0;
    char v4 = 0;
    char v5 = 0;
    jump v0 ? &sub_804944D: &sub_8049468;
}

void* initializer_0() {
    void* result = __gmon_start__;
    if(result) {
        result = (void*)result();
    }
    return result;
}

int initializer_1() {
    return register_tm_clones();
}

int log_size_4_var_000() {
    short v0;
    short v1;
    *(int*)&v0 = (unsigned int)v1;
    return 0;
}

int log_size_4_var_001() {
    short v0;
    short v1;
    *(int*)&v0 = (unsigned int)v1;
    return 0;
}

int log_size_4_var_002() {
    short v0;
    short v1;
    *(int*)&v0 = (unsigned int)v1;
    return 0;
}

int log_size_4_var_003() {
    short v0;
    short v1;
    *(int*)&v0 = (unsigned int)v1;
    return 0;
}

int log_size_4_var_004() {
    short v0;
    short v1;
    *(int*)&v0 = (unsigned int)v1;
    return 0;
}

int log_size_4_var_005() {
    short v0;
    short v1;
    *(int*)&v0 = (unsigned int)v1;
    return 0;
}

int log_size_4_var_006() {
    short v0;
    short v1;
    *(int*)&v0 = (unsigned int)v1;
    return 0;
}

int log_size_4_var_007() {
    short v0;
    short v1;
    *(int*)&v0 = (unsigned int)v1;
    return 0;
}

int log_size_4_var_008() {
    short v0;
    short v1;
    *(int*)&v0 = (unsigned int)v1;
    return 0;
}

int log_size_4_var_009() {
    short v0;
    short v1;
    *(int*)&v0 = (unsigned int)v1;
    return 0;
}

int log_size_4_var_010() {
    short v0;
    short v1;
    *(int*)&v0 = (unsigned int)v1;
    return 0;
}

int log_size_4_var_011() {
    short v0;
    short v1;
    *(int*)&v0 = (unsigned int)v1;
    return 0;
}

int log_size_4_var_012() {
    short v0;
    short v1;
    *(int*)&v0 = (unsigned int)v1;
    return 0;
}

int log_size_4_var_013() {
    short v0;
    short v1;
    *(int*)&v0 = (unsigned int)v1;
    return 0;
}

int log_size_4_var_014() {
    short v0;
    short v1;
    *(int*)&v0 = (unsigned int)v1;
    return 0;
}

int log_size_4_var_015() {
    short v0;
    short v1;
    *(int*)&v0 = (unsigned int)v1;
    return 0;
}

int log_size_4_var_016() {
    short v0;
    short v1;
    *(int*)&v0 = (unsigned int)v1;
    return 0;
}

int log_size_4_var_017() {
    short v0;
    short v1;
    *(int*)&v0 = (unsigned int)v1;
    return 0;
}

int log_size_4_var_018() {
    short v0;
    short v1;
    *(int*)&v0 = (unsigned int)v1;
    return -14260;
}

int log_size_4_var_019() {
    short v0;
    short v1;
    *(int*)&v0 = (unsigned int)v1;
    return 0;
}

int log_size_4_var_020() {
    short v0;
    short v1;
    *(int*)&v0 = (unsigned int)v1;
    return 0;
}

int log_size_4_var_021() {
    short v0;
    short v1;
    *(int*)&v0 = (unsigned int)v1;
    return 0;
}

int log_size_4_var_022() {
    short v0;
    short v1;
    *(int*)&v0 = (unsigned int)v1;
    return 0;
}

int log_size_4_var_023() {
    short v0;
    short v1;
    *(int*)&v0 = (unsigned int)v1;
    return 0;
}

int log_size_4_var_024() {
    short v0;
    short v1;
    *(int*)&v0 = (unsigned int)v1;
    return 0;
}

int log_size_4_var_025() {
    short v0;
    short v1;
    *(int*)&v0 = (unsigned int)v1;
    return 0;
}

int log_size_4_var_026() {
    short v0;
    short v1;
    *(int*)&v0 = (unsigned int)v1;
    return 0;
}

int log_size_4_var_027() {
    short v0;
    short v1;
    *(int*)&v0 = (unsigned int)v1;
    return 1827;
}

int log_size_4_var_028() {
    short v0;
    short v1;
    *(int*)&v0 = (unsigned int)v1;
    return 0;
}

int log_size_4_var_029() {
    short v0;
    short v1;
    *(int*)&v0 = (unsigned int)v1;
    return 0;
}

int log_size_4_var_030() {
    short v0;
    short v1;
    *(int*)&v0 = (unsigned int)v1;
    return 0;
}

int log_size_4_var_031() {
    short v0;
    short v1;
    *(int*)&v0 = (unsigned int)v1;
    return 0;
}

int log_size_4_var_032() {
    short v0;
    short v1;
    *(int*)&v0 = (unsigned int)v1;
    int i;
    for(i = 31; !(0x7cbc020b >>> i); --i) {
    }
    return i - 30;
}

int log_size_4_var_033() {
    short v0;
    short v1;
    *(int*)&v0 = (unsigned int)v1;
    return 0;
}

int log_size_4_var_034() {
    short v0;
    short v1;
    *(int*)&v0 = (unsigned int)v1;
    return 0;
}

int log_size_4_var_035() {
    short v0;
    short v1;
    *(int*)&v0 = (unsigned int)v1;
    return 0;
}

int log_size_4_var_036() {
    short v0;
    short v1;
    *(int*)&v0 = (unsigned int)v1;
    return 0;
}

int log_size_4_var_037() {
    short v0;
    short v1;
    *(int*)&v0 = (unsigned int)v1;
    return 3721;
}

int log_size_4_var_038() {
    short v0;
    short v1;
    *(int*)&v0 = (unsigned int)v1;
    return 0;
}

int log_size_4_var_039() {
    short v0;
    short v1;
    *(int*)&v0 = (unsigned int)v1;
    return 0;
}

int log_size_4_var_040() {
    short v0;
    short v1;
    *(int*)&v0 = (unsigned int)v1;
    return 0;
}

int log_size_4_var_041() {
    short v0;
    short v1;
    *(int*)&v0 = (unsigned int)v1;
    return 0;
}

int log_size_4_var_042() {
    short v0;
    short v1;
    *(int*)&v0 = (unsigned int)v1;
    return 0;
}

int log_size_4_var_043() {
    short v0;
    short v1;
    *(int*)&v0 = (unsigned int)v1;
    return 0;
}

int log_size_4_var_044() {
    short v0;
    short v1;
    *(int*)&v0 = (unsigned int)v1;
    return 0;
}

int log_size_4_var_045() {
    short v0;
    short v1;
    *(int*)&v0 = (unsigned int)v1;
    return 0;
}

int log_size_4_var_046() {
    short v0;
    short v1;
    *(int*)&v0 = (unsigned int)v1;
    return 0;
}

int log_size_4_var_047() {
    short v0;
    short v1;
    *(int*)&v0 = (unsigned int)v1;
    return 0;
}

int log_size_4_var_048() {
    short v0;
    short v1;
    *(int*)&v0 = (unsigned int)v1;
    return 0;
}

int log_size_4_var_049() {
    short v0;
    short v1;
    *(int*)&v0 = (unsigned int)v1;
    return 0;
}

int log_size_4_var_050() {
    short v0;
    short v1;
    *(int*)&v0 = (unsigned int)v1;
    return 0;
}

int log_size_4_var_051() {
    short v0;
    short v1;
    *(int*)&v0 = (unsigned int)v1;
    return 0;
}

int log_size_4_var_052() {
    short v0;
    short v1;
    *(int*)&v0 = (unsigned int)v1;
    return 0;
}

int log_size_4_var_053() {
    short v0;
    short v1;
    *(int*)&v0 = (unsigned int)v1;
    return 0;
}

int log_size_4_var_054() {
    short v0;
    short v1;
    *(int*)&v0 = (unsigned int)v1;
    return 0;
}

int log_size_4_var_055() {
    short v0;
    short v1;
    *(int*)&v0 = (unsigned int)v1;
    return 0;
}

int log_size_4_var_056() {
    short v0;
    short v1;
    *(int*)&v0 = (unsigned int)v1;
    return 0;
}

int log_size_4_var_057() {
    short v0;
    short v1;
    *(int*)&v0 = (unsigned int)v1;
    return 0;
}

int log_size_4_var_058() {
    short v0;
    short v1;
    *(int*)&v0 = (unsigned int)v1;
    return 0;
}

int log_size_4_var_059() {
    short v0;
    short v1;
    *(int*)&v0 = (unsigned int)v1;
    return 0;
}

int log_size_4_var_060() {
    short v0;
    short v1;
    *(int*)&v0 = (unsigned int)v1;
    return 0;
}

int log_size_4_var_061() {
    short v0;
    short v1;
    *(int*)&v0 = (unsigned int)v1;
    return 0;
}

int log_size_4_var_062() {
    short v0;
    short v1;
    *(int*)&v0 = (unsigned int)v1;
    return 0;
}

int log_size_4_var_063() {
    short v0;
    short v1;
    *(int*)&v0 = (unsigned int)v1;
    return -1235438253;
}

int log_size_4_var_064() {
    short v0;
    short v1;
    *(int*)&v0 = (unsigned int)v1;
    return 0;
}

int log_size_4_var_065() {
    short v0;
    short v1;
    *(int*)&v0 = (unsigned int)v1;
    return 0;
}

int log_size_4_var_066() {
    short v0;
    short v1;
    *(int*)&v0 = (unsigned int)v1;
    return 0;
}

int log_size_4_var_067() {
    short v0;
    short v1;
    *(int*)&v0 = (unsigned int)v1;
    return 445203194;
}

int log_size_4_var_068() {
    short v0;
    short v1;
    *(int*)&v0 = (unsigned int)v1;
    return 0;
}

int log_size_4_var_069() {
    short v0;
    short v1;
    *(int*)&v0 = (unsigned int)v1;
    return 0;
}

int log_size_4_var_070() {
    short v0;
    short v1;
    *(int*)&v0 = (unsigned int)v1;
    return 0;
}

int log_size_4_var_071() {
    short v0;
    short v1;
    *(int*)&v0 = (unsigned int)v1;
    return 0;
}

int log_size_4_var_072() {
    short v0;
    short v1;
    *(int*)&v0 = (unsigned int)v1;
    return 0;
}

int log_size_4_var_073() {
    short v0;
    short v1;
    *(int*)&v0 = (unsigned int)v1;
    return 0;
}

int log_size_4_var_074() {
    short v0;
    short v1;
    *(int*)&v0 = (unsigned int)v1;
    return 0;
}

int log_size_4_var_075() {
    short v0;
    short v1;
    *(int*)&v0 = (unsigned int)v1;
    return 0;
}

int log_size_4_var_076() {
    short v0;
    short v1;
    *(int*)&v0 = (unsigned int)v1;
    return 0;
}

int log_size_4_var_077() {
    short v0;
    short v1;
    *(int*)&v0 = (unsigned int)v1;
    int i;
    for(i = 0; !((-43662788 >>> i) & 0x1); ++i) {
    }
    return (unsigned int)((unsigned char)i & 0xf3) - 2;
}

int log_size_4_var_078() {
    short v0;
    short v1;
    *(int*)&v0 = (unsigned int)v1;
    return 0;
}

int log_size_4_var_079() {
    short v0;
    short v1;
    *(int*)&v0 = (unsigned int)v1;
    return 0;
}

int log_size_4_var_080() {
    short v0;
    short v1;
    *(int*)&v0 = (unsigned int)v1;
    return 0;
}

int log_size_4_var_081() {
    short v0;
    short v1;
    *(int*)&v0 = (unsigned int)v1;
    return 0;
}

int log_size_4_var_082() {
    short v0;
    short v1;
    *(int*)&v0 = (unsigned int)v1;
    return 0;
}

int log_size_4_var_083() {
    short v0;
    short v1;
    *(int*)&v0 = (unsigned int)v1;
    int i;
    for(i = 31; !(148282631 >>> i); --i) {
    }
    return i - 27;
}

int log_size_4_var_084() {
    short v0;
    short v1;
    *(int*)&v0 = (unsigned int)v1;
    return 0;
}

int log_size_4_var_085() {
    short v0;
    short v1;
    *(int*)&v0 = (unsigned int)v1;
    return 0;
}

int log_size_4_var_086() {
    short v0;
    short v1;
    *(int*)&v0 = (unsigned int)v1;
    return 0;
}

int log_size_4_var_087() {
    short v0;
    short v1;
    *(int*)&v0 = (unsigned int)v1;
    return 0;
}

int log_size_4_var_088() {
    short v0;
    short v1;
    *(int*)&v0 = (unsigned int)v1;
    return 0;
}

int log_size_4_var_089() {
    short v0;
    short v1;
    *(int*)&v0 = (unsigned int)v1;
    return 0;
}

int log_size_4_var_090() {
    short v0;
    short v1;
    *(int*)&v0 = (unsigned int)v1;
    return 0;
}

int log_size_4_var_091() {
    short v0;
    short v1;
    *(int*)&v0 = (unsigned int)v1;
    return 0;
}

int log_size_4_var_092() {
    short v0;
    short v1;
    *(int*)&v0 = (unsigned int)v1;
    return 0;
}

int log_size_4_var_093() {
    short v0;
    short v1;
    *(int*)&v0 = (unsigned int)v1;
    return 0;
}

int log_size_4_var_094() {
    short v0;
    short v1;
    *(int*)&v0 = (unsigned int)v1;
    return 24314;
}

int log_size_4_var_095() {
    short v0;
    short v1;
    *(int*)&v0 = (unsigned int)v1;
    return -968492320;
}

int log_size_4_var_096() {
    short v0;
    short v1;
    *(int*)&v0 = (unsigned int)v1;
    int i;
    for(i = 0; !((0x65227600 >>> i) & 0x1); ++i) {
    }
    return ((unsigned int)(unsigned short)i | ((unsigned int)636 << 16)) + 2135424217 + ((unsigned int)0x7565 | ((unsigned int)(unsigned short)(i >>> 16) << 16)) + (((unsigned int)0 | ((unsigned int)(unsigned char)__rol__((unsigned short)0 | ((unsigned short)(((unsigned int)(unsigned short)i | ((unsigned int)636 << 16)) < 2159543079) << 8), 13) << 8) | ((unsigned int)14944 << 16)) - 188399612) + 0x4f1645b5;
}

int log_size_4_var_097() {
    short v0;
    short v1;
    *(int*)&v0 = (unsigned int)v1;
    return 0;
}

int log_size_4_var_098() {
    short v0;
    short v1;
    *(int*)&v0 = (unsigned int)v1;
    int i;
    for(i = 31; !(1495320745 >>> i); --i) {
    }
    return (unsigned int)((unsigned short)(i >> 31) >>> 8) | ((unsigned int)(unsigned short)((i >> 31) >>> 16) << 16);
}

int log_size_4_var_099() {
    short v0;
    short v1;
    *(int*)&v0 = (unsigned int)v1;
    return 0;
}

int main() {
    int v0;
    char v1;
    int* ptr0;
    void* ptr1;
    int v2;
    int* ptr2 = &v1;
    char v3 = &v0 ? 0: 1;
    char v4 = (int)&v0 < 0;
    char v5 = __parity__((unsigned char)&v0);
    char v6 = 0;
    char v7 = 0;
    int v8 = v0;
    int* ptr3 = &ptr0;
    int v9 = v2;
    int* ptr4 = &v1;
    int v10 = log_size_4_var_000();
    int v11 = v10;
    int v12 = log_size_4_var_001();
    int v13 = v11;
    int v14 = v12 + v11;
    char v15 = v14 ? 0: 1;
    char v16 = v14 < 0;
    char v17 = __parity__((unsigned char)v14);
    char v18 = (((v12 ^ v13) ^ v14) >>> 4) & 0x1;
    char v19 = __carry__(v12, v13);
    char v20 = ((v14 ^ v13) & ~(v12 ^ v13)) < 0;
    int v21 = log_size_4_var_002();
    int v22 = v14;
    int v23 = v21 + v14;
    char v24 = v23 ? 0: 1;
    char v25 = v23 < 0;
    char v26 = __parity__((unsigned char)v23);
    char v27 = (((v21 ^ v22) ^ v23) >>> 4) & 0x1;
    char v28 = __carry__(v21, v22);
    char v29 = ((v23 ^ v22) & ~(v21 ^ v22)) < 0;
    int v30 = log_size_4_var_003();
    int v31 = v23;
    int v32 = v30 + v23;
    char v33 = v32 ? 0: 1;
    char v34 = v32 < 0;
    char v35 = __parity__((unsigned char)v32);
    char v36 = (((v30 ^ v31) ^ v32) >>> 4) & 0x1;
    char v37 = __carry__(v30, v31);
    char v38 = ((v32 ^ v31) & ~(v30 ^ v31)) < 0;
    int v39 = log_size_4_var_004();
    int v40 = v32;
    int v41 = v39 + v32;
    char v42 = v41 ? 0: 1;
    char v43 = v41 < 0;
    char v44 = __parity__((unsigned char)v41);
    char v45 = (((v39 ^ v40) ^ v41) >>> 4) & 0x1;
    char v46 = __carry__(v39, v40);
    char v47 = ((v41 ^ v40) & ~(v39 ^ v40)) < 0;
    int v48 = log_size_4_var_005();
    int v49 = v41;
    int v50 = v48 + v41;
    char v51 = v50 ? 0: 1;
    char v52 = v50 < 0;
    char v53 = __parity__((unsigned char)v50);
    char v54 = (((v48 ^ v49) ^ v50) >>> 4) & 0x1;
    char v55 = __carry__(v48, v49);
    char v56 = ((v50 ^ v49) & ~(v48 ^ v49)) < 0;
    int v57 = log_size_4_var_006();
    int v58 = v50;
    int v59 = v57 + v50;
    char v60 = v59 ? 0: 1;
    char v61 = v59 < 0;
    char v62 = __parity__((unsigned char)v59);
    char v63 = (((v57 ^ v58) ^ v59) >>> 4) & 0x1;
    char v64 = __carry__(v57, v58);
    char v65 = ((v59 ^ v58) & ~(v57 ^ v58)) < 0;
    int v66 = log_size_4_var_007();
    int v67 = v59;
    int v68 = v66 + v59;
    char v69 = v68 ? 0: 1;
    char v70 = v68 < 0;
    char v71 = __parity__((unsigned char)v68);
    char v72 = (((v66 ^ v67) ^ v68) >>> 4) & 0x1;
    char v73 = __carry__(v66, v67);
    char v74 = ((v68 ^ v67) & ~(v66 ^ v67)) < 0;
    int v75 = log_size_4_var_008();
    int v76 = v68;
    int v77 = v75 + v68;
    char v78 = v77 ? 0: 1;
    char v79 = v77 < 0;
    char v80 = __parity__((unsigned char)v77);
    char v81 = (((v75 ^ v76) ^ v77) >>> 4) & 0x1;
    char v82 = __carry__(v75, v76);
    char v83 = ((v77 ^ v76) & ~(v75 ^ v76)) < 0;
    int v84 = log_size_4_var_009();
    int v85 = v77;
    int v86 = v84 + v77;
    char v87 = v86 ? 0: 1;
    char v88 = v86 < 0;
    char v89 = __parity__((unsigned char)v86);
    char v90 = (((v84 ^ v85) ^ v86) >>> 4) & 0x1;
    char v91 = __carry__(v84, v85);
    char v92 = ((v86 ^ v85) & ~(v84 ^ v85)) < 0;
    int v93 = log_size_4_var_010();
    int v94 = v86;
    int v95 = v93 + v86;
    char v96 = v95 ? 0: 1;
    char v97 = v95 < 0;
    char v98 = __parity__((unsigned char)v95);
    char v99 = (((v93 ^ v94) ^ v95) >>> 4) & 0x1;
    char v100 = __carry__(v93, v94);
    char v101 = ((v95 ^ v94) & ~(v93 ^ v94)) < 0;
    int v102 = log_size_4_var_011();
    int v103 = v95;
    int v104 = v102 + v95;
    char v105 = v104 ? 0: 1;
    char v106 = v104 < 0;
    char v107 = __parity__((unsigned char)v104);
    char v108 = (((v102 ^ v103) ^ v104) >>> 4) & 0x1;
    char v109 = __carry__(v102, v103);
    char v110 = ((v104 ^ v103) & ~(v102 ^ v103)) < 0;
    int v111 = log_size_4_var_012();
    int v112 = v104;
    int v113 = v111 + v104;
    char v114 = v113 ? 0: 1;
    char v115 = v113 < 0;
    char v116 = __parity__((unsigned char)v113);
    char v117 = (((v111 ^ v112) ^ v113) >>> 4) & 0x1;
    char v118 = __carry__(v111, v112);
    char v119 = ((v113 ^ v112) & ~(v111 ^ v112)) < 0;
    int v120 = log_size_4_var_013();
    int v121 = v113;
    int v122 = v120 + v113;
    char v123 = v122 ? 0: 1;
    char v124 = v122 < 0;
    char v125 = __parity__((unsigned char)v122);
    char v126 = (((v120 ^ v121) ^ v122) >>> 4) & 0x1;
    char v127 = __carry__(v120, v121);
    char v128 = ((v122 ^ v121) & ~(v120 ^ v121)) < 0;
    int v129 = log_size_4_var_014();
    int v130 = v122;
    int v131 = v129 + v122;
    char v132 = v131 ? 0: 1;
    char v133 = v131 < 0;
    char v134 = __parity__((unsigned char)v131);
    char v135 = (((v129 ^ v130) ^ v131) >>> 4) & 0x1;
    char v136 = __carry__(v129, v130);
    char v137 = ((v131 ^ v130) & ~(v129 ^ v130)) < 0;
    int v138 = log_size_4_var_015();
    int v139 = v131;
    int v140 = v138 + v131;
    char v141 = v140 ? 0: 1;
    char v142 = v140 < 0;
    char v143 = __parity__((unsigned char)v140);
    char v144 = (((v138 ^ v139) ^ v140) >>> 4) & 0x1;
    char v145 = __carry__(v138, v139);
    char v146 = ((v140 ^ v139) & ~(v138 ^ v139)) < 0;
    int v147 = log_size_4_var_016();
    int v148 = v140;
    int v149 = v147 + v140;
    char v150 = v149 ? 0: 1;
    char v151 = v149 < 0;
    char v152 = __parity__((unsigned char)v149);
    char v153 = (((v147 ^ v148) ^ v149) >>> 4) & 0x1;
    char v154 = __carry__(v147, v148);
    char v155 = ((v149 ^ v148) & ~(v147 ^ v148)) < 0;
    int v156 = log_size_4_var_017();
    int v157 = v149;
    int v158 = v156 + v149;
    char v159 = v158 ? 0: 1;
    char v160 = v158 < 0;
    char v161 = __parity__((unsigned char)v158);
    char v162 = (((v156 ^ v157) ^ v158) >>> 4) & 0x1;
    char v163 = __carry__(v156, v157);
    char v164 = ((v158 ^ v157) & ~(v156 ^ v157)) < 0;
    int v165 = log_size_4_var_018();
    int v166 = v158;
    int v167 = v165 + v158;
    char v168 = v167 ? 0: 1;
    char v169 = v167 < 0;
    char v170 = __parity__((unsigned char)v167);
    char v171 = (((v165 ^ v166) ^ v167) >>> 4) & 0x1;
    char v172 = __carry__(v165, v166);
    char v173 = ((v167 ^ v166) & ~(v165 ^ v166)) < 0;
    int v174 = log_size_4_var_019();
    int v175 = v167;
    int v176 = v174 + v167;
    char v177 = v176 ? 0: 1;
    char v178 = v176 < 0;
    char v179 = __parity__((unsigned char)v176);
    char v180 = (((v174 ^ v175) ^ v176) >>> 4) & 0x1;
    char v181 = __carry__(v174, v175);
    char v182 = ((v176 ^ v175) & ~(v174 ^ v175)) < 0;
    int v183 = log_size_4_var_020();
    int v184 = v176;
    int v185 = v183 + v176;
    char v186 = v185 ? 0: 1;
    char v187 = v185 < 0;
    char v188 = __parity__((unsigned char)v185);
    char v189 = (((v183 ^ v184) ^ v185) >>> 4) & 0x1;
    char v190 = __carry__(v183, v184);
    char v191 = ((v185 ^ v184) & ~(v183 ^ v184)) < 0;
    int v192 = log_size_4_var_021();
    int v193 = v185;
    int v194 = v192 + v185;
    char v195 = v194 ? 0: 1;
    char v196 = v194 < 0;
    char v197 = __parity__((unsigned char)v194);
    char v198 = (((v192 ^ v193) ^ v194) >>> 4) & 0x1;
    char v199 = __carry__(v192, v193);
    char v200 = ((v194 ^ v193) & ~(v192 ^ v193)) < 0;
    int v201 = log_size_4_var_022();
    int v202 = v194;
    int v203 = v201 + v194;
    char v204 = v203 ? 0: 1;
    char v205 = v203 < 0;
    char v206 = __parity__((unsigned char)v203);
    char v207 = (((v201 ^ v202) ^ v203) >>> 4) & 0x1;
    char v208 = __carry__(v201, v202);
    char v209 = ((v203 ^ v202) & ~(v201 ^ v202)) < 0;
    int v210 = log_size_4_var_023();
    int v211 = v203;
    int v212 = v210 + v203;
    char v213 = v212 ? 0: 1;
    char v214 = v212 < 0;
    char v215 = __parity__((unsigned char)v212);
    char v216 = (((v210 ^ v211) ^ v212) >>> 4) & 0x1;
    char v217 = __carry__(v210, v211);
    char v218 = ((v212 ^ v211) & ~(v210 ^ v211)) < 0;
    int v219 = log_size_4_var_024();
    int v220 = v212;
    int v221 = v219 + v212;
    char v222 = v221 ? 0: 1;
    char v223 = v221 < 0;
    char v224 = __parity__((unsigned char)v221);
    char v225 = (((v219 ^ v220) ^ v221) >>> 4) & 0x1;
    char v226 = __carry__(v219, v220);
    char v227 = ((v221 ^ v220) & ~(v219 ^ v220)) < 0;
    int v228 = log_size_4_var_025();
    int v229 = v221;
    int v230 = v228 + v221;
    char v231 = v230 ? 0: 1;
    char v232 = v230 < 0;
    char v233 = __parity__((unsigned char)v230);
    char v234 = (((v228 ^ v229) ^ v230) >>> 4) & 0x1;
    char v235 = __carry__(v228, v229);
    char v236 = ((v230 ^ v229) & ~(v228 ^ v229)) < 0;
    int v237 = log_size_4_var_026();
    int v238 = v230;
    int v239 = v237 + v230;
    char v240 = v239 ? 0: 1;
    char v241 = v239 < 0;
    char v242 = __parity__((unsigned char)v239);
    char v243 = (((v237 ^ v238) ^ v239) >>> 4) & 0x1;
    char v244 = __carry__(v237, v238);
    char v245 = ((v239 ^ v238) & ~(v237 ^ v238)) < 0;
    int v246 = log_size_4_var_027();
    int v247 = v239;
    int v248 = v246 + v239;
    char v249 = v248 ? 0: 1;
    char v250 = v248 < 0;
    char v251 = __parity__((unsigned char)v248);
    char v252 = (((v246 ^ v247) ^ v248) >>> 4) & 0x1;
    char v253 = __carry__(v246, v247);
    char v254 = ((v248 ^ v247) & ~(v246 ^ v247)) < 0;
    int v255 = log_size_4_var_028();
    int v256 = v248;
    int v257 = v255 + v248;
    char v258 = v257 ? 0: 1;
    char v259 = v257 < 0;
    char v260 = __parity__((unsigned char)v257);
    char v261 = (((v255 ^ v256) ^ v257) >>> 4) & 0x1;
    char v262 = __carry__(v255, v256);
    char v263 = ((v257 ^ v256) & ~(v255 ^ v256)) < 0;
    int v264 = log_size_4_var_029();
    int v265 = v257;
    int v266 = v264 + v257;
    char v267 = v266 ? 0: 1;
    char v268 = v266 < 0;
    char v269 = __parity__((unsigned char)v266);
    char v270 = (((v264 ^ v265) ^ v266) >>> 4) & 0x1;
    char v271 = __carry__(v264, v265);
    char v272 = ((v266 ^ v265) & ~(v264 ^ v265)) < 0;
    int v273 = log_size_4_var_030();
    int v274 = v266;
    int v275 = v273 + v266;
    char v276 = v275 ? 0: 1;
    char v277 = v275 < 0;
    char v278 = __parity__((unsigned char)v275);
    char v279 = (((v273 ^ v274) ^ v275) >>> 4) & 0x1;
    char v280 = __carry__(v273, v274);
    char v281 = ((v275 ^ v274) & ~(v273 ^ v274)) < 0;
    int v282 = log_size_4_var_031();
    int v283 = v275;
    int v284 = v282 + v275;
    char v285 = v284 ? 0: 1;
    char v286 = v284 < 0;
    char v287 = __parity__((unsigned char)v284);
    char v288 = (((v282 ^ v283) ^ v284) >>> 4) & 0x1;
    char v289 = __carry__(v282, v283);
    char v290 = ((v284 ^ v283) & ~(v282 ^ v283)) < 0;
    int v291 = log_size_4_var_032();
    int v292 = v284;
    int v293 = v291 + v284;
    char v294 = v293 ? 0: 1;
    char v295 = v293 < 0;
    char v296 = __parity__((unsigned char)v293);
    char v297 = (((v291 ^ v292) ^ v293) >>> 4) & 0x1;
    char v298 = __carry__(v291, v292);
    char v299 = ((v293 ^ v292) & ~(v291 ^ v292)) < 0;
    int v300 = log_size_4_var_033();
    int v301 = v293;
    int v302 = v300 + v293;
    char v303 = v302 ? 0: 1;
    char v304 = v302 < 0;
    char v305 = __parity__((unsigned char)v302);
    char v306 = (((v300 ^ v301) ^ v302) >>> 4) & 0x1;
    char v307 = __carry__(v300, v301);
    char v308 = ((v302 ^ v301) & ~(v300 ^ v301)) < 0;
    int v309 = log_size_4_var_034();
    int v310 = v302;
    int v311 = v309 + v302;
    char v312 = v311 ? 0: 1;
    char v313 = v311 < 0;
    char v314 = __parity__((unsigned char)v311);
    char v315 = (((v309 ^ v310) ^ v311) >>> 4) & 0x1;
    char v316 = __carry__(v309, v310);
    char v317 = ((v311 ^ v310) & ~(v309 ^ v310)) < 0;
    int v318 = log_size_4_var_035();
    int v319 = v311;
    int v320 = v318 + v311;
    char v321 = v320 ? 0: 1;
    char v322 = v320 < 0;
    char v323 = __parity__((unsigned char)v320);
    char v324 = (((v318 ^ v319) ^ v320) >>> 4) & 0x1;
    char v325 = __carry__(v318, v319);
    char v326 = ((v320 ^ v319) & ~(v318 ^ v319)) < 0;
    int v327 = log_size_4_var_036();
    int v328 = v320;
    int v329 = v327 + v320;
    char v330 = v329 ? 0: 1;
    char v331 = v329 < 0;
    char v332 = __parity__((unsigned char)v329);
    char v333 = (((v327 ^ v328) ^ v329) >>> 4) & 0x1;
    char v334 = __carry__(v327, v328);
    char v335 = ((v329 ^ v328) & ~(v327 ^ v328)) < 0;
    int v336 = log_size_4_var_037();
    int v337 = v329;
    int v338 = v336 + v329;
    char v339 = v338 ? 0: 1;
    char v340 = v338 < 0;
    char v341 = __parity__((unsigned char)v338);
    char v342 = (((v336 ^ v337) ^ v338) >>> 4) & 0x1;
    char v343 = __carry__(v336, v337);
    char v344 = ((v338 ^ v337) & ~(v336 ^ v337)) < 0;
    int v345 = log_size_4_var_038();
    int v346 = v338;
    int v347 = v345 + v338;
    char v348 = v347 ? 0: 1;
    char v349 = v347 < 0;
    char v350 = __parity__((unsigned char)v347);
    char v351 = (((v345 ^ v346) ^ v347) >>> 4) & 0x1;
    char v352 = __carry__(v345, v346);
    char v353 = ((v347 ^ v346) & ~(v345 ^ v346)) < 0;
    int v354 = log_size_4_var_039();
    int v355 = v347;
    int v356 = v354 + v347;
    char v357 = v356 ? 0: 1;
    char v358 = v356 < 0;
    char v359 = __parity__((unsigned char)v356);
    char v360 = (((v354 ^ v355) ^ v356) >>> 4) & 0x1;
    char v361 = __carry__(v354, v355);
    char v362 = ((v356 ^ v355) & ~(v354 ^ v355)) < 0;
    int v363 = log_size_4_var_040();
    int v364 = v356;
    int v365 = v363 + v356;
    char v366 = v365 ? 0: 1;
    char v367 = v365 < 0;
    char v368 = __parity__((unsigned char)v365);
    char v369 = (((v363 ^ v364) ^ v365) >>> 4) & 0x1;
    char v370 = __carry__(v363, v364);
    char v371 = ((v365 ^ v364) & ~(v363 ^ v364)) < 0;
    int v372 = log_size_4_var_041();
    int v373 = v365;
    int v374 = v372 + v365;
    char v375 = v374 ? 0: 1;
    char v376 = v374 < 0;
    char v377 = __parity__((unsigned char)v374);
    char v378 = (((v372 ^ v373) ^ v374) >>> 4) & 0x1;
    char v379 = __carry__(v372, v373);
    char v380 = ((v374 ^ v373) & ~(v372 ^ v373)) < 0;
    int v381 = log_size_4_var_042();
    int v382 = v374;
    int v383 = v381 + v374;
    char v384 = v383 ? 0: 1;
    char v385 = v383 < 0;
    char v386 = __parity__((unsigned char)v383);
    char v387 = (((v381 ^ v382) ^ v383) >>> 4) & 0x1;
    char v388 = __carry__(v381, v382);
    char v389 = ((v383 ^ v382) & ~(v381 ^ v382)) < 0;
    int v390 = log_size_4_var_043();
    int v391 = v383;
    int v392 = v390 + v383;
    char v393 = v392 ? 0: 1;
    char v394 = v392 < 0;
    char v395 = __parity__((unsigned char)v392);
    char v396 = (((v390 ^ v391) ^ v392) >>> 4) & 0x1;
    char v397 = __carry__(v390, v391);
    char v398 = ((v392 ^ v391) & ~(v390 ^ v391)) < 0;
    int v399 = log_size_4_var_044();
    int v400 = v392;
    int v401 = v399 + v392;
    char v402 = v401 ? 0: 1;
    char v403 = v401 < 0;
    char v404 = __parity__((unsigned char)v401);
    char v405 = (((v399 ^ v400) ^ v401) >>> 4) & 0x1;
    char v406 = __carry__(v399, v400);
    char v407 = ((v401 ^ v400) & ~(v399 ^ v400)) < 0;
    int v408 = log_size_4_var_045();
    int v409 = v401;
    int v410 = v408 + v401;
    char v411 = v410 ? 0: 1;
    char v412 = v410 < 0;
    char v413 = __parity__((unsigned char)v410);
    char v414 = (((v408 ^ v409) ^ v410) >>> 4) & 0x1;
    char v415 = __carry__(v408, v409);
    char v416 = ((v410 ^ v409) & ~(v408 ^ v409)) < 0;
    int v417 = log_size_4_var_046();
    int v418 = v410;
    int v419 = v417 + v410;
    char v420 = v419 ? 0: 1;
    char v421 = v419 < 0;
    char v422 = __parity__((unsigned char)v419);
    char v423 = (((v417 ^ v418) ^ v419) >>> 4) & 0x1;
    char v424 = __carry__(v417, v418);
    char v425 = ((v419 ^ v418) & ~(v417 ^ v418)) < 0;
    int v426 = log_size_4_var_047();
    int v427 = v419;
    int v428 = v426 + v419;
    char v429 = v428 ? 0: 1;
    char v430 = v428 < 0;
    char v431 = __parity__((unsigned char)v428);
    char v432 = (((v426 ^ v427) ^ v428) >>> 4) & 0x1;
    char v433 = __carry__(v426, v427);
    char v434 = ((v428 ^ v427) & ~(v426 ^ v427)) < 0;
    int v435 = log_size_4_var_048();
    int v436 = v428;
    int v437 = v435 + v428;
    char v438 = v437 ? 0: 1;
    char v439 = v437 < 0;
    char v440 = __parity__((unsigned char)v437);
    char v441 = (((v435 ^ v436) ^ v437) >>> 4) & 0x1;
    char v442 = __carry__(v435, v436);
    char v443 = ((v437 ^ v436) & ~(v435 ^ v436)) < 0;
    int v444 = log_size_4_var_049();
    int v445 = v437;
    int v446 = v444 + v437;
    char v447 = v446 ? 0: 1;
    char v448 = v446 < 0;
    char v449 = __parity__((unsigned char)v446);
    char v450 = (((v444 ^ v445) ^ v446) >>> 4) & 0x1;
    char v451 = __carry__(v444, v445);
    char v452 = ((v446 ^ v445) & ~(v444 ^ v445)) < 0;
    int v453 = log_size_4_var_050();
    int v454 = v446;
    int v455 = v453 + v446;
    char v456 = v455 ? 0: 1;
    char v457 = v455 < 0;
    char v458 = __parity__((unsigned char)v455);
    char v459 = (((v453 ^ v454) ^ v455) >>> 4) & 0x1;
    char v460 = __carry__(v453, v454);
    char v461 = ((v455 ^ v454) & ~(v453 ^ v454)) < 0;
    int v462 = log_size_4_var_051();
    int v463 = v455;
    int v464 = v462 + v455;
    char v465 = v464 ? 0: 1;
    char v466 = v464 < 0;
    char v467 = __parity__((unsigned char)v464);
    char v468 = (((v462 ^ v463) ^ v464) >>> 4) & 0x1;
    char v469 = __carry__(v462, v463);
    char v470 = ((v464 ^ v463) & ~(v462 ^ v463)) < 0;
    int v471 = log_size_4_var_052();
    int v472 = v464;
    int v473 = v471 + v464;
    char v474 = v473 ? 0: 1;
    char v475 = v473 < 0;
    char v476 = __parity__((unsigned char)v473);
    char v477 = (((v471 ^ v472) ^ v473) >>> 4) & 0x1;
    char v478 = __carry__(v471, v472);
    char v479 = ((v473 ^ v472) & ~(v471 ^ v472)) < 0;
    int v480 = log_size_4_var_053();
    int v481 = v473;
    int v482 = v480 + v473;
    char v483 = v482 ? 0: 1;
    char v484 = v482 < 0;
    char v485 = __parity__((unsigned char)v482);
    char v486 = (((v480 ^ v481) ^ v482) >>> 4) & 0x1;
    char v487 = __carry__(v480, v481);
    char v488 = ((v482 ^ v481) & ~(v480 ^ v481)) < 0;
    int v489 = log_size_4_var_054();
    int v490 = v482;
    int v491 = v489 + v482;
    char v492 = v491 ? 0: 1;
    char v493 = v491 < 0;
    char v494 = __parity__((unsigned char)v491);
    char v495 = (((v489 ^ v490) ^ v491) >>> 4) & 0x1;
    char v496 = __carry__(v489, v490);
    char v497 = ((v491 ^ v490) & ~(v489 ^ v490)) < 0;
    int v498 = log_size_4_var_055();
    int v499 = v491;
    int v500 = v498 + v491;
    char v501 = v500 ? 0: 1;
    char v502 = v500 < 0;
    char v503 = __parity__((unsigned char)v500);
    char v504 = (((v498 ^ v499) ^ v500) >>> 4) & 0x1;
    char v505 = __carry__(v498, v499);
    char v506 = ((v500 ^ v499) & ~(v498 ^ v499)) < 0;
    int v507 = log_size_4_var_056();
    int v508 = v500;
    int v509 = v507 + v500;
    char v510 = v509 ? 0: 1;
    char v511 = v509 < 0;
    char v512 = __parity__((unsigned char)v509);
    char v513 = (((v507 ^ v508) ^ v509) >>> 4) & 0x1;
    char v514 = __carry__(v507, v508);
    char v515 = ((v509 ^ v508) & ~(v507 ^ v508)) < 0;
    int v516 = log_size_4_var_057();
    int v517 = v509;
    int v518 = v516 + v509;
    char v519 = v518 ? 0: 1;
    char v520 = v518 < 0;
    char v521 = __parity__((unsigned char)v518);
    char v522 = (((v516 ^ v517) ^ v518) >>> 4) & 0x1;
    char v523 = __carry__(v516, v517);
    char v524 = ((v518 ^ v517) & ~(v516 ^ v517)) < 0;
    int v525 = log_size_4_var_058();
    int v526 = v518;
    int v527 = v525 + v518;
    char v528 = v527 ? 0: 1;
    char v529 = v527 < 0;
    char v530 = __parity__((unsigned char)v527);
    char v531 = (((v525 ^ v526) ^ v527) >>> 4) & 0x1;
    char v532 = __carry__(v525, v526);
    char v533 = ((v527 ^ v526) & ~(v525 ^ v526)) < 0;
    int v534 = log_size_4_var_059();
    int v535 = v527;
    int v536 = v534 + v527;
    char v537 = v536 ? 0: 1;
    char v538 = v536 < 0;
    char v539 = __parity__((unsigned char)v536);
    char v540 = (((v534 ^ v535) ^ v536) >>> 4) & 0x1;
    char v541 = __carry__(v534, v535);
    char v542 = ((v536 ^ v535) & ~(v534 ^ v535)) < 0;
    int v543 = log_size_4_var_060();
    int v544 = v536;
    int v545 = v543 + v536;
    char v546 = v545 ? 0: 1;
    char v547 = v545 < 0;
    char v548 = __parity__((unsigned char)v545);
    char v549 = (((v543 ^ v544) ^ v545) >>> 4) & 0x1;
    char v550 = __carry__(v543, v544);
    char v551 = ((v545 ^ v544) & ~(v543 ^ v544)) < 0;
    int v552 = log_size_4_var_061();
    int v553 = v545;
    int v554 = v552 + v545;
    char v555 = v554 ? 0: 1;
    char v556 = v554 < 0;
    char v557 = __parity__((unsigned char)v554);
    char v558 = (((v552 ^ v553) ^ v554) >>> 4) & 0x1;
    char v559 = __carry__(v552, v553);
    char v560 = ((v554 ^ v553) & ~(v552 ^ v553)) < 0;
    int v561 = log_size_4_var_062();
    int v562 = v554;
    int v563 = v561 + v554;
    char v564 = v563 ? 0: 1;
    char v565 = v563 < 0;
    char v566 = __parity__((unsigned char)v563);
    char v567 = (((v561 ^ v562) ^ v563) >>> 4) & 0x1;
    char v568 = __carry__(v561, v562);
    char v569 = ((v563 ^ v562) & ~(v561 ^ v562)) < 0;
    int v570 = log_size_4_var_063();
    int v571 = v563;
    int v572 = v570 + v563;
    char v573 = v572 ? 0: 1;
    char v574 = v572 < 0;
    char v575 = __parity__((unsigned char)v572);
    char v576 = (((v570 ^ v571) ^ v572) >>> 4) & 0x1;
    char v577 = __carry__(v570, v571);
    char v578 = ((v572 ^ v571) & ~(v570 ^ v571)) < 0;
    int v579 = log_size_4_var_064();
    int v580 = v572;
    int v581 = v579 + v572;
    char v582 = v581 ? 0: 1;
    char v583 = v581 < 0;
    char v584 = __parity__((unsigned char)v581);
    char v585 = (((v579 ^ v580) ^ v581) >>> 4) & 0x1;
    char v586 = __carry__(v579, v580);
    char v587 = ((v581 ^ v580) & ~(v579 ^ v580)) < 0;
    int v588 = log_size_4_var_065();
    int v589 = v581;
    int v590 = v588 + v581;
    char v591 = v590 ? 0: 1;
    char v592 = v590 < 0;
    char v593 = __parity__((unsigned char)v590);
    char v594 = (((v588 ^ v589) ^ v590) >>> 4) & 0x1;
    char v595 = __carry__(v588, v589);
    char v596 = ((v590 ^ v589) & ~(v588 ^ v589)) < 0;
    int v597 = log_size_4_var_066();
    int v598 = v590;
    int v599 = v597 + v590;
    char v600 = v599 ? 0: 1;
    char v601 = v599 < 0;
    char v602 = __parity__((unsigned char)v599);
    char v603 = (((v597 ^ v598) ^ v599) >>> 4) & 0x1;
    char v604 = __carry__(v597, v598);
    char v605 = ((v599 ^ v598) & ~(v597 ^ v598)) < 0;
    int v606 = log_size_4_var_067();
    int v607 = v599;
    int v608 = v606 + v599;
    char v609 = v608 ? 0: 1;
    char v610 = v608 < 0;
    char v611 = __parity__((unsigned char)v608);
    char v612 = (((v606 ^ v607) ^ v608) >>> 4) & 0x1;
    char v613 = __carry__(v606, v607);
    char v614 = ((v608 ^ v607) & ~(v606 ^ v607)) < 0;
    int v615 = log_size_4_var_068();
    int v616 = v608;
    int v617 = v615 + v608;
    char v618 = v617 ? 0: 1;
    char v619 = v617 < 0;
    char v620 = __parity__((unsigned char)v617);
    char v621 = (((v615 ^ v616) ^ v617) >>> 4) & 0x1;
    char v622 = __carry__(v615, v616);
    char v623 = ((v617 ^ v616) & ~(v615 ^ v616)) < 0;
    int v624 = log_size_4_var_069();
    int v625 = v617;
    int v626 = v624 + v617;
    char v627 = v626 ? 0: 1;
    char v628 = v626 < 0;
    char v629 = __parity__((unsigned char)v626);
    char v630 = (((v624 ^ v625) ^ v626) >>> 4) & 0x1;
    char v631 = __carry__(v624, v625);
    char v632 = ((v626 ^ v625) & ~(v624 ^ v625)) < 0;
    int v633 = log_size_4_var_070();
    int v634 = v626;
    int v635 = v633 + v626;
    char v636 = v635 ? 0: 1;
    char v637 = v635 < 0;
    char v638 = __parity__((unsigned char)v635);
    char v639 = (((v633 ^ v634) ^ v635) >>> 4) & 0x1;
    char v640 = __carry__(v633, v634);
    char v641 = ((v635 ^ v634) & ~(v633 ^ v634)) < 0;
    int v642 = log_size_4_var_071();
    int v643 = v635;
    int v644 = v642 + v635;
    char v645 = v644 ? 0: 1;
    char v646 = v644 < 0;
    char v647 = __parity__((unsigned char)v644);
    char v648 = (((v642 ^ v643) ^ v644) >>> 4) & 0x1;
    char v649 = __carry__(v642, v643);
    char v650 = ((v644 ^ v643) & ~(v642 ^ v643)) < 0;
    int v651 = log_size_4_var_072();
    int v652 = v644;
    int v653 = v651 + v644;
    char v654 = v653 ? 0: 1;
    char v655 = v653 < 0;
    char v656 = __parity__((unsigned char)v653);
    char v657 = (((v651 ^ v652) ^ v653) >>> 4) & 0x1;
    char v658 = __carry__(v651, v652);
    char v659 = ((v653 ^ v652) & ~(v651 ^ v652)) < 0;
    int v660 = log_size_4_var_073();
    int v661 = v653;
    int v662 = v660 + v653;
    char v663 = v662 ? 0: 1;
    char v664 = v662 < 0;
    char v665 = __parity__((unsigned char)v662);
    char v666 = (((v660 ^ v661) ^ v662) >>> 4) & 0x1;
    char v667 = __carry__(v660, v661);
    char v668 = ((v662 ^ v661) & ~(v660 ^ v661)) < 0;
    int v669 = log_size_4_var_074();
    int v670 = v662;
    int v671 = v669 + v662;
    char v672 = v671 ? 0: 1;
    char v673 = v671 < 0;
    char v674 = __parity__((unsigned char)v671);
    char v675 = (((v669 ^ v670) ^ v671) >>> 4) & 0x1;
    char v676 = __carry__(v669, v670);
    char v677 = ((v671 ^ v670) & ~(v669 ^ v670)) < 0;
    int v678 = log_size_4_var_075();
    int v679 = v671;
    int v680 = v678 + v671;
    char v681 = v680 ? 0: 1;
    char v682 = v680 < 0;
    char v683 = __parity__((unsigned char)v680);
    char v684 = (((v678 ^ v679) ^ v680) >>> 4) & 0x1;
    char v685 = __carry__(v678, v679);
    char v686 = ((v680 ^ v679) & ~(v678 ^ v679)) < 0;
    int v687 = log_size_4_var_076();
    int v688 = v680;
    int v689 = v687 + v680;
    char v690 = v689 ? 0: 1;
    char v691 = v689 < 0;
    char v692 = __parity__((unsigned char)v689);
    char v693 = (((v687 ^ v688) ^ v689) >>> 4) & 0x1;
    char v694 = __carry__(v687, v688);
    char v695 = ((v689 ^ v688) & ~(v687 ^ v688)) < 0;
    int v696 = log_size_4_var_077();
    int v697 = v689;
    int v698 = v696 + v689;
    char v699 = v698 ? 0: 1;
    char v700 = v698 < 0;
    char v701 = __parity__((unsigned char)v698);
    char v702 = (((v696 ^ v697) ^ v698) >>> 4) & 0x1;
    char v703 = __carry__(v696, v697);
    char v704 = ((v698 ^ v697) & ~(v696 ^ v697)) < 0;
    int v705 = log_size_4_var_078();
    int v706 = v698;
    int v707 = v705 + v698;
    char v708 = v707 ? 0: 1;
    char v709 = v707 < 0;
    char v710 = __parity__((unsigned char)v707);
    char v711 = (((v705 ^ v706) ^ v707) >>> 4) & 0x1;
    char v712 = __carry__(v705, v706);
    char v713 = ((v707 ^ v706) & ~(v705 ^ v706)) < 0;
    int v714 = log_size_4_var_079();
    int v715 = v707;
    int v716 = v714 + v707;
    char v717 = v716 ? 0: 1;
    char v718 = v716 < 0;
    char v719 = __parity__((unsigned char)v716);
    char v720 = (((v714 ^ v715) ^ v716) >>> 4) & 0x1;
    char v721 = __carry__(v714, v715);
    char v722 = ((v716 ^ v715) & ~(v714 ^ v715)) < 0;
    int v723 = log_size_4_var_080();
    int v724 = v716;
    int v725 = v723 + v716;
    char v726 = v725 ? 0: 1;
    char v727 = v725 < 0;
    char v728 = __parity__((unsigned char)v725);
    char v729 = (((v723 ^ v724) ^ v725) >>> 4) & 0x1;
    char v730 = __carry__(v723, v724);
    char v731 = ((v725 ^ v724) & ~(v723 ^ v724)) < 0;
    int v732 = log_size_4_var_081();
    int v733 = v725;
    int v734 = v732 + v725;
    char v735 = v734 ? 0: 1;
    char v736 = v734 < 0;
    char v737 = __parity__((unsigned char)v734);
    char v738 = (((v732 ^ v733) ^ v734) >>> 4) & 0x1;
    char v739 = __carry__(v732, v733);
    char v740 = ((v734 ^ v733) & ~(v732 ^ v733)) < 0;
    int v741 = log_size_4_var_082();
    int v742 = v734;
    int v743 = v741 + v734;
    char v744 = v743 ? 0: 1;
    char v745 = v743 < 0;
    char v746 = __parity__((unsigned char)v743);
    char v747 = (((v741 ^ v742) ^ v743) >>> 4) & 0x1;
    char v748 = __carry__(v741, v742);
    char v749 = ((v743 ^ v742) & ~(v741 ^ v742)) < 0;
    int v750 = log_size_4_var_083();
    int v751 = v743;
    int v752 = v750 + v743;
    char v753 = v752 ? 0: 1;
    char v754 = v752 < 0;
    char v755 = __parity__((unsigned char)v752);
    char v756 = (((v750 ^ v751) ^ v752) >>> 4) & 0x1;
    char v757 = __carry__(v750, v751);
    char v758 = ((v752 ^ v751) & ~(v750 ^ v751)) < 0;
    int v759 = log_size_4_var_084();
    int v760 = v752;
    int v761 = v759 + v752;
    char v762 = v761 ? 0: 1;
    char v763 = v761 < 0;
    char v764 = __parity__((unsigned char)v761);
    char v765 = (((v759 ^ v760) ^ v761) >>> 4) & 0x1;
    char v766 = __carry__(v759, v760);
    char v767 = ((v761 ^ v760) & ~(v759 ^ v760)) < 0;
    int v768 = log_size_4_var_085();
    int v769 = v761;
    int v770 = v768 + v761;
    char v771 = v770 ? 0: 1;
    char v772 = v770 < 0;
    char v773 = __parity__((unsigned char)v770);
    char v774 = (((v768 ^ v769) ^ v770) >>> 4) & 0x1;
    char v775 = __carry__(v768, v769);
    char v776 = ((v770 ^ v769) & ~(v768 ^ v769)) < 0;
    int v777 = log_size_4_var_086();
    int v778 = v770;
    int v779 = v777 + v770;
    char v780 = v779 ? 0: 1;
    char v781 = v779 < 0;
    char v782 = __parity__((unsigned char)v779);
    char v783 = (((v777 ^ v778) ^ v779) >>> 4) & 0x1;
    char v784 = __carry__(v777, v778);
    char v785 = ((v779 ^ v778) & ~(v777 ^ v778)) < 0;
    int v786 = log_size_4_var_087();
    int v787 = v779;
    int v788 = v786 + v779;
    char v789 = v788 ? 0: 1;
    char v790 = v788 < 0;
    char v791 = __parity__((unsigned char)v788);
    char v792 = (((v786 ^ v787) ^ v788) >>> 4) & 0x1;
    char v793 = __carry__(v786, v787);
    char v794 = ((v788 ^ v787) & ~(v786 ^ v787)) < 0;
    int v795 = log_size_4_var_088();
    int v796 = v788;
    int v797 = v795 + v788;
    char v798 = v797 ? 0: 1;
    char v799 = v797 < 0;
    char v800 = __parity__((unsigned char)v797);
    char v801 = (((v795 ^ v796) ^ v797) >>> 4) & 0x1;
    char v802 = __carry__(v795, v796);
    char v803 = ((v797 ^ v796) & ~(v795 ^ v796)) < 0;
    int v804 = log_size_4_var_089();
    int v805 = v797;
    int v806 = v804 + v797;
    char v807 = v806 ? 0: 1;
    char v808 = v806 < 0;
    char v809 = __parity__((unsigned char)v806);
    char v810 = (((v804 ^ v805) ^ v806) >>> 4) & 0x1;
    char v811 = __carry__(v804, v805);
    char v812 = ((v806 ^ v805) & ~(v804 ^ v805)) < 0;
    int v813 = log_size_4_var_090();
    int v814 = v806;
    int v815 = v813 + v806;
    char v816 = v815 ? 0: 1;
    char v817 = v815 < 0;
    char v818 = __parity__((unsigned char)v815);
    char v819 = (((v813 ^ v814) ^ v815) >>> 4) & 0x1;
    char v820 = __carry__(v813, v814);
    char v821 = ((v815 ^ v814) & ~(v813 ^ v814)) < 0;
    int v822 = log_size_4_var_091();
    int v823 = v815;
    int v824 = v822 + v815;
    char v825 = v824 ? 0: 1;
    char v826 = v824 < 0;
    char v827 = __parity__((unsigned char)v824);
    char v828 = (((v822 ^ v823) ^ v824) >>> 4) & 0x1;
    char v829 = __carry__(v822, v823);
    char v830 = ((v824 ^ v823) & ~(v822 ^ v823)) < 0;
    int v831 = log_size_4_var_092();
    int v832 = v824;
    int v833 = v831 + v824;
    char v834 = v833 ? 0: 1;
    char v835 = v833 < 0;
    char v836 = __parity__((unsigned char)v833);
    char v837 = (((v831 ^ v832) ^ v833) >>> 4) & 0x1;
    char v838 = __carry__(v831, v832);
    char v839 = ((v833 ^ v832) & ~(v831 ^ v832)) < 0;
    int v840 = log_size_4_var_093();
    int v841 = v833;
    int v842 = v840 + v833;
    char v843 = v842 ? 0: 1;
    char v844 = v842 < 0;
    char v845 = __parity__((unsigned char)v842);
    char v846 = (((v840 ^ v841) ^ v842) >>> 4) & 0x1;
    char v847 = __carry__(v840, v841);
    char v848 = ((v842 ^ v841) & ~(v840 ^ v841)) < 0;
    int v849 = log_size_4_var_094();
    int v850 = v842;
    int v851 = v849 + v842;
    char v852 = v851 ? 0: 1;
    char v853 = v851 < 0;
    char v854 = __parity__((unsigned char)v851);
    char v855 = (((v849 ^ v850) ^ v851) >>> 4) & 0x1;
    char v856 = __carry__(v849, v850);
    char v857 = ((v851 ^ v850) & ~(v849 ^ v850)) < 0;
    int v858 = log_size_4_var_095();
    int v859 = v851;
    int v860 = v858 + v851;
    char v861 = v860 ? 0: 1;
    char v862 = v860 < 0;
    char v863 = __parity__((unsigned char)v860);
    char v864 = (((v858 ^ v859) ^ v860) >>> 4) & 0x1;
    char v865 = __carry__(v858, v859);
    char v866 = ((v860 ^ v859) & ~(v858 ^ v859)) < 0;
    int v867 = log_size_4_var_096();
    int v868 = v860;
    int v869 = v867 + v860;
    char v870 = v869 ? 0: 1;
    char v871 = v869 < 0;
    char v872 = __parity__((unsigned char)v869);
    char v873 = (((v867 ^ v868) ^ v869) >>> 4) & 0x1;
    char v874 = __carry__(v867, v868);
    char v875 = ((v869 ^ v868) & ~(v867 ^ v868)) < 0;
    int v876 = log_size_4_var_097();
    int v877 = v869;
    int v878 = v876 + v869;
    char v879 = v878 ? 0: 1;
    char v880 = v878 < 0;
    char v881 = __parity__((unsigned char)v878);
    char v882 = (((v876 ^ v877) ^ v878) >>> 4) & 0x1;
    char v883 = __carry__(v876, v877);
    char v884 = ((v878 ^ v877) & ~(v876 ^ v877)) < 0;
    int v885 = log_size_4_var_098();
    int v886 = v878;
    int v887 = v885 + v878;
    char v888 = v887 ? 0: 1;
    char v889 = v887 < 0;
    char v890 = __parity__((unsigned char)v887);
    char v891 = (((v885 ^ v886) ^ v887) >>> 4) & 0x1;
    char v892 = __carry__(v885, v886);
    char v893 = ((v887 ^ v886) & ~(v885 ^ v886)) < 0;
    int v894 = log_size_4_var_099();
    int v895 = v887;
    int v896 = v894 + v887;
    char v897 = v896 ? 0: 1;
    char v898 = v896 < 0;
    char v899 = __parity__((unsigned char)v896);
    char v900 = (((v894 ^ v895) ^ v896) >>> 4) & 0x1;
    char v901 = __carry__(v894, v895);
    char v902 = ((v896 ^ v895) & ~(v894 ^ v895)) < 0;
    if(!v897) {
        int* ptr5 = &ptr1;
        /*NO_RETURN*/ →__assert_fail("sum==0", "source_complex_with_base_100_funcs_of_size_16.c", 211, (char*)&__PRETTY_FUNCTION__.2306);
    }
    return 0;
}

int register_tm_clones() {
    return 0;
}

int sub_8049036() {
    return gvar_804F008();
}

void sub_8049397() {
}

int sub_80493CC() {
    return 0;
}

void sub_8049418() {
}

int sub_804944D() {
    int result = deregister_tm_clones();
    completed.6844 = 1;
    return result;
}

void sub_8049468() {
}

void →__assert_fail(char* __assertion, char* __file, unsigned int __line, char* __function) {
    while(1) {
        /*NO_RETURN*/ __assert_fail(__assertion, __file, __line, __function);
        unsigned int* ptr0 = ptr0 - 1;
        *ptr0 = 8;
        --ptr0;
        *ptr0 = gvar_804F004;
    }
}

void →__libc_start_main() {
    while(1) {
        /*BAD_CALL!*/ __libc_start_main();
        unsigned int* ptr0 = ptr0 - 1;
        *ptr0 = 0;
        --ptr0;
        *ptr0 = gvar_804F004;
    }
}
