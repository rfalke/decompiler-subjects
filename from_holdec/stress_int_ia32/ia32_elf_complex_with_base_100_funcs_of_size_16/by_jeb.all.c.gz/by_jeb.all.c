
void __libc_csu_fini() {
}

int __libc_csu_init(int param0, int param1, int param2) {
    int result;
    initializer_0();
    int v0 = 0;
    do {
        result = *(int*)(v0 * 4 + (int)&__frame_dummy_init_array_entry){initializer_1}();
        ++v0;
    }
    while(v0 != 1);
    return result;
}

void __x86.get_pc_thunk.bx() {
}

void _dl_relocate_static_pie() {
}

int _start(int param0, int param1) {
    →__libc_start_main();
    hlt();
}

// Stale decompilation - Refresh this view to re-decompile this code
int deregister_tm_clones() {
    return &completed.6844;
}

void finalizer_0() {
}

void finalizer_1() {
    if(!completed.6844) {
        deregister_tm_clones();
        completed.6844 = 1;
    }
}

void* initializer_0() {
    void* result = __gmon_start__;
    if(result) {
        result = (void*)result();
    }
    return result;
}

int initializer_1() {
    return register_tm_clones();
}

int log_size_4_var_000() {
    return 0;
}

int log_size_4_var_001() {
    return 0;
}

int log_size_4_var_002() {
    return 0;
}

int log_size_4_var_003() {
    return 0;
}

int log_size_4_var_004() {
    return 0;
}

int log_size_4_var_005() {
    return 0;
}

int log_size_4_var_006() {
    return 0;
}

int log_size_4_var_007() {
    return 0;
}

int log_size_4_var_008() {
    return 0;
}

int log_size_4_var_009() {
    return 0;
}

int log_size_4_var_010() {
    return 0;
}

int log_size_4_var_011() {
    return 0;
}

int log_size_4_var_012() {
    return 0;
}

int log_size_4_var_013() {
    return 0;
}

int log_size_4_var_014() {
    return 0;
}

int log_size_4_var_015() {
    return 0;
}

int log_size_4_var_016() {
    return 0;
}

int log_size_4_var_017() {
    return 0;
}

int log_size_4_var_018() {
    int i;
    for(i = 0; !((-1094455617 >>> i) & 0x1); ++i) {
    }
    return __rol__((unsigned int)((unsigned char)((unsigned short)i & 0x3fff) / 0xff) | ((unsigned int)((unsigned char)((unsigned short)i & 0x3fff) % 0xff) << 8) | ((unsigned int)15714 << 16), 20) + ((unsigned int)((unsigned short)i + 9818) | ((unsigned int)(unsigned short)(i >>> 16) << 16)) + (((unsigned int)(unsigned short)__rol__((unsigned int)51074 | ((unsigned int)((unsigned short)i >= 55718) << 16), 1) | ((unsigned int)11143 << 16)) - 1094455553) + 363875791;
}

int log_size_4_var_019() {
    return 0;
}

int log_size_4_var_020() {
    return 0;
}

int log_size_4_var_021() {
    return 0;
}

int log_size_4_var_022() {
    return 0;
}

int log_size_4_var_023() {
    return 0;
}

int log_size_4_var_024() {
    return 0;
}

int log_size_4_var_025() {
    return 0;
}

int log_size_4_var_026() {
    return 0;
}

int log_size_4_var_027() {
    return 1827;
}

int log_size_4_var_028() {
    int i;
    for(i = 31; !(-836958943 >>> i); --i) {
    }
    return (unsigned int)((unsigned short)i >>> 7) | ((unsigned int)(unsigned short)(i >>> 16) << 16);
}

int log_size_4_var_029() {
    return 0;
}

int log_size_4_var_030() {
    return 0;
}

int log_size_4_var_031() {
    return 0;
}

int log_size_4_var_032() {
    int i;
    for(i = 31; !(0x7cbc020b >>> i); --i) {
    }
    return i - 30;
}

int log_size_4_var_033() {
    return 0;
}

int log_size_4_var_034() {
    return 0;
}

int log_size_4_var_035() {
    return 0;
}

int log_size_4_var_036() {
    return 0;
}

int log_size_4_var_037() {
    for(int i = 31; !(-1677232251 >>> i); --i) {
    }
    return 3721;
}

int log_size_4_var_038() {
    return 0;
}

int log_size_4_var_039() {
    return 0;
}

int log_size_4_var_040() {
    return 0;
}

int log_size_4_var_041() {
    return 0;
}

int log_size_4_var_042() {
    return 0;
}

int log_size_4_var_043() {
    return 0;
}

int log_size_4_var_044() {
    return 0;
}

int log_size_4_var_045() {
    return 0;
}

int log_size_4_var_046() {
    return 0;
}

int log_size_4_var_047() {
    return 0;
}

int log_size_4_var_048() {
    return 0;
}

int log_size_4_var_049() {
    return 0;
}

int log_size_4_var_050() {
    return 0;
}

int log_size_4_var_051() {
    return 0;
}

int log_size_4_var_052() {
    return 0;
}

int log_size_4_var_053() {
    return 0;
}

int log_size_4_var_054() {
    return 0;
}

int log_size_4_var_055() {
    return 0;
}

int log_size_4_var_056() {
    int i;
    for(i = 31; !(-747000134 >>> i); --i) {
    }
    return i - 31;
}

int log_size_4_var_057() {
    return 0;
}

int log_size_4_var_058() {
    return 0;
}

int log_size_4_var_059() {
    return 0;
}

int log_size_4_var_060() {
    return 0;
}

int log_size_4_var_061() {
    return 0;
}

int log_size_4_var_062() {
    return 0;
}

int log_size_4_var_063() {
    return -1235438253;
}

int log_size_4_var_064() {
    return 0;
}

int log_size_4_var_065() {
    return 0;
}

int log_size_4_var_066() {
    return 0;
}

int log_size_4_var_067() {
    return 445203194;
}

int log_size_4_var_068() {
    return 0;
}

int log_size_4_var_069() {
    return 0;
}

int log_size_4_var_070() {
    return 0;
}

int log_size_4_var_071() {
    return 0;
}

int log_size_4_var_072() {
    return 0;
}

int log_size_4_var_073() {
    return 0;
}

int log_size_4_var_074() {
    return 0;
}

int log_size_4_var_075() {
    return 0;
}

int log_size_4_var_076() {
    return 0;
}

int log_size_4_var_077() {
    int i;
    for(i = 0; !((-43662788 >>> i) & 0x1); ++i) {
    }
    return (unsigned int)(unsigned char)((unsigned short)i & 0xf0f3) - 2;
}

int log_size_4_var_078() {
    return 0;
}

int log_size_4_var_079() {
    return 0;
}

int log_size_4_var_080() {
    return 0;
}

int log_size_4_var_081() {
    int i;
    for(i = 31; !(-1174036313 >>> i); --i) {
    }
    int v0 = (unsigned int)(unsigned char)i | ((unsigned int)(unsigned char)__rol__((unsigned short)(unsigned char)(i >>> 8) | ((unsigned short)1 << 8), 16) << 8) | ((unsigned int)(unsigned short)(i >>> 16) << 16);
    return ((unsigned int)(unsigned short)((unsigned int)(((unsigned short)v0 >>> 3) & 0x1FFF) | ((unsigned int)42142 << 13)) | ((unsigned int)0xe09e << 16)) + v0 + 526448606;
}

int log_size_4_var_082() {
    return 0;
}

int log_size_4_var_083() {
    int i;
    for(i = 31; !(148282631 >>> i); --i) {
    }
    return i - 27;
}

int log_size_4_var_084() {
    return 0;
}

int log_size_4_var_085() {
    return 0;
}

int log_size_4_var_086() {
    return 0;
}

int log_size_4_var_087() {
    return 0;
}

int log_size_4_var_088() {
    return 0;
}

int log_size_4_var_089() {
    return 0;
}

int log_size_4_var_090() {
    return 0;
}

int log_size_4_var_091() {
    return 0;
}

int log_size_4_var_092() {
    return 0;
}

int log_size_4_var_093() {
    return 0;
}

int log_size_4_var_094() {
    return 24314;
}

int log_size_4_var_095() {
    return -968492320;
}

int log_size_4_var_096() {
    int i;
    for(i = 0; !((0x65227600 >>> i) & 0x1); ++i) {
    }
    return ((unsigned int)(unsigned short)i | ((unsigned int)636 << 16)) + 2135424217 + ((unsigned int)0x7565 | ((unsigned int)(unsigned short)(i >>> 16) << 16)) + (((unsigned int)0 | ((unsigned int)(unsigned char)__rol__((unsigned short)0 | ((unsigned short)(((unsigned int)(unsigned short)i | ((unsigned int)636 << 16)) < 2159543079) << 8), 13) << 8) | ((unsigned int)14944 << 16)) - 1532522059) - 0x60cc0bfc;
}

int log_size_4_var_097() {
    return 0;
}

int log_size_4_var_098() {
    int i;
    for(i = 31; !(1495320745 >>> i); --i) {
    }
    return (unsigned int)((unsigned short)(i >> 31) >>> 8) | ((unsigned int)(unsigned short)((i >> 31) >>> 16) << 16);
}

int log_size_4_var_099() {
    return 0;
}

int main() {
    int v0 = log_size_4_var_000();
    int v1 = /*BAD_CALL!*/ log_size_4_var_001();
    int v2 = /*BAD_CALL!*/ log_size_4_var_002();
    int v3 = /*BAD_CALL!*/ log_size_4_var_003();
    int v4 = /*BAD_CALL!*/ log_size_4_var_004();
    int v5 = /*BAD_CALL!*/ log_size_4_var_005();
    int v6 = /*BAD_CALL!*/ log_size_4_var_006();
    int v7 = /*BAD_CALL!*/ log_size_4_var_007();
    int v8 = /*BAD_CALL!*/ log_size_4_var_008();
    int v9 = /*BAD_CALL!*/ log_size_4_var_009();
    int v10 = /*BAD_CALL!*/ log_size_4_var_010();
    int v11 = /*BAD_CALL!*/ log_size_4_var_011();
    int v12 = /*BAD_CALL!*/ log_size_4_var_012();
    int v13 = /*BAD_CALL!*/ log_size_4_var_013();
    int v14 = /*BAD_CALL!*/ log_size_4_var_014();
    int v15 = /*BAD_CALL!*/ log_size_4_var_015();
    int v16 = /*BAD_CALL!*/ log_size_4_var_016();
    int v17 = /*BAD_CALL!*/ log_size_4_var_017();
    int v18 = /*BAD_CALL!*/ log_size_4_var_018();
    int v19 = /*BAD_CALL!*/ log_size_4_var_019();
    int v20 = /*BAD_CALL!*/ log_size_4_var_020();
    int v21 = /*BAD_CALL!*/ log_size_4_var_021();
    int v22 = /*BAD_CALL!*/ log_size_4_var_022();
    int v23 = /*BAD_CALL!*/ log_size_4_var_023();
    int v24 = /*BAD_CALL!*/ log_size_4_var_024();
    int v25 = /*BAD_CALL!*/ log_size_4_var_025();
    int v26 = /*BAD_CALL!*/ log_size_4_var_026();
    int v27 = /*BAD_CALL!*/ log_size_4_var_027();
    int v28 = /*BAD_CALL!*/ log_size_4_var_028();
    int v29 = /*BAD_CALL!*/ log_size_4_var_029();
    int v30 = /*BAD_CALL!*/ log_size_4_var_030();
    int v31 = /*BAD_CALL!*/ log_size_4_var_031();
    int v32 = /*BAD_CALL!*/ log_size_4_var_032();
    int v33 = /*BAD_CALL!*/ log_size_4_var_033();
    int v34 = /*BAD_CALL!*/ log_size_4_var_034();
    int v35 = /*BAD_CALL!*/ log_size_4_var_035();
    int v36 = /*BAD_CALL!*/ log_size_4_var_036();
    int v37 = /*BAD_CALL!*/ log_size_4_var_037();
    int v38 = /*BAD_CALL!*/ log_size_4_var_038();
    int v39 = /*BAD_CALL!*/ log_size_4_var_039();
    int v40 = /*BAD_CALL!*/ log_size_4_var_040();
    int v41 = /*BAD_CALL!*/ log_size_4_var_041();
    int v42 = /*BAD_CALL!*/ log_size_4_var_042();
    int v43 = /*BAD_CALL!*/ log_size_4_var_043();
    int v44 = /*BAD_CALL!*/ log_size_4_var_044();
    int v45 = /*BAD_CALL!*/ log_size_4_var_045();
    int v46 = /*BAD_CALL!*/ log_size_4_var_046();
    int v47 = /*BAD_CALL!*/ log_size_4_var_047();
    int v48 = /*BAD_CALL!*/ log_size_4_var_048();
    int v49 = /*BAD_CALL!*/ log_size_4_var_049();
    int v50 = /*BAD_CALL!*/ log_size_4_var_050();
    int v51 = /*BAD_CALL!*/ log_size_4_var_051();
    int v52 = /*BAD_CALL!*/ log_size_4_var_052();
    int v53 = /*BAD_CALL!*/ log_size_4_var_053();
    int v54 = /*BAD_CALL!*/ log_size_4_var_054();
    int v55 = /*BAD_CALL!*/ log_size_4_var_055();
    int v56 = /*BAD_CALL!*/ log_size_4_var_056();
    int v57 = /*BAD_CALL!*/ log_size_4_var_057();
    int v58 = /*BAD_CALL!*/ log_size_4_var_058();
    int v59 = /*BAD_CALL!*/ log_size_4_var_059();
    int v60 = /*BAD_CALL!*/ log_size_4_var_060();
    int v61 = /*BAD_CALL!*/ log_size_4_var_061();
    int v62 = /*BAD_CALL!*/ log_size_4_var_062();
    int v63 = /*BAD_CALL!*/ log_size_4_var_063();
    int v64 = /*BAD_CALL!*/ log_size_4_var_064();
    int v65 = /*BAD_CALL!*/ log_size_4_var_065();
    int v66 = /*BAD_CALL!*/ log_size_4_var_066();
    int v67 = /*BAD_CALL!*/ log_size_4_var_067();
    int v68 = /*BAD_CALL!*/ log_size_4_var_068();
    int v69 = /*BAD_CALL!*/ log_size_4_var_069();
    int v70 = /*BAD_CALL!*/ log_size_4_var_070();
    int v71 = /*BAD_CALL!*/ log_size_4_var_071();
    int v72 = /*BAD_CALL!*/ log_size_4_var_072();
    int v73 = /*BAD_CALL!*/ log_size_4_var_073();
    int v74 = /*BAD_CALL!*/ log_size_4_var_074();
    int v75 = /*BAD_CALL!*/ log_size_4_var_075();
    int v76 = /*BAD_CALL!*/ log_size_4_var_076();
    int v77 = /*BAD_CALL!*/ log_size_4_var_077();
    int v78 = /*BAD_CALL!*/ log_size_4_var_078();
    int v79 = /*BAD_CALL!*/ log_size_4_var_079();
    int v80 = /*BAD_CALL!*/ log_size_4_var_080();
    int v81 = /*BAD_CALL!*/ log_size_4_var_081();
    int v82 = /*BAD_CALL!*/ log_size_4_var_082();
    int v83 = /*BAD_CALL!*/ log_size_4_var_083();
    int v84 = /*BAD_CALL!*/ log_size_4_var_084();
    int v85 = /*BAD_CALL!*/ log_size_4_var_085();
    int v86 = /*BAD_CALL!*/ log_size_4_var_086();
    int v87 = /*BAD_CALL!*/ log_size_4_var_087();
    int v88 = /*BAD_CALL!*/ log_size_4_var_088();
    int v89 = /*BAD_CALL!*/ log_size_4_var_089();
    int v90 = /*BAD_CALL!*/ log_size_4_var_090();
    int v91 = /*BAD_CALL!*/ log_size_4_var_091();
    int v92 = /*BAD_CALL!*/ log_size_4_var_092();
    int v93 = /*BAD_CALL!*/ log_size_4_var_093();
    int v94 = /*BAD_CALL!*/ log_size_4_var_094();
    int v95 = /*BAD_CALL!*/ log_size_4_var_095();
    int v96 = /*BAD_CALL!*/ log_size_4_var_096();
    int v97 = /*BAD_CALL!*/ log_size_4_var_097();
    int v98 = /*BAD_CALL!*/ log_size_4_var_098();
    int v99 = log_size_4_var_099();
    if((v1 + v10 + (v11 + v12) + (v13 + v14 + (v15 + v16)) + (v17 + v18 + (v19 + v2) + (v20 + v21 + (v22 + v23))) + (v24 + v25 + (v26 + v27) + (v28 + v29 + (v3 + v30)) + (v31 + v32 + (v33 + v34) + (v35 + v36 + (v37 + v38)))) + (v39 + v4 + (v40 + v41) + (v42 + v43 + (v44 + v45)) + (v46 + v47 + (v48 + v49) + (v5 + v50 + (v51 + v52))) + (v53 + v54 + (v55 + v56) + (v57 + v58 + (v59 + v6)) + (v60 + v61 + (v62 + v63) + (v64 + v65 + (v66 + v67))))) + (v68 + v69 + (v7 + v70) + (v71 + v72 + (v73 + v74)) + (v75 + v76 + (v77 + v78) + (v79 + v8 + (v80 + v81))) + (v82 + v83 + (v84 + v85) + (v86 + v87 + (v88 + v89)) + (v9 + v90 + (v91 + v92) + (v93 + v94 + (v95 + v96)))) + (v97 + v98 + (v99 + v0))))) {
        /*NO_RETURN*/ →__assert_fail("sum==0", "source_complex_with_base_100_funcs_of_size_16.c", 211, (char*)&__PRETTY_FUNCTION__.2306);
    }
    return 0;
}

int register_tm_clones() {
    return 0;
}

void r→__assert_fail(char* __assertion, char* __file, unsigned int __line, char* __function) {
    /*BAD_CALL!*/ sub_8049030();
}

int r→__libc_start_main() {
    /*BAD_CALL!*/ sub_8049030();
}

void sub_8049030() {
    jump gvar_804F008;
}

void sub_8049397() {
}

void →__assert_fail(char* __assertion, char* __file, unsigned int __line, char* __function) {
    ptr___assert_fail[0]{r→__assert_fail}(__assertion, __file, __line, __function);
}

int →__libc_start_main() {
    return ptr___libc_start_main{r→__libc_start_main}();
}
