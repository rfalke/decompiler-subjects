
void __libc_csu_fini() {
}

int __libc_csu_init(int param0, int param1, int param2) {
    int result;
    initializer_0();
    unsigned int v0 = 0;
    do {
        result = *(int*)(v0 * 4 + (int)&__frame_dummy_init_array_entry){initializer_1}();
        ++v0;
    }
    while(v0 != 1);
    return result;
}

void __x86.get_pc_thunk.bx() {
}

void _dl_relocate_static_pie() {
}

int _start(int param0, int param1) {
    int v0;
    char v1;
    void* ptr0;
    int v2;
    int v3 = 0;
    char v4 = 1;
    char v5 = 0;
    char v6 = 1;
    char v7 = 0;
    char v8 = 0;
    int v9 = v0;
    int* ptr1 = &v1;
    char v10 = &v0 ? 0: 1;
    char v11 = (int)&v0 < 0;
    char v12 = __parity__((unsigned char)&v0);
    char v13 = 0;
    char v14 = 0;
    int v15 = v2;
    int* ptr2 = &v15;
    int* ptr3 = &v15;
    int v16 = param1;
    int v17 = &loc_80491E4;
    int v18 = &loc_80491E4;
    int v19 = &_GLOBAL_OFFSET_TABLE_;
    char v20 = 0;
    char v21 = 0;
    char v22 = 1;
    char v23 = 1;
    char v24 = 0;
    char v25 = 0;
    int v26 = &__libc_csu_fini;
    int v27 = &__libc_csu_fini;
    int v28 = &__libc_csu_init;
    int v29 = &__libc_csu_init;
    int* ptr4 = &v1;
    int v30 = &main;
    int v31 = &main;
    int* ptr5 = &ptr0;
    →__libc_start_main();
    hlt();
}

int deregister_tm_clones() {
    return &completed.6844;
}

int do_cmp(unsigned char param0, unsigned char param1) {
    return (char)param0 >= (char)param1 ? 0: 1;
}

int do_cmp_const(unsigned char param0) {
    return (char)param0 >= 10 ? 0: 1;
}

int do_signed(unsigned char param0, unsigned char param1) {
    return (char)param0 >= (char)param1 ? 0: 1;
}

int do_signed_const(unsigned char param0) {
    return (char)param0 >= 10 ? 0: 1;
}

void finalizer_0() {
}

void finalizer_1() {
    char v0 = completed.6844 ? 0: 1;
    char v1 = completed.6844 >= 128;
    char v2 = __parity__(completed.6844);
    char v3 = completed.6844 < 0;
    char v4 = 0;
    char v5 = 0;
    jump v0 ? &sub_80492BD: &sub_80492D8;
}

void* initializer_0() {
    void* result = __gmon_start__;
    if(result) {
        result = (void*)result();
    }
    return result;
}

int initializer_1() {
    return register_tm_clones();
}

int main() {
    int v0;
    int v1;
    unsigned char v2;
    int v3;
    char v4;
    unsigned char v5;
    int v6 = v1;
    int v7 = 0;
    int v8 = v3;
    int* ptr0 = &v4;
    do {
        *(int*)&v2 = v7;
        int v9 = do_cmp_const(v2);
        *(int*)&v2 = v7;
        int v10 = do_signed_const(v2);
        unsigned char v11 = (unsigned char)v7;
        if(((unsigned char)v7 > 9 ? 0: 1) != v9) {
            v0 = v10;
            *(int*)&v5 = v7;
            *(int*)&v2 = "CONST C and setl differ: %3d = 0x%02x  ->  ";
            →printf(*(int*)&v2);
            *(int*)&v5 = v9;
            *(int*)&v2 = "x<10 = %d %d\n";
            →printf(*(int*)&v2);
            v10 = v0;
        }
        v0 = v10;
        if(v9 != v10) {
            *(int*)&v5 = v7;
            *(int*)&v2 = "CONST %3d = 0x%02x  ->  ";
            →printf(*(int*)&v2);
            *(int*)&v5 = v9;
            *(int*)&v2 = "x<10 = %d %d ";
            →printf(*(int*)&v2);
            *(int*)&v5 = v0;
            *(int*)&v2 = "x-10<0 =%d\n";
            →printf(*(int*)&v2);
        }
        unsigned int v12 = 0;
        do {
            *(unsigned int*)&v5 = v12;
            *(int*)&v2 = v7;
            int v13 = do_cmp(v2, v5);
            *(unsigned int*)&v5 = v12;
            *(int*)&v2 = v7;
            int v14 = do_signed(v2, v5);
            int v15 = (unsigned char)v12 <= (char)v11 ? 0: 1;
            int v16 = v14;
            v0 = v15;
            if(v15 != v13) {
                int v17 = v14;
                *(unsigned int*)&v2 = v12;
                →printf("C and setl differ: %3d = 0x%02x %3d = 0x%02x  ->  ");
                int v18 = v15;
                *(int*)&v5 = v13;
                *(int*)&v2 = "x<y = %d %d\n";
                →printf(*(int*)&v2);
                v16 = v17;
            }
            v0 = v16;
            if(v16 != v13) {
                *(unsigned int*)&v2 = v12;
                →printf("%3d = 0x%02x %3d = 0x%02x  ->  ");
                *(int*)&v5 = v13;
                *(int*)&v2 = "x<y = %d ";
                →printf(*(int*)&v2);
                *(int*)&v5 = v0;
                *(int*)&v2 = "x-y<0 =%d\n";
                →printf(*(int*)&v2);
            }
            ++v12;
        }
        while(v12 != 0x100);
        ++v7;
    }
    while(v7 != 0x100);
    return 0;
}

int register_tm_clones() {
    return 0;
}

int sub_8049036() {
    return gvar_804C008();
}

void sub_8049207() {
}

int sub_804923C() {
    return 0;
}

void sub_8049288() {
}

int sub_80492BD() {
    int result = deregister_tm_clones();
    completed.6844 = 1;
    return result;
}

void sub_80492D8() {
}

void →__libc_start_main() {
    while(1) {
        /*BAD_CALL!*/ __libc_start_main();
        unsigned int* ptr0 = ptr0 - 1;
        *ptr0 = 8;
        --ptr0;
        *ptr0 = gvar_804C004;
    }
}

void →printf(int param0) {
    unsigned int* ptr0;
    while(1) {
        /*BAD_CALL!*/ printf(*(char**)(ptr0 + 1));
        --ptr0;
        *ptr0 = 0;
        --ptr0;
        *ptr0 = gvar_804C004;
    }
}
