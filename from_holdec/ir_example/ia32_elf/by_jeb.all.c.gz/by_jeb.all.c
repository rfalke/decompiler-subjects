
void __libc_csu_fini() {
}

int __libc_csu_init(int param0, int param1, int param2) {
    int result;
    initializer_0();
    unsigned int v0 = 0;
    do {
        result = *(int*)(v0 * 4 + (int)&__frame_dummy_init_array_entry){initializer_1}();
        ++v0;
    }
    while(v0 != 1);
    return result;
}

void __x86.get_pc_thunk.bx() {
}

void _dl_relocate_static_pie() {
}

int _start(int param0, int param1) {
    int v0;
    char v1;
    void* ptr0;
    int v2;
    int v3 = 0;
    char v4 = 1;
    char v5 = 0;
    char v6 = 1;
    char v7 = 0;
    char v8 = 0;
    int v9 = v0;
    int* ptr1 = &v1;
    char v10 = &v0 ? 0: 1;
    char v11 = (int)&v0 < 0;
    char v12 = __parity__((unsigned char)&v0);
    char v13 = 0;
    char v14 = 0;
    int v15 = v2;
    int* ptr2 = &v15;
    int* ptr3 = &v15;
    int v16 = param1;
    int v17 = &loc_80490C4;
    int v18 = &loc_80490C4;
    int v19 = &_GLOBAL_OFFSET_TABLE_;
    char v20 = 0;
    char v21 = 0;
    char v22 = 1;
    char v23 = 1;
    char v24 = 0;
    char v25 = 0;
    int v26 = &__libc_csu_fini;
    int v27 = &__libc_csu_fini;
    int v28 = &__libc_csu_init;
    int v29 = &__libc_csu_init;
    int* ptr4 = &v1;
    int v30 = &main;
    int v31 = &main;
    int* ptr5 = &ptr0;
    →__libc_start_main();
    hlt();
}

int deregister_tm_clones() {
    return &completed.6844;
}

void finalizer_0() {
}

void finalizer_1() {
    char v0 = completed.6844 ? 0: 1;
    char v1 = completed.6844 >= 128;
    char v2 = __parity__(completed.6844);
    char v3 = completed.6844 < 0;
    char v4 = 0;
    char v5 = 0;
    jump v0 ? &sub_804919D: &sub_80491B8;
}

void* initializer_0() {
    void* result = __gmon_start__;
    if(result) {
        result = (void*)result();
    }
    return result;
}

int initializer_1() {
    return register_tm_clones();
}

int main(unsigned int param0, int param1) {
    int v0;
    if((param0 != 2 || !**(unsigned int*)(param1 + 4))) {
        v0 = "not enough args or too small";
    }
    else if(*(char*)(*(int*)(param1 + 4) + 1) != 97) {
        v0 = "no \'a\'";
    }
    else {
        v0 = "got an \'a\'";
    }
    →puts(v0);
    return 0;
}

int register_tm_clones() {
    return 0;
}

int sub_8049036() {
    return gvar_804C008();
}

void sub_80490E7() {
}

int sub_804911C() {
    return 0;
}

void sub_8049168() {
}

int sub_804919D() {
    int result = deregister_tm_clones();
    completed.6844 = 1;
    return result;
}

void sub_80491B8() {
}

void →__libc_start_main() {
    while(1) {
        /*BAD_CALL!*/ __libc_start_main();
        unsigned int* ptr0 = ptr0 - 1;
        *ptr0 = 8;
        --ptr0;
        *ptr0 = gvar_804C004;
    }
}

void →puts(int param0) {
    unsigned int* ptr0;
    while(1) {
        /*BAD_CALL!*/ puts(*(char**)(ptr0 + 1));
        --ptr0;
        *ptr0 = 0;
        --ptr0;
        *ptr0 = gvar_804C004;
    }
}
