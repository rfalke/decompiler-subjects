
void dispatch() {
    jump external;
}

int main() {
    alu_x = target;
    alu_y = 2281998180;
    int v0 = (unsigned int)*(char*)&alu_x;
    unsigned int v1 = (unsigned int)*(char*)((unsigned int)*(char*)&alu_y + *(unsigned int*)(v0 * 4 + (int)&alu_eq));
    b0 = (unsigned int)*(char*)((unsigned int)*(char*)&alu_y + *(unsigned int*)(v0 * 4 + (int)&alu_eq));
    v0 = (unsigned int)*((char*)&alu_x + 1) | ((unsigned int)((v0 >>> 8) & 0xffffff) << 8);
    v1 = (unsigned int)*(char*)(((unsigned int)*((char*)&alu_y + 1) | ((unsigned int)((v1 >>> 8) & 0xffffff) << 8)) + *(unsigned int*)(v0 * 4 + (int)&alu_eq)) | ((unsigned int)((v1 >>> 8) & 0xffffff) << 8);
    b1 = v1;
    v0 = (unsigned int)*((char*)&alu_x + 2) | ((unsigned int)((v0 >>> 8) & 0xffffff) << 8);
    v1 = (unsigned int)*(char*)(((unsigned int)*((char*)&alu_y + 2) | ((unsigned int)((v1 >>> 8) & 0xffffff) << 8)) + *(unsigned int*)(v0 * 4 + (int)&alu_eq)) | ((unsigned int)((v1 >>> 8) & 0xffffff) << 8);
    b2 = v1;
    b3 = (unsigned int)*(char*)(((unsigned int)*((char*)&alu_y + 3) | ((unsigned int)((v1 >>> 8) & 0xffffff) << 8)) + *(int*)(((unsigned int)*((char*)&alu_x + 3) | ((unsigned int)((v0 >>> 8) & 0xffffff) << 8)) * 4 + &alu_eq)) | ((unsigned int)((v1 >>> 8) & 0xffffff) << 8);
    b0 = *(unsigned int*)(b1 * 4 + *(unsigned int*)(b0 * 4 + (int)&and));
    b0 = *(unsigned int*)(b2 * 4 + *(unsigned int*)(b0 * 4 + (int)&and));
    b0 = *(unsigned int*)(b3 * 4 + *(unsigned int*)(b0 * 4 + (int)&and));
    unsigned int v2 = b0;
    *(unsigned char*)*(unsigned char**)(v2 * 4 + (int)&sel_data) = *(int*)&jmp_r0;
    **(unsigned int**)(v2 * 4 + (int)&sel_data) = jmp_r1;
    **(unsigned int**)(v2 * 4 + (int)&sel_data) = jmp_r2;
    **(unsigned int**)(v2 * 4 + (int)&sel_data) = jmp_r3;
    *(unsigned char*)*(unsigned char**)(v2 * 4 + (int)&sel_data) = *(int*)&jmp_f0;
    **(unsigned int**)(v2 * 4 + (int)&sel_data) = jmp_f1;
    unsigned int* ptr0 = *(unsigned int*)(v2 * 4 + (int)&sel_data);
    *ptr0 = *(int*)&jmp_d0;
    *(ptr0 + 1) = gvar_85F418C;
    unsigned int* ptr1 = *(unsigned int*)(v2 * 4 + (int)&sel_data);
    *ptr1 = jmp_d1;
    *(ptr1 + 1) = gvar_85F4194;
    **(unsigned int*)(b0 * 4 + (int)&sel_on) = 1;
    stack_temp = fp;
    unsigned int v3 = on;
    **(unsigned int*)(v3 * 4 + (int)&sel_data) = *(int*)(sp - 0x200068);
    unsigned int v4 = on;
    data_p = sp;
    **(unsigned int**)(v4 * 4 + (int)&sel_data) = stack_temp;
    stack_temp = R1;
    unsigned int v5 = on;
    **(unsigned int*)(v5 * 4 + (int)&sel_data) = *(int*)(sp - 0x200068);
    unsigned int v6 = on;
    data_p = sp;
    **(unsigned int**)(v6 * 4 + (int)&sel_data) = stack_temp;
    stack_temp = R2;
    unsigned int v7 = on;
    **(unsigned int*)(v7 * 4 + (int)&sel_data) = *(int*)(sp - 0x200068);
    unsigned int v8 = on;
    data_p = sp;
    **(unsigned int**)(v8 * 4 + (int)&sel_data) = stack_temp;
    stack_temp = R3;
    unsigned int v9 = on;
    **(unsigned int*)(v9 * 4 + (int)&sel_data) = *(int*)(sp - 0x200068);
    unsigned int v10 = on;
    data_p = sp;
    **(unsigned int**)(v10 * 4 + (int)&sel_data) = stack_temp;
    stack_temp = F1;
    unsigned int v11 = on;
    **(unsigned int*)(v11 * 4 + (int)&sel_data) = *(int*)(sp - 0x200068);
    unsigned int v12 = on;
    data_p = sp;
    **(unsigned int**)(v12 * 4 + (int)&sel_data) = stack_temp;
    stack_temp = D1;
    gvar_81F40F4 = gvar_804B05C;
    unsigned int v13 = on;
    **(unsigned int*)(v13 * 4 + (int)&sel_data) = *(int*)(*(int*)(sp - 0x200068) - 0x200068);
    unsigned int v14 = on;
    data_p = sp;
    unsigned int* ptr2 = *(unsigned int*)(v14 * 4 + (int)&sel_data);
    *ptr2 = stack_temp;
    *(ptr2 + 1) = gvar_81F40F4;
    unsigned int v15 = on;
    **(unsigned int**)(v15 * 4 + (int)&sel_data) = sp;
    R3 = "Hello, world!\n";
    stack_temp = R3;
    unsigned int v16 = on;
    **(unsigned int*)(v16 * 4 + (int)&sel_data) = *(int*)(sp - 0x200068);
    unsigned int v17 = on;
    data_p = sp;
    **(unsigned int**)(v17 * 4 + (int)&sel_data) = stack_temp;
    alu_x = 2281999524;
    alu_y = 0x80000000;
    alu_c = 0;
    int v18 = (unsigned int)*(short*)&alu_x;
    int v19 = (unsigned int)*(short*)&alu_y;
    int v20 = *(int*)(v19 * 4 + *(unsigned int*)(v18 * 4 + (int)&alu_add16));
    v19 = (unsigned int)*(short*)((char*)&alu_c + 2) | ((unsigned int)(unsigned short)(v19 >>> 16) << 16);
    unsigned int v21 = *(unsigned int*)(v19 * 4 + *(unsigned int*)(v20 * 4 + (int)&alu_add16));
    *(short*)&alu_s = (unsigned short)v21;
    alu_c = v21;
    unsigned int v22 = *(unsigned int*)(((unsigned int)*(short*)((char*)&alu_c + 2) | ((unsigned int)(unsigned short)(v19 >>> 16) << 16)) * 4 + *(int*)(*(int*)(((unsigned int)*(short*)((char*)&alu_y + 2) | ((unsigned int)(unsigned short)(v19 >>> 16) << 16)) * 4 + *(int*)(((unsigned int)*(short*)((char*)&alu_x + 2) | ((unsigned int)(unsigned short)(v18 >>> 16) << 16)) * 4 + &alu_add16)) * 4 + &alu_add16));
    *(short*)((char*)&alu_s + 2) = (unsigned short)v22;
    alu_c = v22;
    stack_temp = alu_s;
    unsigned int v23 = on;
    **(unsigned int*)(v23 * 4 + (int)&sel_data) = *(int*)(sp - 0x200068);
    unsigned int v24 = on;
    data_p = sp;
    **(unsigned int**)(v24 * 4 + (int)&sel_data) = stack_temp;
    external = &→printf;
    unsigned int v25 = on;
    **(unsigned int*)(v25 * 4 + (int)&sel_data) = *(int*)(sp - 0x200060);
    stack_temp = *(unsigned int*)(sp - 0x200060);
    unsigned int v26 = on;
    **(unsigned int**)(v26 * 4 + (int)&sel_data) = stack_temp;
    R0 = 0;
    alu_x = target;
    alu_y = 2281999644;
    int v27 = (unsigned int)*(char*)&alu_x;
    unsigned int v28 = (unsigned int)*(char*)((unsigned int)*(char*)&alu_y + *(unsigned int*)(v27 * 4 + (int)&alu_eq));
    b0 = (unsigned int)*(char*)((unsigned int)*(char*)&alu_y + *(unsigned int*)(v27 * 4 + (int)&alu_eq));
    v27 = (unsigned int)*((char*)&alu_x + 1) | ((unsigned int)((v27 >>> 8) & 0xffffff) << 8);
    v28 = (unsigned int)*(char*)(((unsigned int)*((char*)&alu_y + 1) | ((unsigned int)((v28 >>> 8) & 0xffffff) << 8)) + *(unsigned int*)(v27 * 4 + (int)&alu_eq)) | ((unsigned int)((v28 >>> 8) & 0xffffff) << 8);
    b1 = v28;
    v27 = (unsigned int)*((char*)&alu_x + 2) | ((unsigned int)((v27 >>> 8) & 0xffffff) << 8);
    v28 = (unsigned int)*(char*)(((unsigned int)*((char*)&alu_y + 2) | ((unsigned int)((v28 >>> 8) & 0xffffff) << 8)) + *(unsigned int*)(v27 * 4 + (int)&alu_eq)) | ((unsigned int)((v28 >>> 8) & 0xffffff) << 8);
    b2 = v28;
    b3 = (unsigned int)*(char*)(((unsigned int)*((char*)&alu_y + 3) | ((unsigned int)((v28 >>> 8) & 0xffffff) << 8)) + *(int*)(((unsigned int)*((char*)&alu_x + 3) | ((unsigned int)((v27 >>> 8) & 0xffffff) << 8)) * 4 + &alu_eq)) | ((unsigned int)((v28 >>> 8) & 0xffffff) << 8);
    b0 = *(unsigned int*)(b1 * 4 + *(unsigned int*)(b0 * 4 + (int)&and));
    b0 = *(unsigned int*)(b2 * 4 + *(unsigned int*)(b0 * 4 + (int)&and));
    b0 = *(unsigned int*)(b3 * 4 + *(unsigned int*)(b0 * 4 + (int)&and));
    unsigned int v29 = b0;
    *(unsigned char*)*(unsigned char**)(v29 * 4 + (int)&sel_data) = *(int*)&jmp_r0;
    **(unsigned int**)(v29 * 4 + (int)&sel_data) = jmp_r1;
    **(unsigned int**)(v29 * 4 + (int)&sel_data) = jmp_r2;
    **(unsigned int**)(v29 * 4 + (int)&sel_data) = jmp_r3;
    *(unsigned char*)*(unsigned char**)(v29 * 4 + (int)&sel_data) = *(int*)&jmp_f0;
    **(unsigned int**)(v29 * 4 + (int)&sel_data) = jmp_f1;
    unsigned int* ptr3 = *(unsigned int*)(v29 * 4 + (int)&sel_data);
    *ptr3 = *(int*)&jmp_d0;
    *(ptr3 + 1) = gvar_85F418C;
    unsigned int* ptr4 = *(unsigned int*)(v29 * 4 + (int)&sel_data);
    *ptr4 = jmp_d1;
    *(ptr4 + 1) = gvar_85F4194;
    **(unsigned int*)(b0 * 4 + (int)&sel_on) = 1;
    unsigned int v30 = on;
    **(unsigned int**)(v30 * 4 + (int)&sel_data) = fp;
    unsigned int* ptr5 = sp;
    stack_temp = *ptr5;
    gvar_81F40F4 = *(ptr5 + 1);
    unsigned int v31 = on;
    **(unsigned int*)(v31 * 4 + (int)&sel_data) = *(int*)(*(int*)(sp - 0x200060) - 0x200060);
    unsigned int v32 = on;
    unsigned int* ptr6 = *(unsigned int*)(v32 * 4 + (int)&sel_data);
    *ptr6 = stack_temp;
    *(ptr6 + 1) = gvar_81F40F4;
    stack_temp = *sp;
    unsigned int v33 = on;
    **(unsigned int*)(v33 * 4 + (int)&sel_data) = *(int*)(sp - 0x200060);
    unsigned int v34 = on;
    **(unsigned int**)(v34 * 4 + (int)&sel_data) = stack_temp;
    stack_temp = *sp;
    unsigned int v35 = on;
    **(unsigned int*)(v35 * 4 + (int)&sel_data) = *(int*)(sp - 0x200060);
    unsigned int v36 = on;
    **(unsigned int**)(v36 * 4 + (int)&sel_data) = stack_temp;
    stack_temp = *sp;
    unsigned int v37 = on;
    **(unsigned int*)(v37 * 4 + (int)&sel_data) = *(int*)(sp - 0x200060);
    unsigned int v38 = on;
    **(unsigned int**)(v38 * 4 + (int)&sel_data) = stack_temp;
    stack_temp = *sp;
    unsigned int v39 = on;
    **(unsigned int*)(v39 * 4 + (int)&sel_data) = *(int*)(sp - 0x200060);
    unsigned int v40 = on;
    **(unsigned int**)(v40 * 4 + (int)&sel_data) = stack_temp;
    stack_temp = *sp;
    unsigned int v41 = on;
    **(unsigned int*)(v41 * 4 + (int)&sel_data) = *(int*)(sp - 0x200060);
    unsigned int v42 = on;
    **(unsigned int**)(v42 * 4 + (int)&sel_data) = stack_temp;
    stack_temp = *sp;
    unsigned int v43 = on;
    **(unsigned int*)(v43 * 4 + (int)&sel_data) = *(int*)(sp - 0x200060);
    branch_temp = stack_temp;
    **(unsigned int**)(on * 4 + (int)&sel_target) = branch_temp;
    unsigned int v44 = on;
    unsigned int* ptr7 = *(unsigned int*)(v44 * 4 + (int)&sel_data);
    *ptr7 = R0;
    *(ptr7 + 1) = R1;
    *(ptr7 + 2) = R2;
    *(ptr7 + 3) = R3;
    unsigned int* ptr8 = *(unsigned int*)(v44 * 4 + (int)&sel_data);
    *ptr8 = F0;
    *(ptr8 + 1) = F1;
    data_p = &jmp_d0;
    unsigned int* ptr9 = *(unsigned int*)(v44 * 4 + (int)&sel_data);
    *ptr9 = D0;
    *(ptr9 + 1) = gvar_804B054;
    *(ptr9 + 2) = D1;
    *(ptr9 + 3) = gvar_804B05C;
    **(unsigned int*)(on * 4 + (int)&sel_on) = 0;
}

int r→sigaction(int __sig, sigaction* __act, sigaction* __oact) {
    /*BAD_CALL!*/ sub_80481F0();
}

void start() {
    // Decompilation error
}

void sub_80481F0() {
    jump gvar_804B008;
}

int sub_8048206() {
    /*BAD_CALL!*/ sub_80481F0();
}

int sub_8048216() {
    /*BAD_CALL!*/ sub_80481F0();
}

void →exit(int __status) {
    unsigned int* ptr0;
    /*BAD_CALL!*/ ptr_exit[0]{→exit}(*(int*)(ptr0 + 1));
}

int →printf(char* __format, ...) {
    unsigned int* ptr0;
    /*BAD_CALL!*/ ptr_printf[0]{→printf}(*(char**)(ptr0 + 1));
}

int →sigaction(int __sig, sigaction* __act, sigaction* __oact) {
    return ptr_sigaction[0]{r→sigaction}(__sig, __act, __oact);
}
