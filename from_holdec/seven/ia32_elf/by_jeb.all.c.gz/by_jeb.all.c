
void __libc_csu_fini() {
}

int __libc_csu_init(int param0, int param1, int param2) {
    int result;
    initializer_0();
    int v0 = 0;
    do {
        result = *(int*)(v0 * 4 + (int)&__frame_dummy_init_array_entry){initializer_1}();
        ++v0;
    }
    while(v0 != 1);
    return result;
}

void __x86.get_pc_thunk.bx() {
}

int _start(int param0, int param1) {
    →__libc_start_main();
    hlt();
}

// Stale decompilation - Refresh this view to re-decompile this code
int deregister_tm_clones() {
    return 3;
}

void finalizer_0() {
}

int finalizer_1() {
    int result;
    return result;
}

int initializer_0() {
    int result;
    if(__gmon_start__) {
        sub_8048300();
    }
    return result;
}

int initializer_1() {
    return register_tm_clones();
}

int main() {
    unsigned int v0 = 0;
    unsigned int v1 = 0;
    while(1) {
        unsigned int v2 = test_1(v0);
        int v3 = test_2((int)v0);
        int v4 = test_3((int)v0);
        if(v3 != v2 || v4 != v2) {
            →printf("%u %u %u (diff=%d) %u (diff=%d)\n", v0, v2, v3, v3 - v2, v4, v4 - v2);
        }
        if(v1 && v0 < v1) {
            return 0;
        }
        v1 = v0;
        v0 += 1000000;
    }
    return 0;
}

int register_tm_clones() {
    return 0;
}

int r→__libc_start_main() {
    /*BAD_CALL!*/ sub_80482D0();
}

int r→printf(char* __format, ...) {
    /*BAD_CALL!*/ sub_80482D0();
}

void sub_80482D0() {
    jump gvar_804A008;
}

void sub_8048300() {
    jump __gmon_start__;
}

unsigned int test_1(unsigned int param0) {
    return param0 / 7;
}

int test_2(unsigned int param0) {
    return (int)(param0 / 7);
}

int test_3(int param0) {
    return (unsigned int)(((unsigned long long)param0 * 613566757L) >>> 32L);
}

int →__libc_start_main() {
    return ptr___libc_start_main{r→__libc_start_main}();
}

int →printf(char* __format, ...) {
    return ptr_printf[0]{r→printf}(__format);
}
