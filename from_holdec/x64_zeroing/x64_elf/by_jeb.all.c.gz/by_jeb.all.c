
void __libc_csu_fini() {
}

void* __libc_csu_init(long param0, long param1) {
    void* result;
    initializer_0();
    long v0 = 0L;
    do {
        result = (void*)*(long*)(v0 * 8L + (long)&__frame_dummy_init_array_entry){initializer_1}();
        ++v0;
    }
    while(v0 != 1L);
    return result;
}

void _dl_relocate_static_pie() {
}

long _start(long param0, long param1) {
    long v0;
    long v1;
    long v2;
    char v3;
    __libc_start_main(&main, v0, (long)&v3, &__libc_csu_init, &__libc_csu_fini, param1, (long)&v1, v2);
    hlt();
}

// Stale decompilation - Refresh this view to re-decompile this code
long deregister_tm_clones() {
    return &__TMC_END__;
}

void finalizer_0() {
}

void finalizer_1() {
    if(!completed.7287) {
        deregister_tm_clones();
        completed.7287 = 1;
    }
}

void* initializer_0() {
    void* result = __gmon_start__;
    if(result) {
        result = (void*)result();
    }
    return result;
}

long initializer_1() {
    return register_tm_clones();
}

long main() {
    →printf("mov eax: 0x%016lx\n", 0x7654L);
    →printf("mov  ax: 0x%016lx\n", 0x1122334455667654L);
    return 0L;
}

long register_tm_clones() {
    return 0L;
}

int r→printf(char* __format, ...) {
    jump gvar_404010;
}

int →printf(char* __format, ...) {
    return ptr_printf[0]{r→printf}(__format);
}
