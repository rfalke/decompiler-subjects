
void __libc_csu_fini() {
}

int __libc_csu_init(int param0, int param1, int param2) {
    int result;
    initializer_0();
    unsigned int v0 = 0;
    do {
        result = *(int*)(v0 * 4 + (int)&__frame_dummy_init_array_entry){initializer_1}();
        ++v0;
    }
    while(v0 != 1);
    return result;
}

void __x86.get_pc_thunk.bx() {
}

int _start(int param0, int param1) {
    int v0;
    char v1;
    void* ptr0;
    int v2;
    int v3 = 0;
    char v4 = 1;
    char v5 = 0;
    char v6 = 1;
    char v7 = 0;
    char v8 = 0;
    int v9 = v0;
    int* ptr1 = &v1;
    char v10 = &v0 ? 0: 1;
    char v11 = (int)&v0 < 0;
    char v12 = __parity__((unsigned char)&v0);
    char v13 = 0;
    char v14 = 0;
    int v15 = v2;
    int* ptr2 = &v15;
    int* ptr3 = &v15;
    int v16 = param1;
    int v17 = &__libc_csu_fini;
    int v18 = &__libc_csu_init;
    int* ptr4 = &v1;
    int v19 = &main;
    int* ptr5 = &ptr0;
    int v20 = →__libc_start_main();
    hlt();
}

int deregister_tm_clones() {
    return 3;
}

void finalizer_0() {
}

void finalizer_1() {
    char v0 = completed.6532 ? 0: 1;
    char v1 = completed.6532 >= 128;
    char v2 = __parity__(completed.6532);
    char v3 = completed.6532 < 0;
    char v4 = 0;
    char v5 = 0;
    jump v0 ? &sub_8048399: &sub_80483AC;
}

int initializer_0() {
    int result = __gmon_start__;
    if(result) {
        result = sub_80482D0();
    }
    return result;
}

int initializer_1() {
    int v0 = &__JCR_LIST__;
    unsigned char v1 = *(int*)&__JCR_LIST__;
    char v2 = v1 ? 0: 1;
    char v3 = v1 >= 0x80000000;
    char v4 = __parity__((unsigned char)v1);
    char v5 = 0;
    char v6 = 0;
    jump v2 ? &→register_tm_clones: &sub_80483C0;
}

int main() {
    return sum5(1, 2, 3, 4, 5);
}

int sub_80482D0() {
    return __gmon_start__();
}

int sub_804832F() {
    return 0;
}

void sub_8048368() {
}

int sub_8048399() {
    int v0;
    int v1 = v0;
    deregister_tm_clones();
    completed.6532 = 1;
}

void sub_80483AC() {
}

int sub_80483C0() {
    return register_tm_clones();
}

int sum5(int param0, int param1, int param2, int param3, int param4) {
    return param0 + param1 + (param2 + param3) + param4;
}

int →__libc_start_main() {
    int result;
    __libc_start_main();
    return result;
}
