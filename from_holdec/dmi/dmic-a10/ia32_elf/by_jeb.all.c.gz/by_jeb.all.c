
void __libc_csu_fini() {
}

int __libc_csu_init(int param0, int param1, int param2) {
    int result;
    initializer_0();
    int v0 = 0;
    do {
        result = *(int*)(v0 * 4 + (int)&__frame_dummy_init_array_entry){initializer_1}();
        ++v0;
    }
    while(v0 != 1);
    return result;
}

void __x86.get_pc_thunk.bx() {
}

int _start(int param0, int param1) {
    →__libc_start_main();
    hlt();
}

// Stale decompilation - Refresh this view to re-decompile this code
int deregister_tm_clones() {
    return 3;
}

void finalizer_0() {
}

int finalizer_1() {
    int result;
    return result;
}

int initializer_0() {
    int result;
    if(__gmon_start__) {
        sub_80482D0();
    }
    return result;
}

int initializer_1() {
    return register_tm_clones();
}

int main() {
    return sum5(1, 2, 3, 4, 5);
}

int register_tm_clones() {
    return 0;
}

void r→__libc_start_main() {
    jump gvar_804A008;
}

void sub_80482D0() {
    jump __gmon_start__;
}

int sum5(int param0, int param1, int param2, int param3, int param4) {
    return param0 + param1 + (param2 + param3) + param4;
}

int →__libc_start_main() {
    int result;
    ptr___libc_start_main{r→__libc_start_main}();
    return result;
}
