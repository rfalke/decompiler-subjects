
void __libc_csu_fini() {
}

int __libc_csu_init(int param0, int param1, int param2) {
    int result;
    initializer_0();
    int v0 = 0;
    do {
        result = *(int*)(v0 * 4 + (int)&__frame_dummy_init_array_entry){initializer_1}();
        ++v0;
    }
    while(v0 != 1);
    return result;
}

void __x86.get_pc_thunk.bx() {
}

int _start(int param0, int param1) {
    →__libc_start_main();
    hlt();
}

// Stale decompilation - Refresh this view to re-decompile this code
int deregister_tm_clones() {
    return 3;
}

void finalizer_0() {
}

int finalizer_1() {
    int result;
    return result;
}

int initializer_0() {
    int result;
    if(__gmon_start__) {
        sub_8048300();
    }
    return result;
}

int initializer_1() {
    return register_tm_clones();
}

int main(int param0, int param1) {
    int v0;
    int v1;
    int v2;
    int v3 = v0;
    int v4 = v2;
    int v5 = v1;
    int* ptr0 = &param0;
    if(param0 > 0) {
        int v6 = 0;
        do {
            char* __s = *(char**)(v6 * 4 + param1);
            ++v6;
            →puts(__s);
        }
        while(v6 != param0);
    }
    jump v4;
}

int register_tm_clones() {
    return 0;
}

int r→__libc_start_main() {
    /*BAD_CALL!*/ sub_80482D0();
}

int r→puts(char* __s) {
    /*BAD_CALL!*/ sub_80482D0();
}

void sub_80482D0() {
    jump gvar_804A008;
}

void sub_8048300() {
    jump __gmon_start__;
}

int →__libc_start_main() {
    return ptr___libc_start_main{r→__libc_start_main}();
}

int →puts(char* __s) {
    return ptr_puts[0]{r→puts}(__s);
}
