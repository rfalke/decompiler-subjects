
void __libc_csu_fini() {
}

int __libc_csu_init(int param0, int param1, int param2) {
    int result;
    initializer_0();
    int v0 = 0;
    do {
        result = *(int*)(v0 * 4 + (int)&__frame_dummy_init_array_entry){initializer_1}();
        ++v0;
    }
    while(v0 != 1);
    return result;
}

void __x86.get_pc_thunk.bx() {
}

int _start(int param0, int param1) {
    →__libc_start_main();
    hlt();
}

int advanced_1_boolean_minization(int param0, int param1, int param2) {
    return (!param0 && !param1 && param2) || (!param0 && param1 && param2) || (param0 && !param1) ? 1: 0;
}

// Stale decompilation - Refresh this view to re-decompile this code
int deregister_tm_clones() {
    return 3;
}

void finalizer_0() {
}

int finalizer_1() {
    int result;
    return result;
}

int initializer_0() {
    int result;
    if(__gmon_start__) {
        sub_8048360();
    }
    return result;
}

int initializer_1() {
    return register_tm_clones();
}

int intermediate_1_cmp_with_are_constant(int param0) {
    if(0) {
        →puts("not reached");
    }
    return 0;
}

int intermediate_2_cmp_with_extra(int param0) {
    if(param0 > 10 && param0 <= 19) {
        →puts("!=30 is always true");
    }
    if(param0 == 1) {
        →puts("!=2 is always true");
    }
    if(param0 > 10) {
        →puts(">9 is always true");
    }
    return 0;
}

int intermediate_3_division_by_multiplication(int param0) {
    →putchar(param0 / 7);
    return 0;
}

int intermediate_4_swap_with_xor(int param0, int param1) {
    int v0 = param0 ^ param1;
    int __c = v0 ^ param1;
    →putchar(v0 ^ __c);
    →putchar(__c);
    return 0;
}

int main(int param0, unsigned int* param1) {
    int v0;
    int v1;
    int v2 = v0;
    int v3 = v1;
    int* ptr0 = &param0;
    int v4 = intermediate_1_cmp_with_are_constant(param0);
    int v5 = /*BAD_CALL!*/ intermediate_2_cmp_with_extra(param0);
    int v6 = /*BAD_CALL!*/ intermediate_3_division_by_multiplication(param0);
    int v7 = /*BAD_CALL!*/ intermediate_4_swap_with_xor(48, 97);
    int v8 = /*BAD_CALL!*/ advanced_1_boolean_minization(param0 ? 0: 1, ~param0 & 0x1, param0 / 3 * 3 == param0 ? 1: 0);
    /*NO_RETURN*/ →exit((int)**param1 + v5 + (v8 + v6) + (v7 + v4));
}

int register_tm_clones() {
    return 0;
}

int r→__libc_start_main() {
    /*BAD_CALL!*/ sub_8048310();
}

void r→exit(int __status) {
    /*BAD_CALL!*/ sub_8048310();
}

int r→putchar(int __c) {
    /*BAD_CALL!*/ sub_8048310();
}

int r→puts(char* __s) {
    /*BAD_CALL!*/ sub_8048310();
}

void sub_8048310() {
    jump gvar_804A008;
}

void sub_8048360() {
    jump __gmon_start__;
}

int →__libc_start_main() {
    return ptr___libc_start_main{r→__libc_start_main}();
}

void →exit(int __status) {
    ptr_exit[0]{r→exit}(__status);
}

int →putchar(int __c) {
    return ptr_putchar[0]{r→putchar}(__c);
}

int →puts(char* __s) {
    return ptr_puts[0]{r→puts}(__s);
}
