
unsigned int __do_global_ctors_aux() {
    int v0;
    int v1 = v0;
    unsigned int v2 = *(int*)&__CTOR_LIST__;
    if(v2 != -1) {
        unsigned int* ptr0 = (unsigned int*)&__CTOR_LIST__;
        do {
            --ptr0;
            v2();
            v2 = *ptr0;
        }
        while(v2 != -1);
    }
    return -1;
}

unsigned int __do_global_dtors_aux() {
    unsigned int result;
    return result;
}

void __i686.get_pc_thunk.bx() {
}

void __libc_csu_fini() {
}

int __libc_csu_init() {
    initializer_0();
    return &__CTOR_LIST__;
}

int _start(int param0, int param1) {
    int v0;
    char v1;
    void* ptr0;
    int v2;
    int v3 = 0;
    char v4 = 1;
    char v5 = 0;
    char v6 = 1;
    char v7 = 0;
    char v8 = 0;
    int v9 = v0;
    int* ptr1 = &v1;
    char v10 = &v0 ? 0: 1;
    char v11 = (int)&v0 < 0;
    char v12 = __parity__((unsigned char)&v0);
    char v13 = 0;
    char v14 = 0;
    int v15 = v2;
    int* ptr2 = &v15;
    int* ptr3 = &v15;
    int v16 = param1;
    int v17 = &__libc_csu_fini;
    int v18 = &__libc_csu_init;
    int* ptr4 = &v1;
    int v19 = &main;
    int* ptr5 = &ptr0;
    →__libc_start_main();
    hlt();
}

unsigned int fibo_normal(unsigned int param0) {
    unsigned int result;
    if((int)param0 > 1) {
        int v0 = fibo_normal(param0 - 1);
        int v1 = fibo_normal(param0 - 2);
        result = (unsigned int)(v1 + v0);
    }
    else {
        result = param0;
    }
    return result;
}

unsigned int fibo_return_on_stack(unsigned int param0) {
    unsigned int result;
    int v0;
    if((int)param0 > 1) {
        fibo_return_on_stack(param0 - 1);
        fibo_return_on_stack(param0 - 2);
        result = (unsigned int)(v0 * 2);
    }
    return result;
}

// Stale decompilation - Refresh this view to re-decompile this code
int fibo_wrapper_return_on_stack(int param0) {
    int result;
    fibo_return_on_stack(param0);
    return result;
}

unsigned int finalizer_0() {
    return __do_global_dtors_aux();
}

unsigned char frame_dummy() {
    return 0;
}

int initializer_0() {
    int result;
    if(__gmon_start__) {
        →__gmon_start__();
    }
    frame_dummy();
    __do_global_ctors_aux();
    return result;
}

// Stale decompilation - Refresh this view to re-decompile this code
int main() {
    unsigned int v0;
    →printf("Input number: ");
    →__isoc99_scanf();
    int v1 = fibo_normal((int)v0);
    unsigned int v2 = fibo_return_on_stack(v0);
    →printf("fibonacci(%d) = %d %d\n");
    return 0;
}

int sub_804830E() {
    return gvar_8049798();
}

void →__gmon_start__() {
    while(1) {
        /*BAD_CALL!*/ __gmon_start__();
        unsigned int* ptr0 = ptr0 - 1;
        *ptr0 = 0;
        --ptr0;
        *ptr0 = gvar_8049794;
    }
}

void →__isoc99_scanf() {
    while(1) {
        /*BAD_CALL!*/ __isoc99_scanf();
        unsigned int* ptr0 = ptr0 - 1;
        *ptr0 = 24;
        --ptr0;
        *ptr0 = gvar_8049794;
    }
}

void →__libc_start_main() {
    while(1) {
        /*BAD_CALL!*/ __libc_start_main();
        unsigned int* ptr0 = ptr0 - 1;
        *ptr0 = 8;
        --ptr0;
        *ptr0 = gvar_8049794;
    }
}

void →printf(int param0) {
    unsigned int* ptr0;
    while(1) {
        /*BAD_CALL!*/ printf(*(char**)(ptr0 + 1));
        --ptr0;
        *ptr0 = 16;
        --ptr0;
        *ptr0 = gvar_8049794;
    }
}
