
unsigned char __do_global_ctors_aux() {
    unsigned char v0 = *(int*)&__CTOR_LIST__;
    if(v0 != -1) {
        unsigned int* ptr0 = (unsigned int*)&__CTOR_LIST__;
        do {
            --ptr0;
            v0();
            v0 = *ptr0;
        }
        while(v0 != -1);
    }
    return -1;
}

void __do_global_dtors_aux() {
}

void __i686.get_pc_thunk.bx() {
}

void __libc_csu_fini() {
}

int __libc_csu_init() {
    initializer_0();
    return &__CTOR_LIST__;
}

int _start(int param0, int param1) {
    →__libc_start_main();
    hlt();
}

int finalizer_0() {
    int result;
    __do_global_dtors_aux();
    return result;
}

void forever() {
    int v0 = 0;
    while(1) {
        int v1 = v0;
        ++v0;
        →printf("i=%d\n", v1);
    }
}

unsigned char frame_dummy() {
    return 0;
}

int initializer_0() {
    int result;
    if(__gmon_start__) {
        →__gmon_start__();
    }
    frame_dummy();
    __do_global_ctors_aux();
    return result;
}

int main() {
    /*NO_RETURN*/ forever();
}

int r→__gmon_start__() {
    /*BAD_CALL!*/ sub_80482C4();
}

int r→__libc_start_main() {
    /*BAD_CALL!*/ sub_80482C4();
}

int r→printf(char* __format, ...) {
    /*BAD_CALL!*/ sub_80482C4();
}

void sub_80482C4() {
    jump gvar_8049654;
}

int sub_80483F6() {
    return 0;
}

int →__gmon_start__() {
    return ptr___gmon_start__{r→__gmon_start__}();
}

int →__libc_start_main() {
    return ptr___libc_start_main{r→__libc_start_main}();
}

int →printf(char* __format, ...) {
    return ptr_printf[0]{r→printf}(__format);
}
