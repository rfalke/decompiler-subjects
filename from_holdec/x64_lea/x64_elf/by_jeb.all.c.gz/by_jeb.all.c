
void __libc_csu_fini() {
}

void* __libc_csu_init(long param0, long param1) {
    void* result;
    initializer_0();
    long v0 = 0L;
    do {
        result = (void*)*(long*)(v0 * 8L + (long)&__frame_dummy_init_array_entry){initializer_1}();
        ++v0;
    }
    while(v0 != 1L);
    return result;
}

void _dl_relocate_static_pie() {
}

long _start(long param0, long param1) {
    long v0;
    long v1;
    long v2;
    char v3;
    __libc_start_main(&main, v0, (long)&v3, &__libc_csu_init, &__libc_csu_fini, param1, (long)&v1, v2);
    hlt();
}

// Stale decompilation - Refresh this view to re-decompile this code
long deregister_tm_clones() {
    return &__TMC_END__;
}

void finalizer_0() {
}

void finalizer_1() {
    if(!completed.7287) {
        deregister_tm_clones();
        completed.7287 = 1;
    }
}

void* initializer_0() {
    void* result = __gmon_start__;
    if(result) {
        result = (void*)result();
    }
    return result;
}

long initializer_1() {
    return register_tm_clones();
}

long main() {
    →printf("lea1 should=0x1a2a3a4a5a6a7b8b/1885383485026892683 is=0x%016lx\n", 1885383485026892683L);
    →printf("lea2 should=0x1a2a3a4a5a6a7b8b/1885383485026892683 is=0x%016lx\n", 1885383485026892683L);
    →printf("lea3 should=0x000000005b6b7b8b/         1533770635 is=0x%016lx\n", 1533770635L);
    →printf("lea4 should=0x000000005b6b7b8b/         1533770635 is=0x%016lx\n", 1533770635L);
    →printf("lea5 should=0x1b2b3b4b5b6b7b8b/1957723657864969099 is=0x%016lx\n", 1957723657864969099L);
    →printf("lea6 should=0x000000005b6b7b8b/         1533770635 is=0x%016lx\n", 1533770635L);
    return 0L;
}

long register_tm_clones() {
    return 0L;
}

int r→printf(char* __format, ...) {
    jump gvar_404010;
}

int →printf(char* __format, ...) {
    return ptr_printf[0]{r→printf}(__format);
}
