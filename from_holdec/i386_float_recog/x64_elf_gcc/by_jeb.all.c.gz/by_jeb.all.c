
void __libc_csu_fini() {
}

void* __libc_csu_init(long param0, long param1) {
    void* result;
    initializer_0();
    long v0 = 0L;
    do {
        result = (void*)*(long*)(v0 * 8L + (long)&__frame_dummy_init_array_entry){initializer_1}();
        ++v0;
    }
    while(v0 != 1L);
    return result;
}

void _dl_relocate_static_pie() {
}

long _start(long param0, long param1) {
    long v0;
    long v1;
    long v2;
    char v3;
    __libc_start_main(&main, v0, (long)&v3, &__libc_csu_init, &__libc_csu_fini, param1, (long)&v1, v2);
    hlt();
}

// Stale decompilation - Refresh this view to re-decompile this code
long deregister_tm_clones() {
    return &__TMC_END__;
}

long double_to_double() {
    __int128 v0;
    →printf("got 2*x=%f\n", v0);
    return 0L;
}

long double_to_unknown() {
    __int128 v0;
    →printf("got a double with      0x%02x 0x%02x 0x%02x 0x%02x 0x%02x 0x%02x 0x%02x 0x%02x\n", (unsigned long)v0 >>> 56, (unsigned long)(unsigned char)(v0 >>> 0x30X), (unsigned long)(unsigned char)(v0 >>> 0x28X), (unsigned long)(unsigned char)(v0 >>> 0x20X), (unsigned long)((unsigned int)v0 >>> 24), (unsigned long)(unsigned char)(v0 >>> 0x10X), (unsigned long)(unsigned char)(v0 >>> 0x8X), (unsigned long)v0 & 0xffL);
    return 0L;
}

void finalizer_0() {
}

void finalizer_1() {
    if(!completed.7287) {
        deregister_tm_clones();
        completed.7287 = 1;
    }
}

void* initializer_0() {
    void* result = __gmon_start__;
    if(result) {
        result = (void*)result();
    }
    return result;
}

long initializer_1() {
    return register_tm_clones();
}

long main(int param0) {
    double v0;
    char v1;
    __int128 v2;
    __int128 v3;
    long v4;
    unknown_to_unknown();
    double_to_unknown();
    unknown_to_double();
    double v5 = (double)param0;
    double_to_double();
    *(__int128*)&v0 = 2.32;
    →printf("unknown: int-a=%d double=%f int-b=%d long double=%Lf int-c=%d\n", 100L, v2, 102L, v3, v4);
    *&v1 = v5 + 2.42;
    →printf("double: int-a=%d double=%f int-b=%d long double=%Lf int-c=%d\n", 200L, v2, 202L, v3, v4);
    return 0L;
}

long register_tm_clones() {
    return 0L;
}

int r→printf(char* __format, ...) {
    jump gvar_404010;
}

long unknown_to_double() {
    __int128 v0;
    →printf("got 2*x=%f\n", v0);
    return 0L;
}

long unknown_to_unknown() {
    __int128 v0;
    →printf("got a double with      0x%02x 0x%02x 0x%02x 0x%02x 0x%02x 0x%02x 0x%02x 0x%02x\n", (unsigned long)v0 >>> 56, (unsigned long)(unsigned char)(v0 >>> 0x30X), (unsigned long)(unsigned char)(v0 >>> 0x28X), (unsigned long)(unsigned char)(v0 >>> 0x20X), (unsigned long)((unsigned int)v0 >>> 24), (unsigned long)(unsigned char)(v0 >>> 0x10X), (unsigned long)(unsigned char)(v0 >>> 0x8X), (unsigned long)v0 & 0xffL);
    return 0L;
}

int →printf(char* __format, ...) {
    return ptr_printf[0]{r→printf}(__format);
}
