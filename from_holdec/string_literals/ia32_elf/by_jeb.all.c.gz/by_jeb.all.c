
void __libc_csu_fini() {
}

int __libc_csu_init(int param0, int param1, int param2) {
    int result;
    initializer_0();
    unsigned int v0 = 0;
    do {
        result = *(int*)(v0 * 4 + (int)&__frame_dummy_init_array_entry){initializer_1}();
        ++v0;
    }
    while(v0 != 1);
    return result;
}

void __x86.get_pc_thunk.bx() {
}

int _start(int param0, int param1) {
    int v0;
    char v1;
    void* ptr0;
    int v2;
    int v3 = 0;
    char v4 = 1;
    char v5 = 0;
    char v6 = 1;
    char v7 = 0;
    char v8 = 0;
    int v9 = v0;
    int* ptr1 = &v1;
    char v10 = &v0 ? 0: 1;
    char v11 = (int)&v0 < 0;
    char v12 = __parity__((unsigned char)&v0);
    char v13 = 0;
    char v14 = 0;
    int v15 = v2;
    int* ptr2 = &v15;
    int* ptr3 = &v15;
    int v16 = param1;
    int v17 = &__libc_csu_fini;
    int v18 = &__libc_csu_init;
    int* ptr4 = &v1;
    int v19 = &main;
    int* ptr5 = &ptr0;
    →__libc_start_main();
    hlt();
}

int deregister_tm_clones() {
    return 3;
}

void finalizer_0() {
}

void finalizer_1() {
    char v0 = completed.6532 ? 0: 1;
    char v1 = completed.6532 >= 128;
    char v2 = __parity__(completed.6532);
    char v3 = completed.6532 < 0;
    char v4 = 0;
    char v5 = 0;
    jump v0 ? &sub_8049159: &sub_804916C;
}

int initializer_0() {
    int result = __gmon_start__;
    if(result) {
        result = sub_8048410();
    }
    return result;
}

int initializer_1() {
    int v0 = &__JCR_LIST__;
    unsigned char v1 = *(int*)&__JCR_LIST__;
    char v2 = v1 ? 0: 1;
    char v3 = v1 >= 0x80000000;
    char v4 = __parity__((unsigned char)v1);
    char v5 = 0;
    char v6 = 0;
    jump v2 ? &→register_tm_clones: &sub_8049180;
}

int main(int param0, int* param1) {
    int v0;
    int v1;
    int v2;
    int v3 = v0;
    int v4 = v1;
    int* ptr0 = &param0;
    int v5 = 39;
    →strchr(param1[0], 39);
    →printf("with single \' quote %p\n");
    v5 = 34;
    /*BAD_CALL!*/ →strchr(param1[0], 34);
    →printf("with double \" quote %p\n");
    /*BAD_CALL!*/ →fopen("with-null-byte", &gvar_8049254);
    →fwrite("with null byte ", 17, 1, v2);
    →fwrite("with null byte ", 1, 17, v2);
    →fclose(v2);
    →puts(&gvar_8049265);
    →puts(&gvar_804927F);
    →puts(&gvar_8049299);
    →puts(&gvar_80492B3);
    →puts(&gvar_80492CD);
    →puts(&gvar_80492E7);
    →puts(&gvar_8049301);
    →puts(&gvar_804931B);
    →puts("hex=0x09 dec=9 char=\tFINI");
    →puts("hex=0x0a dec=10 char=\nFINI");
    →puts(&gvar_804936A);
    →puts(&gvar_8049385);
    →puts("hex=0x0d dec=13 char=\rFINI");
    →puts(&gvar_80493BB);
    →puts(&gvar_80493D6);
    →puts(&gvar_80493F1);
    →puts(&gvar_804940C);
    →puts(&gvar_8049427);
    →puts(&gvar_8049442);
    →puts(&gvar_804945D);
    →puts(&gvar_8049478);
    →puts(&gvar_8049493);
    →puts(&gvar_80494AE);
    →puts(&gvar_80494C9);
    →puts(&gvar_80494E4);
    →puts(&gvar_80494FF);
    →puts(&gvar_804951A);
    →puts(&gvar_8049535);
    →puts(&gvar_8049550);
    →puts(&gvar_804956B);
    →puts(&gvar_8049586);
    →puts("hex=0x20 dec=32 char= FINI");
    →puts("hex=0x21 dec=33 char=!FINI");
    →puts("hex=0x22 dec=34 char=\"FINI");
    →puts("hex=0x23 dec=35 char=#FINI");
    →puts("hex=0x24 dec=36 char=$FINI");
    →puts("hex=0x25 dec=37 char=%FINI");
    →puts("hex=0x26 dec=38 char=&FINI");
    →puts("hex=0x27 dec=39 char=\'FINI");
    →puts("hex=0x28 dec=40 char=(FINI");
    →puts("hex=0x29 dec=41 char=)FINI");
    →puts("hex=0x2a dec=42 char=*FINI");
    →puts("hex=0x2b dec=43 char=+FINI");
    →puts("hex=0x2c dec=44 char=,FINI");
    →puts("hex=0x2d dec=45 char=-FINI");
    →puts("hex=0x2e dec=46 char=.FINI");
    →puts("hex=0x2f dec=47 char=/FINI");
    →puts("hex=0x30 dec=48 char=0FINI");
    →puts("hex=0x31 dec=49 char=1FINI");
    →puts("hex=0x32 dec=50 char=2FINI");
    →puts("hex=0x33 dec=51 char=3FINI");
    →puts("hex=0x34 dec=52 char=4FINI");
    →puts("hex=0x35 dec=53 char=5FINI");
    →puts("hex=0x36 dec=54 char=6FINI");
    →puts("hex=0x37 dec=55 char=7FINI");
    →puts("hex=0x38 dec=56 char=8FINI");
    →puts("hex=0x39 dec=57 char=9FINI");
    →puts("hex=0x3a dec=58 char=:FINI");
    →puts("hex=0x3b dec=59 char=;FINI");
    →puts("hex=0x3c dec=60 char=<FINI");
    →puts("hex=0x3d dec=61 char==FINI");
    →puts("hex=0x3e dec=62 char=>FINI");
    →puts("hex=0x3f dec=63 char=?FINI");
    →puts("hex=0x40 dec=64 char=@FINI");
    →puts("hex=0x41 dec=65 char=AFINI");
    →puts("hex=0x42 dec=66 char=BFINI");
    →puts("hex=0x43 dec=67 char=CFINI");
    →puts("hex=0x44 dec=68 char=DFINI");
    →puts("hex=0x45 dec=69 char=EFINI");
    →puts("hex=0x46 dec=70 char=FFINI");
    →puts("hex=0x47 dec=71 char=GFINI");
    →puts("hex=0x48 dec=72 char=HFINI");
    →puts("hex=0x49 dec=73 char=IFINI");
    →puts("hex=0x4a dec=74 char=JFINI");
    →puts("hex=0x4b dec=75 char=KFINI");
    →puts("hex=0x4c dec=76 char=LFINI");
    →puts("hex=0x4d dec=77 char=MFINI");
    →puts("hex=0x4e dec=78 char=NFINI");
    →puts("hex=0x4f dec=79 char=OFINI");
    →puts("hex=0x50 dec=80 char=PFINI");
    →puts("hex=0x51 dec=81 char=QFINI");
    →puts("hex=0x52 dec=82 char=RFINI");
    →puts("hex=0x53 dec=83 char=SFINI");
    →puts("hex=0x54 dec=84 char=TFINI");
    →puts("hex=0x55 dec=85 char=UFINI");
    →puts("hex=0x56 dec=86 char=VFINI");
    →puts("hex=0x57 dec=87 char=WFINI");
    →puts("hex=0x58 dec=88 char=XFINI");
    →puts("hex=0x59 dec=89 char=YFINI");
    →puts("hex=0x5a dec=90 char=ZFINI");
    →puts("hex=0x5b dec=91 char=[FINI");
    →puts("hex=0x5c dec=92 char=\\FINI");
    →puts("hex=0x5d dec=93 char=]FINI");
    →puts("hex=0x5e dec=94 char=^FINI");
    →puts("hex=0x5f dec=95 char=_FINI");
    →puts("hex=0x60 dec=96 char=`FINI");
    →puts("hex=0x61 dec=97 char=aFINI");
    →puts("hex=0x62 dec=98 char=bFINI");
    →puts("hex=0x63 dec=99 char=cFINI");
    →puts("hex=0x64 dec=100 char=dFINI");
    →puts("hex=0x65 dec=101 char=eFINI");
    →puts("hex=0x66 dec=102 char=fFINI");
    →puts("hex=0x67 dec=103 char=gFINI");
    →puts("hex=0x68 dec=104 char=hFINI");
    →puts("hex=0x69 dec=105 char=iFINI");
    →puts("hex=0x6a dec=106 char=jFINI");
    →puts("hex=0x6b dec=107 char=kFINI");
    →puts("hex=0x6c dec=108 char=lFINI");
    →puts("hex=0x6d dec=109 char=mFINI");
    →puts("hex=0x6e dec=110 char=nFINI");
    →puts("hex=0x6f dec=111 char=oFINI");
    →puts("hex=0x70 dec=112 char=pFINI");
    →puts("hex=0x71 dec=113 char=qFINI");
    →puts("hex=0x72 dec=114 char=rFINI");
    →puts("hex=0x73 dec=115 char=sFINI");
    →puts("hex=0x74 dec=116 char=tFINI");
    →puts("hex=0x75 dec=117 char=uFINI");
    →puts("hex=0x76 dec=118 char=vFINI");
    →puts("hex=0x77 dec=119 char=wFINI");
    →puts("hex=0x78 dec=120 char=xFINI");
    →puts("hex=0x79 dec=121 char=yFINI");
    →puts("hex=0x7a dec=122 char=zFINI");
    →puts("hex=0x7b dec=123 char={FINI");
    →puts("hex=0x7c dec=124 char=|FINI");
    →puts("hex=0x7d dec=125 char=}FINI");
    →puts("hex=0x7e dec=126 char=~FINI");
    →puts(&gvar_8049FC1);
    →puts(&gvar_8049FDD);
    →puts(&gvar_8049FF9);
    →puts(&gvar_804A015);
    →puts(&gvar_804A031);
    →puts(&gvar_804A04D);
    →puts(&gvar_804A069);
    →puts(&gvar_804A085);
    →puts(&gvar_804A0A1);
    →puts(&gvar_804A0BD);
    →puts(&gvar_804A0D9);
    →puts(&gvar_804A0F5);
    →puts(&gvar_804A111);
    →puts(&gvar_804A12D);
    →puts(&gvar_804A149);
    →puts(&gvar_804A165);
    →puts(&gvar_804A181);
    →puts(&gvar_804A19D);
    →puts(&gvar_804A1B9);
    →puts(&gvar_804A1D5);
    →puts(&gvar_804A1F1);
    →puts(&gvar_804A20D);
    →puts(&gvar_804A229);
    →puts(&gvar_804A245);
    →puts(&gvar_804A261);
    →puts(&gvar_804A27D);
    →puts(&gvar_804A299);
    →puts(&gvar_804A2B5);
    →puts(&gvar_804A2D1);
    →puts(&gvar_804A2ED);
    →puts(&gvar_804A309);
    →puts(&gvar_804A325);
    →puts(&gvar_804A341);
    →puts(&gvar_804A35D);
    →puts(&gvar_804A379);
    →puts(&gvar_804A395);
    →puts(&gvar_804A3B1);
    →puts(&gvar_804A3CD);
    →puts(&gvar_804A3E9);
    →puts(&gvar_804A405);
    →puts(&gvar_804A421);
    →puts(&gvar_804A43D);
    →puts(&gvar_804A459);
    →puts(&gvar_804A475);
    →puts(&gvar_804A491);
    →puts(&gvar_804A4AD);
    →puts(&gvar_804A4C9);
    →puts(&gvar_804A4E5);
    →puts(&gvar_804A501);
    →puts(&gvar_804A51D);
    →puts(&gvar_804A539);
    →puts(&gvar_804A555);
    →puts(&gvar_804A571);
    →puts(&gvar_804A58D);
    →puts(&gvar_804A5A9);
    →puts(&gvar_804A5C5);
    →puts(&gvar_804A5E1);
    →puts(&gvar_804A5FD);
    →puts(&gvar_804A619);
    →puts(&gvar_804A635);
    →puts(&gvar_804A651);
    →puts(&gvar_804A66D);
    →puts(&gvar_804A689);
    →puts(&gvar_804A6A5);
    →puts(&gvar_804A6C1);
    →puts(&gvar_804A6DD);
    →puts(&gvar_804A6F9);
    →puts(&gvar_804A715);
    →puts(&gvar_804A731);
    →puts(&gvar_804A74D);
    →puts(&gvar_804A769);
    →puts(&gvar_804A785);
    →puts(&gvar_804A7A1);
    →puts(&gvar_804A7BD);
    →puts(&gvar_804A7D9);
    →puts(&gvar_804A7F5);
    →puts(&gvar_804A811);
    →puts(&gvar_804A82D);
    →puts(&gvar_804A849);
    →puts(&gvar_804A865);
    →puts(&gvar_804A881);
    →puts(&gvar_804A89D);
    →puts(&gvar_804A8B9);
    →puts(&gvar_804A8D5);
    →puts(&gvar_804A8F1);
    →puts(&gvar_804A90D);
    →puts(&gvar_804A929);
    →puts(&gvar_804A945);
    →puts(&gvar_804A961);
    →puts(&gvar_804A97D);
    →puts(&gvar_804A999);
    →puts(&gvar_804A9B5);
    →puts(&gvar_804A9D1);
    →puts(&gvar_804A9ED);
    →puts(&gvar_804AA09);
    →puts(&gvar_804AA25);
    →puts(&gvar_804AA41);
    →puts(&gvar_804AA5D);
    →puts(&gvar_804AA79);
    →puts(&gvar_804AA95);
    →puts(&gvar_804AAB1);
    →puts(&gvar_804AACD);
    →puts(&gvar_804AAE9);
    →puts(&gvar_804AB05);
    →puts(&gvar_804AB21);
    →puts(&gvar_804AB3D);
    →puts(&gvar_804AB59);
    →puts(&gvar_804AB75);
    →puts(&gvar_804AB91);
    →puts(&gvar_804ABAD);
    →puts(&gvar_804ABC9);
    →puts(&gvar_804ABE5);
    →puts(&gvar_804AC01);
    →puts(&gvar_804AC1D);
    →puts(&gvar_804AC39);
    →puts(&gvar_804AC55);
    →puts(&gvar_804AC71);
    →puts(&gvar_804AC8D);
    →puts(&gvar_804ACA9);
    →puts(&gvar_804ACC5);
    →puts(&gvar_804ACE1);
    →puts(&gvar_804ACFD);
    →puts(&gvar_804AD19);
    →puts(&gvar_804AD35);
    →puts(&gvar_804AD51);
    →puts(&gvar_804AD6D);
    →puts(&gvar_804AD89);
    →puts(&gvar_804ADA5);
    →puts(&gvar_804ADC1);
    return 0;
}

int sub_8048396() {
    return gvar_804C008();
}

int sub_8048410() {
    return __gmon_start__();
}

int sub_80490EF() {
    return 0;
}

void sub_8049128() {
}

int sub_8049159() {
    int v0;
    int v1 = v0;
    deregister_tm_clones();
    completed.6532 = 1;
}

void sub_804916C() {
}

int sub_8049180() {
    return register_tm_clones();
}

void →__libc_start_main() {
    while(1) {
        /*BAD_CALL!*/ __libc_start_main();
        unsigned int* ptr0 = ptr0 - 1;
        *ptr0 = 40;
        --ptr0;
        *ptr0 = gvar_804C004;
    }
}

void →fopen(int param0, int param1) {
    unsigned int* ptr0;
    while(1) {
        /*BAD_CALL!*/ fopen(*(char**)(ptr0 + 1), *(char**)(ptr0 + 2));
        --ptr0;
        *ptr0 = 48;
        --ptr0;
        *ptr0 = gvar_804C004;
    }
}

void →fwrite(int param0, int param1, int param2, int param3) {
    unsigned int* ptr0;
    while(1) {
        /*BAD_CALL!*/ fwrite(*(void**)(ptr0 + 1), *(size_t*)(ptr0 + 2), *(size_t*)(ptr0 + 3), *(FILE**)(ptr0 + 4));
        --ptr0;
        *ptr0 = 16;
        --ptr0;
        *ptr0 = gvar_804C004;
    }
}

void →printf(int param0) {
    unsigned int* ptr0;
    while(1) {
        /*BAD_CALL!*/ printf(*(char**)(ptr0 + 1));
        --ptr0;
        *ptr0 = 0;
        --ptr0;
        *ptr0 = gvar_804C004;
    }
}

void →puts(int param0) {
    unsigned int* ptr0;
    while(1) {
        /*BAD_CALL!*/ puts(*(char**)(ptr0 + 1));
        --ptr0;
        *ptr0 = 24;
        --ptr0;
        *ptr0 = gvar_804C004;
    }
}

void →strchr(int param0, int param1) {
    unsigned int* ptr0;
    while(1) {
        /*BAD_CALL!*/ strchr(*(char**)(ptr0 + 1), *(int*)(ptr0 + 2));
        --ptr0;
        *ptr0 = 32;
        --ptr0;
        *ptr0 = gvar_804C004;
    }
}
