
void __libc_csu_fini() {
}

void* __libc_csu_init(long param0, long param1) {
    void* result;
    initializer_0();
    long v0 = 0L;
    do {
        result = (void*)*(long*)(v0 * 8L + (long)&__frame_dummy_init_array_entry){initializer_1}();
        ++v0;
    }
    while(v0 != 1L);
    return result;
}

void _dl_relocate_static_pie() {
}

long _start(long param0, long param1) {
    long v0;
    long v1;
    long v2;
    char v3;
    __libc_start_main(&main, v0, (long)&v3, &__libc_csu_init, &__libc_csu_fini, param1, (long)&v1, v2);
    hlt();
}

// Stale decompilation - Refresh this view to re-decompile this code
long deregister_tm_clones() {
    return &__TMC_END__;
}

void finalizer_0() {
}

void finalizer_1() {
    if(!completed.7287) {
        deregister_tm_clones();
        completed.7287 = 1;
    }
}

void* initializer_0() {
    void* result = __gmon_start__;
    if(result) {
        result = (void*)result();
    }
    return result;
}

long initializer_1() {
    return register_tm_clones();
}

long log_size_7_var_000(long param0, long param1, long param2, long param3, long param4, long param5) {
    unsigned short i;
    for(i = 0; !((0x909 >>> i) & 0x1); ++i) {
    }
    long v0 = (unsigned long)(short)((unsigned char)((unsigned long)(unsigned char)((~(1 << (i % 16)) & 0x2c45) | (0 << (i % 16))) | ((unsigned long)0xffff00L << 8)) * 25) | ((unsigned long)0xffffL << 16);
    long v1 = (unsigned long)((unsigned int)((unsigned long)(unsigned short)(((unsigned int)(unsigned short)((unsigned long)(unsigned char)((~(1 << (i % 16)) & 0x2c45) | (0 << (i % 16))) | ((unsigned long)0xffff00L << 8)) * 14361) >>> 16) | ((unsigned long)(((unsigned long)__ror__(__parity__((unsigned char)((~(1 << (i % 16)) & 0x2c45) | (0 << (i % 16)))) ? 0x21f0000: 0x21f0001, 1) >>> 16L) & 0xffffffffffffL) << 16)) * 0x1000) & 0x3fffffffffffffffL;
    unsigned long v2 = (unsigned long)((unsigned __int128)v0 | ((unsigned __int128)v1 << 64)) / -964798665872433767L;
    return (unsigned long)((unsigned __int128)v0 | ((unsigned __int128)v1 << 64)) % -964798665872433767L + (unsigned long)((unsigned int)((unsigned long)i | ((unsigned long)0xffffL << 16)) + 1483374932) + ((unsigned long)(unsigned int)((unsigned long)(((unsigned int)v2 >>> 11) & 0x1FFFFF) | ((unsigned long)2699500953L << 21)) + ((unsigned long)((unsigned short)v2 & 0x9b0e) | ((unsigned long)((v2 >>> 16L) & 0xffffffffffffL) << 16))) + (((unsigned long)((~(1 << (i % 16)) & 0x2c45) | (0 << (i % 16))) | ((unsigned long)0x1d66L << 16)) + ((unsigned long)(unsigned char)(v2 >>> 11L) | ((unsigned long)5996697L << 8)) + (((unsigned long)(unsigned int)((unsigned long)(((unsigned int)v2 >>> 11) & 0x1FFFFF) | ((unsigned long)2699500953L << 21)) | ((unsigned long)-1 << 32)) + 2L)) + 4614847253645828607L;
}

long log_size_7_var_001(long param0, long param1, long param2, long param3, long param4, long param5) {
    return 0x3fffffff00000000L;
}

long log_size_7_var_002(long param0, long param1, long param2, long param3, long param4, long param5) {
    long i;
    for(i = 63L; !(3252649574L >>> i); --i) {
    }
    unsigned long v0 = 192862720L / (unsigned long)((unsigned long)((unsigned short)i * 2) | ((unsigned long)((i >>> 16L) & 0xffffffffffffL) << 16) | 0xc000000000000000L);
    unsigned long v1 = 192862720L % (unsigned long)((unsigned long)((unsigned short)i * 2) | ((unsigned long)((i >>> 16L) & 0xffffffffffffL) << 16) | 0xc000000000000000L);
    long v2 = (unsigned long)(((unsigned int)~((((unsigned long)((unsigned short)i * 2) | ((unsigned long)((i >>> 16L) & 0xffffffffffffL) << 16) | 0xc000000000000000L) >>> 15L) & 0x1L) * 0x8000) | ((unsigned int)((unsigned long)((unsigned short)i * 2) | ((unsigned long)((i >>> 16L) & 0xffffffffffffL) << 16) | 0xc000000000000000L) & 0xffff7fff)) | ((unsigned long)(unsigned int)(((unsigned long)((unsigned short)i * 2) | ((unsigned long)((i >>> 16L) & 0xffffffffffffL) << 16) | 0xc000000000000000L) >>> 32L) << 32);
    long j;
    for(j = 0L; !((0xf800L >>> j) & 0x1L); ++j) {
    }
    return j * -1501704645L - 0xf800L + ((unsigned long)((unsigned short)v2 + 12161) | ((unsigned long)0x720000000020L << 16)) + (((unsigned long)12161 | ((unsigned long)((v2 >>> 16L) & 0xffffffffffffL) << 16)) + ((unsigned long)(unsigned char)v0 | ((unsigned long)((unsigned char)(v0 >>> 8L) ^ (unsigned char)v0) << 8) | ((unsigned long)((v0 >>> 16L) & 0xffffffffffffL) << 16))) + (((unsigned long)(unsigned char)v1 | ((unsigned long)(((unsigned char)(v1 >>> 8L) + 240) | (unsigned char)v0) << 8) | ((unsigned long)((v1 >>> 16L) & 0xffffffffffffL) << 16)) + 0x4e00009371276450L);
}

long log_size_7_var_003(long param0, long param1, long param2, long param3, long param4, long param5) {
    long v0 = (unsigned long)((unsigned short)5828419384702221953L | 0xc000) | ((unsigned long)88934621958957L << 16);
    long v1 = (unsigned long)(0x2dcda24e - ((unsigned int)((unsigned short)((unsigned short)((unsigned long)(unsigned short)((unsigned int)1955 | ((unsigned int)(unsigned short)(((unsigned __int128)32661758096083L | ((unsigned __int128)(14886 % (unsigned short)((unsigned short)5828419384702221953L | 0xc000)) << 48) | ((unsigned __int128)10900283331636L << 64)) >>> 0x2FX) << 15) | ((unsigned int)0 << 31)) | ((unsigned long)211464667939065L << 16)) + 0x1dd3) >= 17402) - 1716743463));
    short i;
    for(i = 15; !(57322 >>> i); --i) {
    }
    return ((unsigned long)(unsigned char)v1 | ((unsigned long)219060L << 8)) + ((unsigned long)i | ((unsigned long)8700128075026L << 16)) + (((unsigned long)64949 | ((unsigned long)(((unsigned long)((unsigned int)((unsigned long)__ror__((unsigned short)v0, 27) | ((unsigned long)((v0 >>> 16L) & 0xffffffffffffL) << 16)) >>> 1L) >>> 16L) & 0xffffffffffffL) << 16)) + v1) - 570171602821790202L;
}

long log_size_7_var_004(long param0, long param1, long param2, long param3, long param4, long param5) {
    long i;
    for(i = 63L; !(9219113998380114091L >>> i); --i) {
    }
    return (unsigned long)((unsigned int)i + 1870936321) + 1766550917L;
}

long log_size_7_var_006(long param0, long param1, long param2, long param3, long param4, long param5) {
    return -2751101117722397037L;
}

long log_size_7_var_007(long param0, long param1, long param2, long param3, long param4, long param5) {
    short i;
    for(i = 15; !(47159 >>> i); --i) {
    }
    long v0 = (unsigned long)(unsigned int)((unsigned long)0xbe17dcb | ((unsigned long)((unsigned int)((unsigned long)((long)(unsigned int)(unsigned long)((unsigned int)((unsigned long)(i - 3471) | ((unsigned long)179678981700517L << 16)) * -58431) == ((unsigned long)(unsigned int)(unsigned long)((unsigned int)((unsigned long)(i - 3471) | ((unsigned long)179678981700517L << 16)) * -58431) | ((unsigned long)(unsigned int)(((long)(unsigned int)((unsigned long)(i - 3471) | ((unsigned long)179678981700517L << 16)) * -58431L) >>> 32L) << 32)) ? (unsigned short)((unsigned long)(i - 3471) | ((unsigned long)179678981700517L << 16)): 30180) | ((unsigned long)((((unsigned long)(i - 3471) | ((unsigned long)179678981700517L << 16)) >>> 16L) & 0xffffffffffffL) << 16)) + 17414200) << 29) | ((unsigned long)0 << 61));
    long v1 = (unsigned long)((unsigned short)(unsigned int)(((long)(unsigned int)((unsigned long)(i - 3471) | ((unsigned long)179678981700517L << 16)) * -58431L) >>> 32L) + 0x75e5) | ((unsigned long)12887314765868L << 16);
    long v2 = (unsigned long)((unsigned int)(unsigned char)(unsigned int)(((long)(unsigned int)((unsigned long)(i - 3471) | ((unsigned long)179678981700517L << 16)) * -58431L) >>> 32L) - 1709285824);
    return (unsigned long)(((unsigned int)(unsigned short)v1 * (unsigned int)(short)(unsigned char)((unsigned long)((unsigned int)((unsigned long)(i - 3471) | ((unsigned long)179678981700517L << 16)) * -58431) - 844583060495955428L)) >>> 16) + (unsigned long)__rol__((unsigned int)((unsigned long)((unsigned char)v2 - 34) | ((unsigned long)((v2 >>> 8L) & 0xffffffffffffffL) << 8)), 7) + ((unsigned long)(unsigned int)(((long)(unsigned int)((unsigned long)(i - 3471) | ((unsigned long)179678981700517L << 16)) * -58431L) >>> 32L) + ((unsigned long)((unsigned short)v0 + 1) | ((unsigned long)((v0 >>> 16L) & 0xffffffffffffL) << 16))) + (((unsigned long)((unsigned short)v1 * (short)(unsigned char)((unsigned long)((unsigned int)((unsigned long)(i - 3471) | ((unsigned long)179678981700517L << 16)) * -58431) - 844583060495955428L)) | ((unsigned long)((((unsigned long)((unsigned int)((unsigned long)(i - 3471) | ((unsigned long)179678981700517L << 16)) * -58431) - 844583060495955428L) >>> 16L) & 0xffffffffffffL) << 16)) + ((unsigned long)(unsigned char)(-7019932222830795729L >>> (v2 & 0x1fL)) | ((unsigned long)0x1226daad5ac8c5L << 8)) + (((unsigned long)(unsigned short)((unsigned int)479 | ((unsigned int)(unsigned short)((unsigned long)((unsigned char)(-7019932222830795729L >>> (v2 & 0x1fL)) + 0xee) | ((unsigned long)((((-7019932222830795729L >>> (v2 & 0x1fL)) & 0xffffffffL) >>> 8L) & 0xffffffffffffffL) << 8)) << 10) | ((unsigned int)0 << 26)) | ((unsigned long)((((-7019932222830795729L >>> (v2 & 0x1fL)) & 0xffffffffL) >>> 16L) & 0xffffffffffffL) << 16)) + v1)) + 6492320389173027997L;
}

long log_size_7_var_008(long param0, long param1, long param2, long param3, long param4, long param5) {
    long i;
    for(i = 63L; !(1704447473049432587L >>> i); --i) {
    }
    short j;
    for(j = 0; !((40189 >>> j) & 0x1); ++j) {
    }
    long v0 = (unsigned long)__rol__((unsigned long)(unsigned int)((unsigned long)(((unsigned short)i + 1) * 46117) | ((unsigned long)15771516934012L << 16)), 1);
    long v1 = (unsigned long)((unsigned short)__ror__((unsigned long)0xec0000 | ((unsigned long)((v0 >>> 32L) & 0x1L) << 32), 1) ^ 0xdc75) | ((unsigned long)(((unsigned long)(unsigned int)__ror__((unsigned long)0xec0000 | ((unsigned long)((v0 >>> 32L) & 0x1L) << 32), 1) >>> 16L) & 0xffffffffffffL) << 16);
    long v2 = (unsigned long)(unsigned int)((unsigned long)(((unsigned int)((unsigned long)j | ((unsigned long)0x112cL << 16)) >>> 5) & 0x7FFFFFF) | ((unsigned long)(unsigned int)((unsigned long)(((unsigned int)__ror__((unsigned long)0xec0000 | ((unsigned long)((v0 >>> 32L) & 0x1L) << 32), 1) >>> 1) & 0x7FFFFFFF) | ((unsigned long)(unsigned int)v0 << 31) | ((unsigned long)0 << 63)) << 27) | ((unsigned long)0 << 59));
    long v3 = ((j >>> 3) & 0x1) != 0 ? 183L: (unsigned int)v1 < 3255135096 ? 65435L: 3255135096L;
    v2 = (unsigned long)((unsigned char)v2 ^ 0x2) | ((unsigned long)((v2 >>> 8L) & 0xffffffffffffffL) << 8);
    long v4 = ((unsigned char)v2 ? 0: 1) || ((v2 >>> 7L) & 0x1L) != 0 ? 4237600659L: 0xc0000000L;
    long v5 = (unsigned long)((unsigned int)((unsigned long)(((unsigned char)((unsigned long)j | ((unsigned long)0x112cL << 16)) * 8 + 10) ^ 0xfe) | ((unsigned long)0x227100L << 8)) >>> 1);
    long v6 = (unsigned long)(((((unsigned char)((unsigned long)j | ((unsigned long)0x112cL << 16)) * 8 + 10) & (unsigned char)v2) < 0 ? (unsigned short)((unsigned int)((unsigned long)(((unsigned char)((unsigned long)j | ((unsigned long)0x112cL << 16)) * 8 + 10) ^ 0xfe) | ((unsigned long)0x227100L << 8)) >>> 1): 0) >> 19) | ((unsigned long)((((((unsigned char)((unsigned long)j | ((unsigned long)0x112cL << 16)) * 8 + 10) & (unsigned char)v2) < 0 ? (unsigned long)((unsigned int)((unsigned long)(((unsigned char)((unsigned long)j | ((unsigned long)0x112cL << 16)) * 8 + 10) ^ 0xfe) | ((unsigned long)0x227100L << 8)) >>> 1): 0L) >>> 16L) & 0xffffffffffffL) << 16);
    if((unsigned int)((unsigned long)j | ((unsigned long)0x112cL << 16)) * 8 != -7690) {
        for(int k = 31; !(((unsigned int)((unsigned long)j | ((unsigned long)0x112cL << 16)) * 8 + 7690) >>> k); --k) {
        }
    }
    return ((unsigned long)j | ((unsigned long)0x112cL << 16)) * 8L + (unsigned long)(unsigned int)((unsigned long)2 | ((unsigned long)(unsigned int)((unsigned long)0 | ((unsigned long)(((unsigned long)__ror__((unsigned short)v3, 24) | ((unsigned long)((v3 >>> 16L) & 0xffffffffffffL) << 16)) & 0x7ffffffffffL) << 21)) << 20) | ((unsigned long)0 << 52)) + (((unsigned long)((unsigned short)((unsigned char)v1 + 0xbb) ^ 0x61ff) | ((unsigned long)229028633462406L << 16)) + ((unsigned long)((v4 | 0x271aL) < 0L ? 0xFF: (unsigned short)(v4 | 0x271aL)) | ((unsigned long)(((v4 | 0x271aL) >>> 16L) & 0xffffffffffffL) << 16))) + (((unsigned long)(unsigned char)v6 | ((unsigned long)(unsigned char)__rol__((unsigned short)(unsigned char)(v6 >>> 8L), 1) << 8) | ((unsigned long)((v6 >>> 16L) & 0xffffffffffffL) << 16)) + v5 + (v4 + v2)) + 3437123542072137369L;
}

long log_size_7_var_009(long param0, long param1, long param2, long param3, long param4, long param5) {
    long i;
    for(i = 0L; !((0x1fff7effL >>> i) & 0x1L); ++i) {
    }
    return i;
}

long main(long param0, long param1, long param2, long param3, long param4, long param5) {
    long v0 = log_size_7_var_000(param0, param1, param2, param3, param4, param5);
    long v1 = /*BAD_CALL!*/ log_size_7_var_001(param0, param1, param2, param3, param4, param5);
    long v2 = /*BAD_CALL!*/ log_size_7_var_002(param0, param1, param2, param3, param4, param5);
    long v3 = /*BAD_CALL!*/ log_size_7_var_003(param0, param1, param2, param3, param4, param5);
    long v4 = /*BAD_CALL!*/ log_size_7_var_004(param0, param1, param2, param3, param4, param5);
    long v5 = /*BAD_CALL!*/ log_size_7_var_005(param0, param1, param2, param3, param4, param5);
    long v6 = /*BAD_CALL!*/ log_size_7_var_006(param0, param1, param2, param3, param4, param5);
    long v7 = /*BAD_CALL!*/ log_size_7_var_007(param0, param1, param2, param3, param4, param5);
    long v8 = /*BAD_CALL!*/ log_size_7_var_008(param0, param1, param2, param3, param4, param5);
    long v9 = log_size_7_var_009(param0, param1, param2, param3, param4, param5);
    if((v1 + v2 + (v3 + v4) + (v5 + v6 + (v7 + v8)) + (v9 + v0))) {
        /*NO_RETURN*/ →__assert_fail("sum==0", "source_complex_with_base_10_funcs_of_size_128.c", 31, (char*)&__PRETTY_FUNCTION__.2443);
    }
    return 0L;
}

long register_tm_clones() {
    return 0L;
}

void r→__assert_fail(char* __assertion, char* __file, unsigned int __line, char* __function) {
    jump gvar_405010;
}

void →__assert_fail(char* __assertion, char* __file, unsigned int __line, char* __function) {
    ptr___assert_fail[0]{r→__assert_fail}(__assertion, __file, (unsigned int)__line, __function);
}
