
void __libc_csu_fini() {
}

void* __libc_csu_init(long param0, long param1, long param2) {
    void* result;
    initializer_0();
    unsigned long v0 = 0L;
    do {
        result = (void*)*(long*)(v0 * 8L + (long)&__frame_dummy_init_array_entry){initializer_1}();
        ++v0;
    }
    while(v0 != 1L);
    return result;
}

void _dl_relocate_static_pie() {
}

long _start(long param0, long param1) {
    long v0;
    long v1;
    long v2;
    long v3;
    char v4;
    long v5 = 0L;
    char v6 = 1;
    char v7 = 0;
    char v8 = 1;
    char v9 = 0;
    char v10 = 0;
    long v11 = param1;
    long v12 = v0;
    long* ptr0 = &v4;
    char v13 = &v0 ? 0: 1;
    char v14 = (long)&v0 < 0L;
    char v15 = __parity__((unsigned char)&v0);
    char v16 = 0;
    char v17 = 0;
    long* ptr1 = &v1;
    long v18 = &__libc_csu_fini;
    long v19 = &__libc_csu_init;
    long v20 = &main;
    long* ptr2 = &v2;
    long v21 = __libc_start_main(&main, v12, (long)&v4, &__libc_csu_init, &__libc_csu_fini, v11, (long)&v1, v3);
    hlt();
}

long deregister_tm_clones() {
    return &__TMC_END__;
}

void finalizer_0() {
}

void finalizer_1() {
    char v0 = completed.7287 ? 0: 1;
    char v1 = completed.7287 >= 128;
    char v2 = __parity__(completed.7287);
    char v3 = completed.7287 < 0;
    char v4 = 0;
    char v5 = 0;
    jump v0 ? &sub_40116D: &sub_401180;
}

void* initializer_0() {
    void* result = __gmon_start__;
    if(result) {
        result = (void*)result();
    }
    return result;
}

long initializer_1() {
    return register_tm_clones();
}

long log_size_7_var_000(long param0, long param1, long param2, long param3, long param4, long param5) {
    return 0x2bbb37a2a39e9d36L;
}

long log_size_7_var_001(long param0, long param1, long param2, long param3, long param4, long param5) {
    return 0x3fffffff00000000L;
}

long log_size_7_var_002(long param0, long param1, long param2, long param3, long param4, long param5) {
    long i;
    for(i = 63L; !(3252649574L >>> i); --i) {
    }
    unsigned long v0 = 192862720L / (unsigned long)((unsigned long)((unsigned short)i * 2) | ((unsigned long)((i >>> 16L) & 0xffffffffffffL) << 16) | 0xc000000000000000L);
    unsigned long v1 = 192862720L % (unsigned long)((unsigned long)((unsigned short)i * 2) | ((unsigned long)((i >>> 16L) & 0xffffffffffffL) << 16) | 0xc000000000000000L);
    long v2 = (unsigned long)(((unsigned int)~((((unsigned long)((unsigned short)i * 2) | ((unsigned long)((i >>> 16L) & 0xffffffffffffL) << 16) | 0xc000000000000000L) >>> 15L) & 0x1L) * 0x8000) | ((unsigned int)((unsigned long)((unsigned short)i * 2) | ((unsigned long)((i >>> 16L) & 0xffffffffffffL) << 16)) & 0xffff7fff)) | ((unsigned long)(unsigned int)(((unsigned long)((unsigned short)i * 2) | ((unsigned long)((i >>> 16L) & 0xffffffffffffL) << 16) | 0xc000000000000000L) >>> 32L) << 32);
    long j;
    for(j = 0L; !((0xf800L >>> j) & 0x1L); ++j) {
    }
    return (unsigned long)(j * -1501704645L + ((unsigned long)((unsigned short)v2 + 12161) | ((unsigned long)0x720000000020L << 16)) + (((unsigned long)12161 | ((unsigned long)((v2 >>> 16L) & 0xffffffffffffL) << 16)) + ((unsigned long)(unsigned char)v0 | ((unsigned long)((unsigned char)(v0 >>> 8L) ^ (unsigned char)v0) << 8) | ((unsigned long)((v0 >>> 16L) & 0xffffffffffffL) << 16))) + (((unsigned long)(unsigned char)v1 | ((unsigned long)(((unsigned char)(v1 >>> 8L) + 240) | (unsigned char)v0) << 8) | ((unsigned long)((v1 >>> 16L) & 0xffffffffffffL) << 16)) + 0x40000003a335eb54L)) + 0xe00008fcdf080fcL;
}

long log_size_7_var_003(long param0, long param1, long param2, long param3, long param4, long param5) {
    long v0 = (unsigned long)(0x2dcda24e - ((unsigned int)((unsigned short)((unsigned short)((unsigned int)1955 | ((unsigned int)(unsigned short)(((unsigned __int128)32661758096083L | ((unsigned __int128)(14886 % (unsigned short)((unsigned short)5828419384702221953L | 0xc000)) << 48) | ((unsigned __int128)10900283331636L << 64)) >>> 0x2FX) << 15) | ((unsigned int)0 << 31)) + 0x1dd3) >= 17402) - 1716743463));
    return ((unsigned long)(unsigned char)v0 | ((unsigned long)219060L << 8)) + ((unsigned long)64949 | ((unsigned long)(((unsigned long)((unsigned int)((unsigned long)__ror__((unsigned short)5828419384702221953L | 0xc000, 27) | ((unsigned long)88934621958957L << 16)) >>> 1L) >>> 16L) & 0xffffffffffffL) << 16)) + (v0 - 570171602821790202L) + 570171593524903951L;
}

long log_size_7_var_004(long param0, long param1, long param2, long param3, long param4, long param5) {
    long i;
    for(i = 63L; !(9219113998380133013L >>> i); --i) {
    }
    return (unsigned long)((unsigned int)i + 1870936321) - 1870936381L;
}

long log_size_7_var_005(long param0, long param1, long param2, long param3, long param4, long param5) {
    return -2457609492L;
}

long log_size_7_var_006(long param0, long param1, long param2, long param3, long param4, long param5) {
    return -2751101117722397037L;
}

long log_size_7_var_007(long param0, long param1, long param2, long param3, long param4, long param5) {
    return 0x6c4035ad00000001L;
}

long log_size_7_var_008(long param0, long param1, long param2, long param3, long param4, long param5) {
    long i;
    for(i = 63L; !(1704447473049432587L >>> i); --i) {
    }
    long v0 = (unsigned long)__rol__((unsigned long)(unsigned int)((unsigned long)(((unsigned short)i + 1) * 46117) | ((unsigned long)15771516934012L << 16)), 1);
    long v1 = (unsigned long)((unsigned short)__ror__((unsigned long)0xec0000 | ((unsigned long)((v0 >>> 32L) & 0x1L) << 32), 1) ^ 0xdc75) | ((unsigned long)(((unsigned long)(unsigned int)__ror__((unsigned long)0xec0000 | ((unsigned long)((v0 >>> 32L) & 0x1L) << 32), 1) >>> 16L) & 0xffffffffffffL) << 16);
    long v2 = (unsigned long)2 | ((unsigned long)(((unsigned long)(unsigned int)((unsigned long)0x896000 | ((unsigned long)(unsigned int)((unsigned long)(((unsigned int)__ror__((unsigned long)0xec0000 | ((unsigned long)((v0 >>> 32L) & 0x1L) << 32), 1) >>> 1) & 0x7FFFFFFF) | ((unsigned long)(unsigned int)v0 << 31) | ((unsigned long)0 << 63)) << 27) | ((unsigned long)0 << 59)) >>> 8L) & 0xffffffffffffffL) << 8);
    return (unsigned long)(unsigned int)((unsigned long)2 | ((unsigned long)(unsigned int)((unsigned long)0 | ((unsigned long)(((unsigned long)((unsigned int)v1 < 3255135096 ? 39935: 30827) | ((unsigned long)((unsigned int)v1 < 3255135096 ? 0L: 49669L) << 16)) & 0x7ffffffffffL) << 21)) << 20) | ((unsigned long)0 << 52)) + (((v2 >>> 7L) & 0x1L) == 0 ? v2 + 0xc0000000L: v2 + 4237600659L) + (((unsigned long)((unsigned short)((unsigned char)v1 + 0xbb) ^ 0x61ff) | ((unsigned long)229028633462406L << 16)) + ((unsigned long)(((v2 >>> 7L) & 0x1L) != 0 ? 42907: 10010) | ((unsigned long)(((v2 >>> 7L) & 0x1L) == 0 ? 0xc000L: 64660L) << 16))) + 3437123544665822995L;
}

long log_size_7_var_009(long param0, long param1, long param2, long param3, long param4, long param5) {
    return 0L;
}

long main(long param0, long param1, long param2, long param3, long param4, long param5) {
    void* ptr0;
    long v0;
    long v1 = v0;
    long v2 = log_size_7_var_000(param0, param1, param2, param3, param4, param5);
    long v3 = v2;
    long v4 = log_size_7_var_001(param0, param1, param2, param3, param4, param5);
    long v5 = v4 + v3;
    long v6 = log_size_7_var_002(param0, param1, param2, param3, param4, param5);
    long v7 = v6 + v5;
    long v8 = log_size_7_var_003(param0, param1, param2, param3, param4, param5);
    long v9 = v8 + v7;
    long v10 = log_size_7_var_004(param0, param1, param2, param3, param4, param5);
    long v11 = v10 + v9;
    long v12 = log_size_7_var_005(param0, param1, param2, param3, param4, param5);
    long v13 = v12 + v11;
    long v14 = log_size_7_var_006(param0, param1, param2, param3, param4, param5);
    long v15 = v14 + v13;
    long v16 = log_size_7_var_007(param0, param1, param2, param3, param4, param5);
    long v17 = v16 + v15;
    long v18 = log_size_7_var_008(param0, param1, param2, param3, param4, param5);
    long v19 = v18 + v17;
    long v20 = log_size_7_var_009(param0, param1, param2, param3, param4, param5);
    long v21 = v20 + v19;
    char v22 = v21 ? 0: 1;
    if(v22) {
        return 0L;
    }
    long v23 = &__PRETTY_FUNCTION__.2443;
    long v24 = 31L;
    long v25 = "source_complex_with_base_10_funcs_of_size_128.c";
    long v26 = "sum==0";
    long* ptr1 = &ptr0;
    long v27 = /*NO_RETURN*/ →__assert_fail("sum==0", "source_complex_with_base_10_funcs_of_size_128.c", 31L, (char*)&__PRETTY_FUNCTION__.2443);
}

long register_tm_clones() {
    return 0L;
}

long sub_4010FD() {
    return 0L;
}

long sub_40113F() {
    return 0L;
}

long sub_40116D() {
    long result = deregister_tm_clones();
    completed.7287 = 1;
    return result;
}

void sub_401180() {
}

long →__assert_fail(char* __assertion, char* __file, long param2, char* __function) {
    /*NO_RETURN*/ __assert_fail(__assertion, __file, (unsigned int)param2, __function);
    unsigned long* ptr0 = ptr0 - 1;
    *ptr0 = 0L;
    --ptr0;
    *ptr0 = gvar_405008;
    /*BAD_CALL!*/ gvar_405010();
}
