
void __libc_csu_fini() {
}

void* __libc_csu_init(long param0, long param1) {
    void* result;
    initializer_0();
    long v0 = 0L;
    do {
        result = (void*)*(long*)(v0 * 8L + (long)&__frame_dummy_init_array_entry){initializer_1}();
        ++v0;
    }
    while(v0 != 1L);
    return result;
}

void _dl_relocate_static_pie() {
}

long _start(long param0, long param1) {
    long v0;
    long v1;
    long v2;
    char v3;
    __libc_start_main(&main, v0, (long)&v3, &__libc_csu_init, &__libc_csu_fini, param1, (long)&v1, v2);
    hlt();
}

// Stale decompilation - Refresh this view to re-decompile this code
long deregister_tm_clones() {
    return &__TMC_END__;
}

void finalizer_0() {
}

void finalizer_1() {
    if(!completed.7287) {
        deregister_tm_clones();
        completed.7287 = 1;
    }
}

void* initializer_0() {
    void* result = __gmon_start__;
    if(result) {
        result = (void*)result();
    }
    return result;
}

long initializer_1() {
    return register_tm_clones();
}

long inst_0_flags_var_0(long param0, long param1, long param2, long param3, long param4, long param5) {
    for(short i = 0; !((31813 >>> i) & 0x1); ++i) {
    }
    return 1L;
}

long inst_0_flags_var_1(long param0, long param1, long param2, long param3, long param4, long param5) {
    for(short i = 0; !((0xdee4 >>> i) & 0x1); ++i) {
    }
    return 1L;
}

long inst_0_flags_var_3(long param0, long param1, long param2, long param3, long param4, long param5) {
    for(short i = 0; !((20118 >>> i) & 0x1); ++i) {
    }
    return 1L;
}

long inst_0_flags_var_4(long param0, long param1, long param2, long param3, long param4, long param5) {
    for(short i = 0; !((51119 >>> i) & 0x1); ++i) {
    }
    return 1L;
}

long inst_0_flags_var_5(long param0, long param1, long param2, long param3, long param4, long param5) {
    for(short i = 0; !((41560 >>> i) & 0x1); ++i) {
    }
    return 1L;
}

long inst_0_flags_var_6(long param0, long param1, long param2, long param3, long param4, long param5) {
    for(short i = 0; !((12039 >>> i) & 0x1); ++i) {
    }
    return 1L;
}

long inst_0_flags_var_7(long param0, long param1, long param2, long param3, long param4, long param5) {
    for(short i = 0; !((3448 >>> i) & 0x1); ++i) {
    }
    return 1L;
}

long inst_0_flags_var_8(long param0, long param1, long param2, long param3, long param4, long param5) {
    for(short i = 0; !((34599 >>> i) & 0x1); ++i) {
    }
    return 1L;
}

long inst_0_flags_var_9(long param0, long param1, long param2, long param3, long param4, long param5) {
    for(short i = 0; !((34614 >>> i) & 0x1); ++i) {
    }
    return 1L;
}

long inst_0_values_var_0(long param0, long param1, long param2, long param3, long param4, long param5) {
    short i;
    for(i = 0; !((0x1381 >>> i) & 0x1); ++i) {
    }
    return ((unsigned long)i | ((unsigned long)100016906640040L << 16)) - 0x5af700311aa80000L;
}

long inst_0_values_var_1(long param0, long param1, long param2, long param3, long param4, long param5) {
    short i;
    for(i = 0; !((59812 >>> i) & 0x1); ++i) {
    }
    return ((unsigned long)i | ((unsigned long)272216613384779L << 16)) + 606756098924675070L;
}

long inst_0_values_var_2(long param0, long param1, long param2, long param3, long param4, long param5) {
    short i;
    for(i = 0; !((0xbddd >>> i) & 0x1); ++i) {
    }
    return ((unsigned long)i | ((unsigned long)220397670835811L << 16)) + 0x378cab1ed99d0000L;
}

long inst_0_values_var_3(long param0, long param1, long param2, long param3, long param4, long param5) {
    short i;
    for(i = 0; !((0xf0f2 >>> i) & 0x1); ++i) {
    }
    return ((unsigned long)i | ((unsigned long)0x45fb01aa92bL << 16)) - 0x45fb01aa92b0001L;
}

long inst_0_values_var_4(long param0, long param1, long param2, long param3, long param4, long param5) {
    short i;
    for(i = 0; !((32440 >>> i) & 0x1); ++i) {
    }
    return ((unsigned long)i | ((unsigned long)199480412190071L << 16)) + 0x4a92d8e44a88fffdL;
}

long inst_0_values_var_5(long param0, long param1, long param2, long param3, long param4, long param5) {
    short i;
    for(i = 0; !((12437 >>> i) & 0x1); ++i) {
    }
    return ((unsigned long)i | ((unsigned long)222371563033130L << 16)) + 3873401318770343936L;
}

long inst_0_values_var_6(long param0, long param1, long param2, long param3, long param4, long param5) {
    short i;
    for(i = 0; !((24992 >>> i) & 0x1); ++i) {
    }
    return ((unsigned long)i | ((unsigned long)0x49a08a6f399aL << 16)) - 0x49a08a6f399a0005L;
}

long inst_0_values_var_7(long param0, long param1, long param2, long param3, long param4, long param5) {
    short i;
    for(i = 0; !((11493 >>> i) & 0x1); ++i) {
    }
    return ((unsigned long)i | ((unsigned long)101168061660255L << 16)) - 0x5c030660bc5f0000L;
}

long inst_0_values_var_8(long param0, long param1, long param2, long param3, long param4, long param5) {
    short i;
    for(i = 0; !((0x3199 >>> i) & 0x1); ++i) {
    }
    return ((unsigned long)i | ((unsigned long)5309039459489L << 16)) - 347933210017071104L;
}

long inst_0_values_var_9(long param0, long param1, long param2, long param3, long param4, long param5) {
    short i;
    for(i = 0; !((0x5117 >>> i) & 0x1); ++i) {
    }
    return ((unsigned long)i | ((unsigned long)163299014339836L << 16)) + 0x6b7afc4213040000L;
}

long inst_10_flags_var_0(long param0, long param1, long param2, long param3, long param4, long param5) {
    long v0 = blsr(1112425229888558863L, -7159155083379192514L);
    return 1L;
}

long inst_10_flags_var_1(long param0, long param1, long param2, long param3, long param4, long param5) {
    long v0 = blsr(-3477812633329000940L, 4358291303300883053L);
    return 1L;
}

long inst_10_flags_var_2(long param0, long param1, long param2, long param3, long param4, long param5) {
    long v0 = blsr(-5237119014493203449L, -1196484513868751189L);
    return -7L;
}

long inst_10_flags_var_3(long param0, long param1, long param2, long param3, long param4, long param5) {
    long v0 = blsr(100428379037579450L, -6549748931887511432L);
    return -7L;
}

long inst_10_flags_var_4(long param0, long param1, long param2, long param3, long param4, long param5) {
    long v0 = blsr(-858389739171818689L, -1098163210179112968L);
    return 1L;
}

long inst_10_flags_var_5(long param0, long param1, long param2, long param3, long param4, long param5) {
    long v0 = blsr(6136393637043229176L, 4001495358167501485L);
    return 1L;
}

long inst_10_flags_var_6(long param0, long param1, long param2, long param3, long param4, long param5) {
    long v0 = blsr(-8216109728471667899L, 0x4a6cca64c8ba9ca4L);
    return 1L;
}

long inst_10_flags_var_7(long param0, long param1, long param2, long param3, long param4, long param5) {
    long v0 = blsr(0x9f61c110a9db1262L, -5869321757234972448L);
    return 1L;
}

long inst_10_flags_var_8(long param0, long param1, long param2, long param3, long param4, long param5) {
    long v0 = blsr(-5587582792196458000L, 1619346055512034935L);
    return 1L;
}

long inst_10_flags_var_9(long param0, long param1, long param2, long param3, long param4, long param5) {
    long v0 = blsr(0x8992d18983d8b83cL, 6383137870126945918L);
    return 1L;
}

long inst_10_values_var_0(long param0, long param1, long param2, long param3, long param4, long param5) {
    long v0;
    long v0 = blsr(-8093377287929473567L, 0xdac07c50c89a931fL);
    return v0 + 0x253f83af37656ce2L;
}

long inst_10_values_var_1(long param0, long param1, long param2, long param3, long param4, long param5) {
    long v0;
    long v0 = blsr(0xeea7b5c676a33be3L, 1006550978933796200L);
    return v0 - 1006550978933796192L;
}

long inst_10_values_var_2(long param0, long param1, long param2, long param3, long param4, long param5) {
    long v0;
    long v0 = blsr(612009410466749083L, -8549087332653353175L);
    return v0 + 8549087332653353176L;
}

long inst_10_values_var_3(long param0, long param1, long param2, long param3, long param4, long param5) {
    long v0;
    long v0 = blsr(-7424970368925551585L, -7398367574033251594L);
    return v0 + 7398367574033251596L;
}

long inst_10_values_var_4(long param0, long param1, long param2, long param3, long param4, long param5) {
    long v0;
    long v0 = blsr(0xc5ce1ffe0430682fL, -5596501233099274114L);
    return v0 + 5596501233099274116L;
}

long inst_10_values_var_5(long param0, long param1, long param2, long param3, long param4, long param5) {
    long v0;
    long v0 = blsr(5514904711804903902L, -2853973497501889288L);
    return v0 + 2853973497501889296L;
}

long inst_10_values_var_6(long param0, long param1, long param2, long param3, long param4, long param5) {
    long v0;
    long v0 = blsr(2163188238805924268L, 0xd001d321044b6baL);
    return v0 - 0xd001d321044b6b8L;
}

long inst_10_values_var_7(long param0, long param1, long param2, long param3, long param4, long param5) {
    long v0;
    long v0 = blsr(6001926573835100426L, -5052672137101615295L);
    return v0 + 5052672137101615296L;
}

long inst_10_values_var_8(long param0, long param1, long param2, long param3, long param4, long param5) {
    long v0;
    long v0 = blsr(-8654851622574732376L, -7062963598956329092L);
    return v0 + 0x6204aff8d94e7888L;
}

long inst_10_values_var_9(long param0, long param1, long param2, long param3, long param4, long param5) {
    long v0;
    long v0 = blsr(0xe1fd5ec4fee9d0a4L, -259612915372559906L);
    return v0 + 259612915372559908L;
}

long inst_11_flags_var_0(long param0, long param1, long param2, long param3, long param4, long param5) {
    (unsigned int)v0 = bextr(1155954351, -1967635191, -629372622);
    return 1L;
}

long inst_11_flags_var_1(long param0, long param1, long param2, long param3, long param4, long param5) {
    (unsigned int)v0 = bextr(0x6855ccdd, 1467024603, 1467024603);
    return 1L;
}

long inst_11_flags_var_2(long param0, long param1, long param2, long param3, long param4, long param5) {
    (unsigned int)v0 = bextr(-2079208956, 0xefb4dadc, 0xefb4dadc);
    return 1L;
}

long inst_11_flags_var_3(long param0, long param1, long param2, long param3, long param4, long param5) {
    (unsigned int)v0 = bextr(-811982501, -1360369339, -1405333005);
    return 1L;
}

long inst_11_flags_var_4(long param0, long param1, long param2, long param3, long param4, long param5) {
    (unsigned int)v0 = bextr(1523534570, 0xf930519a, -779463037);
    return 1L;
}

long inst_11_flags_var_6(long param0, long param1, long param2, long param3, long param4, long param5) {
    (unsigned int)v0 = bextr(-1954131329, 306576407, -1174113272);
    return 1L;
}

long inst_11_flags_var_7(long param0, long param1, long param2, long param3, long param4, long param5) {
    (unsigned int)v0 = bextr(1099626367, -1915490699, -2062437421);
    return 1L;
}

long inst_11_flags_var_8(long param0, long param1, long param2, long param3, long param4, long param5) {
    int v0 = bextr(-169282325, 0xfdbf5e2e, 0x17f0188d);
    return 1L;
}

long inst_11_flags_var_9(long param0, long param1, long param2, long param3, long param4, long param5) {
    (unsigned int)v0 = bextr(-1798266290, -1798266290, -440739349);
    return 1L;
}

long inst_11_values_var_0(long param0, long param1, long param2, long param3, long param4, long param5) {
    long result;
    (unsigned int)v0 = bextr(-1496257200, -676364247, -1496257200);
    return result;
}

long inst_11_values_var_1(long param0, long param1, long param2, long param3, long param4, long param5) {
    long v0;
    (unsigned int)v1 = bextr(2121317910, -1437346370, 0xabfc060e);
    return v0 - 15L;
}

long inst_11_values_var_2(long param0, long param1, long param2, long param3, long param4, long param5) {
    (unsigned int)v0 = bextr(0x3a9e90e7, 912800303, 1963035737);
    return param0;
}

long inst_11_values_var_3(long param0, long param1, long param2, long param3, long param4, long param5) {
    long result;
    (unsigned int)v0 = bextr(1373447963, 1992250933, 135864211);
    return result;
}

long inst_11_values_var_4(long param0, long param1, long param2, long param3, long param4, long param5) {
    long result;
    (unsigned int)v0 = bextr(0xa88e03b1, -1850829042, 1706752737);
    return result;
}

long inst_11_values_var_5(long param0, long param1, long param2, long param3, long param4, long param5) {
    (unsigned int)v0 = bextr(1108210124, 0xaf0f8094, 1108210124);
    return param5;
}

long inst_11_values_var_6(long param0, long param1, long param2, long param3, long param4, long param5) {
    long result;
    (unsigned int)v0 = bextr(-598308957, 33717051, -598308957);
    return result;
}

long inst_11_values_var_7(long param0, long param1, long param2, long param3, long param4, long param5) {
    (unsigned int)v0 = bextr(-2087987647, -1196647115, 1527400828);
    return param3;
}

long inst_11_values_var_8(long param0, long param1, long param2, long param3, long param4, long param5) {
    (unsigned int)v0 = bextr(-1726745054, -1779984578, 1483677921);
    return param0;
}

long inst_11_values_var_9(long param0, long param1, long param2, long param3, long param4, long param5) {
    long result;
    int v0 = bextr(389949160, 389949160, 0x7d2dd5c);
    return result;
}

long inst_12_flags_var_0(long param0, long param1, long param2, long param3, long param4, long param5) {
    long v0 = bextr(1852791523882589183L, 0xafa9a246d44deff2L, 5357800880752109899L);
    return 1L;
}

long inst_12_flags_var_1(long param0, long param1, long param2, long param3, long param4, long param5) {
    long v0 = bextr(-126810543012899244L, -9211977348360622258L, -7641795277752141115L);
    return 1L;
}

long inst_12_flags_var_2(long param0, long param1, long param2, long param3, long param4, long param5) {
    long v0 = bextr(-3095443142605263961L, 3034441180536223062L, 5388440111465036581L);
    return 1L;
}

long inst_12_flags_var_3(long param0, long param1, long param2, long param3, long param4, long param5) {
    long v0 = bextr(5602756931065856682L, -9220849156304777003L, 1701517850433263543L);
    return 1L;
}

long inst_12_flags_var_4(long param0, long param1, long param2, long param3, long param4, long param5) {
    long v0 = bextr(6990741444433298199L, 8367872210245815110L, 0x99ac1b7c7d80d35eL);
    return 1L;
}

long inst_12_flags_var_5(long param0, long param1, long param2, long param3, long param4, long param5) {
    long v0 = bextr(1118382622825207191L, 0x4fc35d93ffe0a4c6L, 4842219248459220112L);
    return 1L;
}

long inst_12_flags_var_6(long param0, long param1, long param2, long param3, long param4, long param5) {
    long v0 = bextr(7116337335723420090L, -6643688050845289632L, 5597886376525837341L);
    return 1L;
}

long inst_12_flags_var_7(long param0, long param1, long param2, long param3, long param4, long param5) {
    long v0 = bextr(4300517644525753088L, 0x57c6baf78918b159L, 2989618667350531022L);
    return 1L;
}

long inst_12_flags_var_8(long param0, long param1, long param2, long param3, long param4, long param5) {
    long v0 = bextr(3295924205128555696L, -2046148005987273620L, -8954319236786141633L);
    return 1L;
}

long inst_12_flags_var_9(long param0, long param1, long param2, long param3, long param4, long param5) {
    long v0 = bextr(5668585449380055457L, 575846678674589116L, 77826764149441909L);
    return 1L;
}

long inst_12_values_var_0(long param0, long param1, long param2, long param3, long param4, long param5) {
    long result;
    long result = bextr(-5804069712955346783L, 1751832248679391408L, 0xccd85a44a0b28ba0L);
    return result;
}

long inst_12_values_var_1(long param0, long param1, long param2, long param3, long param4, long param5) {
    long result;
    long result = bextr(-8950228783496482234L, 5194434643064205571L, -5447150586543465539L);
    return result;
}

long inst_12_values_var_2(long param0, long param1, long param2, long param3, long param4, long param5) {
    long result;
    long result = bextr(177478313211440784L, 177478313211440784L, -6328657379900591172L);
    return result;
}

long inst_12_values_var_3(long param0, long param1, long param2, long param3, long param4, long param5) {
    long v0;
    long v0 = bextr(-4004982180546236742L, -4742667764055007010L, 6333201344632940835L);
    return v0 - 398841113L;
}

long inst_12_values_var_4(long param0, long param1, long param2, long param3, long param4, long param5) {
    long result;
    long result = bextr(-3510480415417092713L, -6312348731440391282L, 1875807434911861474L);
    return result;
}

long inst_12_values_var_5(long param0, long param1, long param2, long param3, long param4, long param5) {
    long v0;
    long v0 = bextr(0x9eff203694a7f59L, -1599085027207996660L, -895364250295566825L);
    return v0 - 2008397465527L;
}

long inst_12_values_var_6(long param0, long param1, long param2, long param3, long param4, long param5) {
    long result;
    long result = bextr(2604005043909248593L, -5853560933660821945L, 5495080092666910620L);
    return result;
}

long inst_12_values_var_7(long param0, long param1, long param2, long param3, long param4, long param5) {
    long v0;
    long v0 = bextr(-4739044183736738011L, 5548157839421296972L, 0x2e0ad0a6672e753bL);
    return v0 - 9L;
}

long inst_12_values_var_8(long param0, long param1, long param2, long param3, long param4, long param5) {
    long result;
    long result = bextr(0xc91ff9b49ba7678aL, -1678728552994949511L, 0xc91ff9b49ba7678aL);
    return result;
}

long inst_12_values_var_9(long param0, long param1, long param2, long param3, long param4, long param5) {
    long result;
    long result = bextr(0xcde58b78001805caL, 5782811455631160442L, 0xcde58b78001805caL);
    return result;
}

long inst_13_flags_var_0(long param0, long param1, long param2, long param3, long param4, long param5) {
    (unsigned int)v0 = bzhi(-74257130, -341112448, 0xa8eefcf2);
    return -8L;
}

long inst_13_flags_var_1(long param0, long param1, long param2, long param3, long param4, long param5) {
    int v0 = bzhi(-1520528325, -1061681594, 0x9076a677);
    return -8L;
}

long inst_13_flags_var_2(long param0, long param1, long param2, long param3, long param4, long param5) {
    (unsigned int)v0 = bzhi(0xee543f54, 0x60db4cba, 0xcbc62576);
    return 8L;
}

long inst_13_flags_var_3(long param0, long param1, long param2, long param3, long param4, long param5) {
    (unsigned int)v0 = bzhi(1364949873, 80711943, -381987637);
    return 8L;
}

long inst_13_flags_var_4(long param0, long param1, long param2, long param3, long param4, long param5) {
    (unsigned int)v0 = bzhi(-416651300, 0x75330b33, 766136809);
    return 8L;
}

long inst_13_flags_var_5(long param0, long param1, long param2, long param3, long param4, long param5) {
    (unsigned int)v0 = bzhi(-1317073709, 678697607, 0xaa6ab3ed);
    return 8L;
}

long inst_13_flags_var_6(long param0, long param1, long param2, long param3, long param4, long param5) {
    int v0 = bzhi(-1409601727, -1409601727, -47748112);
    return -8L;
}

long inst_13_flags_var_7(long param0, long param1, long param2, long param3, long param4, long param5) {
    (unsigned int)v0 = bzhi(1411199300, -610126431, 383802267);
    return 0L;
}

long inst_13_flags_var_8(long param0, long param1, long param2, long param3, long param4, long param5) {
    int v0 = bzhi(-383274057, 1467790068, 0xfa62235c);
    return 8L;
}

long inst_13_flags_var_9(long param0, long param1, long param2, long param3, long param4, long param5) {
    (unsigned int)v0 = bzhi(-1184282378, 0xe656dd75, 0xe656dd75);
    return 0L;
}

long inst_13_values_var_0(long param0, long param1, long param2, long param3, long param4, long param5) {
    long v0;
    int v1 = bzhi(0x21415946, -1356823854, 0xabb29d21);
    return v0 - 2938143442L;
}

long inst_13_values_var_1(long param0, long param1, long param2, long param3, long param4, long param5) {
    (unsigned int)v0 = bzhi(-96233293, -556613140, -871409750);
    return param3 - 0xded2c1ecL;
}

long inst_13_values_var_2(long param0, long param1, long param2, long param3, long param4, long param5) {
    long v0;
    (unsigned int)v1 = bzhi(-1873667111, -437721009, -437721009);
    return v0 - 0xe5e8e84fL;
}

long inst_13_values_var_3(long param0, long param1, long param2, long param3, long param4, long param5) {
    (unsigned int)v0 = bzhi(0x11318c14, 0x829c0cc, -465651278);
    return param1 - 0x829c0ccL;
}

long inst_13_values_var_4(long param0, long param1, long param2, long param3, long param4, long param5) {
    long v0;
    (unsigned int)v1 = bzhi(-1909392092, 1780260221, 1780260221);
    return v0 - 1780260221L;
}

long inst_13_values_var_5(long param0, long param1, long param2, long param3, long param4, long param5) {
    (unsigned int)v0 = bzhi(-77489944, -1026519902, 891998447);
    return param1 - 3268447394L;
}

long inst_13_values_var_6(long param0, long param1, long param2, long param3, long param4, long param5) {
    long v0;
    (unsigned int)v1 = bzhi(0xe35a29aa, -1286633662, 1508316189);
    return v0 - 323979074L;
}

long inst_13_values_var_7(long param0, long param1, long param2, long param3, long param4, long param5) {
    long v0;
    (unsigned int)v1 = bzhi(361606115, 0x37211292, 0x37211292);
    return v0 - 0x37211292L;
}

long inst_13_values_var_8(long param0, long param1, long param2, long param3, long param4, long param5) {
    long v0;
    (unsigned int)v1 = bzhi(1780036103, -231009480, 2009153701);
    return v0 - 0xf23b1338L;
}

long inst_14_flags_var_0(long param0, long param1, long param2, long param3, long param4, long param5) {
    long v0 = bzhi(2745361205436576105L, 4840228138545650899L, -3779043654213844704L);
    return 9L;
}

long inst_14_flags_var_1(long param0, long param1, long param2, long param3, long param4, long param5) {
    long v0 = bzhi(4413554576048931181L, -4277559551105158808L, 5454941739036636465L);
    return 1L;
}

long inst_14_flags_var_2(long param0, long param1, long param2, long param3, long param4, long param5) {
    long v0 = bzhi(0x402e9ab14471ec2eL, 4632612577877148437L, 0x43de9c9a9fffea02L);
    return 9L;
}

long inst_14_flags_var_3(long param0, long param1, long param2, long param3, long param4, long param5) {
    long v0 = bzhi(8058171162857889930L, -6817171625087217444L, -2171108408899008365L);
    return -8L;
}

long inst_14_flags_var_4(long param0, long param1, long param2, long param3, long param4, long param5) {
    long v0 = bzhi(-8786816522546037588L, 0x220291e025e0a292L, -4453682560113564269L);
    return 8L;
}

long inst_14_flags_var_5(long param0, long param1, long param2, long param3, long param4, long param5) {
    long v0 = bzhi(1193138896175431794L, 1193138896175431794L, 4345256655147508744L);
    return 1L;
}

long inst_14_flags_var_6(long param0, long param1, long param2, long param3, long param4, long param5) {
    long v0 = bzhi(-4957171340394782689L, -4957171340394782689L, -5548386747927258563L);
    return 9L;
}

long inst_14_flags_var_9(long param0, long param1, long param2, long param3, long param4, long param5) {
    long v0 = bzhi(7972531912138540638L, 0xfefea272d12b81abL, -6517117001310664035L);
    return 0L;
}

long inst_14_values_var_0(long param0, long param1, long param2, long param3, long param4, long param5) {
    long v0;
    long v0 = bzhi(-128038187465403664L, -9009066948088663809L, -128038187465403664L);
    return v0 + 9009066948088663809L;
}

long inst_14_values_var_1(long param0, long param1, long param2, long param3, long param4, long param5) {
    long v0;
    long v0 = bzhi(-6035371930753536463L, -8987948197665645506L, -6035371930753536463L);
    return v0 - 110758659021886L;
}

long inst_14_values_var_2(long param0, long param1, long param2, long param3, long param4, long param5) {
    long v0;
    long v0 = bzhi(-3986161584244143433L, 7764567022253126504L, -2101191265228002562L);
    return v0 - 7764567022253126504L;
}

long inst_14_values_var_3(long param0, long param1, long param2, long param3, long param4, long param5) {
    long v0;
    long v0 = bzhi(6366094704976451568L, 6366094704976451568L, 6366094704976451568L);
    return v0 - 6366094704976451568L;
}

long inst_14_values_var_4(long param0, long param1, long param2, long param3, long param4, long param5) {
    long v0;
    long v0 = bzhi(5775868310778511968L, 4101861488764319020L, 8779650003526992015L);
    return v0 - 4101861488764319020L;
}

long inst_14_values_var_5(long param0, long param1, long param2, long param3, long param4, long param5) {
    long v0;
    long v0 = bzhi(8021403648975712099L, 8753130126968838405L, 8615996331403331601L);
    return v0 - 0x15905L;
}

long inst_14_values_var_6(long param0, long param1, long param2, long param3, long param4, long param5) {
    long v0;
    long v0 = bzhi(-3594625574212203068L, -1748480248364330471L, 672922350451154206L);
    return v0 - 0x1b751219L;
}

long inst_14_values_var_7(long param0, long param1, long param2, long param3, long param4, long param5) {
    long v0;
    long v0 = bzhi(9042131698504453494L, 887180992131574599L, -3749629490941074861L);
    return v0 - 887180992131574599L;
}

long inst_14_values_var_8(long param0, long param1, long param2, long param3, long param4, long param5) {
    long v0;
    long v0 = bzhi(3306472895305209999L, 0x3ce5b129f877f727L, 5366452071773548908L);
    return v0 - 0x3ce5b129f877f727L;
}

long inst_14_values_var_9(long param0, long param1, long param2, long param3, long param4, long param5) {
    long v0;
    long v0 = bzhi(-2951677856387454124L, -4458900495044656493L, -4458900495044656493L);
    return v0 + 4458900495044656493L;
}

long inst_15_flags_var_0(long param0, long param1, long param2, long param3, long param4, long param5) {
    int v0 = mulx(0x61a9882, -1311245971, 0x1779c9c8, 638879832);
    return 0L;
}

long inst_15_flags_var_1(long param0, long param1, long param2, long param3, long param4, long param5) {
    (unsigned int)v0 = mulx(-91614393, -799539135, 1581210648, 0xb1c07bad);
    return 0L;
}

long inst_15_flags_var_2(long param0, long param1, long param2, long param3, long param4, long param5) {
    (unsigned int)v0 = mulx(0x6f0fc6e6, -972826789, -972826789, 588744567);
    return 0L;
}

long inst_15_flags_var_3(long param0, long param1, long param2, long param3, long param4, long param5) {
    (unsigned int)v0 = mulx(1327268726, 410777798, 236124851, 4338399);
    return 0L;
}

long inst_15_flags_var_4(long param0, long param1, long param2, long param3, long param4, long param5) {
    (unsigned int)v0 = mulx(-1364754446, 518159386, 1584972891, 448158547);
    return 0L;
}

long inst_15_flags_var_5(long param0, long param1, long param2, long param3, long param4, long param5) {
    (unsigned int)v0 = mulx(-204370189, 1577265447, 1026131262, 1014628790);
    return 0L;
}

long inst_15_flags_var_6(long param0, long param1, long param2, long param3, long param4, long param5) {
    (unsigned int)v0 = mulx(722856961, -569522009, 0xefef7f4f, -1929882262);
    return 0L;
}

long inst_15_flags_var_8(long param0, long param1, long param2, long param3, long param4, long param5) {
    (unsigned int)v0 = mulx(-612144460, 1594507852, -1595074434, 0x200466ff);
    return 0L;
}

long inst_15_flags_var_9(long param0, long param1, long param2, long param3, long param4, long param5) {
    int v0 = mulx(0x32d52d34, -1889019139, -1332565419, 0x5b9b5b18);
    return 0L;
}

long inst_15_values_var_0(long param0, long param1, long param2, long param3, long param4, long param5) {
    (unsigned int)v0 = mulx(337534738, 1143735406, 0x23eacc82, -1098311265);
    return param4 - 3488220675157471832L;
}

long inst_15_values_var_1(long param0, long param1, long param2, long param3, long param4, long param5) {
    long v0;
    (unsigned int)v1 = mulx(-839482979, 1825546066, 1825546066, -370350738);
    return v0 - 303077923256064214L;
}

long inst_15_values_var_2(long param0, long param1, long param2, long param3, long param4, long param5) {
    (unsigned int)v0 = mulx(-241717516, -975069336, -1303527538, 0x4df1d1);
    return param1 + 4267926763422041259L;
}

long inst_15_values_var_3(long param0, long param1, long param2, long param3, long param4, long param5) {
    long v0;
    (unsigned int)v1 = mulx(137731045, 0x167b1c68, 747449225, -333777960);
    return v0 - 5673943028506918680L;
}

long inst_15_values_var_4(long param0, long param1, long param2, long param3, long param4, long param5) {
    long v0;
    (unsigned int)v1 = mulx(-1471103680, -1608817893, -766913122, 1093743460);
    return v0 + 8585963012369305038L;
}

long inst_15_values_var_5(long param0, long param1, long param2, long param3, long param4, long param5) {
    long v0;
    (unsigned int)v1 = mulx(1347962822, 1646727029, -530957475, 996376273);
    return v0 + 7245363856502019282L;
}

long inst_15_values_var_6(long param0, long param1, long param2, long param3, long param4, long param5) {
    long v0;
    (unsigned int)v1 = mulx(1677190199, 1677190199, 1524206515, -1064453815);
    return v0 - 0x44557459L;
}

long inst_15_values_var_7(long param0, long param1, long param2, long param3, long param4, long param5) {
    long v0;
    (unsigned int)v1 = mulx(861586647, -1689650750, -1689650750, 0x624bf040);
    return v0 - 6850981366563125442L;
}

long inst_15_values_var_8(long param0, long param1, long param2, long param3, long param4, long param5) {
    long v0;
    (unsigned int)v1 = mulx(-169441079, 81440453, 793666177, -1354848302);
    return v0 - 5121871916739882849L;
}

long inst_15_values_var_9(long param0, long param1, long param2, long param3, long param4, long param5) {
    long v0;
    (unsigned int)v1 = mulx(0x6cb5e3d6, 454911762, 0xc82dbb18, 0x67445f89);
    return v0 - 2635298434221440486L;
}

long inst_16_flags_var_0(long param0, long param1, long param2, long param3, long param4, long param5) {
    long v0 = mulx(9173426437361239554L, -6223935866936753565L, -4625338060893655049L, -4625338060893655049L);
    return 0L;
}

long inst_16_flags_var_2(long param0, long param1, long param2, long param3, long param4, long param5) {
    long v0 = mulx(351634280314901646L, 5772965695003593245L, -1167692589702073191L, -724613688212771349L);
    return 0L;
}

long inst_16_flags_var_3(long param0, long param1, long param2, long param3, long param4, long param5) {
    long v0 = mulx(-1863857224343513945L, 0xc29abc3f9b593b54L, -6054067732627869040L, 4400966338826646384L);
    return 0L;
}

long inst_16_flags_var_4(long param0, long param1, long param2, long param3, long param4, long param5) {
    long v0 = mulx(8747441214581204678L, -2068254609888092949L, -7787273303196303305L, 7042319229011171387L);
    return 0L;
}

long inst_16_flags_var_5(long param0, long param1, long param2, long param3, long param4, long param5) {
    long v0 = mulx(0xff964ab86ef456a0L, 0xff964ab86ef456a0L, 5892980346015377018L, -7872092544506000571L);
    return 0L;
}

long inst_16_flags_var_8(long param0, long param1, long param2, long param3, long param4, long param5) {
    long v0 = mulx(5562518613338889688L, -8620042280880614395L, 7816624189164246822L, 6977948698385937271L);
    return 0L;
}

long inst_16_flags_var_9(long param0, long param1, long param2, long param3, long param4, long param5) {
    long v0 = mulx(-2856807801382226068L, 0x1b898c2eba5bb7dcL, 0xf4141d418cbbcd7L, 9021193838281054779L);
    return 0L;
}

long inst_16_values_var_0(long param0, long param1, long param2, long param3, long param4, long param5) {
    long v0;
    long v0 = mulx(0xc444787b087494f8L, 0xc444787b087494f8L, -4776982636757708744L, -6719886034678310385L);
    return v0 - 8690062113835232303L;
}

long inst_16_values_var_1(long param0, long param1, long param2, long param3, long param4, long param5) {
    long v0;
    long v0 = mulx(54032875360284442L, 0x3673cae1fcd06665L, 0x3673cae1fcd06665L, -6915572973648650182L);
    return v0 + 7913460211420379979L;
}

long inst_16_values_var_2(long param0, long param1, long param2, long param3, long param4, long param5) {
    long v0;
    long v0 = mulx(-3195234263730291414L, -6643615561189082156L, 2566388762256078547L, 9211759701501046233L);
    return v0 + 2265483463058160839L;
}

long inst_16_values_var_3(long param0, long param1, long param2, long param3, long param4, long param5) {
    long v0;
    long v0 = mulx(812175379697433626L, -1950240440358468376L, 0x5703acf9fdce2324L, -8983362911649303993L);
    return v0 - 0x3fa8876fdb568d19L;
}

long inst_16_values_var_4(long param0, long param1, long param2, long param3, long param4, long param5) {
    long v0;
    long v0 = mulx(1889444280297758154L, 3903044583243072642L, -6056916025262428541L, 8210689772092415908L);
    return v0 + 7123121882980723613L;
}

long inst_16_values_var_5(long param0, long param1, long param2, long param3, long param4, long param5) {
    long v0;
    long v0 = mulx(-1629620869077671147L, -534243306860692164L, -1629620869077671147L, -3281516293419362403L);
    return v0 - 9058595956440653935L;
}

long inst_16_values_var_6(long param0, long param1, long param2, long param3, long param4, long param5) {
    long v0;
    long v0 = mulx(2199931096387258172L, -234068735099597752L, 0x778dcb1ecc239fa6L, 2199931096387258172L);
    return v0 - 404027068358398790L;
}

long inst_16_values_var_7(long param0, long param1, long param2, long param3, long param4, long param5) {
    long v0;
    long v0 = mulx(-2137309821584613527L, 7559415197985443256L, -8762075872450438536L, 1150578062149658881L);
    return v0 + 4831660008385432601L;
}

long inst_16_values_var_9(long param0, long param1, long param2, long param3, long param4, long param5) {
    long v0;
    long v0 = mulx(0x39bab3021f62aebaL, 5958610310748605313L, 3225282509266469316L, 0x39bab3021f62aebaL);
    return v0 + 794657268831482970L;
}

long inst_17_flags_var_0(long param0, long param1, long param2, long param3, long param4, long param5) {
    (unsigned int)v0 = pdep(-213344573, -1492667482, -1226848440);
    return 0L;
}

long inst_17_flags_var_1(long param0, long param1, long param2, long param3, long param4, long param5) {
    (unsigned int)v0 = pdep(1789283689, 0x33b26b70, -2064868397);
    return 0L;
}

long inst_17_flags_var_2(long param0, long param1, long param2, long param3, long param4, long param5) {
    (unsigned int)v0 = pdep(261017968, 0x5244eef8, 0xaab1e4c4);
    return 0L;
}

long inst_17_flags_var_3(long param0, long param1, long param2, long param3, long param4, long param5) {
    (unsigned int)v0 = pdep(0x4dd29425, 0x4dd29425, 0x93439f59);
    return 0L;
}

long inst_17_flags_var_4(long param0, long param1, long param2, long param3, long param4, long param5) {
    (unsigned int)v0 = pdep(2128821568, -1705442052, 0x86702823);
    return 0L;
}

long inst_17_flags_var_5(long param0, long param1, long param2, long param3, long param4, long param5) {
    (unsigned int)v0 = pdep(1009480089, 160660011, 435308992);
    return 0L;
}

long inst_17_flags_var_6(long param0, long param1, long param2, long param3, long param4, long param5) {
    (unsigned int)v0 = pdep(0x36c5c552, -1091184276, 1823940381);
    return 0L;
}

long inst_17_flags_var_7(long param0, long param1, long param2, long param3, long param4, long param5) {
    (unsigned int)v0 = pdep(0xce39aacd, 1780185340, 1740000577);
    return 0L;
}

long inst_17_flags_var_8(long param0, long param1, long param2, long param3, long param4, long param5) {
    int v0 = pdep(675974299, 0xdf5aa3fe, -117573413);
    return 0L;
}

long inst_17_flags_var_9(long param0, long param1, long param2, long param3, long param4, long param5) {
    (unsigned int)v0 = pdep(-1751200903, 687496898, 509012408);
    return 0L;
}

long inst_17_values_var_0(long param0, long param1, long param2, long param3, long param4, long param5) {
    long v0;
    (unsigned int)v1 = pdep(-1538202763, 453112330, 0x16a07a7a);
    return v0 - 369115176L;
}

long inst_17_values_var_1(long param0, long param1, long param2, long param3, long param4, long param5) {
    long v0;
    (unsigned int)v1 = pdep(-2123286218, -297282019, 1706377069);
    return v0 - 631517289L;
}

long inst_17_values_var_2(long param0, long param1, long param2, long param3, long param4, long param5) {
    long v0;
    (unsigned int)v1 = pdep(-1040446042, 1113043096, -388662029);
    return v0 - 1754531936L;
}

long inst_17_values_var_3(long param0, long param1, long param2, long param3, long param4, long param5) {
    (unsigned int)v0 = pdep(654935447, 1989458473, 0x511e922a);
    return param4 - 1343259138L;
}

long inst_17_values_var_4(long param0, long param1, long param2, long param3, long param4, long param5) {
    int v0 = pdep(322904447, -413089997, -1481222386);
    return param2 - 0x5b60606L;
}

long inst_17_values_var_5(long param0, long param1, long param2, long param3, long param4, long param5) {
    (unsigned int)v0 = pdep(-122979930, 0xfc338e87, -2034123302);
    return param4 - 2214701082L;
}

long inst_17_values_var_6(long param0, long param1, long param2, long param3, long param4, long param5) {
    (unsigned int)v0 = pdep(258268601, 1463931509, 0x1cd97acc);
    return param0 - 0x1c411a44L;
}

long inst_17_values_var_7(long param0, long param1, long param2, long param3, long param4, long param5) {
    long v0;
    (unsigned int)v1 = pdep(1687157166, -1872017086, -138103250);
    return v0 - 1686147076L;
}

long inst_17_values_var_8(long param0, long param1, long param2, long param3, long param4, long param5) {
    long v0;
    (unsigned int)v1 = pdep(-178398231, 720939477, -1251900633);
    return v0 - 0x24218105L;
}

long inst_18_flags_var_0(long param0, long param1, long param2, long param3, long param4, long param5) {
    long v0 = pdep(-5478992982683307981L, 4851194345911085553L, -8897038721879118709L);
    return 0L;
}

long inst_18_flags_var_1(long param0, long param1, long param2, long param3, long param4, long param5) {
    long v0 = pdep(94512102710567556L, -3104848745335486272L, -8406062304820264410L);
    return 0L;
}

long inst_18_flags_var_2(long param0, long param1, long param2, long param3, long param4, long param5) {
    long v0 = pdep(5913488776640223516L, -2904382388128804555L, 7828429938013843717L);
    return 0L;
}

long inst_18_flags_var_3(long param0, long param1, long param2, long param3, long param4, long param5) {
    long v0 = pdep(-596174924304350930L, -1028568957963103109L, -223532954975936189L);
    return 0L;
}

long inst_18_flags_var_4(long param0, long param1, long param2, long param3, long param4, long param5) {
    long v0 = pdep(0xf2ed332daa50a545L, 6767433491838685478L, -5264911583873008201L);
    return 0L;
}

long inst_18_flags_var_5(long param0, long param1, long param2, long param3, long param4, long param5) {
    long v0 = pdep(-8657602290671922196L, 0x78ef4eddfa0703a1L, -5924509439957762528L);
    return 0L;
}

long inst_18_flags_var_6(long param0, long param1, long param2, long param3, long param4, long param5) {
    long v0 = pdep(4187792709608913223L, 3320743727869193348L, 0xcefedd24b8b96ea0L);
    return 0L;
}

long inst_18_flags_var_7(long param0, long param1, long param2, long param3, long param4, long param5) {
    long v0 = pdep(-9133816218735629140L, 7575708035392095873L, -3687956744970409833L);
    return 0L;
}

long inst_18_flags_var_8(long param0, long param1, long param2, long param3, long param4, long param5) {
    long v0 = pdep(2142872504125012003L, 1411513833975710175L, 7715918576130317022L);
    return 0L;
}

long inst_18_flags_var_9(long param0, long param1, long param2, long param3, long param4, long param5) {
    long v0 = pdep(0x506da460c9e51234L, -888071837425172998L, -4960869250026364890L);
    return 0L;
}

long inst_18_values_var_0(long param0, long param1, long param2, long param3, long param4, long param5) {
    long v0;
    long v0 = pdep(0x70565d59fc20dfe4L, 4220681479325672649L, -7102230271701868893L);
    return v0 + 8048062266450110335L;
}

long inst_18_values_var_1(long param0, long param1, long param2, long param3, long param4, long param5) {
    long v0;
    long v0 = pdep(-5163398105230184871L, 9078705274567044086L, 775536528282526225L);
    return v0 - 720646347855659536L;
}

long inst_18_values_var_2(long param0, long param1, long param2, long param3, long param4, long param5) {
    long v0;
    long v0 = pdep(7328919537888899132L, -5597758289138076783L, 540634703490188594L);
    return v0 - 0x500a84466800402L;
}

long inst_18_values_var_3(long param0, long param1, long param2, long param3, long param4, long param5) {
    long v0;
    long v0 = pdep(-2532321583011994672L, -3651122772632494038L, -3651122772632494038L);
    return v0 + 8929352575216377848L;
}

long inst_18_values_var_4(long param0, long param1, long param2, long param3, long param4, long param5) {
    long v0;
    long v0 = pdep(0x8b7f94999ebcdf7dL, 1825107913403230589L, -8002131248394190571L);
    return v0 + 8029856551939784431L;
}

long inst_18_values_var_5(long param0, long param1, long param2, long param3, long param4, long param5) {
    long v0;
    long v0 = pdep(-677754916259069584L, 8342383489682148042L, 4548129032623549588L);
    return v0 - 0x21212400208c410L;
}

long inst_18_values_var_6(long param0, long param1, long param2, long param3, long param4, long param5) {
    long v0;
    long v0 = pdep(0x581dd8a750123459L, 4759262773071321129L, -6581976281649757915L);
    return v0 + 0x7b77f7fe7ff7feffL;
}

long inst_18_values_var_7(long param0, long param1, long param2, long param3, long param4, long param5) {
    long v0;
    long v0 = pdep(-7010982843575761799L, 159691398865741767L, 3411119496911049223L);
    return v0 - 0x554111c08ca8007L;
}

long inst_18_values_var_8(long param0, long param1, long param2, long param3, long param4, long param5) {
    long v0;
    long v0 = pdep(-984141009830830772L, -1353339937179673543L, -374306861659459567L);
    return v0 + 0x2d7fff1fd67f1fffL;
}

long inst_18_values_var_9(long param0, long param1, long param2, long param3, long param4, long param5) {
    long v0;
    long v0 = pdep(-6173219788695372540L, 0x564ababb1317f0e1L, 0x564ababb1317f0e1L);
    return v0 - 4629877004836069377L;
}

long inst_19_flags_var_0(long param0, long param1, long param2, long param3, long param4, long param5) {
    (unsigned int)v0 = pext(1496948589, 0xb1bbb92d, 645065037);
    return 0L;
}

long inst_19_flags_var_1(long param0, long param1, long param2, long param3, long param4, long param5) {
    (unsigned int)v0 = pext(-264819241, 0x9e14f2f3, -1954157982);
    return 0L;
}

long inst_19_flags_var_2(long param0, long param1, long param2, long param3, long param4, long param5) {
    (unsigned int)v0 = pext(1725427978, -195988665, -195988665);
    return 0L;
}

long inst_19_flags_var_3(long param0, long param1, long param2, long param3, long param4, long param5) {
    (unsigned int)v0 = pext(765368420, 0x121cf037, 1189650362);
    return 0L;
}

long inst_19_flags_var_4(long param0, long param1, long param2, long param3, long param4, long param5) {
    (unsigned int)v0 = pext(1567098321, 611182862, 84463327);
    return 0L;
}

long inst_19_flags_var_5(long param0, long param1, long param2, long param3, long param4, long param5) {
    (unsigned int)v0 = pext(845399151, 0x6a102115, 408376863);
    return 0L;
}

long inst_19_flags_var_6(long param0, long param1, long param2, long param3, long param4, long param5) {
    (unsigned int)v0 = pext(-1601001608, 0xbec7b72f, -792171549);
    return 0L;
}

long inst_19_flags_var_7(long param0, long param1, long param2, long param3, long param4, long param5) {
    (unsigned int)v0 = pext(0xccd7e4c, 1055482490, 1055482490);
    return 0L;
}

long inst_19_flags_var_8(long param0, long param1, long param2, long param3, long param4, long param5) {
    (unsigned int)v0 = pext(3436437, -1804267779, -649503935);
    return 0L;
}

long inst_19_flags_var_9(long param0, long param1, long param2, long param3, long param4, long param5) {
    (unsigned int)v0 = pext(0xd7455d75, 614891323, -2121449002);
    return 0L;
}

long inst_19_values_var_0(long param0, long param1, long param2, long param3, long param4, long param5) {
    long v0;
    (unsigned int)v1 = pext(1778956504, 446078641, 548588942);
    return v0 - 5992L;
}

long inst_19_values_var_1(long param0, long param1, long param2, long param3, long param4, long param5) {
    (unsigned int)v0 = pext(-1911754879, 1776344594, -86919223);
    return param0 - 439008L;
}

long inst_19_values_var_2(long param0, long param1, long param2, long param3, long param4, long param5) {
    int v0 = pext(-1314545608, 1279876767, 622680391);
    return param2 - 9703L;
}

long inst_19_values_var_3(long param0, long param1, long param2, long param3, long param4, long param5) {
    (unsigned int)v0 = pext(82533312, 82533312, 1898368977);
    return param1 - 5564L;
}

long inst_19_values_var_4(long param0, long param1, long param2, long param3, long param4, long param5) {
    long v0;
    (unsigned int)v1 = pext(-1137510548, 786404299, 594733725);
    return v0 - 110133L;
}

long inst_19_values_var_5(long param0, long param1, long param2, long param3, long param4, long param5) {
    (unsigned int)v0 = pext(998793014, 0x95a59f5, 0xc8518945);
    return param0 - 927L;
}

long inst_19_values_var_6(long param0, long param1, long param2, long param3, long param4, long param5) {
    long v0;
    (unsigned int)v1 = pext(-310025813, 0xd98fbccf, 1479408509);
    return v0 - 0xef727L;
}

long inst_19_values_var_7(long param0, long param1, long param2, long param3, long param4, long param5) {
    (unsigned int)v0 = pext(0x9d14b233, -233934069, -99410123);
    return param1 - 251185L;
}

long inst_19_values_var_8(long param0, long param1, long param2, long param3, long param4, long param5) {
    (unsigned int)v0 = pext(0xbbb64454, 380211160, -126020083);
    return param0 - 0x255cL;
}

long inst_19_values_var_9(long param0, long param1, long param2, long param3, long param4, long param5) {
    long v0;
    int v1 = pext(0x16816692, 0x3012bbb, -968198492);
    return v0 - 2126L;
}

long inst_1_flags_var_0(long param0, long param1, long param2, long param3, long param4, long param5) {
    (unsigned int)v0 = tzcnt(-618976819, -776369093);
    return 1L;
}

long inst_1_flags_var_1(long param0, long param1, long param2, long param3, long param4, long param5) {
    (unsigned int)v0 = tzcnt(0xd1e0b5bc, -1479606858);
    return 1L;
}

long inst_1_flags_var_2(long param0, long param1, long param2, long param3, long param4, long param5) {
    (unsigned int)v0 = tzcnt(-1691923994, -1877324895);
    return 1L;
}

long inst_1_flags_var_3(long param0, long param1, long param2, long param3, long param4, long param5) {
    (unsigned int)v0 = tzcnt(-665728377, 352234176);
    return 1L;
}

long inst_1_flags_var_4(long param0, long param1, long param2, long param3, long param4, long param5) {
    (unsigned int)v0 = tzcnt(1644277494, 211445847);
    return 1L;
}

long inst_1_flags_var_5(long param0, long param1, long param2, long param3, long param4, long param5) {
    (unsigned int)v0 = tzcnt(0x43a8a18a, 1581477502);
    return 1L;
}

long inst_1_flags_var_6(long param0, long param1, long param2, long param3, long param4, long param5) {
    (unsigned int)v0 = tzcnt(-2131121095, 1283645603);
    return 1L;
}

long inst_1_flags_var_7(long param0, long param1, long param2, long param3, long param4, long param5) {
    (unsigned int)v0 = tzcnt(-1971126855, 0x9595bc42);
    return 1L;
}

long inst_1_flags_var_8(long param0, long param1, long param2, long param3, long param4, long param5) {
    int v0 = tzcnt(2016672789, -1594819081);
    return 1L;
}

long inst_1_flags_var_9(long param0, long param1, long param2, long param3, long param4, long param5) {
    int v0 = tzcnt(-175952537, -175952537);
    return 1L;
}

long inst_1_values_var_0(long param0, long param1, long param2, long param3, long param4, long param5) {
    long result;
    (unsigned int)v0 = tzcnt(-1157661820, 0x232210d5);
    return result;
}

long inst_1_values_var_1(long param0, long param1, long param2, long param3, long param4, long param5) {
    (unsigned int)v0 = tzcnt(0xbabbce0e, -1450387663);
    return param0;
}

long inst_1_values_var_2(long param0, long param1, long param2, long param3, long param4, long param5) {
    long result;
    (unsigned int)v0 = tzcnt(0x70ea4557, -110009167);
    return result;
}

long inst_1_values_var_3(long param0, long param1, long param2, long param3, long param4, long param5) {
    (unsigned int)v0 = tzcnt(0x6df6ba96, -965634780);
    return param4 - 2L;
}

long inst_1_values_var_4(long param0, long param1, long param2, long param3, long param4, long param5) {
    int v0 = tzcnt(609980475, 332554277);
    return param2;
}

long inst_1_values_var_5(long param0, long param1, long param2, long param3, long param4, long param5) {
    long result;
    (unsigned int)v0 = tzcnt(-212709077, 1675395533);
    return result;
}

long inst_1_values_var_6(long param0, long param1, long param2, long param3, long param4, long param5) {
    (unsigned int)v0 = tzcnt(512341369, -240455670);
    return param3 - 1L;
}

long inst_1_values_var_7(long param0, long param1, long param2, long param3, long param4, long param5) {
    long v0;
    (unsigned int)v1 = tzcnt(1665893877, -1992891564);
    return v0 - 2L;
}

long inst_1_values_var_8(long param0, long param1, long param2, long param3, long param4, long param5) {
    long v0;
    (unsigned int)v1 = tzcnt(0xcc0959e8, -402415988);
    return v0 - 2L;
}

long inst_1_values_var_9(long param0, long param1, long param2, long param3, long param4, long param5) {
    long v0;
    (unsigned int)v1 = tzcnt(-514196809, -940118146);
    return v0 - 1L;
}

long inst_20_flags_var_0(long param0, long param1, long param2, long param3, long param4, long param5) {
    long v0 = pext(-710342189122235817L, 581342210816614265L, 740607965143033234L);
    return 0L;
}

long inst_20_flags_var_1(long param0, long param1, long param2, long param3, long param4, long param5) {
    long v0 = pext(-4448767615585846897L, 4715954139222213347L, 0xa903e989ffa88ec9L);
    return 0L;
}

long inst_20_flags_var_2(long param0, long param1, long param2, long param3, long param4, long param5) {
    long v0 = pext(0x3951f0439654a4a4L, 0x3951f0439654a4a4L, 0x9877b79b2e77bba4L);
    return 0L;
}

long inst_20_flags_var_3(long param0, long param1, long param2, long param3, long param4, long param5) {
    long v0 = pext(-4505604507388739215L, 8246132568554016476L, 5848567367892356132L);
    return 0L;
}

long inst_20_flags_var_4(long param0, long param1, long param2, long param3, long param4, long param5) {
    long v0 = pext(-2767774891633244210L, 7269534767840598707L, 1777274969208586979L);
    return 0L;
}

long inst_20_flags_var_5(long param0, long param1, long param2, long param3, long param4, long param5) {
    long v0 = pext(-2805541159219462136L, 6160035514476220201L, 0x535baa5ce704defbL);
    return 0L;
}

long inst_20_flags_var_6(long param0, long param1, long param2, long param3, long param4, long param5) {
    long v0 = pext(-9022357242812702340L, -1992586500956061993L, 0xdcdedef192f64b1bL);
    return 0L;
}

long inst_20_flags_var_7(long param0, long param1, long param2, long param3, long param4, long param5) {
    long v0 = pext(-6425123480301285688L, -3986930404559735809L, -3868389672632800491L);
    return 0L;
}

long inst_20_flags_var_8(long param0, long param1, long param2, long param3, long param4, long param5) {
    long v0 = pext(982336716981873128L, 189917385006681662L, 8431450152150102027L);
    return 0L;
}

long inst_20_flags_var_9(long param0, long param1, long param2, long param3, long param4, long param5) {
    long v0 = pext(-168775611931251903L, 6777798989206392072L, -168775611931251903L);
    return 0L;
}

long inst_20_values_var_0(long param0, long param1, long param2, long param3, long param4, long param5) {
    long v0;
    long v0 = pext(1374705673542547142L, 1374705673542547142L, 7007057054143183047L);
    return v0 - 10840798L;
}

long inst_20_values_var_1(long param0, long param1, long param2, long param3, long param4, long param5) {
    long v0;
    long v0 = pext(1341658328667304657L, 358070084779637078L, 7396509799629821646L);
    return v0 - 1484476299L;
}

long inst_20_values_var_2(long param0, long param1, long param2, long param3, long param4, long param5) {
    long v0;
    long v0 = pext(-5745047791846332213L, -3885174646834932476L, -5790120505353998687L);
    return v0 - 45322773648L;
}

long inst_20_values_var_3(long param0, long param1, long param2, long param3, long param4, long param5) {
    long v0;
    long v0 = pext(5858925129586093832L, -1880828307296916057L, 0x4cbc28deb02baa66L);
    return v0 - 1557647719L;
}

long inst_20_values_var_4(long param0, long param1, long param2, long param3, long param4, long param5) {
    long v0;
    long v0 = pext(-714866961479593401L, -3152781695824937903L, 5949659819689959587L);
    return v0 - 0x1991e11L;
}

long inst_20_values_var_5(long param0, long param1, long param2, long param3, long param4, long param5) {
    long v0;
    long v0 = pext(-6580486521001502318L, 9199417146005379084L, -7974449808572566236L);
    return v0 - 12711377L;
}

long inst_20_values_var_6(long param0, long param1, long param2, long param3, long param4, long param5) {
    long v0;
    long v0 = pext(0x998857ea8f74643cL, 6970411554633665017L, 5154927454321507519L);
    return v0 - 1234873579897L;
}

long inst_20_values_var_7(long param0, long param1, long param2, long param3, long param4, long param5) {
    long v0;
    long v0 = pext(-7569322056860381325L, -5484263497380908981L, 2111200264593893937L);
    return v0 - 0x133dddf21L;
}

long inst_20_values_var_8(long param0, long param1, long param2, long param3, long param4, long param5) {
    long v0;
    long v0 = pext(-1444763495903464564L, 5684787506934719502L, 8979055501575426522L);
    return v0 - 21008391171L;
}

long inst_20_values_var_9(long param0, long param1, long param2, long param3, long param4, long param5) {
    long v0;
    long v0 = pext(0xc2b3b92fc6fffb8cL, -3272446248186688588L, -8676096398371683928L);
    return v0 - 0x2b5b5eL;
}

long inst_21_flags_var_0(long param0, long param1, long param2, long param3, long param4, long param5) {
    (unsigned int)v0 = rorx(-61919341, -818401437, 58);
    return 0L;
}

long inst_21_flags_var_1(long param0, long param1, long param2, long param3, long param4, long param5) {
    (unsigned int)v0 = rorx(0x81567734, -1810426003, 106);
    return 0L;
}

long inst_21_flags_var_2(long param0, long param1, long param2, long param3, long param4, long param5) {
    (unsigned int)v0 = rorx(-960883892, 1902729347, 254);
    return 0L;
}

long inst_21_flags_var_3(long param0, long param1, long param2, long param3, long param4, long param5) {
    (unsigned int)v0 = rorx(-347853866, 0xc0a22801, 169);
    return 0L;
}

long inst_21_flags_var_4(long param0, long param1, long param2, long param3, long param4, long param5) {
    (unsigned int)v0 = rorx(-261421888, 616848817, 230);
    return 0L;
}

long inst_21_flags_var_5(long param0, long param1, long param2, long param3, long param4, long param5) {
    (unsigned int)v0 = rorx(-1896637734, 0x676b2152, 247);
    return 0L;
}

long inst_21_flags_var_7(long param0, long param1, long param2, long param3, long param4, long param5) {
    (unsigned int)v0 = rorx(-825531314, 0xf2877212, 22);
    return 0L;
}

long inst_21_flags_var_8(long param0, long param1, long param2, long param3, long param4, long param5) {
    (unsigned int)v0 = rorx(-2116797433, 2040336421, 145);
    return 0L;
}

long inst_21_flags_var_9(long param0, long param1, long param2, long param3, long param4, long param5) {
    (unsigned int)v0 = rorx(1194389699, 1075649077, 135);
    return 0L;
}

long inst_21_values_var_0(long param0, long param1, long param2, long param3, long param4, long param5) {
    (unsigned int)v0 = rorx(310365038, 0x17f2bb00, 150);
    return param5 - 3404464223L;
}

long inst_21_values_var_1(long param0, long param1, long param2, long param3, long param4, long param5) {
    long v0;
    (unsigned int)v1 = rorx(535246949, -782000898, 213);
    return v0 - 484963979L;
}

long inst_21_values_var_2(long param0, long param1, long param2, long param3, long param4, long param5) {
    (unsigned int)v0 = rorx(2139932437, 85705025, 194);
    return param5 - 1095168080L;
}

long inst_21_values_var_3(long param0, long param1, long param2, long param3, long param4, long param5) {
    long v0;
    (unsigned int)v1 = rorx(-881614334, -1574052212, 201);
    return v0 - 1179719407L;
}

long inst_21_values_var_4(long param0, long param1, long param2, long param3, long param4, long param5) {
    (unsigned int)v0 = rorx(840435669, 1372752056, 230);
    return param5 - 3779545634L;
}

long inst_21_values_var_5(long param0, long param1, long param2, long param3, long param4, long param5) {
    int v0 = rorx(0x2ce8e3f0, 0xc123b397, 141);
    return param2 - 2629699869L;
}

long inst_21_values_var_6(long param0, long param1, long param2, long param3, long param4, long param5) {
    long v0;
    (unsigned int)v1 = rorx(-1334987048, -1160414424, 195);
    return v0 - 391819109L;
}

long inst_21_values_var_7(long param0, long param1, long param2, long param3, long param4, long param5) {
    (unsigned int)v0 = rorx(-496484194, 901578617, 245);
    return param1 - 3892038061L;
}

long inst_21_values_var_8(long param0, long param1, long param2, long param3, long param4, long param5) {
    (unsigned int)v0 = rorx(-776828317, -1924228167, 239);
    return param5 - 930290333L;
}

long inst_21_values_var_9(long param0, long param1, long param2, long param3, long param4, long param5) {
    long v0;
    (unsigned int)v1 = rorx(914617784, -1125587707, 48);
    return v0 - 3842358504L;
}

long inst_22_flags_var_0(long param0, long param1, long param2, long param3, long param4, long param5) {
    long v0 = rorx(-7958171842679272627L, 7219959322021527605L, 215);
    return 0L;
}

long inst_22_flags_var_1(long param0, long param1, long param2, long param3, long param4, long param5) {
    long v0 = rorx(1733717819500011583L, 5570433715534147013L, 101);
    return 0L;
}

long inst_22_flags_var_2(long param0, long param1, long param2, long param3, long param4, long param5) {
    long v0 = rorx(250047386625673690L, -8577340488427420664L, 200);
    return 0L;
}

long inst_22_flags_var_3(long param0, long param1, long param2, long param3, long param4, long param5) {
    long v0 = rorx(-645531781318216882L, -8126488719187830881L, 119);
    return 0L;
}

long inst_22_flags_var_4(long param0, long param1, long param2, long param3, long param4, long param5) {
    long v0 = rorx(-5095076114944278926L, 0x61fff15304951e97L, 251);
    return 0L;
}

long inst_22_flags_var_5(long param0, long param1, long param2, long param3, long param4, long param5) {
    long v0 = rorx(0x76549cb699f1676bL, 4963046265512263012L, 93);
    return 0L;
}

long inst_22_flags_var_6(long param0, long param1, long param2, long param3, long param4, long param5) {
    long v0 = rorx(4174347268239004812L, 6816587000765570696L, 142);
    return 0L;
}

long inst_22_flags_var_7(long param0, long param1, long param2, long param3, long param4, long param5) {
    long v0 = rorx(-6090117523245300087L, 2955487596890376806L, 222);
    return 0L;
}

long inst_22_flags_var_8(long param0, long param1, long param2, long param3, long param4, long param5) {
    long v0 = rorx(-4577055944119342330L, 1379975394240225384L, 158);
    return 0L;
}

long inst_22_flags_var_9(long param0, long param1, long param2, long param3, long param4, long param5) {
    long v0 = rorx(2036607672311447388L, 7652284148969336144L, 26);
    return 0L;
}

long inst_22_values_var_0(long param0, long param1, long param2, long param3, long param4, long param5) {
    long v0;
    long v0 = rorx(-2508242859478824437L, -8124604139200975476L, 152);
    return v0 - 4750607728821114070L;
}

long inst_22_values_var_1(long param0, long param1, long param2, long param3, long param4, long param5) {
    long v0;
    long v0 = rorx(-297437086611024331L, -6140976131825603565L, 41);
    return v0 - 6865791465211388783L;
}

long inst_22_values_var_2(long param0, long param1, long param2, long param3, long param4, long param5) {
    long v0;
    long v0 = rorx(-2332841669673723263L, -6134906490201246918L, 236);
    return v0 + 1093788604462092858L;
}

long inst_22_values_var_3(long param0, long param1, long param2, long param3, long param4, long param5) {
    long v0;
    long v0 = rorx(-6588954138529577125L, -6224500002003560654L, 130);
    return v0 + 0x5598777178f5ca34L;
}

long inst_22_values_var_4(long param0, long param1, long param2, long param3, long param4, long param5) {
    long v0;
    long v0 = rorx(6897778669755744931L, 6897778669755744931L, 0xee);
    return v0 - 6097267218621234919L;
}

long inst_22_values_var_5(long param0, long param1, long param2, long param3, long param4, long param5) {
    long v0;
    long v0 = rorx(-6925307297411444382L, -7010391830241466041L, 208);
    return v0 - 2974520583788029480L;
}

long inst_22_values_var_6(long param0, long param1, long param2, long param3, long param4, long param5) {
    long v0;
    long v0 = rorx(0x74334210a9685f62L, -1686103610790310289L, 200);
    return v0 - 8063864190018279182L;
}

long inst_22_values_var_7(long param0, long param1, long param2, long param3, long param4, long param5) {
    long v0;
    long v0 = rorx(-4139299964547415980L, 8846143098949876977L, 64);
    return v0 - 8846143098949876977L;
}

long inst_22_values_var_8(long param0, long param1, long param2, long param3, long param4, long param5) {
    long v0;
    long v0 = rorx(7535496222978240254L, 5169987025606245913L, 241);
    return v0 + 4762717883055954977L;
}

long inst_22_values_var_9(long param0, long param1, long param2, long param3, long param4, long param5) {
    long v0;
    long v0 = rorx(3254789296943373748L, -4086507984084254396L, 51);
    return v0 - 0x39d4789b882898e9L;
}

long inst_23_flags_var_0(long param0, long param1, long param2, long param3, long param4, long param5) {
    int v0 = sarx(1240803343, 0x27664418, 0xcd279aa4);
    return 0L;
}

long inst_23_flags_var_1(long param0, long param1, long param2, long param3, long param4, long param5) {
    (unsigned int)v0 = sarx(1218134177, -1845657419, -1394654064);
    return 0L;
}

long inst_23_flags_var_2(long param0, long param1, long param2, long param3, long param4, long param5) {
    (unsigned int)v0 = sarx(1946629531, -2102462633, 0x12e54500);
    return 0L;
}

long inst_23_flags_var_3(long param0, long param1, long param2, long param3, long param4, long param5) {
    (unsigned int)v0 = sarx(522233371, 1557864623, 1557864623);
    return 0L;
}

long inst_23_flags_var_4(long param0, long param1, long param2, long param3, long param4, long param5) {
    (unsigned int)v0 = sarx(-161529562, 1340168060, -651643690);
    return 0L;
}

long inst_23_flags_var_5(long param0, long param1, long param2, long param3, long param4, long param5) {
    (unsigned int)v0 = sarx(1177063402, 378390249, 2091516092);
    return 0L;
}

long inst_23_flags_var_6(long param0, long param1, long param2, long param3, long param4, long param5) {
    (unsigned int)v0 = sarx(1012639862, 1256149212, -423296097);
    return 0L;
}

long inst_23_flags_var_7(long param0, long param1, long param2, long param3, long param4, long param5) {
    (unsigned int)v0 = sarx(-1010393356, 915883597, 915883597);
    return 0L;
}

long inst_23_flags_var_8(long param0, long param1, long param2, long param3, long param4, long param5) {
    (unsigned int)v0 = sarx(898386062, 1325966565, 0x21e4061e);
    return 0L;
}

long inst_23_flags_var_9(long param0, long param1, long param2, long param3, long param4, long param5) {
    (unsigned int)v0 = sarx(1321573668, 1215002647, 1321573668);
    return 0L;
}

long inst_23_values_var_0(long param0, long param1, long param2, long param3, long param4, long param5) {
    long v0;
    (unsigned int)v1 = sarx(-479844964, -1005863664, -353166956);
    return v0 - 0xfffffc40L;
}

long inst_23_values_var_1(long param0, long param1, long param2, long param3, long param4, long param5) {
    (unsigned int)v0 = sarx(1102165205, 777235315, 1152113940);
    return param3 - 741L;
}

long inst_23_values_var_2(long param0, long param1, long param2, long param3, long param4, long param5) {
    (unsigned int)v0 = sarx(2031125852, 1827797574, 0xcc7fc598);
    return param1 - 108L;
}

long inst_23_values_var_3(long param0, long param1, long param2, long param3, long param4, long param5) {
    long v0;
    (unsigned int)v1 = sarx(882951601, -972120853, 1009698103);
    return v0 - 0xffffff8cL;
}

long inst_23_values_var_4(long param0, long param1, long param2, long param3, long param4, long param5) {
    long v0;
    (unsigned int)v1 = sarx(865776977, 502965636, 1623675224);
    return v0 - 29L;
}

long inst_23_values_var_5(long param0, long param1, long param2, long param3, long param4, long param5) {
    (unsigned int)v0 = sarx(1238716405, 1216234664, -839435327);
    return param3 - 608117332L;
}

long inst_23_values_var_6(long param0, long param1, long param2, long param3, long param4, long param5) {
    int v0 = sarx(-1780094072, -32078330, -1780094072);
    return param2 - 0xfffe1686L;
}

long inst_23_values_var_7(long param0, long param1, long param2, long param3, long param4, long param5) {
    int v0 = sarx(-1989462787, -209938719, 325960128);
    return param2 - 4085028577L;
}

long inst_23_values_var_8(long param0, long param1, long param2, long param3, long param4, long param5) {
    long v0;
    (unsigned int)v1 = sarx(-813680470, 0x8cccdc28, -1955521410);
    return v0 - 0xfffffffeL;
}

long inst_23_values_var_9(long param0, long param1, long param2, long param3, long param4, long param5) {
    (unsigned int)v0 = sarx(-538758735, 242142264, 721190373);
    return param3 - 0x737661L;
}

long inst_24_flags_var_0(long param0, long param1, long param2, long param3, long param4, long param5) {
    long v0 = sarx(6042641949386444893L, 5678465757903006536L, -1379804389370983912L);
    return 0L;
}

long inst_24_flags_var_1(long param0, long param1, long param2, long param3, long param4, long param5) {
    long v0 = sarx(5373527479181867712L, -6640715917274300018L, -6640715917274300018L);
    return 0L;
}

long inst_24_flags_var_2(long param0, long param1, long param2, long param3, long param4, long param5) {
    long v0 = sarx(0x9e961222956a613bL, 0xb2397929522bf789L, 1482408014778522735L);
    return 0L;
}

long inst_24_flags_var_3(long param0, long param1, long param2, long param3, long param4, long param5) {
    long v0 = sarx(-6853915175813846584L, 0xa4b9458dd852ba97L, -607960343994175995L);
    return 0L;
}

long inst_24_flags_var_4(long param0, long param1, long param2, long param3, long param4, long param5) {
    long v0 = sarx(-1212743148982034492L, 584252938969469305L, 584252938969469305L);
    return 0L;
}

long inst_24_flags_var_5(long param0, long param1, long param2, long param3, long param4, long param5) {
    long v0 = sarx(-2336919777908649628L, 785774576564520951L, -7028531404639632261L);
    return 0L;
}

long inst_24_flags_var_6(long param0, long param1, long param2, long param3, long param4, long param5) {
    long v0 = sarx(-8923043196463792687L, 6883011298108569740L, 6883011298108569740L);
    return 0L;
}

long inst_24_flags_var_7(long param0, long param1, long param2, long param3, long param4, long param5) {
    long v0 = sarx(8850470065666978975L, 1830347738901577073L, 1316778044725988691L);
    return 0L;
}

long inst_24_flags_var_8(long param0, long param1, long param2, long param3, long param4, long param5) {
    long v0 = sarx(-8391277972461715213L, 7639488609263593744L, -5818882338085037154L);
    return 0L;
}

long inst_24_flags_var_9(long param0, long param1, long param2, long param3, long param4, long param5) {
    long v0 = sarx(0xff82db4ee9bcd0afL, 6473314905600052236L, 6473314905600052236L);
    return 0L;
}

long inst_24_values_var_0(long param0, long param1, long param2, long param3, long param4, long param5) {
    long result;
    long result = sarx(1381479761027642733L, 0x3042d07ba42c2432L, 0x1b1018da458f1a3fL);
    return result;
}

long inst_24_values_var_1(long param0, long param1, long param2, long param3, long param4, long param5) {
    long v0;
    long v0 = sarx(-4551443103950868402L, 7817327356720329356L, -4551443103950868402L);
    return v0 - 477131796674824L;
}

long inst_24_values_var_2(long param0, long param1, long param2, long param3, long param4, long param5) {
    long v0;
    long v0 = sarx(-6966133612423346533L, 7915485625368276249L, -2261497582067957018L);
    return v0 - 0x1b765d0L;
}

long inst_24_values_var_3(long param0, long param1, long param2, long param3, long param4, long param5) {
    long v0;
    long v0 = sarx(6926378757672799118L, -2978036694799855351L, 7095807906234787631L);
    return v0 + 21161L;
}

long inst_24_values_var_4(long param0, long param1, long param2, long param3, long param4, long param5) {
    long v0;
    long v0 = sarx(-4573340950720524307L, 541030174230813941L, 8210126812782847589L);
    return v0 - 0x3c1100L;
}

long inst_24_values_var_5(long param0, long param1, long param2, long param3, long param4, long param5) {
    long v0;
    long v0 = sarx(0x2a335ba9846e41eL, 8392584703369833245L, 2607841124564263152L);
    return v0 - 0x7478L;
}

long inst_24_values_var_6(long param0, long param1, long param2, long param3, long param4, long param5) {
    long v0;
    long v0 = sarx(-5853038536169595784L, 0xea8770f4784d9adeL, 8784049199688624434L);
    return v0 + 0x55fL;
}

long inst_24_values_var_7(long param0, long param1, long param2, long param3, long param4, long param5) {
    long v0;
    long v0 = sarx(874134248373111330L, 2544144379065395624L, 7286438430233978975L);
    return v0 - 0x469d3baaL;
}

long inst_24_values_var_8(long param0, long param1, long param2, long param3, long param4, long param5) {
    long v0;
    long v0 = sarx(-7097807073846217186L, 0xec0fff7823df380fL, 1719372624021955419L);
    return v0 + 0x27e0010fcL;
}

long inst_24_values_var_9(long param0, long param1, long param2, long param3, long param4, long param5) {
    long v0;
    long v0 = sarx(-7946650456871086227L, 0xbbaa9c6422d84901L, -6727852206455163080L);
    return v0 + 69L;
}

long inst_25_flags_var_0(long param0, long param1, long param2, long param3, long param4, long param5) {
    (unsigned int)v0 = shlx(-1654696004, 0x36987389, 2142131969);
    return 0L;
}

long inst_25_flags_var_1(long param0, long param1, long param2, long param3, long param4, long param5) {
    (unsigned int)v0 = shlx(-1323913485, -1125381924, 1439107796);
    return 0L;
}

long inst_25_flags_var_2(long param0, long param1, long param2, long param3, long param4, long param5) {
    int v0 = shlx(-1404090186, 250655534, -491046804);
    return 0L;
}

long inst_25_flags_var_3(long param0, long param1, long param2, long param3, long param4, long param5) {
    (unsigned int)v0 = shlx(0xec80c758, 1603193013, 0x933d2aa0);
    return 0L;
}

long inst_25_flags_var_4(long param0, long param1, long param2, long param3, long param4, long param5) {
    (unsigned int)v0 = shlx(1395381339, -1771923520, 1395381339);
    return 0L;
}

long inst_25_flags_var_5(long param0, long param1, long param2, long param3, long param4, long param5) {
    (unsigned int)v0 = shlx(-1518123545, 1003994351, 0x8889e025);
    return 0L;
}

long inst_25_flags_var_6(long param0, long param1, long param2, long param3, long param4, long param5) {
    (unsigned int)v0 = shlx(-929933876, 114548948, 1545647271);
    return 0L;
}

long inst_25_flags_var_7(long param0, long param1, long param2, long param3, long param4, long param5) {
    (unsigned int)v0 = shlx(1853090494, 0x9dcf3144, 0xeda68a8b);
    return 0L;
}

long inst_25_flags_var_8(long param0, long param1, long param2, long param3, long param4, long param5) {
    (unsigned int)v0 = shlx(-2027953643, 0x9f3321c6, 642728078);
    return 0L;
}

long inst_25_flags_var_9(long param0, long param1, long param2, long param3, long param4, long param5) {
    (unsigned int)v0 = shlx(-1805354428, 1328043848, 0xcaddfd8b);
    return 0L;
}

long inst_25_values_var_0(long param0, long param1, long param2, long param3, long param4, long param5) {
    long v0;
    (unsigned int)v1 = shlx(1618282034, -1904149235, 0x8a9a7fd9);
    return v0 - 0x1a000000L;
}

long inst_25_values_var_1(long param0, long param1, long param2, long param3, long param4, long param5) {
    (unsigned int)v0 = shlx(0xf4a131d4, 1442728879, 0xe9a37c34);
    return param5 - 0xbaf00000L;
}

long inst_25_values_var_2(long param0, long param1, long param2, long param3, long param4, long param5) {
    long v0;
    (unsigned int)v1 = shlx(-1802364434, 2022364210, -788001026);
    return v0 - 0x80000000L;
}

long inst_25_values_var_3(long param0, long param1, long param2, long param3, long param4, long param5) {
    long v0;
    (unsigned int)v1 = shlx(-279853010, 776050856, 443786602);
    return v0 - 0x662a000L;
}

long inst_25_values_var_4(long param0, long param1, long param2, long param3, long param4, long param5) {
    (unsigned int)v0 = shlx(0x244325e7, 937994059, -87288442);
    return param3 - 4197044928L;
}

long inst_25_values_var_5(long param0, long param1, long param2, long param3, long param4, long param5) {
    long v0;
    (unsigned int)v1 = shlx(-1373064566, 1390677151, -922370053);
    return v0 - 0xf8000000L;
}

long inst_25_values_var_6(long param0, long param1, long param2, long param3, long param4, long param5) {
    long v0;
    (unsigned int)v1 = shlx(-1057358750, 0x33834b47, 979365975);
    return v0 - 0xa3800000L;
}

long inst_25_values_var_7(long param0, long param1, long param2, long param3, long param4, long param5) {
    long v0;
    (unsigned int)v1 = shlx(234160470, 427208915, -1701455415);
    return v0 - 3982599680L;
}

long inst_25_values_var_8(long param0, long param1, long param2, long param3, long param4, long param5) {
    long v0;
    (unsigned int)v1 = shlx(-558183617, 130263511, 0xce8bedeb);
    return v0 - 491698176L;
}

long inst_25_values_var_9(long param0, long param1, long param2, long param3, long param4, long param5) {
    long v0;
    (unsigned int)v1 = shlx(0xd9b63592, 0xd9b63592, 0xeac0e045);
    return v0 - 918991424L;
}

long inst_26_flags_var_0(long param0, long param1, long param2, long param3, long param4, long param5) {
    long v0 = shlx(-1125396675372113623L, -1125396675372113623L, 0xf11edd64fc9aa50eL);
    return 0L;
}

long inst_26_flags_var_1(long param0, long param1, long param2, long param3, long param4, long param5) {
    long v0 = shlx(7245469709012815992L, 1979729353152859337L, 7245469709012815992L);
    return 0L;
}

long inst_26_flags_var_2(long param0, long param1, long param2, long param3, long param4, long param5) {
    long v0 = shlx(0x97398e840655bed1L, -4809258609937050208L, 3708464448996111657L);
    return 0L;
}

long inst_26_flags_var_3(long param0, long param1, long param2, long param3, long param4, long param5) {
    long v0 = shlx(5364996361813425308L, 5558164296481781246L, 5521622779276569049L);
    return 0L;
}

long inst_26_flags_var_4(long param0, long param1, long param2, long param3, long param4, long param5) {
    long v0 = shlx(0x406a0deddf47b72eL, 1954569640340128835L, 5205492904090670362L);
    return 0L;
}

long inst_26_flags_var_5(long param0, long param1, long param2, long param3, long param4, long param5) {
    long v0 = shlx(-5001357243675559046L, 8568013815330099768L, 8568013815330099768L);
    return 0L;
}

long inst_26_flags_var_6(long param0, long param1, long param2, long param3, long param4, long param5) {
    long v0 = shlx(0xe6e8ae101427126fL, -3136478054221524720L, -1597039742254315939L);
    return 0L;
}

long inst_26_flags_var_7(long param0, long param1, long param2, long param3, long param4, long param5) {
    long v0 = shlx(1044160215137065172L, -5042279394155346817L, 8211448856911238430L);
    return 0L;
}

long inst_26_flags_var_8(long param0, long param1, long param2, long param3, long param4, long param5) {
    long v0 = shlx(-6069613476110936197L, -530122610097759349L, 7080180107521426126L);
    return 0L;
}

long inst_26_flags_var_9(long param0, long param1, long param2, long param3, long param4, long param5) {
    long v0 = shlx(2481457869449760980L, 1934290109447723829L, 5433461885918038655L);
    return 0L;
}

long inst_26_values_var_0(long param0, long param1, long param2, long param3, long param4, long param5) {
    long v0;
    long v0 = shlx(-7364139989238098041L, -6062543634060965592L, -730516388562321867L);
    return v0 - 0x2500000000000000L;
}

long inst_26_values_var_1(long param0, long param1, long param2, long param3, long param4, long param5) {
    long v0;
    long v0 = shlx(-4004349252126905132L, 7411527118182693649L, 2946250968066285383L);
    return v0 - 7891523368197654656L;
}

long inst_26_values_var_2(long param0, long param1, long param2, long param3, long param4, long param5) {
    long v0;
    long v0 = shlx(-2282885730539078368L, -8505931709107299807L, -2182597770081915349L);
    return v0 - 0x6cd1080000000000L;
}

long inst_26_values_var_3(long param0, long param1, long param2, long param3, long param4, long param5) {
    long v0;
    long v0 = shlx(7333351168077236669L, 51676792738785635L, 7333351168077236669L);
    return v0 - 0x6000000000000000L;
}

long inst_26_values_var_4(long param0, long param1, long param2, long param3, long param4, long param5) {
    long v0;
    long v0 = shlx(-4806650822924949334L, -4056367392137207626L, 0xb221004c2a9989eL);
    return v0 - 0x4c4bc82d80000000L;
}

long inst_26_values_var_5(long param0, long param1, long param2, long param3, long param4, long param5) {
    long v0;
    long v0 = shlx(4672182165688726782L, -1906475043148423065L, 7847938666756691343L);
    return v0 - 7747963766724329472L;
}

long inst_26_values_var_6(long param0, long param1, long param2, long param3, long param4, long param5) {
    long v0;
    long v0 = shlx(-1958275979053160418L, 0x5dcc280d5564cafdL, 1982381883417457142L);
    return v0 + 0x40c0000000000000L;
}

long inst_26_values_var_7(long param0, long param1, long param2, long param3, long param4, long param5) {
    long v0;
    long v0 = shlx(-1297607768903194058L, -8480037924730238670L, 8796402896513011595L);
    return v0 + 0x792c81cb17b67000L;
}

long inst_26_values_var_8(long param0, long param1, long param2, long param3, long param4, long param5) {
    long v0;
    long v0 = shlx(-6808144420510968244L, 5492991229740406764L, -8266751060489606043L);
    return v0 - 0x606afd8000000000L;
}

long inst_26_values_var_9(long param0, long param1, long param2, long param3, long param4, long param5) {
    long v0;
    long v0 = shlx(2282651452840678221L, 1761399805793135838L, 3972657721433202184L);
    return v0 - 0x71bfca83bdecde00L;
}

long inst_27_flags_var_0(long param0, long param1, long param2, long param3, long param4, long param5) {
    int v0 = shrx(-167382180, 0x3f85d3d9, 0x55589699);
    return 0L;
}

long inst_27_flags_var_1(long param0, long param1, long param2, long param3, long param4, long param5) {
    (unsigned int)v0 = shrx(-1391462399, -548588613, 669717001);
    return 0L;
}

long inst_27_flags_var_2(long param0, long param1, long param2, long param3, long param4, long param5) {
    (unsigned int)v0 = shrx(1638949565, 889497479, 1816992479);
    return 0L;
}

long inst_27_flags_var_3(long param0, long param1, long param2, long param3, long param4, long param5) {
    int v0 = shrx(-569272337, 1252521038, 986477070);
    return 0L;
}

long inst_27_flags_var_4(long param0, long param1, long param2, long param3, long param4, long param5) {
    (unsigned int)v0 = shrx(468346702, 606662573, -388302979);
    return 0L;
}

long inst_27_flags_var_5(long param0, long param1, long param2, long param3, long param4, long param5) {
    int v0 = shrx(-1072254721, 0x45bab486, 271951725);
    return 0L;
}

long inst_27_flags_var_6(long param0, long param1, long param2, long param3, long param4, long param5) {
    (unsigned int)v0 = shrx(709717355, -1492239682, 2001409411);
    return 0L;
}

long inst_27_flags_var_7(long param0, long param1, long param2, long param3, long param4, long param5) {
    (unsigned int)v0 = shrx(-1562900234, 0xa42bcbf2, 1454047783);
    return 0L;
}

long inst_27_flags_var_8(long param0, long param1, long param2, long param3, long param4, long param5) {
    (unsigned int)v0 = shrx(-2051463696, 607799223, -396598403);
    return 0L;
}

long inst_27_flags_var_9(long param0, long param1, long param2, long param3, long param4, long param5) {
    (unsigned int)v0 = shrx(0x6a5555a9, -2129998552, -844297943);
    return 0L;
}

long inst_27_values_var_0(long param0, long param1, long param2, long param3, long param4, long param5) {
    long v0;
    (unsigned int)v1 = shrx(0x6c533579, 1119178072, 434669327);
    return v0 - 34154L;
}

long inst_27_values_var_1(long param0, long param1, long param2, long param3, long param4, long param5) {
    (unsigned int)v0 = shrx(-1873101827, 23211974, 23211974);
    return param3 - 0x588bfL;
}

long inst_27_values_var_2(long param0, long param1, long param2, long param3, long param4, long param5) {
    long v0;
    (unsigned int)v1 = shrx(1681718461, 1681718461, 0xcbb8cb78);
    return v0 - 100L;
}

long inst_27_values_var_3(long param0, long param1, long param2, long param3, long param4, long param5) {
    long v0;
    int v1 = shrx(0x60edc4ed, -1656251261, -1971098396);
    return v0 - 164919752L;
}

long inst_27_values_var_4(long param0, long param1, long param2, long param3, long param4, long param5) {
    long v0;
    (unsigned int)v1 = shrx(164267282, 1775527388, -28147823);
    return v0 - 13546L;
}

long inst_27_values_var_5(long param0, long param1, long param2, long param3, long param4, long param5) {
    long v0;
    (unsigned int)v1 = shrx(-1311972982, -606468483, 1540796949);
    return v0 - 1758L;
}

long inst_27_values_var_6(long param0, long param1, long param2, long param3, long param4, long param5) {
    long v0;
    (unsigned int)v1 = shrx(1136802823, 2104928694, -1733550057);
    return v0 - 250L;
}

long inst_27_values_var_7(long param0, long param1, long param2, long param3, long param4, long param5) {
    (unsigned int)v0 = shrx(179673141, -1580603490, -944458238);
    return param4 - 678590951L;
}

long inst_27_values_var_8(long param0, long param1, long param2, long param3, long param4, long param5) {
    (unsigned int)v0 = shrx(-1115976364, 95944756, 150701229);
    return param5 - 11712L;
}

long inst_27_values_var_9(long param0, long param1, long param2, long param3, long param4, long param5) {
    long v0;
    (unsigned int)v1 = shrx(-1479020591, -1479020591, -797144091);
    return v0 - 87998334L;
}

long inst_28_flags_var_0(long param0, long param1, long param2, long param3, long param4, long param5) {
    long v0 = shrx(4967572794897627894L, 2261413619386781354L, 7232391002979735632L);
    return 0L;
}

long inst_28_flags_var_1(long param0, long param1, long param2, long param3, long param4, long param5) {
    long v0 = shrx(3731113586039874074L, 0xe0e60f9ccdd1a187L, -8754960676151450740L);
    return 0L;
}

long inst_28_flags_var_2(long param0, long param1, long param2, long param3, long param4, long param5) {
    long v0 = shrx(0x5624b414296f6765L, 0x651a7676200702fL, -448024272286943276L);
    return 0L;
}

long inst_28_flags_var_3(long param0, long param1, long param2, long param3, long param4, long param5) {
    long v0 = shrx(0xf89bf3b88e647434L, 2773140606416755688L, 3863010178573636987L);
    return 0L;
}

long inst_28_flags_var_4(long param0, long param1, long param2, long param3, long param4, long param5) {
    long v0 = shrx(5846900977746931304L, 4437681366129869668L, 5381404088936313194L);
    return 0L;
}

long inst_28_flags_var_5(long param0, long param1, long param2, long param3, long param4, long param5) {
    long v0 = shrx(3344186560665140965L, 0x7fc0aa99c557afddL, -3209354345603787405L);
    return 0L;
}

long inst_28_flags_var_6(long param0, long param1, long param2, long param3, long param4, long param5) {
    long v0 = shrx(-7106505523967267123L, -7106505523967267123L, -2474457917549072902L);
    return 0L;
}

long inst_28_flags_var_7(long param0, long param1, long param2, long param3, long param4, long param5) {
    long v0 = shrx(8896984970607495745L, -7752086507606593652L, 0x8fa3aa4effb87803L);
    return 0L;
}

long inst_28_flags_var_8(long param0, long param1, long param2, long param3, long param4, long param5) {
    long v0 = shrx(-6308815285067895134L, 0x4155e2311107a7c8L, -1941222722502986679L);
    return 0L;
}

long inst_28_flags_var_9(long param0, long param1, long param2, long param3, long param4, long param5) {
    long v0 = shrx(-6169656568004499787L, 7410690917687256194L, 0xe6845692e20888f8L);
    return 0L;
}

long inst_28_values_var_0(long param0, long param1, long param2, long param3, long param4, long param5) {
    long v0;
    long v0 = shrx(-4464724004527253654L, 0x2c7a3213e1a02243L, 3980188469817966969L);
    return v0 - 22L;
}

long inst_28_values_var_1(long param0, long param1, long param2, long param3, long param4, long param5) {
    long v0;
    long v0 = shrx(-8797164407913967646L, -4575597068326949131L, 1333377826582383997L);
    return v0 - 6L;
}

long inst_28_values_var_2(long param0, long param1, long param2, long param3, long param4, long param5) {
    long v0;
    long v0 = shrx(-4843264129564056711L, -6478164947004394357L, -1835839175200915693L);
    return v0 - 22828253034029L;
}

long inst_28_values_var_3(long param0, long param1, long param2, long param3, long param4, long param5) {
    long v0;
    long v0 = shrx(0x8b1f5c6e2dc0100L, 0x8b1f5c6e2dc0100L, 3290278098494544623L);
    return v0 - 4451L;
}

long inst_28_values_var_4(long param0, long param1, long param2, long param3, long param4, long param5) {
    long v0;
    long v0 = shrx(1003520709948326647L, -6111463861647325217L, 6872557271902864663L);
    return v0 - 0x1565f6ffed9L;
}

long inst_28_values_var_5(long param0, long param1, long param2, long param3, long param4, long param5) {
    long v0;
    long v0 = shrx(8620809832519605511L, 3466345895949378001L, -8086974442325648260L);
    return v0 - 3L;
}

long inst_28_values_var_6(long param0, long param1, long param2, long param3, long param4, long param5) {
    long v0;
    long v0 = shrx(4770702189932743204L, 0xa0d6c854486388ddL, -7474209392357782675L);
    return v0 - 329398L;
}

long inst_28_values_var_7(long param0, long param1, long param2, long param3, long param4, long param5) {
    long v0;
    long v0 = shrx(607395636757674055L, 5819935932075675578L, 653655678080586088L);
    return v0 - 5293200L;
}

long inst_28_values_var_9(long param0, long param1, long param2, long param3, long param4, long param5) {
    long v0;
    long v0 = shrx(-8083724400569538996L, 8152070634277633927L, 0x8382ec1c7dee75cbL);
    return v0 - 3980503239393375L;
}

long inst_29_flags_var_0(long param0, long param1, long param2, long param3, long param4, long param5) {
    (unsigned int)v0 = adox(0x774eedfb, 1352452273);
    return 0L;
}

long inst_29_flags_var_1(long param0, long param1, long param2, long param3, long param4, long param5) {
    int v0 = adox(-1984607801, 1545804397);
    return 0L;
}

long inst_29_flags_var_2(long param0, long param1, long param2, long param3, long param4, long param5) {
    (unsigned int)v0 = adox(0x295cd0c2, -1962980514);
    return 0L;
}

long inst_29_flags_var_3(long param0, long param1, long param2, long param3, long param4, long param5) {
    (unsigned int)v0 = adox(-1999550961, 1303187765);
    return 0L;
}

long inst_29_flags_var_4(long param0, long param1, long param2, long param3, long param4, long param5) {
    (unsigned int)v0 = adox(0xdd1d2356, 0xdd1d2356);
    return -2L;
}

long inst_29_flags_var_5(long param0, long param1, long param2, long param3, long param4, long param5) {
    int v0 = adox(625595930, 0x2249cf4c);
    return 0L;
}

long inst_29_flags_var_6(long param0, long param1, long param2, long param3, long param4, long param5) {
    (unsigned int)v0 = adox(2084143278, 1791572127);
    return 0L;
}

long inst_29_flags_var_7(long param0, long param1, long param2, long param3, long param4, long param5) {
    int v0 = adox(-629334623, -521718345);
    return -2L;
}

long inst_29_flags_var_8(long param0, long param1, long param2, long param3, long param4, long param5) {
    (unsigned int)v0 = adox(1879852692, -1306544277);
    return -2L;
}

long inst_29_flags_var_9(long param0, long param1, long param2, long param3, long param4, long param5) {
    (unsigned int)v0 = adox(0xb242b2f1, -931733253);
    return -2L;
}

long inst_29_values_var_0(long param0, long param1, long param2, long param3, long param4, long param5) {
    int v0 = adox(1434844237, 1801262249);
    return param2 - 3236106486L;
}

long inst_29_values_var_1(long param0, long param1, long param2, long param3, long param4, long param5) {
    (unsigned int)v0 = adox(0xfde41172, 0x1bda81bf);
    return param1 - 431919921L;
}

long inst_29_values_var_2(long param0, long param1, long param2, long param3, long param4, long param5) {
    (unsigned int)v0 = adox(-1784321460, -2043374756);
    return param4 - 467271080L;
}

long inst_29_values_var_3(long param0, long param1, long param2, long param3, long param4, long param5) {
    (unsigned int)v0 = adox(-2138118463, 1287701674);
    return param3 - 3444550507L;
}

long inst_29_values_var_4(long param0, long param1, long param2, long param3, long param4, long param5) {
    (unsigned int)v0 = adox(0x3fed596c, -1304626436);
    return param0 - 4062860392L;
}

long inst_29_values_var_5(long param0, long param1, long param2, long param3, long param4, long param5) {
    (unsigned int)v0 = adox(0x2c992c48, -419969850);
    return param5 - 328265998L;
}

long inst_29_values_var_6(long param0, long param1, long param2, long param3, long param4, long param5) {
    long v0;
    (unsigned int)v1 = adox(0x2b2b6cac, 427867404);
    return v0 - 1152133560L;
}

long inst_29_values_var_7(long param0, long param1, long param2, long param3, long param4, long param5) {
    long v0;
    (unsigned int)v1 = adox(-168910903, -1797276239);
    return v0 - 2328780154L;
}

long inst_29_values_var_8(long param0, long param1, long param2, long param3, long param4, long param5) {
    long v0;
    (unsigned int)v1 = adox(0xf3f4a1f5, 0x509f25df);
    return v0 - 1150535636L;
}

long inst_29_values_var_9(long param0, long param1, long param2, long param3, long param4, long param5) {
    long v0;
    (unsigned int)v1 = adox(-102876071, 485677638);
    return v0 - 382801567L;
}

long inst_2_flags_var_0(long param0, long param1, long param2, long param3, long param4, long param5) {
    long v0 = tzcnt(4703504620528936883L, 7896754100362288110L);
    return 1L;
}

long inst_2_flags_var_1(long param0, long param1, long param2, long param3, long param4, long param5) {
    long v0 = tzcnt(6442195850957633303L, 290277462574363563L);
    return 1L;
}

long inst_2_flags_var_2(long param0, long param1, long param2, long param3, long param4, long param5) {
    long v0 = tzcnt(6904866471023706155L, 0xbd5451909d33b0f0L);
    return 1L;
}

long inst_2_flags_var_3(long param0, long param1, long param2, long param3, long param4, long param5) {
    long v0 = tzcnt(-8296713237371005074L, 1063057187918169919L);
    return 1L;
}

long inst_2_flags_var_4(long param0, long param1, long param2, long param3, long param4, long param5) {
    long v0 = tzcnt(0x5121c1f0899a26f4L, -755642570956923153L);
    return 1L;
}

long inst_2_flags_var_5(long param0, long param1, long param2, long param3, long param4, long param5) {
    long v0 = tzcnt(-1185253378129627916L, 0x6eb1e07edcbc9b92L);
    return 1L;
}

long inst_2_flags_var_7(long param0, long param1, long param2, long param3, long param4, long param5) {
    long v0 = tzcnt(3765612305569137184L, 0x9dabcf001889f7d9L);
    return 1L;
}

long inst_2_flags_var_8(long param0, long param1, long param2, long param3, long param4, long param5) {
    long v0 = tzcnt(7154204321025651566L, 7154204321025651566L);
    return 1L;
}

long inst_2_flags_var_9(long param0, long param1, long param2, long param3, long param4, long param5) {
    long v0 = tzcnt(5365252903400377849L, -7972214740996048592L);
    return 1L;
}

long inst_2_values_var_0(long param0, long param1, long param2, long param3, long param4, long param5) {
    long result;
    long result = tzcnt(-7263689557637026591L, 2856120984033545071L);
    return result;
}

long inst_2_values_var_1(long param0, long param1, long param2, long param3, long param4, long param5) {
    long v0;
    long v0 = tzcnt(438635480159750699L, -5369725937837615616L);
    return v0 - 9L;
}

long inst_2_values_var_2(long param0, long param1, long param2, long param3, long param4, long param5) {
    long v0;
    long v0 = tzcnt(4395349638261696422L, -1008626295065040864L);
    return v0 - 5L;
}

long inst_2_values_var_3(long param0, long param1, long param2, long param3, long param4, long param5) {
    long result;
    long result = tzcnt(-6063752247498085335L, 0x37cbb16d877bf9a1L);
    return result;
}

long inst_2_values_var_4(long param0, long param1, long param2, long param3, long param4, long param5) {
    long v0;
    long v0 = tzcnt(-8901445532232260484L, 9171438328038481194L);
    return v0 - 1L;
}

long inst_2_values_var_5(long param0, long param1, long param2, long param3, long param4, long param5) {
    long v0;
    long v0 = tzcnt(2060731335651910337L, 7556244397254405776L);
    return v0 - 4L;
}

long inst_2_values_var_6(long param0, long param1, long param2, long param3, long param4, long param5) {
    long result;
    long result = tzcnt(-6187173018154273708L, 432289476892436057L);
    return result;
}

long inst_2_values_var_7(long param0, long param1, long param2, long param3, long param4, long param5) {
    long v0;
    long v0 = tzcnt(0x46d232d09b8780c8L, -3636050666541221498L);
    return v0 - 1L;
}

long inst_2_values_var_8(long param0, long param1, long param2, long param3, long param4, long param5) {
    long result;
    long result = tzcnt(0xb357bdc96656a651L, -2908002047921765777L);
    return result;
}

long inst_2_values_var_9(long param0, long param1, long param2, long param3, long param4, long param5) {
    long v0;
    long v0 = tzcnt(0xbfd0655183572c81L, 8920025746079598548L);
    return v0 - 2L;
}

long inst_30_flags_var_0(long param0, long param1, long param2, long param3, long param4, long param5) {
    long v0 = adox(8657228057660562928L, 208055119710569531L);
    return 0L;
}

long inst_30_flags_var_1(long param0, long param1, long param2, long param3, long param4, long param5) {
    long v0 = adox(0xf2ae877dc592ebbdL, -7304466084953965862L);
    return -2L;
}

long inst_30_flags_var_2(long param0, long param1, long param2, long param3, long param4, long param5) {
    long v0 = adox(7025008765138454694L, -914524710222436427L);
    return -2L;
}

long inst_30_flags_var_3(long param0, long param1, long param2, long param3, long param4, long param5) {
    long v0 = adox(1017691238139275118L, 0xf454730b2fd5b10eL);
    return -2L;
}

long inst_30_flags_var_4(long param0, long param1, long param2, long param3, long param4, long param5) {
    long v0 = adox(-1440885097333743078L, -6684715012375183435L);
    return -2L;
}

long inst_30_flags_var_5(long param0, long param1, long param2, long param3, long param4, long param5) {
    long v0 = adox(-1252258054126718550L, -7104287078218681038L);
    return -2L;
}

long inst_30_flags_var_6(long param0, long param1, long param2, long param3, long param4, long param5) {
    long v0 = adox(2212315769773706227L, 0x19a341ae8eeeaabbL);
    return 0L;
}

long inst_30_flags_var_7(long param0, long param1, long param2, long param3, long param4, long param5) {
    long v0 = adox(5570764155313147015L, 6189831421978926468L);
    return 0L;
}

long inst_30_flags_var_8(long param0, long param1, long param2, long param3, long param4, long param5) {
    long v0 = adox(0x2c4dcdc3f391bc80L, 4650444980294234033L);
    return 0L;
}

long inst_30_flags_var_9(long param0, long param1, long param2, long param3, long param4, long param5) {
    long v0 = adox(0xd7fb99f33f3cabb9L, -3567123121194469664L);
    return -2L;
}

long inst_30_values_var_0(long param0, long param1, long param2, long param3, long param4, long param5) {
    long v0;
    long v0 = adox(0x31eac81227a31220L, 259723791111371580L);
    return v0 - 3856631023820098908L;
}

long inst_30_values_var_1(long param0, long param1, long param2, long param3, long param4, long param5) {
    long v0;
    long v0 = adox(-6049851516152629591L, 765496470963219060L);
    return v0 + 0x4955ccea778edee3L;
}

long inst_30_values_var_2(long param0, long param1, long param2, long param3, long param4, long param5) {
    long v0;
    long v0 = adox(-4357371632446718144L, 4531039125914125454L);
    return v0 - 173667493467407310L;
}

long inst_30_values_var_3(long param0, long param1, long param2, long param3, long param4, long param5) {
    long v0;
    long v0 = adox(-7807679418732989799L, 1138409989504286806L);
    return v0 + 6669269429228702993L;
}

long inst_30_values_var_4(long param0, long param1, long param2, long param3, long param4, long param5) {
    long v0;
    long v0 = adox(-2374987399298889139L, 1460277863039988368L);
    return v0 + 0xcb1b37a155fc323L;
}

long inst_30_values_var_5(long param0, long param1, long param2, long param3, long param4, long param5) {
    long v0;
    long v0 = adox(4683504931910925246L, 2199580980382452531L);
    return v0 - 6883085912293377777L;
}

long inst_30_values_var_6(long param0, long param1, long param2, long param3, long param4, long param5) {
    long v0;
    long v0 = adox(-1768481539705085425L, -997934389833536541L);
    return v0 + 2766415929538621966L;
}

long inst_30_values_var_7(long param0, long param1, long param2, long param3, long param4, long param5) {
    long v0;
    long v0 = adox(0x67957010e877b5a6L, 0x589ac3aba4f2eb9eL);
    return v0 + 4598118334625832636L;
}

long inst_30_values_var_8(long param0, long param1, long param2, long param3, long param4, long param5) {
    long v0;
    long v0 = adox(-1348787702883048449L, -1402096754557427600L);
    return v0 + 2750884457440476049L;
}

long inst_30_values_var_9(long param0, long param1, long param2, long param3, long param4, long param5) {
    long v0;
    long v0 = adox(-3653067235159966414L, 2504800038379532197L);
    return v0 + 1148267196780434217L;
}

long inst_31_flags_var_0(long param0, long param1, long param2, long param3, long param4, long param5) {
    int v0 = adcx(1715846878, 1791054745);
    return 1L;
}

long inst_31_flags_var_1(long param0, long param1, long param2, long param3, long param4, long param5) {
    (unsigned int)v0 = adcx(731810100, 1262463701);
    return 1L;
}

long inst_31_flags_var_2(long param0, long param1, long param2, long param3, long param4, long param5) {
    (unsigned int)v0 = adcx(0x7cdd52a2, 0xd468b001);
    return 0L;
}

long inst_31_flags_var_3(long param0, long param1, long param2, long param3, long param4, long param5) {
    (unsigned int)v0 = adcx(-1708190249, 0xd45459d1);
    return 0L;
}

long inst_31_flags_var_4(long param0, long param1, long param2, long param3, long param4, long param5) {
    (unsigned int)v0 = adcx(-1246644313, -594532772);
    return 0L;
}

long inst_31_flags_var_5(long param0, long param1, long param2, long param3, long param4, long param5) {
    (unsigned int)v0 = adcx(-138059379, 541762761);
    return 0L;
}

long inst_31_flags_var_6(long param0, long param1, long param2, long param3, long param4, long param5) {
    (unsigned int)v0 = adcx(-669929093, 1676611244);
    return 0L;
}

long inst_31_flags_var_7(long param0, long param1, long param2, long param3, long param4, long param5) {
    (unsigned int)v0 = adcx(935811075, -864776646);
    return 0L;
}

long inst_31_flags_var_8(long param0, long param1, long param2, long param3, long param4, long param5) {
    (unsigned int)v0 = adcx(-1597626562, -394586967);
    return 0L;
}

long inst_31_flags_var_9(long param0, long param1, long param2, long param3, long param4, long param5) {
    (unsigned int)v0 = adcx(-1100660301, 0xad64b002);
    return 0L;
}

long inst_31_values_var_0(long param0, long param1, long param2, long param3, long param4, long param5) {
    long v0;
    (unsigned int)v1 = adcx(0x6a26b44b, -554997242);
    return v0 - 0x49121e52L;
}

long inst_31_values_var_1(long param0, long param1, long param2, long param3, long param4, long param5) {
    long v0;
    (unsigned int)v1 = adcx(0xc7879de8, -1907495695);
    return v0 - 0x55d58adaL;
}

long inst_31_values_var_2(long param0, long param1, long param2, long param3, long param4, long param5) {
    long v0;
    (unsigned int)v1 = adcx(-78635733, 1751845524);
    return v0 - 1673209792L;
}

long inst_31_values_var_3(long param0, long param1, long param2, long param3, long param4, long param5) {
    long v0;
    (unsigned int)v1 = adcx(0x3ab63229, 1895000262);
    return v0 - 0xaba99af0L;
}

long inst_31_values_var_4(long param0, long param1, long param2, long param3, long param4, long param5) {
    long v0;
    (unsigned int)v1 = adcx(109994762, -1870860663);
    return v0 - 2534101396L;
}

long inst_31_values_var_5(long param0, long param1, long param2, long param3, long param4, long param5) {
    (unsigned int)v0 = adcx(-73919537, -73919537);
    return param5 - 4147128223L;
}

long inst_31_values_var_6(long param0, long param1, long param2, long param3, long param4, long param5) {
    long v0;
    (unsigned int)v1 = adcx(-1267359873, -1940021267);
    return v0 - 1087586157L;
}

long inst_31_values_var_7(long param0, long param1, long param2, long param3, long param4, long param5) {
    (unsigned int)v0 = adcx(479945461, 897880270);
    return param5 - 1377825732L;
}

long inst_31_values_var_8(long param0, long param1, long param2, long param3, long param4, long param5) {
    long v0;
    (unsigned int)v1 = adcx(1904382326, -140868892);
    return v0 - 1763513435L;
}

long inst_31_values_var_9(long param0, long param1, long param2, long param3, long param4, long param5) {
    long v0;
    (unsigned int)v1 = adcx(-1182991474, 1053813829);
    return v0 - 4165789652L;
}

long inst_32_flags_var_0(long param0, long param1, long param2, long param3, long param4, long param5) {
    long v0 = adcx(1063105513401192862L, -4413820067084116924L);
    return 1L;
}

long inst_32_flags_var_1(long param0, long param1, long param2, long param3, long param4, long param5) {
    long v0 = adcx(-8506036095888466144L, -1327994220939123165L);
    return 0L;
}

long inst_32_flags_var_2(long param0, long param1, long param2, long param3, long param4, long param5) {
    long v0 = adcx(-1166107143050074598L, 7594630309190714578L);
    return 0L;
}

long inst_32_flags_var_3(long param0, long param1, long param2, long param3, long param4, long param5) {
    long v0 = adcx(5489998016067837845L, -6638262557866221553L);
    return 1L;
}

long inst_32_flags_var_4(long param0, long param1, long param2, long param3, long param4, long param5) {
    long v0 = adcx(-3087730763718462987L, 6739722375173962944L);
    return 0L;
}

long inst_32_flags_var_5(long param0, long param1, long param2, long param3, long param4, long param5) {
    long v0 = adcx(2819914262860850433L, 1325901029361713510L);
    return 1L;
}

long inst_32_flags_var_6(long param0, long param1, long param2, long param3, long param4, long param5) {
    long v0 = adcx(0x2602cb94bcb4b72fL, -1603007066937380010L);
    return 0L;
}

long inst_32_flags_var_7(long param0, long param1, long param2, long param3, long param4, long param5) {
    long v0 = adcx(-4143788611601066626L, 0x4a1673b98accba27L);
    return 0L;
}

long inst_32_flags_var_8(long param0, long param1, long param2, long param3, long param4, long param5) {
    long v0 = adcx(-2211845932379881032L, 5499420369368779955L);
    return 0L;
}

long inst_32_flags_var_9(long param0, long param1, long param2, long param3, long param4, long param5) {
    long v0 = adcx(-746364576077085244L, -5920315616574745831L);
    return 0L;
}

long inst_32_values_var_0(long param0, long param1, long param2, long param3, long param4, long param5) {
    long v0;
    long v0 = adcx(-6629802928178065085L, -1053361658198260871L);
    return v0 + 7683164586376325955L;
}

long inst_32_values_var_1(long param0, long param1, long param2, long param3, long param4, long param5) {
    long v0;
    long v0 = adcx(-1104004265952020316L, -77201295563381750L);
    return v0 + 1181205561515402065L;
}

long inst_32_values_var_2(long param0, long param1, long param2, long param3, long param4, long param5) {
    long v0;
    long v0 = adcx(1459383371195552172L, -8796307679592324170L);
    return v0 + 7336924308396771997L;
}

long inst_32_values_var_3(long param0, long param1, long param2, long param3, long param4, long param5) {
    long v0;
    long v0 = adcx(6830030006600992189L, 8775232906493346241L);
    return v0 + 2841481160615213185L;
}

long inst_32_values_var_4(long param0, long param1, long param2, long param3, long param4, long param5) {
    long v0;
    long v0 = adcx(8774404217847745923L, 3950264732511444076L);
    return v0 + 5722075123350361616L;
}

long inst_32_values_var_6(long param0, long param1, long param2, long param3, long param4, long param5) {
    long v0;
    long v0 = adcx(-5464867446561059953L, -4003883281950166939L);
    return v0 - 8977993345198324725L;
}

long inst_32_values_var_7(long param0, long param1, long param2, long param3, long param4, long param5) {
    long v0;
    long v0 = adcx(-4468104395924249278L, -5986661979270755933L);
    return v0 - 7991977698514546406L;
}

long inst_32_values_var_8(long param0, long param1, long param2, long param3, long param4, long param5) {
    long v0;
    long v0 = adcx(-7273703559039176280L, -3406614133278924666L);
    return v0 - 7766426381391450671L;
}

long inst_32_values_var_9(long param0, long param1, long param2, long param3, long param4, long param5) {
    long v0;
    long v0 = adcx(9193601228445429293L, 1030023819743085209L);
    return v0 + 8223119025521037113L;
}

long inst_33_flags_var_0(long param0, long param1, long param2, long param3, long param4, long param5) {
    (unsigned int)v0 = crc32(1393866779, 172);
    return 0L;
}

long inst_33_flags_var_1(long param0, long param1, long param2, long param3, long param4, long param5) {
    int v0 = crc32(481581563, 214);
    return 0L;
}

long inst_33_flags_var_3(long param0, long param1, long param2, long param3, long param4, long param5) {
    (unsigned int)v0 = crc32(-266116425, 42);
    return 0L;
}

long inst_33_flags_var_4(long param0, long param1, long param2, long param3, long param4, long param5) {
    int v0 = crc32(-1974905320, 212);
    return 0L;
}

long inst_33_flags_var_5(long param0, long param1, long param2, long param3, long param4, long param5) {
    (unsigned int)v0 = crc32(0x16202114, 0xff);
    return 0L;
}

long inst_33_flags_var_6(long param0, long param1, long param2, long param3, long param4, long param5) {
    (unsigned int)v0 = crc32(-176267771, 162);
    return 0L;
}

long inst_33_flags_var_7(long param0, long param1, long param2, long param3, long param4, long param5) {
    (unsigned int)v0 = crc32(-1010999855, 158);
    return 0L;
}

long inst_33_flags_var_8(long param0, long param1, long param2, long param3, long param4, long param5) {
    (unsigned int)v0 = crc32(200198013, 16);
    return 0L;
}

long inst_33_flags_var_9(long param0, long param1, long param2, long param3, long param4, long param5) {
    (unsigned int)v0 = crc32(0x989979a8, 50);
    return 0L;
}

long inst_33_values_var_0(long param0, long param1, long param2, long param3, long param4, long param5) {
    (unsigned int)v0 = crc32(-1472206893, 174);
    return param3 - 3457689401L;
}

long inst_33_values_var_1(long param0, long param1, long param2, long param3, long param4, long param5) {
    long v0;
    int v1 = crc32(0xe722e7ad, 150);
    return v0 - 0xa98dc06dL;
}

long inst_33_values_var_2(long param0, long param1, long param2, long param3, long param4, long param5) {
    long v0;
    (unsigned int)v1 = crc32(-815457030, 0xbb);
    return v0 - 3017800611L;
}

long inst_33_values_var_3(long param0, long param1, long param2, long param3, long param4, long param5) {
    (unsigned int)v0 = crc32(-427025785, 66);
    return param0 - 0xf69abec2L;
}

long inst_33_values_var_4(long param0, long param1, long param2, long param3, long param4, long param5) {
    (unsigned int)v0 = crc32(-1305707882, 193);
    return param1 - 2237502018L;
}

long inst_33_values_var_5(long param0, long param1, long param2, long param3, long param4, long param5) {
    long v0;
    (unsigned int)v1 = crc32(0x50a98b09, 215);
    return v0 - 0x7ffbf707L;
}

long inst_33_values_var_6(long param0, long param1, long param2, long param3, long param4, long param5) {
    (unsigned int)v0 = crc32(1781593820, 190);
    return param3 - 2157433699L;
}

long inst_33_values_var_7(long param0, long param1, long param2, long param3, long param4, long param5) {
    long v0;
    int v1 = crc32(0x3583a779, 121);
    return v0 - 3507111L;
}

long inst_33_values_var_8(long param0, long param1, long param2, long param3, long param4, long param5) {
    (unsigned int)v0 = crc32(2043089696, 32);
    return param3 - 7980819L;
}

long inst_33_values_var_9(long param0, long param1, long param2, long param3, long param4, long param5) {
    (unsigned int)v0 = crc32(1097371590, 158);
    return param0 - 3686656659L;
}

long inst_34_flags_var_0(long param0, long param1, long param2, long param3, long param4, long param5) {
    (unsigned int)v0 = crc32(1998440076, 3);
    return 0L;
}

long inst_34_flags_var_1(long param0, long param1, long param2, long param3, long param4, long param5) {
    (unsigned int)v0 = crc32(-686247808, 106);
    return 0L;
}

long inst_34_flags_var_2(long param0, long param1, long param2, long param3, long param4, long param5) {
    (unsigned int)v0 = crc32(0x5af83122, 143);
    return 0L;
}

long inst_34_flags_var_3(long param0, long param1, long param2, long param3, long param4, long param5) {
    (unsigned int)v0 = crc32(1513205691, 112);
    return 0L;
}

long inst_34_flags_var_4(long param0, long param1, long param2, long param3, long param4, long param5) {
    (unsigned int)v0 = crc32(0xa995932d, 46);
    return 0L;
}

long inst_34_flags_var_5(long param0, long param1, long param2, long param3, long param4, long param5) {
    (unsigned int)v0 = crc32(-257982344, 45);
    return 0L;
}

long inst_34_flags_var_6(long param0, long param1, long param2, long param3, long param4, long param5) {
    (unsigned int)v0 = crc32(108031430, 63);
    return 0L;
}

long inst_34_flags_var_7(long param0, long param1, long param2, long param3, long param4, long param5) {
    (unsigned int)v0 = crc32(-1910544805, 124);
    return 0L;
}

long inst_34_flags_var_8(long param0, long param1, long param2, long param3, long param4, long param5) {
    (unsigned int)v0 = crc32(648329695, 37);
    return 0L;
}

long inst_34_flags_var_9(long param0, long param1, long param2, long param3, long param4, long param5) {
    (unsigned int)v0 = crc32(-474612972, 113);
    return 0L;
}

long inst_34_values_var_0(long param0, long param1, long param2, long param3, long param4, long param5) {
    long v0;
    (unsigned int)v1 = crc32(2127273191, 231);
    return v0 - 8309660L;
}

long inst_34_values_var_1(long param0, long param1, long param2, long param3, long param4, long param5) {
    long v0;
    (unsigned int)v1 = crc32(0xa7000081, 129);
    return v0 - 0xa70000L;
}

long inst_34_values_var_2(long param0, long param1, long param2, long param3, long param4, long param5) {
    long v0;
    (unsigned int)v1 = crc32(1588372668, 198);
    return v0 - 438620305L;
}

long inst_34_values_var_3(long param0, long param1, long param2, long param3, long param4, long param5) {
    long v0;
    int v1 = crc32(0xcfff82e3, 243);
    return v0 - 277952749L;
}

long inst_34_values_var_4(long param0, long param1, long param2, long param3, long param4, long param5) {
    (unsigned int)v0 = crc32(-374915229, 113);
    return param1 - 4052488359L;
}

long inst_34_values_var_5(long param0, long param1, long param2, long param3, long param4, long param5) {
    long v0;
    int v1 = crc32(0x4464d1dd, 167);
    return v0 - 440277220L;
}

long inst_34_values_var_6(long param0, long param1, long param2, long param3, long param4, long param5) {
    long v0;
    int v1 = crc32(1047615046, 218);
    return v0 - 3755295377L;
}

long inst_34_values_var_7(long param0, long param1, long param2, long param3, long param4, long param5) {
    long v0;
    (unsigned int)v1 = crc32(28987983, 18);
    return v0 - 0xee0c2c52L;
}

long inst_34_values_var_8(long param0, long param1, long param2, long param3, long param4, long param5) {
    (unsigned int)v0 = crc32(0x197922b, 180);
    return param4 - 0xccba57a1L;
}

long inst_34_values_var_9(long param0, long param1, long param2, long param3, long param4, long param5) {
    long v0;
    (unsigned int)v1 = crc32(1515128162, 196);
    return v0 - 2226134347L;
}

long inst_35_flags_var_0(long param0, long param1, long param2, long param3, long param4, long param5) {
    int v0 = crc32(675241322, 1427);
    return 0L;
}

long inst_35_flags_var_1(long param0, long param1, long param2, long param3, long param4, long param5) {
    (unsigned int)v0 = crc32(346526541, 53907);
    return 0L;
}

long inst_35_flags_var_2(long param0, long param1, long param2, long param3, long param4, long param5) {
    (unsigned int)v0 = crc32(-158721281, 6031);
    return 0L;
}

long inst_35_flags_var_3(long param0, long param1, long param2, long param3, long param4, long param5) {
    (unsigned int)v0 = crc32(-1568535133, 60966);
    return 0L;
}

long inst_35_flags_var_5(long param0, long param1, long param2, long param3, long param4, long param5) {
    (unsigned int)v0 = crc32(-1033713666, 0xff20);
    return 0L;
}

long inst_35_flags_var_6(long param0, long param1, long param2, long param3, long param4, long param5) {
    (unsigned int)v0 = crc32(-94086454, 0xeee0);
    return 0L;
}

long inst_35_flags_var_7(long param0, long param1, long param2, long param3, long param4, long param5) {
    (unsigned int)v0 = crc32(0x25d78da, 12703);
    return 0L;
}

long inst_35_flags_var_8(long param0, long param1, long param2, long param3, long param4, long param5) {
    (unsigned int)v0 = crc32(0x60336ac1, 0x5e58);
    return 0L;
}

long inst_35_flags_var_9(long param0, long param1, long param2, long param3, long param4, long param5) {
    (unsigned int)v0 = crc32(898234401, 0xccb0);
    return 0L;
}

long inst_35_values_var_0(long param0, long param1, long param2, long param3, long param4, long param5) {
    int v0 = crc32(-2102518411, 33295);
    return param2 - 0xc9b3654cL;
}

long inst_35_values_var_1(long param0, long param1, long param2, long param3, long param4, long param5) {
    long v0;
    (unsigned int)v1 = crc32(-348856835, 0xf855);
    return v0 - 0xc10abb5L;
}

long inst_35_values_var_2(long param0, long param1, long param2, long param3, long param4, long param5) {
    long v0;
    (unsigned int)v1 = crc32(631085559, 45818);
    return v0 - 2030582379L;
}

long inst_35_values_var_3(long param0, long param1, long param2, long param3, long param4, long param5) {
    long v0;
    (unsigned int)v1 = crc32(180588401, 34751);
    return v0 - 2060909691L;
}

long inst_35_values_var_4(long param0, long param1, long param2, long param3, long param4, long param5) {
    (unsigned int)v0 = crc32(-821875495, 42305);
    return param0 - 0xa356e777L;
}

long inst_35_values_var_5(long param0, long param1, long param2, long param3, long param4, long param5) {
    (unsigned int)v0 = crc32(-1229425650, 44082);
    return param5 - 3403333435L;
}

long inst_35_values_var_6(long param0, long param1, long param2, long param3, long param4, long param5) {
    long v0;
    int v1 = crc32(575502395, 56891);
    return v0 - 2229956611L;
}

long inst_35_values_var_7(long param0, long param1, long param2, long param3, long param4, long param5) {
    (unsigned int)v0 = crc32(0x31e3437f, 0x991b);
    return param5 - 0x7627bcaaL;
}

long inst_35_values_var_8(long param0, long param1, long param2, long param3, long param4, long param5) {
    (unsigned int)v0 = crc32(-1600464528, 64350);
    return param4 - 1255550779L;
}

long inst_35_values_var_9(long param0, long param1, long param2, long param3, long param4, long param5) {
    long v0;
    (unsigned int)v1 = crc32(0x5eefa784, 0xc229);
    return v0 - 272890489L;
}

long inst_36_flags_var_0(long param0, long param1, long param2, long param3, long param4, long param5) {
    int v0 = crc32(0x594d0554, 0x1887553d);
    return 0L;
}

long inst_36_flags_var_1(long param0, long param1, long param2, long param3, long param4, long param5) {
    (unsigned int)v0 = crc32(1675636711, 1084383339);
    return 0L;
}

long inst_36_flags_var_2(long param0, long param1, long param2, long param3, long param4, long param5) {
    (unsigned int)v0 = crc32(-2070643671, -821193835);
    return 0L;
}

long inst_36_flags_var_3(long param0, long param1, long param2, long param3, long param4, long param5) {
    (unsigned int)v0 = crc32(0x372222f9, -1872100632);
    return 0L;
}

long inst_36_flags_var_4(long param0, long param1, long param2, long param3, long param4, long param5) {
    (unsigned int)v0 = crc32(169704698, -201360381);
    return 0L;
}

long inst_36_flags_var_5(long param0, long param1, long param2, long param3, long param4, long param5) {
    int v0 = crc32(-1497336001, -1677629937);
    return 0L;
}

long inst_36_flags_var_6(long param0, long param1, long param2, long param3, long param4, long param5) {
    (unsigned int)v0 = crc32(0xa99e7298, 0xbb27f3c);
    return 0L;
}

long inst_36_flags_var_7(long param0, long param1, long param2, long param3, long param4, long param5) {
    (unsigned int)v0 = crc32(2096019979, -685538484);
    return 0L;
}

long inst_36_flags_var_8(long param0, long param1, long param2, long param3, long param4, long param5) {
    (unsigned int)v0 = crc32(514462421, -1297711369);
    return 0L;
}

long inst_36_flags_var_9(long param0, long param1, long param2, long param3, long param4, long param5) {
    (unsigned int)v0 = crc32(-2084557854, -2084557854);
    return 0L;
}

long inst_36_values_var_0(long param0, long param1, long param2, long param3, long param4, long param5) {
    long v0;
    (unsigned int)v1 = crc32(1461409299, 0x19fa34cc);
    return v0 - 0x1396301aL;
}

long inst_36_values_var_1(long param0, long param1, long param2, long param3, long param4, long param5) {
    (unsigned int)v0 = crc32(-569682791, 647947252);
    return param4 - 2718491420L;
}

long inst_36_values_var_2(long param0, long param1, long param2, long param3, long param4, long param5) {
    long v0;
    (unsigned int)v1 = crc32(0x3ff1f77, 0x95896369);
    return v0 - 1240908411L;
}

long inst_36_values_var_3(long param0, long param1, long param2, long param3, long param4, long param5) {
    long result;
    (unsigned int)v0 = crc32(636893578, 636893578);
    return result;
}

long inst_36_values_var_4(long param0, long param1, long param2, long param3, long param4, long param5) {
    long v0;
    (unsigned int)v1 = crc32(-81241189, 0x244371b0);
    return v0 - 1905719840L;
}

long inst_36_values_var_5(long param0, long param1, long param2, long param3, long param4, long param5) {
    (unsigned int)v0 = crc32(1613783898, -1863869413);
    return param1 - 1442100667L;
}

long inst_36_values_var_6(long param0, long param1, long param2, long param3, long param4, long param5) {
    long v0;
    (unsigned int)v1 = crc32(-193033414, 565713871);
    return v0 - 295451284L;
}

long inst_36_values_var_7(long param0, long param1, long param2, long param3, long param4, long param5) {
    (unsigned int)v0 = crc32(-1378388794, 0xeffd7277);
    return param4 - 93277497L;
}

long inst_36_values_var_9(long param0, long param1, long param2, long param3, long param4, long param5) {
    (unsigned int)v0 = crc32(0xbc0dcd05, -789257512);
    return param5 - 185423859L;
}

long inst_37_flags_var_0(long param0, long param1, long param2, long param3, long param4, long param5) {
    (unsigned int)v0 = crc32(-379569717, 90);
    return 0L;
}

long inst_37_flags_var_1(long param0, long param1, long param2, long param3, long param4, long param5) {
    (unsigned int)v0 = crc32(0x7a5766ea, 4);
    return 0L;
}

long inst_37_flags_var_2(long param0, long param1, long param2, long param3, long param4, long param5) {
    (unsigned int)v0 = crc32(874003746, 79);
    return 0L;
}

long inst_37_flags_var_3(long param0, long param1, long param2, long param3, long param4, long param5) {
    (unsigned int)v0 = crc32(-83056046, 12);
    return 0L;
}

long inst_37_flags_var_4(long param0, long param1, long param2, long param3, long param4, long param5) {
    (unsigned int)v0 = crc32(134033782, 146);
    return 0L;
}

long inst_37_flags_var_5(long param0, long param1, long param2, long param3, long param4, long param5) {
    (unsigned int)v0 = crc32(-487179088, 13);
    return 0L;
}

long inst_37_flags_var_6(long param0, long param1, long param2, long param3, long param4, long param5) {
    (unsigned int)v0 = crc32(0xa6b66ebc, 212);
    return 0L;
}

long inst_37_flags_var_7(long param0, long param1, long param2, long param3, long param4, long param5) {
    (unsigned int)v0 = crc32(0xad013a18, 99);
    return 0L;
}

long inst_37_flags_var_8(long param0, long param1, long param2, long param3, long param4, long param5) {
    (unsigned int)v0 = crc32(-1581682439, 199);
    return 0L;
}

long inst_37_flags_var_9(long param0, long param1, long param2, long param3, long param4, long param5) {
    (unsigned int)v0 = crc32(1801376368, 40);
    return 0L;
}

long inst_37_values_var_0(long param0, long param1, long param2, long param3, long param4, long param5) {
    long v0;
    int v1 = crc32(532482244, 239);
    return v0 - 0xb92b98edL;
}

long inst_37_values_var_1(long param0, long param1, long param2, long param3, long param4, long param5) {
    int v0 = crc32(0xde246457, 179);
    return param2 - 611588961L;
}

long inst_37_values_var_2(long param0, long param1, long param2, long param3, long param4, long param5) {
    long v0;
    (unsigned int)v1 = crc32(-2035522291, 173);
    return v0 - 2731350467L;
}

long inst_37_values_var_3(long param0, long param1, long param2, long param3, long param4, long param5) {
    (unsigned int)v0 = crc32(-1877356454, 90);
    return param0 - 9443792L;
}

long inst_37_values_var_4(long param0, long param1, long param2, long param3, long param4, long param5) {
    (unsigned int)v0 = crc32(140603582, 190);
    return param1 - 549232L;
}

long inst_37_values_var_5(long param0, long param1, long param2, long param3, long param4, long param5) {
    long v0;
    (unsigned int)v1 = crc32(-1866607006, 145);
    return v0 - 3769508183L;
}

long inst_37_values_var_6(long param0, long param1, long param2, long param3, long param4, long param5) {
    long v0;
    (unsigned int)v1 = crc32(0x97277c45, 134);
    return v0 - 3494572620L;
}

long inst_37_values_var_7(long param0, long param1, long param2, long param3, long param4, long param5) {
    long v0;
    int v1 = crc32(0x553edd, 63);
    return v0 - 34311635L;
}

long inst_37_values_var_8(long param0, long param1, long param2, long param3, long param4, long param5) {
    (unsigned int)v0 = crc32(998383610, 0xbb);
    return param3 - 3005947040L;
}

long inst_37_values_var_9(long param0, long param1, long param2, long param3, long param4, long param5) {
    long v0;
    (unsigned int)v1 = crc32(-1392336003, 43);
    return v0 - 1999191960L;
}

long inst_38_flags_var_0(long param0, long param1, long param2, long param3, long param4, long param5) {
    (unsigned int)v0 = crc32(0x23aed321, 0x1001e333ac4fe425L);
    return 0L;
}

long inst_38_flags_var_1(long param0, long param1, long param2, long param3, long param4, long param5) {
    (unsigned int)v0 = crc32(-1645194653, -2058189262569530198L);
    return 0L;
}

long inst_38_flags_var_2(long param0, long param1, long param2, long param3, long param4, long param5) {
    (unsigned int)v0 = crc32(-1278480891, 0x3c9226ab322b6943L);
    return 0L;
}

long inst_38_flags_var_3(long param0, long param1, long param2, long param3, long param4, long param5) {
    (unsigned int)v0 = crc32(0xea728876, 6450497572044837971L);
    return 0L;
}

long inst_38_flags_var_4(long param0, long param1, long param2, long param3, long param4, long param5) {
    (unsigned int)v0 = crc32(34291443, 3673005157127737624L);
    return 0L;
}

long inst_38_flags_var_5(long param0, long param1, long param2, long param3, long param4, long param5) {
    (unsigned int)v0 = crc32(1142786010, -7061825183319417570L);
    return 0L;
}

long inst_38_flags_var_6(long param0, long param1, long param2, long param3, long param4, long param5) {
    int v0 = crc32(0x236cba36, -183477279784333595L);
    return 0L;
}

long inst_38_flags_var_7(long param0, long param1, long param2, long param3, long param4, long param5) {
    (unsigned int)v0 = crc32(304430242, 0x1b83a43e12253ca2L);
    return 0L;
}

long inst_38_flags_var_8(long param0, long param1, long param2, long param3, long param4, long param5) {
    (unsigned int)v0 = crc32(-997865964, -3822032715101720665L);
    return 0L;
}

long inst_38_flags_var_9(long param0, long param1, long param2, long param3, long param4, long param5) {
    int v0 = crc32(-731475127, -424808331913945985L);
    return 0L;
}

long inst_38_values_var_0(long param0, long param1, long param2, long param3, long param4, long param5) {
    long v0;
    int v1 = crc32(336544971, -9007553126464590393L);
    return v0 - 608711867L;
}

long inst_38_values_var_1(long param0, long param1, long param2, long param3, long param4, long param5) {
    (unsigned int)v0 = crc32(-1887736498, -8011486188130009347L);
    return param4 - 2242678470L;
}

long inst_38_values_var_2(long param0, long param1, long param2, long param3, long param4, long param5) {
    (unsigned int)v0 = crc32(-1846102023, -4598931101279901562L);
    return param5 - 1887460552L;
}

long inst_38_values_var_3(long param0, long param1, long param2, long param3, long param4, long param5) {
    long v0;
    (unsigned int)v1 = crc32(-972416619, -998364791052321141L);
    return v0 - 3339286240L;
}

long inst_38_values_var_4(long param0, long param1, long param2, long param3, long param4, long param5) {
    long v0;
    (unsigned int)v1 = crc32(-830573341, 3873762475452774792L);
    return v0 - 2079873765L;
}

long inst_38_values_var_5(long param0, long param1, long param2, long param3, long param4, long param5) {
    long v0;
    (unsigned int)v1 = crc32(1554111710, 4527740163867087499L);
    return v0 - 1336825213L;
}

long inst_38_values_var_6(long param0, long param1, long param2, long param3, long param4, long param5) {
    long v0;
    (unsigned int)v1 = crc32(-1156455285, 7996489740347777935L);
    return v0 - 2332786022L;
}

long inst_38_values_var_7(long param0, long param1, long param2, long param3, long param4, long param5) {
    long v0;
    (unsigned int)v1 = crc32(-278597274, -9020867534931937895L);
    return v0 - 0xce65000fL;
}

long inst_38_values_var_8(long param0, long param1, long param2, long param3, long param4, long param5) {
    long v0;
    (unsigned int)v1 = crc32(-1671667522, -1146406864719017193L);
    return v0 - 3535484666L;
}

long inst_38_values_var_9(long param0, long param1, long param2, long param3, long param4, long param5) {
    long v0;
    (unsigned int)v1 = crc32(1733734562, -8322720727772984771L);
    return v0 - 3483207041L;
}

long inst_39_flags_var_0(long param0, long param1, long param2, long param3, long param4, long param5) {
    for(short i = 15; !(47420 >>> i); --i) {
    }
    return 0L;
}

long inst_39_flags_var_1(long param0, long param1, long param2, long param3, long param4, long param5) {
    for(short i = 15; !(48080 >>> i); --i) {
    }
    return 0L;
}

long inst_39_flags_var_2(long param0, long param1, long param2, long param3, long param4, long param5) {
    for(short i = 15; !(23873 >>> i); --i) {
    }
    return 0L;
}

long inst_39_flags_var_3(long param0, long param1, long param2, long param3, long param4, long param5) {
    for(short i = 15; !(33497 >>> i); --i) {
    }
    return 0L;
}

long inst_39_flags_var_4(long param0, long param1, long param2, long param3, long param4, long param5) {
    for(short i = 15; !(31904 >>> i); --i) {
    }
    return 0L;
}

long inst_39_flags_var_5(long param0, long param1, long param2, long param3, long param4, long param5) {
    for(short i = 15; !(39134 >>> i); --i) {
    }
    return 0L;
}

long inst_39_flags_var_6(long param0, long param1, long param2, long param3, long param4, long param5) {
    for(short i = 15; !(18416 >>> i); --i) {
    }
    return 0L;
}

long inst_39_flags_var_7(long param0, long param1, long param2, long param3, long param4, long param5) {
    for(short i = 15; !(42610 >>> i); --i) {
    }
    return 0L;
}

long inst_39_flags_var_8(long param0, long param1, long param2, long param3, long param4, long param5) {
    for(short i = 15; !(28452 >>> i); --i) {
    }
    return 0L;
}

long inst_39_flags_var_9(long param0, long param1, long param2, long param3, long param4, long param5) {
    for(short i = 15; !(31481 >>> i); --i) {
    }
    return 0L;
}

long inst_39_values_var_0(long param0, long param1, long param2, long param3, long param4, long param5) {
    short i;
    for(i = 15; !(38392 >>> i); --i) {
    }
    return ((unsigned long)i | ((unsigned long)51559537517310L << 16)) - 0x2ee4a3eb22fe0000L;
}

long inst_39_values_var_1(long param0, long param1, long param2, long param3, long param4, long param5) {
    short i;
    for(i = 15; !(20912 >>> i); --i) {
    }
    return ((unsigned long)i | ((unsigned long)31190119999968L << 16)) - 0x1c5e0405e9e00001L;
}

long inst_39_values_var_2(long param0, long param1, long param2, long param3, long param4, long param5) {
    short i;
    for(i = 15; !(8070 >>> i); --i) {
    }
    return ((unsigned long)i | ((unsigned long)262742065676428L << 16)) + 0x11099881ff73fffdL;
}

long inst_39_values_var_3(long param0, long param1, long param2, long param3, long param4, long param5) {
    short i;
    for(i = 15; !(42463 >>> i); --i) {
    }
    return ((unsigned long)i | ((unsigned long)181933063274434L << 16)) + 0x5a886864003e0000L;
}

long inst_39_values_var_4(long param0, long param1, long param2, long param3, long param4, long param5) {
    short i;
    for(i = 15; !(39521 >>> i); --i) {
    }
    return ((unsigned long)i | ((unsigned long)183345442354450L << 16)) + 0x593f90098aee0000L;
}

long inst_39_values_var_5(long param0, long param1, long param2, long param3, long param4, long param5) {
    short i;
    for(i = 15; !(49149 >>> i); --i) {
    }
    return ((unsigned long)i | ((unsigned long)273977716284013L << 16)) + 0x6d1978b65930000L;
}

long inst_39_values_var_6(long param0, long param1, long param2, long param3, long param4, long param5) {
    short i;
    for(i = 15; !(0x9cce >>> i); --i) {
    }
    return ((unsigned long)i | ((unsigned long)145293191719943L << 16)) + 0x7bdb4aeb53f90000L;
}

long inst_39_values_var_7(long param0, long param1, long param2, long param3, long param4, long param5) {
    short i;
    for(i = 15; !(33373 >>> i); --i) {
    }
    return ((unsigned long)i | ((unsigned long)0x37de0994b433L << 16)) - 4025665651198853120L;
}

long inst_39_values_var_8(long param0, long param1, long param2, long param3, long param4, long param5) {
    short i;
    for(i = 15; !(0x5195 >>> i); --i) {
    }
    return ((unsigned long)i | ((unsigned long)0x18440ca8bbb0L << 16)) - 0x18440ca8bbb00001L;
}

long inst_39_values_var_9(long param0, long param1, long param2, long param3, long param4, long param5) {
    short i;
    for(i = 15; !(4307 >>> i); --i) {
    }
    return ((unsigned long)i | ((unsigned long)196684255671395L << 16)) + 5556844694029008893L;
}

long inst_3_flags_var_0(long param0, long param1, long param2, long param3, long param4, long param5) {
    (unsigned int)v0 = andn(443720055, 743544863, 1583783889);
    return 1L;
}

long inst_3_flags_var_1(long param0, long param1, long param2, long param3, long param4, long param5) {
    (unsigned int)v0 = andn(0x8d6551dd, -1827309656, 0xb01a9191);
    return 1L;
}

long inst_3_flags_var_2(long param0, long param1, long param2, long param3, long param4, long param5) {
    (unsigned int)v0 = andn(-1799689603, 1827766356, -906448856);
    return 1L;
}

long inst_3_flags_var_4(long param0, long param1, long param2, long param3, long param4, long param5) {
    (unsigned int)v0 = andn(207005545, 1042565773, 96930150);
    return 1L;
}

long inst_3_flags_var_5(long param0, long param1, long param2, long param3, long param4, long param5) {
    (unsigned int)v0 = andn(0x539a8cdc, 323028472, -885529265);
    return 1L;
}

long inst_3_flags_var_6(long param0, long param1, long param2, long param3, long param4, long param5) {
    (unsigned int)v0 = andn(0xcf3435e3, -1641132088, -1469993133);
    return 1L;
}

long inst_3_flags_var_7(long param0, long param1, long param2, long param3, long param4, long param5) {
    (unsigned int)v0 = andn(722347940, 1672165873, 871733900);
    return 1L;
}

long inst_3_flags_var_8(long param0, long param1, long param2, long param3, long param4, long param5) {
    (unsigned int)v0 = andn(2109365152, -1142552534, 355803209);
    return 1L;
}

long inst_3_flags_var_9(long param0, long param1, long param2, long param3, long param4, long param5) {
    (unsigned int)v0 = andn(0x426bbabd, -1882458128, -1356767608);
    return 9L;
}

long inst_3_values_var_0(long param0, long param1, long param2, long param3, long param4, long param5) {
    long v0;
    (unsigned int)v1 = andn(1119497129, 0x24cb2905, 209622916);
    return v0 - 137664128L;
}

long inst_3_values_var_1(long param0, long param1, long param2, long param3, long param4, long param5) {
    long v0;
    (unsigned int)v1 = andn(0x66688205, 1758644489, 936021438);
    return v0 - 386401462L;
}

long inst_3_values_var_2(long param0, long param1, long param2, long param3, long param4, long param5) {
    int v0 = andn(645866828, 0x32ccb5c8, 344292836);
    return param2 - 0x4014824L;
}

long inst_3_values_var_3(long param0, long param1, long param2, long param3, long param4, long param5) {
    long v0;
    (unsigned int)v1 = andn(321851031, -451661989, 0x36caa34a);
    return v0 - 0x12ca8000L;
}

long inst_3_values_var_4(long param0, long param1, long param2, long param3, long param4, long param5) {
    long v0;
    (unsigned int)v1 = andn(0x19b606c0, -1195385510, 109652529);
    return v0 - 0x6002221L;
}

long inst_3_values_var_5(long param0, long param1, long param2, long param3, long param4, long param5) {
    long v0;
    (unsigned int)v1 = andn(1128230812, 0xd1db430e, -2120368361);
    return v0 - 0x4bc11L;
}

long inst_3_values_var_6(long param0, long param1, long param2, long param3, long param4, long param5) {
    long v0;
    (unsigned int)v1 = andn(-599285956, 0xc1cb9bc, 1804197292);
    return v0 - 1669415936L;
}

long inst_3_values_var_7(long param0, long param1, long param2, long param3, long param4, long param5) {
    long v0;
    (unsigned int)v1 = andn(-1980967572, 951813969, 0x795e9a9f);
    return v0 - 0x4144188eL;
}

long inst_3_values_var_8(long param0, long param1, long param2, long param3, long param4, long param5) {
    long result;
    (unsigned int)v0 = andn(-1201375725, -653563431, -653563431);
    return result;
}

long inst_3_values_var_9(long param0, long param1, long param2, long param3, long param4, long param5) {
    long v0;
    (unsigned int)v1 = andn(0x206ff433, -1680618160, -199210658);
    return v0 - 0x6420000eL;
}

long inst_40_flags_var_0(long param0, long param1, long param2, long param3, long param4, long param5) {
    (unsigned int)v0 = lzcnt(-279721888, 0x2bd2ac23);
    return 0L;
}

long inst_40_flags_var_1(long param0, long param1, long param2, long param3, long param4, long param5) {
    int v0 = lzcnt(498400948, -1323791276);
    return 0L;
}

long inst_40_flags_var_2(long param0, long param1, long param2, long param3, long param4, long param5) {
    (unsigned int)v0 = lzcnt(0x777395db, -3255257);
    return 0L;
}

long inst_40_flags_var_3(long param0, long param1, long param2, long param3, long param4, long param5) {
    (unsigned int)v0 = lzcnt(0x998dd327, -395445922);
    return 0L;
}

long inst_40_flags_var_4(long param0, long param1, long param2, long param3, long param4, long param5) {
    (unsigned int)v0 = lzcnt(288567634, -1916950612);
    return 0L;
}

long inst_40_flags_var_5(long param0, long param1, long param2, long param3, long param4, long param5) {
    (unsigned int)v0 = lzcnt(-1202551977, -1202551977);
    return 0L;
}

long inst_40_flags_var_6(long param0, long param1, long param2, long param3, long param4, long param5) {
    (unsigned int)v0 = lzcnt(0x1dfac5fc, 0x4866596);
    return 0L;
}

long inst_40_flags_var_7(long param0, long param1, long param2, long param3, long param4, long param5) {
    (unsigned int)v0 = lzcnt(1715446288, 1398193771);
    return 0L;
}

long inst_40_flags_var_8(long param0, long param1, long param2, long param3, long param4, long param5) {
    (unsigned int)v0 = lzcnt(1548848334, 1427040088);
    return 0L;
}

long inst_40_flags_var_9(long param0, long param1, long param2, long param3, long param4, long param5) {
    (unsigned int)v0 = lzcnt(-332159114, 345974580);
    return 0L;
}

long inst_40_values_var_0(long param0, long param1, long param2, long param3, long param4, long param5) {
    (unsigned int)v0 = lzcnt(558987467, -1920131109);
    return param4;
}

long inst_40_values_var_1(long param0, long param1, long param2, long param3, long param4, long param5) {
    long v0;
    (unsigned int)v1 = lzcnt(-1712694752, 0x46477870);
    return v0 - 1L;
}

long inst_40_values_var_2(long param0, long param1, long param2, long param3, long param4, long param5) {
    long result;
    (unsigned int)v0 = lzcnt(1672527628, -511099901);
    return result;
}

long inst_40_values_var_3(long param0, long param1, long param2, long param3, long param4, long param5) {
    (unsigned int)v0 = lzcnt(0xadcd01f1, 1370357273);
    return param3 - 1L;
}

long inst_40_values_var_4(long param0, long param1, long param2, long param3, long param4, long param5) {
    long result;
    int v0 = lzcnt(0x2599a6f7, -1764366576);
    return result;
}

long inst_40_values_var_5(long param0, long param1, long param2, long param3, long param4, long param5) {
    (unsigned int)v0 = lzcnt(1855935991, 714100560);
    return param3 - 2L;
}

long inst_40_values_var_6(long param0, long param1, long param2, long param3, long param4, long param5) {
    (unsigned int)v0 = lzcnt(-1915304002, -2090932574);
    return param4;
}

long inst_40_values_var_7(long param0, long param1, long param2, long param3, long param4, long param5) {
    long v0;
    (unsigned int)v1 = lzcnt(-1646543252, 1917462589);
    return v0 - 1L;
}

long inst_40_values_var_8(long param0, long param1, long param2, long param3, long param4, long param5) {
    (unsigned int)v0 = lzcnt(543116888, -1179275579);
    return param4;
}

long inst_40_values_var_9(long param0, long param1, long param2, long param3, long param4, long param5) {
    (unsigned int)v0 = lzcnt(-106063048, 0xe415abc7);
    return param4;
}

long inst_41_flags_var_0(long param0, long param1, long param2, long param3, long param4, long param5) {
    long v0 = lzcnt(-3823521702923240197L, 1475135778263694845L);
    return 0L;
}

long inst_41_flags_var_1(long param0, long param1, long param2, long param3, long param4, long param5) {
    long v0 = lzcnt(-5268003087354785399L, 4665656518428909466L);
    return 0L;
}

long inst_41_flags_var_2(long param0, long param1, long param2, long param3, long param4, long param5) {
    long v0 = lzcnt(-2828230511869890789L, 2297065381371963981L);
    return 0L;
}

long inst_41_flags_var_3(long param0, long param1, long param2, long param3, long param4, long param5) {
    long v0 = lzcnt(1658956160004479923L, -224307523729879135L);
    return 0L;
}

long inst_41_flags_var_4(long param0, long param1, long param2, long param3, long param4, long param5) {
    long v0 = lzcnt(0xf84ba9aa235af425L, 8944150429020408786L);
    return 0L;
}

long inst_41_flags_var_5(long param0, long param1, long param2, long param3, long param4, long param5) {
    long v0 = lzcnt(-7271413983529874360L, -399966818254433171L);
    return 0L;
}

long inst_41_flags_var_6(long param0, long param1, long param2, long param3, long param4, long param5) {
    long v0 = lzcnt(42680841142010374L, 0xfcfbfeff5f6a1cd8L);
    return 0L;
}

long inst_41_flags_var_7(long param0, long param1, long param2, long param3, long param4, long param5) {
    long v0 = lzcnt(6413205423275453405L, 4025683274740635553L);
    return 0L;
}

long inst_41_flags_var_8(long param0, long param1, long param2, long param3, long param4, long param5) {
    long v0 = lzcnt(-8848055638878838545L, 6860842218355609428L);
    return 0L;
}

long inst_41_flags_var_9(long param0, long param1, long param2, long param3, long param4, long param5) {
    long v0 = lzcnt(-6480873309240931364L, -4285659204925752282L);
    return 0L;
}

long inst_41_values_var_0(long param0, long param1, long param2, long param3, long param4, long param5) {
    long v0;
    long v0 = lzcnt(3103895428776894338L, 4442977343663772878L);
    return v0 - 2L;
}

long inst_41_values_var_1(long param0, long param1, long param2, long param3, long param4, long param5) {
    long v0;
    long v0 = lzcnt(5770678906198416710L, 5717212469739318799L);
    return v0 - 1L;
}

long inst_41_values_var_2(long param0, long param1, long param2, long param3, long param4, long param5) {
    long v0;
    long v0 = lzcnt(-7458040899823448348L, 3639053568635297467L);
    return v0 - 2L;
}

long inst_41_values_var_4(long param0, long param1, long param2, long param3, long param4, long param5) {
    long result;
    long result = lzcnt(0xcafcbad4b771a971L, -2328470488832355066L);
    return result;
}

long inst_41_values_var_5(long param0, long param1, long param2, long param3, long param4, long param5) {
    long v0;
    long v0 = lzcnt(-5135580612585865802L, 1344184944731214541L);
    return v0 - 3L;
}

long inst_41_values_var_6(long param0, long param1, long param2, long param3, long param4, long param5) {
    long v0;
    long v0 = lzcnt(0x115a55e3c37a3997L, 0x2d7ab015ad3deddcL);
    return v0 - 2L;
}

long inst_41_values_var_7(long param0, long param1, long param2, long param3, long param4, long param5) {
    long v0;
    long v0 = lzcnt(0x2d8617c765490c65L, 1048645101288262923L);
    return v0 - 4L;
}

long inst_41_values_var_8(long param0, long param1, long param2, long param3, long param4, long param5) {
    long v0;
    long v0 = lzcnt(-5483457560571655387L, 5951594913062649289L);
    return v0 - 1L;
}

long inst_41_values_var_9(long param0, long param1, long param2, long param3, long param4, long param5) {
    long v0;
    long v0 = lzcnt(8590974544321517739L, 1585458979721253906L);
    return v0 - 3L;
}

long inst_4_flags_var_1(long param0, long param1, long param2, long param3, long param4, long param5) {
    long v0 = andn(0xa54038a33bcb9a9fL, 6717900749053694029L, -9155632432024424141L);
    return 1L;
}

long inst_4_flags_var_2(long param0, long param1, long param2, long param3, long param4, long param5) {
    long v0 = andn(-2111724530906593327L, 0x9bd8a01c0733e124L, 2184031483208998013L);
    return 9L;
}

long inst_4_flags_var_3(long param0, long param1, long param2, long param3, long param4, long param5) {
    long v0 = andn(-6831210195856401059L, -6831210195856401059L, 8735660406160550114L);
    return 1L;
}

long inst_4_flags_var_4(long param0, long param1, long param2, long param3, long param4, long param5) {
    long v0 = andn(965250532524622205L, 4405801165509311825L, -4595786699560252066L);
    return 1L;
}

long inst_4_flags_var_5(long param0, long param1, long param2, long param3, long param4, long param5) {
    long v0 = andn(0xdcbdd336ef576af9L, -8404399364063906495L, 1164992829704558571L);
    return 1L;
}

long inst_4_flags_var_6(long param0, long param1, long param2, long param3, long param4, long param5) {
    long v0 = andn(0x570e56160221e272L, 6764282673216768266L, -3339150284478940509L);
    return -7L;
}

long inst_4_flags_var_7(long param0, long param1, long param2, long param3, long param4, long param5) {
    long v0 = andn(5293578553939871679L, 0xc10f118874efb50L, 6271403116327111981L);
    return 1L;
}

long inst_4_flags_var_8(long param0, long param1, long param2, long param3, long param4, long param5) {
    long v0 = andn(-4302037086490085034L, 0xb5a25a093b00190cL, -4307111467924589611L);
    return 1L;
}

long inst_4_flags_var_9(long param0, long param1, long param2, long param3, long param4, long param5) {
    long v0 = andn(2667250958508043227L, -8736901713298789476L, -7744271878451442217L);
    return 9L;
}

long inst_4_values_var_0(long param0, long param1, long param2, long param3, long param4, long param5) {
    long result;
    long result = andn(6259522455211627837L, 6259522455211627837L, 6259522455211627837L);
    return result;
}

long inst_4_values_var_2(long param0, long param1, long param2, long param3, long param4, long param5) {
    long result;
    long result = andn(-6745119972650407978L, -5237229432907156405L, -5237229432907156405L);
    return result;
}

long inst_4_values_var_3(long param0, long param1, long param2, long param3, long param4, long param5) {
    long v0;
    long v0 = andn(-5248077908884681781L, 8433558487185831409L, -4650996843982988450L);
    return v0 + 0x758bacfedd31b5f2L;
}

long inst_4_values_var_4(long param0, long param1, long param2, long param3, long param4, long param5) {
    long v0;
    long v0 = andn(749009651391257759L, 749009651391257759L, 8689990994025643042L);
    return v0 - 8113244075634466848L;
}

long inst_4_values_var_5(long param0, long param1, long param2, long param3, long param4, long param5) {
    long v0;
    long v0 = andn(-3213658323035489555L, 4198824947250440056L, -3213658323035489555L);
    return v0 + 0x3edd3d3fdeeb277bL;
}

long inst_4_values_var_6(long param0, long param1, long param2, long param3, long param4, long param5) {
    long v0;
    long v0 = andn(3349898178776422812L, 0x19d9274be00877cdL, -4513080655016023617L);
    return v0 + 4609909190002669518L;
}

long inst_4_values_var_7(long param0, long param1, long param2, long param3, long param4, long param5) {
    long v0;
    long v0 = andn(-1136937286668769415L, 0x87d9eed7c4f3fb15L, -6564880742594403855L);
    return v0 - 0x20241128300800e0L;
}

long inst_4_values_var_8(long param0, long param1, long param2, long param3, long param4, long param5) {
    long v0;
    long v0 = andn(0xdbf4ad765f811076L, -8360533589548747423L, 131602025094864793L);
    return v0 - 704787783895704L;
}

long inst_4_values_var_9(long param0, long param1, long param2, long param3, long param4, long param5) {
    long v0;
    long v0 = andn(6980052737493773128L, -1033002954611425379L, 3113573847085822736L);
    return v0 - 0xa15a2a2c10b0000L;
}

long inst_5_flags_var_0(long param0, long param1, long param2, long param3, long param4, long param5) {
    (unsigned int)v0 = blsi(-616929230, 0xd6866a44);
    return 0L;
}

long inst_5_flags_var_1(long param0, long param1, long param2, long param3, long param4, long param5) {
    (unsigned int)v0 = blsi(1192633961, 1919047713);
    return 0L;
}

long inst_5_flags_var_2(long param0, long param1, long param2, long param3, long param4, long param5) {
    (unsigned int)v0 = blsi(775809936, 779783194);
    return 8L;
}

long inst_5_flags_var_3(long param0, long param1, long param2, long param3, long param4, long param5) {
    (unsigned int)v0 = blsi(1871139282, -1364307878);
    return 8L;
}

long inst_5_flags_var_4(long param0, long param1, long param2, long param3, long param4, long param5) {
    (unsigned int)v0 = blsi(0xa3a73005, -947108566);
    return 8L;
}

long inst_5_flags_var_5(long param0, long param1, long param2, long param3, long param4, long param5) {
    (unsigned int)v0 = blsi(0xe9faaa52, 1853335845);
    return 8L;
}

long inst_5_flags_var_6(long param0, long param1, long param2, long param3, long param4, long param5) {
    (unsigned int)v0 = blsi(0x47654b46, 0x47654b46);
    return 8L;
}

long inst_5_flags_var_7(long param0, long param1, long param2, long param3, long param4, long param5) {
    (unsigned int)v0 = blsi(-1107775344, 0x329966b6);
    return 0L;
}

long inst_5_flags_var_8(long param0, long param1, long param2, long param3, long param4, long param5) {
    (unsigned int)v0 = blsi(0xdd11ffe1, -222713289);
    return 8L;
}

long inst_5_flags_var_9(long param0, long param1, long param2, long param3, long param4, long param5) {
    (unsigned int)v0 = blsi(527488710, -1992838797);
    return 0L;
}

long inst_5_values_var_0(long param0, long param1, long param2, long param3, long param4, long param5) {
    (unsigned int)v0 = blsi(1244070803, 1244070803);
    return param1 - 1L;
}

long inst_5_values_var_1(long param0, long param1, long param2, long param3, long param4, long param5) {
    long v0;
    (unsigned int)v1 = blsi(-476992331, -2108479805);
    return v0 - 1L;
}

long inst_5_values_var_3(long param0, long param1, long param2, long param3, long param4, long param5) {
    long v0;
    (unsigned int)v1 = blsi(-1222696207, 1551740008);
    return v0 - 8L;
}

long inst_5_values_var_4(long param0, long param1, long param2, long param3, long param4, long param5) {
    long v0;
    (unsigned int)v1 = blsi(0xc2294d87, 579265533);
    return v0 - 1L;
}

long inst_5_values_var_5(long param0, long param1, long param2, long param3, long param4, long param5) {
    (unsigned int)v0 = blsi(-1674750078, 0xfbcc675a);
    return param1 - 2L;
}

long inst_5_values_var_6(long param0, long param1, long param2, long param3, long param4, long param5) {
    long v0;
    int v1 = blsi(0xbe85e7be, -554086770);
    return v0 - 2L;
}

long inst_5_values_var_7(long param0, long param1, long param2, long param3, long param4, long param5) {
    long v0;
    int v1 = blsi(-1274849369, -1955519452);
    return v0 - 4L;
}

long inst_5_values_var_9(long param0, long param1, long param2, long param3, long param4, long param5) {
    (unsigned int)v0 = blsi(799810935, -50935679);
    return param3 - 1L;
}

long inst_6_flags_var_0(long param0, long param1, long param2, long param3, long param4, long param5) {
    long v0 = blsi(-7760085784007888497L, 4042478884274562012L);
    return 8L;
}

long inst_6_flags_var_1(long param0, long param1, long param2, long param3, long param4, long param5) {
    long v0 = blsi(0x6aba3991f1108858L, 1567709892670421312L);
    return 8L;
}

long inst_6_flags_var_2(long param0, long param1, long param2, long param3, long param4, long param5) {
    long v0 = blsi(-6179378487993509893L, -6867288943319852168L);
    return 8L;
}

long inst_6_flags_var_3(long param0, long param1, long param2, long param3, long param4, long param5) {
    long v0 = blsi(-5384220849702820817L, -5384220849702820817L);
    return 0L;
}

long inst_6_flags_var_4(long param0, long param1, long param2, long param3, long param4, long param5) {
    long v0 = blsi(5599731327065147346L, 4224929629007100674L);
    return 8L;
}

long inst_6_flags_var_5(long param0, long param1, long param2, long param3, long param4, long param5) {
    long v0 = blsi(7749333223352343729L, 8629038787506140322L);
    return 0L;
}

long inst_6_flags_var_6(long param0, long param1, long param2, long param3, long param4, long param5) {
    long v0 = blsi(9143819210053178111L, -2211880619541732236L);
    return 8L;
}

long inst_6_flags_var_7(long param0, long param1, long param2, long param3, long param4, long param5) {
    long v0 = blsi(-4575609119605066203L, 0xbad6652454d400a8L);
    return 0L;
}

long inst_6_flags_var_8(long param0, long param1, long param2, long param3, long param4, long param5) {
    long v0 = blsi(2657063213569940122L, -435177715467660148L);
    return 8L;
}

long inst_6_flags_var_9(long param0, long param1, long param2, long param3, long param4, long param5) {
    long v0 = blsi(-6028260925226555637L, 4669276021531913776L);
    return 8L;
}

long inst_6_values_var_0(long param0, long param1, long param2, long param3, long param4, long param5) {
    long v0;
    long v0 = blsi(0xb6d9856888c3d4efL, -1102451491384141839L);
    return v0 - 1L;
}

long inst_6_values_var_1(long param0, long param1, long param2, long param3, long param4, long param5) {
    long v0;
    long v0 = blsi(0xccccfe7079e79b76L, -3035814107009417132L);
    return v0 - 4L;
}

long inst_6_values_var_2(long param0, long param1, long param2, long param3, long param4, long param5) {
    long v0;
    long v0 = blsi(-3330428809008375324L, -7227582080839374889L);
    return v0 - 1L;
}

long inst_6_values_var_3(long param0, long param1, long param2, long param3, long param4, long param5) {
    long v0;
    long v0 = blsi(3333842202274275976L, 0xc7ab58faa2d7ccbaL);
    return v0 - 2L;
}

long inst_6_values_var_4(long param0, long param1, long param2, long param3, long param4, long param5) {
    long v0;
    long v0 = blsi(2248526360876644874L, 1777888739096796077L);
    return v0 - 1L;
}

long inst_6_values_var_5(long param0, long param1, long param2, long param3, long param4, long param5) {
    long v0;
    long v0 = blsi(0x364139aeeeb9a22cL, 9042020100193214394L);
    return v0 - 2L;
}

long inst_6_values_var_6(long param0, long param1, long param2, long param3, long param4, long param5) {
    long v0;
    long v0 = blsi(8188661680934880179L, 1620600209612493191L);
    return v0 - 1L;
}

long inst_6_values_var_7(long param0, long param1, long param2, long param3, long param4, long param5) {
    long v0;
    long v0 = blsi(-3673140101528393413L, -1664952163412100040L);
    return v0 - 8L;
}

long inst_6_values_var_8(long param0, long param1, long param2, long param3, long param4, long param5) {
    long v0;
    long v0 = blsi(0x49fb6549d5418202L, 3675896098631421943L);
    return v0 - 1L;
}

long inst_6_values_var_9(long param0, long param1, long param2, long param3, long param4, long param5) {
    long v0;
    long v0 = blsi(-4654658469033839768L, 8160801419442419792L);
    return v0 - 16L;
}

long inst_7_flags_var_0(long param0, long param1, long param2, long param3, long param4, long param5) {
    (unsigned int)v0 = blsmsk(-471193830, 0x20cc03ef);
    return 9L;
}

long inst_7_flags_var_1(long param0, long param1, long param2, long param3, long param4, long param5) {
    (unsigned int)v0 = blsmsk(636158820, -2115861458);
    return 9L;
}

long inst_7_flags_var_2(long param0, long param1, long param2, long param3, long param4, long param5) {
    (unsigned int)v0 = blsmsk(-1787429259, -1795670757);
    return 9L;
}

long inst_7_flags_var_4(long param0, long param1, long param2, long param3, long param4, long param5) {
    (unsigned int)v0 = blsmsk(0x234c2324, 0x6dcc3426);
    return 9L;
}

long inst_7_flags_var_5(long param0, long param1, long param2, long param3, long param4, long param5) {
    (unsigned int)v0 = blsmsk(0x33526b42, -1653199731);
    return 1L;
}

long inst_7_flags_var_6(long param0, long param1, long param2, long param3, long param4, long param5) {
    (unsigned int)v0 = blsmsk(1190916519, 1190916519);
    return 1L;
}

long inst_7_flags_var_7(long param0, long param1, long param2, long param3, long param4, long param5) {
    (unsigned int)v0 = blsmsk(1023773447, -213439602);
    return 9L;
}

long inst_7_flags_var_8(long param0, long param1, long param2, long param3, long param4, long param5) {
    (unsigned int)v0 = blsmsk(-1970539977, 0x8dd88775);
    return 9L;
}

long inst_7_flags_var_9(long param0, long param1, long param2, long param3, long param4, long param5) {
    (unsigned int)v0 = blsmsk(-976186898, 209431935);
    return 9L;
}

long inst_7_values_var_0(long param0, long param1, long param2, long param3, long param4, long param5) {
    long v0;
    (unsigned int)v1 = blsmsk(-1863105971, 0xfe275458);
    return v0 - 15L;
}

long inst_7_values_var_1(long param0, long param1, long param2, long param3, long param4, long param5) {
    long v0;
    (unsigned int)v1 = blsmsk(-1938490416, -1709713049);
    return v0 - 1L;
}

long inst_7_values_var_2(long param0, long param1, long param2, long param3, long param4, long param5) {
    (unsigned int)v0 = blsmsk(-816779631, 0xba975f65);
    return param5 - 1L;
}

long inst_7_values_var_3(long param0, long param1, long param2, long param3, long param4, long param5) {
    long v0;
    (unsigned int)v1 = blsmsk(0x99c9ee3a, 2142569564);
    return v0 - 7L;
}

long inst_7_values_var_4(long param0, long param1, long param2, long param3, long param4, long param5) {
    long v0;
    (unsigned int)v1 = blsmsk(-1235959499, -71072645);
    return v0 - 1L;
}

long inst_7_values_var_5(long param0, long param1, long param2, long param3, long param4, long param5) {
    (unsigned int)v0 = blsmsk(2038471474, -916209713);
    return param5 - 1L;
}

long inst_7_values_var_6(long param0, long param1, long param2, long param3, long param4, long param5) {
    long v0;
    (unsigned int)v1 = blsmsk(194102171, -919863177);
    return v0 - 1L;
}

long inst_7_values_var_7(long param0, long param1, long param2, long param3, long param4, long param5) {
    long v0;
    (unsigned int)v1 = blsmsk(1652799316, -1369664848);
    return v0 - 31L;
}

long inst_7_values_var_8(long param0, long param1, long param2, long param3, long param4, long param5) {
    int v0 = blsmsk(277640702, -2549927);
    return param2 - 1L;
}

long inst_7_values_var_9(long param0, long param1, long param2, long param3, long param4, long param5) {
    long v0;
    int v1 = blsmsk(-1995314833, -1250602789);
    return v0 - 1L;
}

long inst_8_flags_var_1(long param0, long param1, long param2, long param3, long param4, long param5) {
    long v0 = blsmsk(5933856786988800988L, -3325465929089690505L);
    return 9L;
}

long inst_8_flags_var_2(long param0, long param1, long param2, long param3, long param4, long param5) {
    long v0 = blsmsk(-3236817146850209621L, -341474840972236433L);
    return 1L;
}

long inst_8_flags_var_3(long param0, long param1, long param2, long param3, long param4, long param5) {
    long v0 = blsmsk(-547101206793762463L, 585285935291812645L);
    return 1L;
}

long inst_8_flags_var_5(long param0, long param1, long param2, long param3, long param4, long param5) {
    long v0 = blsmsk(4668809141138144184L, 110107016724756664L);
    return 9L;
}

long inst_8_flags_var_6(long param0, long param1, long param2, long param3, long param4, long param5) {
    long v0 = blsmsk(0xcb1ed745abbcd794L, -4777741816071995963L);
    return 9L;
}

long inst_8_flags_var_7(long param0, long param1, long param2, long param3, long param4, long param5) {
    long v0 = blsmsk(4982933077355581391L, 4532959978587640907L);
    return 9L;
}

long inst_8_flags_var_8(long param0, long param1, long param2, long param3, long param4, long param5) {
    long v0 = blsmsk(7507528126659323462L, 2502962372463498316L);
    return 1L;
}

long inst_8_flags_var_9(long param0, long param1, long param2, long param3, long param4, long param5) {
    long v0 = blsmsk(6530660785966381415L, 0x535cc2e9744e2ffeL);
    return 9L;
}

long inst_8_values_var_0(long param0, long param1, long param2, long param3, long param4, long param5) {
    long v0;
    long v0 = blsmsk(642331322068434371L, 2500695202928761776L);
    return v0 - 31L;
}

long inst_8_values_var_1(long param0, long param1, long param2, long param3, long param4, long param5) {
    long v0;
    long v0 = blsmsk(0x2725aa0b3dedbaa7L, 6481953992550659361L);
    return v0 - 1L;
}

long inst_8_values_var_2(long param0, long param1, long param2, long param3, long param4, long param5) {
    long v0;
    long v0 = blsmsk(-6629689259696832449L, -5325700304424091430L);
    return v0 - 3L;
}

long inst_8_values_var_3(long param0, long param1, long param2, long param3, long param4, long param5) {
    long v0;
    long v0 = blsmsk(-6065921845462454356L, 8340462320602403157L);
    return v0 - 1L;
}

long inst_8_values_var_4(long param0, long param1, long param2, long param3, long param4, long param5) {
    long v0;
    long v0 = blsmsk(-7620081116652110773L, 0xd5a0afb3fccbf609L);
    return v0 - 1L;
}

long inst_8_values_var_5(long param0, long param1, long param2, long param3, long param4, long param5) {
    long v0;
    long v0 = blsmsk(7765157225680021940L, 5695857873675213053L);
    return v0 - 1L;
}

long inst_8_values_var_6(long param0, long param1, long param2, long param3, long param4, long param5) {
    long v0;
    long v0 = blsmsk(-3004708049202281480L, 545374945776117954L);
    return v0 - 3L;
}

long inst_8_values_var_7(long param0, long param1, long param2, long param3, long param4, long param5) {
    long v0;
    long v0 = blsmsk(-1930802197591016483L, 628640198884519296L);
    return v0 - 0xffL;
}

long inst_8_values_var_8(long param0, long param1, long param2, long param3, long param4, long param5) {
    long v0;
    long v0 = blsmsk(-7605437321113738888L, 4528067559124964124L);
    return v0 - 7L;
}

long inst_8_values_var_9(long param0, long param1, long param2, long param3, long param4, long param5) {
    long v0;
    long v0 = blsmsk(-7113935113177220303L, -9041811895297268598L);
    return v0 - 3L;
}

long inst_9_flags_var_0(long param0, long param1, long param2, long param3, long param4, long param5) {
    (unsigned int)v0 = blsr(-1786348555, 0xc5e18546);
    return 1L;
}

long inst_9_flags_var_1(long param0, long param1, long param2, long param3, long param4, long param5) {
    (unsigned int)v0 = blsr(-469395937, -1828923085);
    return 1L;
}

long inst_9_flags_var_2(long param0, long param1, long param2, long param3, long param4, long param5) {
    (unsigned int)v0 = blsr(-1114478730, -939184670);
    return -7L;
}

long inst_9_flags_var_3(long param0, long param1, long param2, long param3, long param4, long param5) {
    (unsigned int)v0 = blsr(-539808039, -1105921887);
    return -7L;
}

long inst_9_flags_var_4(long param0, long param1, long param2, long param3, long param4, long param5) {
    int v0 = blsr(621196137, 1506721556);
    return 1L;
}

long inst_9_flags_var_5(long param0, long param1, long param2, long param3, long param4, long param5) {
    (unsigned int)v0 = blsr(-1151787601, 159408430);
    return 1L;
}

long inst_9_flags_var_7(long param0, long param1, long param2, long param3, long param4, long param5) {
    int v0 = blsr(0x8685fa6b, 1631974359);
    return 1L;
}

long inst_9_flags_var_8(long param0, long param1, long param2, long param3, long param4, long param5) {
    (unsigned int)v0 = blsr(1596159542, 0x59949b74);
    return 9L;
}

long inst_9_flags_var_9(long param0, long param1, long param2, long param3, long param4, long param5) {
    (unsigned int)v0 = blsr(1016690872, 0x6848551b);
    return 9L;
}

long inst_9_values_var_0(long param0, long param1, long param2, long param3, long param4, long param5) {
    (unsigned int)v0 = blsr(-849083661, -1728690390);
    return param1 - 2566276904L;
}

long inst_9_values_var_1(long param0, long param1, long param2, long param3, long param4, long param5) {
    long v0;
    (unsigned int)v1 = blsr(1056770739, 2037780452);
    return v0 - 2037780448L;
}

long inst_9_values_var_2(long param0, long param1, long param2, long param3, long param4, long param5) {
    long v0;
    (unsigned int)v1 = blsr(0x1877ec29, 1848316874);
    return v0 - 1848316872L;
}

long inst_9_values_var_3(long param0, long param1, long param2, long param3, long param4, long param5) {
    long v0;
    (unsigned int)v1 = blsr(-1276783259, 843361959);
    return v0 - 843361958L;
}

long inst_9_values_var_4(long param0, long param1, long param2, long param3, long param4, long param5) {
    long v0;
    (unsigned int)v1 = blsr(0x58f3a9a0, 0x237c3e3);
    return v0 - 0x237c3e2L;
}

long inst_9_values_var_5(long param0, long param1, long param2, long param3, long param4, long param5) {
    long v0;
    (unsigned int)v1 = blsr(-6751662, -6751662);
    return v0 - 4288215632L;
}

long inst_9_values_var_6(long param0, long param1, long param2, long param3, long param4, long param5) {
    (unsigned int)v0 = blsr(-979942132, 0xb03bdcb);
    return param3 - 184794570L;
}

long inst_9_values_var_7(long param0, long param1, long param2, long param3, long param4, long param5) {
    long v0;
    (unsigned int)v1 = blsr(-1443546552, -1568523502);
    return v0 - 2726443792L;
}

long inst_9_values_var_8(long param0, long param1, long param2, long param3, long param4, long param5) {
    long v0;
    (unsigned int)v1 = blsr(864617997, 864617997);
    return v0 - 864617996L;
}

long inst_9_values_var_9(long param0, long param1, long param2, long param3, long param4, long param5) {
    (unsigned int)v0 = blsr(-1677836857, -693307422);
    return param5 - 3601659872L;
}

void main() {
    // Decompilation error
}

long register_tm_clones() {
    return 0L;
}

void r→__assert_fail(char* __assertion, char* __file, unsigned int __line, char* __function) {
    jump gvar_43A010;
}

void →__assert_fail(char* __assertion, char* __file, unsigned int __line, char* __function) {
    ptr___assert_fail[0]{r→__assert_fail}(__assertion, __file, (unsigned int)__line, __function);
}
