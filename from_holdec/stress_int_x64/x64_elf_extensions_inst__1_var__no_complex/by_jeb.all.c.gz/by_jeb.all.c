
void __libc_csu_fini() {
}

void* __libc_csu_init(long param0, long param1) {
    void* result;
    initializer_0();
    long v0 = 0L;
    do {
        result = (void*)*(long*)(v0 * 8L + (long)&__frame_dummy_init_array_entry){initializer_1}();
        ++v0;
    }
    while(v0 != 1L);
    return result;
}

void _dl_relocate_static_pie() {
}

long _start(long param0, long param1) {
    long v0;
    long v1;
    long v2;
    char v3;
    __libc_start_main(&main, v0, (long)&v3, &__libc_csu_init, &__libc_csu_fini, param1, (long)&v1, v2);
    hlt();
}

// Stale decompilation - Refresh this view to re-decompile this code
long deregister_tm_clones() {
    return &__TMC_END__;
}

void finalizer_0() {
}

void finalizer_1() {
    if(!completed.7287) {
        deregister_tm_clones();
        completed.7287 = 1;
    }
}

void* initializer_0() {
    void* result = __gmon_start__;
    if(result) {
        result = (void*)result();
    }
    return result;
}

long initializer_1() {
    return register_tm_clones();
}

long inst_0_flags_var_0(long param0, long param1, long param2, long param3, long param4, long param5) {
    for(short i = 0; !((31813 >>> i) & 0x1); ++i) {
    }
    return 1L;
}

long inst_0_values_var_0(long param0, long param1, long param2, long param3, long param4, long param5) {
    short i;
    for(i = 0; !((0x1381 >>> i) & 0x1); ++i) {
    }
    return ((unsigned long)i | ((unsigned long)100016906640040L << 16)) - 0x5af700311aa80000L;
}

long inst_10_flags_var_0(long param0, long param1, long param2, long param3, long param4, long param5) {
    long v0 = blsr(7172692094879525845L, -6466120530076208412L);
    return 1L;
}

long inst_10_values_var_0(long param0, long param1, long param2, long param3, long param4, long param5) {
    long v0;
    long v0 = blsr(7300490597898960903L, 0xeace88da232210d5L);
    return v0 + 0x15317725dcddef2cL;
}

long inst_11_flags_var_0(long param0, long param1, long param2, long param3, long param4, long param5) {
    (unsigned int)v0 = bextr(0xd1e0b5bc, -1479606858, 1560881643);
    return 1L;
}

long inst_11_values_var_0(long param0, long param1, long param2, long param3, long param4, long param5) {
    (unsigned int)v0 = bextr(0xbabbce0e, -1450387663, -89947517);
    return param0;
}

long inst_12_flags_var_0(long param0, long param1, long param2, long param3, long param4, long param5) {
    long v0 = bextr(5676642126196483379L, -5521840073420482171L, -25773223198299207L);
    return 1L;
}

long inst_12_values_var_0(long param0, long param1, long param2, long param3, long param4, long param5) {
    long result;
    long result = bextr(3810899245023706227L, -8172127744841274311L, 1210889859216969098L);
    return result;
}

long inst_13_flags_var_0(long param0, long param1, long param2, long param3, long param4, long param5) {
    (unsigned int)v0 = bzhi(-665728377, 352234176, -1069695905);
    return 0L;
}

long inst_13_values_var_0(long param0, long param1, long param2, long param3, long param4, long param5) {
    (unsigned int)v0 = bzhi(0x6df6ba96, -965634780, -1631417467);
    return param4 - 3329332516L;
}

long inst_14_flags_var_0(long param0, long param1, long param2, long param3, long param4, long param5) {
    long v0 = bzhi(0x748923bc801abbaeL, -1224378468239156921L, -7667595504615575818L);
    return -8L;
}

long inst_14_values_var_0(long param0, long param1, long param2, long param3, long param4, long param5) {
    long v0;
    long v0 = bzhi(856913598611446106L, 5238585455148855825L, 0x280eeff9c0cab290L);
    return v0 - 5238585455148855825L;
}

long inst_15_flags_var_0(long param0, long param1, long param2, long param3, long param4, long param5) {
    (unsigned int)v0 = mulx(1581477502, 0x43a8a18a, 0x6786b014, -480230665);
    return 0L;
}

long inst_15_values_var_0(long param0, long param1, long param2, long param3, long param4, long param5) {
    (unsigned int)v0 = mulx(1675395533, -212709077, 1650137760, 0x8d224a4e);
    return param0 + 6100583404676618780L;
}

long inst_16_flags_var_0(long param0, long param1, long param2, long param3, long param4, long param5) {
    long v0 = mulx(-4134326097991732123L, -6003205469697889223L, -4307868293220861095L, 4497058590684198564L);
    return 0L;
}

long inst_16_values_var_0(long param0, long param1, long param2, long param3, long param4, long param5) {
    long v0;
    long v0 = mulx(9043568277826969265L, -4346500026072770159L, 6556702819765705747L, -2723357884104904694L);
    return v0 + 5526512507471308053L;
}

long inst_17_flags_var_0(long param0, long param1, long param2, long param3, long param4, long param5) {
    (unsigned int)v0 = pdep(-1971126855, 0x9595bc42, 1427246226);
    return 0L;
}

long inst_17_values_var_0(long param0, long param1, long param2, long param3, long param4, long param5) {
    long v0;
    (unsigned int)v1 = pdep(1665893877, -1992891564, 0x8225828);
    return v0 - 2115584L;
}

long inst_18_flags_var_0(long param0, long param1, long param2, long param3, long param4, long param5) {
    long v0 = pdep(-5241759867383739375L, 0x450437897833fc15L, 1834563382777405374L);
    return 0L;
}

long inst_18_values_var_0(long param0, long param1, long param2, long param3, long param4, long param5) {
    long v0;
    long v0 = pdep(0xc5c82aea853ede71L, -1166322700620947828L, 4622161162189748655L);
    return v0 - 0x251000068d280cL;
}

long inst_19_flags_var_0(long param0, long param1, long param2, long param3, long param4, long param5) {
    int v0 = pext(-175952537, -175952537, 2126854747);
    return 0L;
}

long inst_19_values_var_0(long param0, long param1, long param2, long param3, long param4, long param5) {
    long v0;
    (unsigned int)v1 = pext(-514196809, -940118146, 478042916);
    return v0 - 0x3ddfL;
}

long inst_1_flags_var_0(long param0, long param1, long param2, long param3, long param4, long param5) {
    (unsigned int)v0 = tzcnt(-2003766222, -2070216649);
    return 1L;
}

long inst_1_values_var_0(long param0, long param1, long param2, long param3, long param4, long param5) {
    (unsigned int)v0 = tzcnt(-229923680, 167755401);
    return param5;
}

long inst_20_flags_var_0(long param0, long param1, long param2, long param3, long param4, long param5) {
    long v0 = pext(4703504620528936883L, 7896754100362288110L, 4703504620528936883L);
    return 0L;
}

long inst_20_values_var_0(long param0, long param1, long param2, long param3, long param4, long param5) {
    long v0;
    long v0 = pext(-7263689557637026591L, 2856120984033545071L, 5077184082415587923L);
    return v0 - 220144219L;
}

long inst_21_flags_var_0(long param0, long param1, long param2, long param3, long param4, long param5) {
    (unsigned int)v0 = rorx(74402734, 0xc944012e, 207);
    return 0L;
}

long inst_21_values_var_0(long param0, long param1, long param2, long param3, long param4, long param5) {
    long v0;
    int v1 = rorx(2062247084, 1014434738, 74);
    return v0 - 3968802242L;
}

long inst_22_flags_var_0(long param0, long param1, long param2, long param3, long param4, long param5) {
    long v0 = rorx(0x9b7434385a593f05L, -8154824121149182200L, 247);
    return 0L;
}

long inst_22_values_var_0(long param0, long param1, long param2, long param3, long param4, long param5) {
    long v0;
    long v0 = rorx(6907233127397032718L, 317413137324962340L, 113);
    return v0 + 0x2937775a06edfdcdL;
}

long inst_23_flags_var_0(long param0, long param1, long param2, long param3, long param4, long param5) {
    (unsigned int)v0 = sarx(1788976009, 974413938, 2014857664);
    return 0L;
}

long inst_23_values_var_0(long param0, long param1, long param2, long param3, long param4, long param5) {
    long v0;
    (unsigned int)v1 = sarx(-954538734, -1313810261, 1828851212);
    return v0 - 0xfffb1b0dL;
}

long inst_24_flags_var_0(long param0, long param1, long param2, long param3, long param4, long param5) {
    long v0 = sarx(-2851225106881470599L, 2419490408684805712L, -9745804569585319L);
    return 0L;
}

long inst_24_values_var_0(long param0, long param1, long param2, long param3, long param4, long param5) {
    long v0;
    long v0 = sarx(7787215185740149443L, -1320227379160198733L, 5431029638131324206L);
    return v0 + 18762L;
}

long inst_25_flags_var_0(long param0, long param1, long param2, long param3, long param4, long param5) {
    (unsigned int)v0 = shlx(-1328118960, -374122533, -623710075);
    return 0L;
}

long inst_25_values_var_0(long param0, long param1, long param2, long param3, long param4, long param5) {
    (unsigned int)v0 = shlx(1890902751, -1725303626, -1725303626);
    return param0 - 0x2d800000L;
}

long inst_26_flags_var_0(long param0, long param1, long param2, long param3, long param4, long param5) {
    long v0 = shlx(8705216305350716414L, 5297523544098838851L, -7029397181050977391L);
    return 0L;
}

long inst_26_values_var_0(long param0, long param1, long param2, long param3, long param4, long param5) {
    long v0;
    long v0 = shlx(979551406635276156L, 2760748735360716793L, 3167837634228497849L);
    return v0 + 0xe00000000000000L;
}

long inst_27_flags_var_0(long param0, long param1, long param2, long param3, long param4, long param5) {
    (unsigned int)v0 = shrx(1757777705, -1837437245, 227949272);
    return 0L;
}

long inst_27_values_var_0(long param0, long param1, long param2, long param3, long param4, long param5) {
    (unsigned int)v0 = shrx(0x1ae0819f, 0x1ae0819f, 1811290242);
    return param0 - 112730215L;
}

long inst_28_flags_var_0(long param0, long param1, long param2, long param3, long param4, long param5) {
    long v0 = shrx(8141442119769674129L, 0x8b1f928319d2ff3eL, 4499868075876245114L);
    return 0L;
}

long inst_28_values_var_0(long param0, long param1, long param2, long param3, long param4, long param5) {
    long v0;
    long v0 = shrx(0xe89127449bbbf529L, 0x2dacc80866774071L, 0xe89127449bbbf529L);
    return v0 - 1496676L;
}

long inst_29_flags_var_0(long param0, long param1, long param2, long param3, long param4, long param5) {
    (unsigned int)v0 = adox(1462789309, 0x337875f);
    return 0L;
}

long inst_29_values_var_0(long param0, long param1, long param2, long param3, long param4, long param5) {
    long v0;
    (unsigned int)v1 = adox(1501179794, 2132981877);
    return v0 - 3634161671L;
}

long inst_2_flags_var_0(long param0, long param1, long param2, long param3, long param4, long param5) {
    long v0 = tzcnt(0xc43b841d0b3454ccL, -5516321153366431621L);
    return 1L;
}

long inst_2_values_var_0(long param0, long param1, long param2, long param3, long param4, long param5) {
    long result;
    long result = tzcnt(3434006439498708527L, 2046868747581727999L);
    return result;
}

long inst_30_flags_var_0(long param0, long param1, long param2, long param3, long param4, long param5) {
    long v0 = adox(-7979740788994210370L, -7979740788994210370L);
    return -2L;
}

long inst_30_values_var_0(long param0, long param1, long param2, long param3, long param4, long param5) {
    long v0;
    long v0 = adox(-8540209264635164419L, -5401955713585627611L);
    return v0 - 4504579095488759586L;
}

long inst_31_flags_var_0(long param0, long param1, long param2, long param3, long param4, long param5) {
    (unsigned int)v0 = adcx(0x39a9e33f, 0x83310089);
    return 1L;
}

long inst_31_values_var_0(long param0, long param1, long param2, long param3, long param4, long param5) {
    long v0;
    (unsigned int)v1 = adcx(-1619385100, -934403311);
    return v0 - 1741178886L;
}

long inst_32_flags_var_0(long param0, long param1, long param2, long param3, long param4, long param5) {
    long v0 = adcx(4939976837417212309L, 7479651943682500978L);
    return 1L;
}

long inst_32_values_var_0(long param0, long param1, long param2, long param3, long param4, long param5) {
    long v0;
    long v0 = adcx(1119762303456978703L, 0x4b0a39603fef23d2L);
    return v0 - 6526959691620960994L;
}

long inst_33_flags_var_0(long param0, long param1, long param2, long param3, long param4, long param5) {
    (unsigned int)v0 = crc32(0x92e9fa80, 92);
    return 0L;
}

long inst_33_values_var_0(long param0, long param1, long param2, long param3, long param4, long param5) {
    (unsigned int)v0 = crc32(199407313, 203);
    return param3 - 2075594209L;
}

long inst_34_flags_var_0(long param0, long param1, long param2, long param3, long param4, long param5) {
    (unsigned int)v0 = crc32(-1505531621, 68);
    return 0L;
}

long inst_34_values_var_0(long param0, long param1, long param2, long param3, long param4, long param5) {
    (unsigned int)v0 = crc32(934842348, 54);
    return param4 - 0xb806711cL;
}

long inst_35_flags_var_0(long param0, long param1, long param2, long param3, long param4, long param5) {
    int v0 = crc32(0x13fa3f2f, 0x92f9);
    return 0L;
}

long inst_35_values_var_0(long param0, long param1, long param2, long param3, long param4, long param5) {
    long v0;
    (unsigned int)v1 = crc32(0x4a88678f, 18738);
    return v0 - 4151617816L;
}

long inst_36_flags_var_0(long param0, long param1, long param2, long param3, long param4, long param5) {
    (unsigned int)v0 = crc32(-76624534, 0x8516674);
    return 0L;
}

long inst_36_values_var_0(long param0, long param1, long param2, long param3, long param4, long param5) {
    long v0;
    (unsigned int)v1 = crc32(558899402, 1990169027);
    return v0 - 0xf2c322c5L;
}

long inst_37_flags_var_0(long param0, long param1, long param2, long param3, long param4, long param5) {
    (unsigned int)v0 = crc32(-278969966, 146);
    return 0L;
}

long inst_37_values_var_0(long param0, long param1, long param2, long param3, long param4, long param5) {
    (unsigned int)v0 = crc32(580811098, 239);
    return param4 - 2277963948L;
}

long inst_38_flags_var_0(long param0, long param1, long param2, long param3, long param4, long param5) {
    (unsigned int)v0 = crc32(-1173608981, -1344226680769175815L);
    return 0L;
}

long inst_38_values_var_0(long param0, long param1, long param2, long param3, long param4, long param5) {
    long v0;
    int v1 = crc32(0xfd1893ea, -5770895646794585377L);
    return v0 - 1029212094L;
}

long inst_39_flags_var_0(long param0, long param1, long param2, long param3, long param4, long param5) {
    for(short i = 15; !(24091 >>> i); --i) {
    }
    return 0L;
}

long inst_39_values_var_0(long param0, long param1, long param2, long param3, long param4, long param5) {
    short i;
    for(i = 15; !(41125 >>> i); --i) {
    }
    return ((unsigned long)i | ((unsigned long)253845721270176L << 16)) + 0x1920eff4b8600000L;
}

long inst_3_flags_var_0(long param0, long param1, long param2, long param3, long param4, long param5) {
    (unsigned int)v0 = andn(0x5cbc96eb, 0xd222a31b, 823932537);
    return 1L;
}

long inst_3_values_var_0(long param0, long param1, long param2, long param3, long param4, long param5) {
    (unsigned int)v0 = andn(-1456740133, 545603680, -1292176842);
    return param0 - 2457514518L;
}

long inst_40_flags_var_0(long param0, long param1, long param2, long param3, long param4, long param5) {
    (unsigned int)v0 = lzcnt(590114656, 940771059);
    return 0L;
}

long inst_40_values_var_0(long param0, long param1, long param2, long param3, long param4, long param5) {
    (unsigned int)v0 = lzcnt(-1467178812, 1777028060);
    return param3 - 1L;
}

long inst_41_flags_var_0(long param0, long param1, long param2, long param3, long param4, long param5) {
    long v0 = lzcnt(0xc37fbc6ced144cdfL, 5191784629106162119L);
    return 0L;
}

long inst_41_values_var_0(long param0, long param1, long param2, long param3, long param4, long param5) {
    long v0;
    long v0 = lzcnt(9078544251186863610L, 6651292065199621522L);
    return v0 - 1L;
}

long inst_4_flags_var_0(long param0, long param1, long param2, long param3, long param4, long param5) {
    long v0 = andn(-7417731337874966200L, -6297421850762214352L, -3287147707474482033L);
    return 1L;
}

long inst_4_values_var_0(long param0, long param1, long param2, long param3, long param4, long param5) {
    long v0;
    long v0 = andn(-3774422457739276044L, 0xbbd9a9b6b933980aL, 3733446890718724004L);
    return v0 - 1783442287126436L;
}

long inst_5_flags_var_0(long param0, long param1, long param2, long param3, long param4, long param5) {
    (unsigned int)v0 = blsi(1941563979, 0xcb550e07);
    return 0L;
}

long inst_5_values_var_0(long param0, long param1, long param2, long param3, long param4, long param5) {
    long v0;
    (unsigned int)v1 = blsi(0xb25552a3, 2056781606);
    return v0 - 2L;
}

long inst_6_flags_var_0(long param0, long param1, long param2, long param3, long param4, long param5) {
    long v0 = blsi(6788959083851585199L, 4680032883993358041L);
    return 8L;
}

long inst_6_values_var_0(long param0, long param1, long param2, long param3, long param4, long param5) {
    long v0;
    long v0 = blsi(0xa4d1146e63d6116L, 2594698656256217671L);
    return v0 - 1L;
}

long inst_7_flags_var_0(long param0, long param1, long param2, long param3, long param4, long param5) {
    (unsigned int)v0 = blsmsk(-2084313040, 440292650);
    return 9L;
}

long inst_7_values_var_0(long param0, long param1, long param2, long param3, long param4, long param5) {
    long v0;
    (unsigned int)v1 = blsmsk(0x97539d9d, 0xeb4d044b);
    return v0 - 1L;
}

long inst_8_flags_var_0(long param0, long param1, long param2, long param3, long param4, long param5) {
    long v0 = blsmsk(-1709262879161268921L, 6444168133486643694L);
    return 1L;
}

long inst_8_values_var_0(long param0, long param1, long param2, long param3, long param4, long param5) {
    long v0;
    long v0 = blsmsk(7180053812736635289L, 7180053812736635289L);
    return v0 - 1L;
}

long inst_9_flags_var_0(long param0, long param1, long param2, long param3, long param4, long param5) {
    (unsigned int)v0 = blsr(0xf88c8736, 2126829873);
    return 9L;
}

long inst_9_values_var_0(long param0, long param1, long param2, long param3, long param4, long param5) {
    long v0;
    (unsigned int)v1 = blsr(-1871434440, 0xecfc2fbf);
    return v0 - 3975950270L;
}

long main(long param0, long param1, long param2, long param3, long param4, long param5) {
    long v0 = inst_0_values_var_0(param0, param1, param2, param3, param4, param5);
    long v1 = /*BAD_CALL!*/ inst_0_flags_var_0(param0, param1, param2, param3, param4, param5);
    long v2 = /*BAD_CALL!*/ inst_1_values_var_0(param0, param1, param2, param3, param4, param5);
    long v3 = /*BAD_CALL!*/ inst_1_flags_var_0(param0, param1, param2, param3, param4, param5);
    long v4 = /*BAD_CALL!*/ inst_2_values_var_0(param0, param1, param2, param3, param4, param5);
    long v5 = /*BAD_CALL!*/ inst_2_flags_var_0(param0, param1, param2, param3, param4, param5);
    long v6 = /*BAD_CALL!*/ inst_3_values_var_0(param0, param1, param2, param3, param4, param5);
    long v7 = /*BAD_CALL!*/ inst_3_flags_var_0(param0, param1, param2, param3, param4, param5);
    long v8 = /*BAD_CALL!*/ inst_4_values_var_0(param0, param1, param2, param3, param4, param5);
    long v9 = /*BAD_CALL!*/ inst_4_flags_var_0(param0, param1, param2, param3, param4, param5);
    long v10 = /*BAD_CALL!*/ inst_5_values_var_0(param0, param1, param2, param3, param4, param5);
    long v11 = /*BAD_CALL!*/ inst_5_flags_var_0(param0, param1, param2, param3, param4, param5);
    long v12 = /*BAD_CALL!*/ inst_6_values_var_0(param0, param1, param2, param3, param4, param5);
    long v13 = /*BAD_CALL!*/ inst_6_flags_var_0(param0, param1, param2, param3, param4, param5);
    long v14 = /*BAD_CALL!*/ inst_7_values_var_0(param0, param1, param2, param3, param4, param5);
    long v15 = /*BAD_CALL!*/ inst_7_flags_var_0(param0, param1, param2, param3, param4, param5);
    long v16 = /*BAD_CALL!*/ inst_8_values_var_0(param0, param1, param2, param3, param4, param5);
    long v17 = /*BAD_CALL!*/ inst_8_flags_var_0(param0, param1, param2, param3, param4, param5);
    long v18 = /*BAD_CALL!*/ inst_9_values_var_0(param0, param1, param2, param3, param4, param5);
    long v19 = /*BAD_CALL!*/ inst_9_flags_var_0(param0, param1, param2, param3, param4, param5);
    long v20 = /*BAD_CALL!*/ inst_10_values_var_0(param0, param1, param2, param3, param4, param5);
    long v21 = /*BAD_CALL!*/ inst_10_flags_var_0(param0, param1, param2, param3, param4, param5);
    long v22 = /*BAD_CALL!*/ inst_11_values_var_0(param0, param1, param2, param3, param4, param5);
    long v23 = /*BAD_CALL!*/ inst_11_flags_var_0(param0, param1, param2, param3, param4, param5);
    long v24 = /*BAD_CALL!*/ inst_12_values_var_0(param0, param1, param2, param3, param4, param5);
    long v25 = /*BAD_CALL!*/ inst_12_flags_var_0(param0, param1, param2, param3, param4, param5);
    long v26 = /*BAD_CALL!*/ inst_13_values_var_0(param0, param1, param2, param3, param4, param5);
    long v27 = /*BAD_CALL!*/ inst_13_flags_var_0(param0, param1, param2, param3, param4, param5);
    long v28 = /*BAD_CALL!*/ inst_14_values_var_0(param0, param1, param2, param3, param4, param5);
    long v29 = /*BAD_CALL!*/ inst_14_flags_var_0(param0, param1, param2, param3, param4, param5);
    long v30 = /*BAD_CALL!*/ inst_15_values_var_0(param0, param1, param2, param3, param4, param5);
    long v31 = /*BAD_CALL!*/ inst_15_flags_var_0(param0, param1, param2, param3, param4, param5);
    long v32 = /*BAD_CALL!*/ inst_16_values_var_0(param0, param1, param2, param3, param4, param5);
    long v33 = /*BAD_CALL!*/ inst_16_flags_var_0(param0, param1, param2, param3, param4, param5);
    long v34 = /*BAD_CALL!*/ inst_17_values_var_0(param0, param1, param2, param3, param4, param5);
    long v35 = /*BAD_CALL!*/ inst_17_flags_var_0(param0, param1, param2, param3, param4, param5);
    long v36 = /*BAD_CALL!*/ inst_18_values_var_0(param0, param1, param2, param3, param4, param5);
    long v37 = /*BAD_CALL!*/ inst_18_flags_var_0(param0, param1, param2, param3, param4, param5);
    long v38 = /*BAD_CALL!*/ inst_19_values_var_0(param0, param1, param2, param3, param4, param5);
    long v39 = /*BAD_CALL!*/ inst_19_flags_var_0(param0, param1, param2, param3, param4, param5);
    long v40 = /*BAD_CALL!*/ inst_20_values_var_0(param0, param1, param2, param3, param4, param5);
    long v41 = /*BAD_CALL!*/ inst_20_flags_var_0(param0, param1, param2, param3, param4, param5);
    long v42 = /*BAD_CALL!*/ inst_21_values_var_0(param0, param1, param2, param3, param4, param5);
    long v43 = /*BAD_CALL!*/ inst_21_flags_var_0(param0, param1, param2, param3, param4, param5);
    long v44 = /*BAD_CALL!*/ inst_22_values_var_0(param0, param1, param2, param3, param4, param5);
    long v45 = /*BAD_CALL!*/ inst_22_flags_var_0(param0, param1, param2, param3, param4, param5);
    long v46 = /*BAD_CALL!*/ inst_23_values_var_0(param0, param1, param2, param3, param4, param5);
    long v47 = /*BAD_CALL!*/ inst_23_flags_var_0(param0, param1, param2, param3, param4, param5);
    long v48 = /*BAD_CALL!*/ inst_24_values_var_0(param0, param1, param2, param3, param4, param5);
    long v49 = /*BAD_CALL!*/ inst_24_flags_var_0(param0, param1, param2, param3, param4, param5);
    long v50 = /*BAD_CALL!*/ inst_25_values_var_0(param0, param1, param2, param3, param4, param5);
    long v51 = /*BAD_CALL!*/ inst_25_flags_var_0(param0, param1, param2, param3, param4, param5);
    long v52 = /*BAD_CALL!*/ inst_26_values_var_0(param0, param1, param2, param3, param4, param5);
    long v53 = /*BAD_CALL!*/ inst_26_flags_var_0(param0, param1, param2, param3, param4, param5);
    long v54 = /*BAD_CALL!*/ inst_27_values_var_0(param0, param1, param2, param3, param4, param5);
    long v55 = /*BAD_CALL!*/ inst_27_flags_var_0(param0, param1, param2, param3, param4, param5);
    long v56 = /*BAD_CALL!*/ inst_28_values_var_0(param0, param1, param2, param3, param4, param5);
    long v57 = /*BAD_CALL!*/ inst_28_flags_var_0(param0, param1, param2, param3, param4, param5);
    long v58 = /*BAD_CALL!*/ inst_29_values_var_0(param0, param1, param2, param3, param4, param5);
    long v59 = /*BAD_CALL!*/ inst_29_flags_var_0(param0, param1, param2, param3, param4, param5);
    long v60 = /*BAD_CALL!*/ inst_30_values_var_0(param0, param1, param2, param3, param4, param5);
    long v61 = /*BAD_CALL!*/ inst_30_flags_var_0(param0, param1, param2, param3, param4, param5);
    long v62 = /*BAD_CALL!*/ inst_31_values_var_0(param0, param1, param2, param3, param4, param5);
    long v63 = /*BAD_CALL!*/ inst_31_flags_var_0(param0, param1, param2, param3, param4, param5);
    long v64 = /*BAD_CALL!*/ inst_32_values_var_0(param0, param1, param2, param3, param4, param5);
    long v65 = /*BAD_CALL!*/ inst_32_flags_var_0(param0, param1, param2, param3, param4, param5);
    long v66 = /*BAD_CALL!*/ inst_33_values_var_0(param0, param1, param2, param3, param4, param5);
    long v67 = /*BAD_CALL!*/ inst_33_flags_var_0(param0, param1, param2, param3, param4, param5);
    long v68 = /*BAD_CALL!*/ inst_34_values_var_0(param0, param1, param2, param3, param4, param5);
    long v69 = /*BAD_CALL!*/ inst_34_flags_var_0(param0, param1, param2, param3, param4, param5);
    long v70 = /*BAD_CALL!*/ inst_35_values_var_0(param0, param1, param2, param3, param4, param5);
    long v71 = /*BAD_CALL!*/ inst_35_flags_var_0(param0, param1, param2, param3, param4, param5);
    long v72 = /*BAD_CALL!*/ inst_36_values_var_0(param0, param1, param2, param3, param4, param5);
    long v73 = /*BAD_CALL!*/ inst_36_flags_var_0(param0, param1, param2, param3, param4, param5);
    long v74 = /*BAD_CALL!*/ inst_37_values_var_0(param0, param1, param2, param3, param4, param5);
    long v75 = /*BAD_CALL!*/ inst_37_flags_var_0(param0, param1, param2, param3, param4, param5);
    long v76 = /*BAD_CALL!*/ inst_38_values_var_0(param0, param1, param2, param3, param4, param5);
    long v77 = /*BAD_CALL!*/ inst_38_flags_var_0(param0, param1, param2, param3, param4, param5);
    long v78 = /*BAD_CALL!*/ inst_39_values_var_0(param0, param1, param2, param3, param4, param5);
    long v79 = /*BAD_CALL!*/ inst_39_flags_var_0(param0, param1, param2, param3, param4, param5);
    long v80 = /*BAD_CALL!*/ inst_40_values_var_0(param0, param1, param2, param3, param4, param5);
    long v81 = /*BAD_CALL!*/ inst_40_flags_var_0(param0, param1, param2, param3, param4, param5);
    long v82 = /*BAD_CALL!*/ inst_41_values_var_0(param0, param1, param2, param3, param4, param5);
    long v83 = inst_41_flags_var_0(param0, param1, param2, param3, param4, param5);
    if((v1 + v10 + (v11 + v12) + (v13 + v14 + (v15 + v16)) + (v17 + v18 + (v19 + v2) + (v20 + v21 + (v22 + v23))) + (v24 + v25 + (v26 + v27) + (v28 + v29 + (v3 + v30)) + (v31 + v32 + (v33 + v34) + (v35 + v36 + (v37 + v38)))) + (v39 + v4 + (v40 + v41) + (v42 + v43 + (v44 + v45)) + (v46 + v47 + (v48 + v49) + (v5 + v50 + (v51 + v52))) + (v53 + v54 + (v55 + v56) + (v57 + v58 + (v59 + v6)) + (v60 + v61 + (v62 + v63) + (v64 + v65 + (v66 + v67))))) + (v68 + v69 + (v7 + v70) + (v71 + v72 + (v73 + v74)) + (v75 + v76 + (v77 + v78) + (v79 + v8 + (v80 + v81))) + (v82 + v83 + (v9 + v0))))) {
        /*NO_RETURN*/ →__assert_fail("sum==0", "source_extensions_inst__1_var__no_complex.c", 179, (char*)&__PRETTY_FUNCTION__.2665);
    }
    return 0L;
}

long register_tm_clones() {
    return 0L;
}

void r→__assert_fail(char* __assertion, char* __file, unsigned int __line, char* __function) {
    jump gvar_409010;
}

void →__assert_fail(char* __assertion, char* __file, unsigned int __line, char* __function) {
    ptr___assert_fail[0]{r→__assert_fail}(__assertion, __file, (unsigned int)__line, __function);
}
