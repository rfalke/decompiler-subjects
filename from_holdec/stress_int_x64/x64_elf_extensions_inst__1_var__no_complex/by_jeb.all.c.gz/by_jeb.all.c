
void __libc_csu_fini() {
}

void* __libc_csu_init(long param0, long param1, long param2) {
    void* result;
    initializer_0();
    unsigned long v0 = 0L;
    do {
        result = (void*)*(long*)(v0 * 8L + (long)&__frame_dummy_init_array_entry){initializer_1}();
        ++v0;
    }
    while(v0 != 1L);
    return result;
}

void _dl_relocate_static_pie() {
}

long _start(long param0, long param1) {
    long v0;
    long v1;
    long v2;
    long v3;
    char v4;
    long v5 = 0L;
    char v6 = 1;
    char v7 = 0;
    char v8 = 1;
    char v9 = 0;
    char v10 = 0;
    long v11 = param1;
    long v12 = v0;
    long* ptr0 = &v4;
    char v13 = &v0 ? 0: 1;
    char v14 = (long)&v0 < 0L;
    char v15 = __parity__((unsigned char)&v0);
    char v16 = 0;
    char v17 = 0;
    long* ptr1 = &v1;
    long v18 = &__libc_csu_fini;
    long v19 = &__libc_csu_init;
    long v20 = &main;
    long* ptr2 = &v2;
    long v21 = __libc_start_main(&main, v12, (long)&v4, &__libc_csu_init, &__libc_csu_fini, v11, (long)&v1, v3);
    hlt();
}

long deregister_tm_clones() {
    return &__TMC_END__;
}

void finalizer_0() {
}

void finalizer_1() {
    char v0 = completed.7287 ? 0: 1;
    char v1 = completed.7287 >= 128;
    char v2 = __parity__(completed.7287);
    char v3 = completed.7287 < 0;
    char v4 = 0;
    char v5 = 0;
    jump v0 ? &sub_4013BD: &sub_4013D0;
}

void* initializer_0() {
    void* result = __gmon_start__;
    if(result) {
        result = (void*)result();
    }
    return result;
}

long initializer_1() {
    return register_tm_clones();
}

unsigned long inst_0_flags_var_0(long param0, long param1, long param2, long param3, long param4, long param5) {
    char v0;
    (unsigned short)v1 = tzcnt(31813);
    return v0 ? 1L: 0L;
}

long inst_0_values_var_0(long param0, long param1, long param2, long param3, long param4, long param5) {
    short v0 = tzcnt(0x1381);
    return param2 - 0x5af700311aa80000L;
}

long inst_10_flags_var_0(long param0, long param1, long param2, long param3, long param4, long param5) {
    char v0;
    char v1;
    char v2;
    long v3 = blsr(-6466120530076208412L);
    return (unsigned long)((v2 ? 1L: 0L) + (v0 ? 8L: 0L) + (v1 ? 2L: 0L)) - 8L;
}

long inst_10_values_var_0(long param0, long param1, long param2, long param3, long param4, long param5) {
    long v0;
    long v0 = blsr(0xeace88da232210d5L);
    return v0 + 0x15317725dcddef2cL;
}

unsigned long inst_11_flags_var_0(long param0, long param1, long param2, long param3, long param4, long param5) {
    char v0;
    char v1;
    (unsigned int)v2 = bextr(-1479606858, 1560881643);
    return (unsigned long)((v1 ? 1L: 0L) + (v0 ? 2L: 0L));
}

long inst_11_values_var_0(long param0, long param1, long param2, long param3, long param4, long param5) {
    (unsigned int)v0 = bextr(-1450387663, -89947517);
    return param0;
}

unsigned long inst_12_flags_var_0(long param0, long param1, long param2, long param3, long param4, long param5) {
    char v0;
    char v1;
    long v2 = bextr(-5521840073420482171L, -25773223198299207L);
    return (unsigned long)((v1 ? 1L: 0L) + (v0 ? 2L: 0L));
}

long inst_12_values_var_0(long param0, long param1, long param2, long param3, long param4, long param5) {
    long result;
    long result = bextr(-8172127744841274311L, 1210889859216969098L);
    return result;
}

long inst_13_flags_var_0(long param0, long param1, long param2, long param3, long param4, long param5) {
    char v0;
    char v1;
    char v2;
    (unsigned int)v3 = bzhi(352234176, -1069695905);
    return (unsigned long)((v2 ? 1L: 0L) + (v0 ? 8L: 0L) + (v1 ? 2L: 0L)) - 1L;
}

long inst_13_values_var_0(long param0, long param1, long param2, long param3, long param4, long param5) {
    (unsigned int)v0 = bzhi(-965634780, -1631417467);
    return param4 - 3329332516L;
}

long inst_14_flags_var_0(long param0, long param1, long param2, long param3, long param4, long param5) {
    char v0;
    char v1;
    char v2;
    long v3 = bzhi(-1224378468239156921L, -7667595504615575818L);
    return (unsigned long)((v2 ? 1L: 0L) + (v0 ? 8L: 0L) + (v1 ? 2L: 0L)) - 9L;
}

long inst_14_values_var_0(long param0, long param1, long param2, long param3, long param4, long param5) {
    long v0;
    long v0 = bzhi(5238585455148855825L, 0x280eeff9c0cab290L);
    return v0 - 5238585455148855825L;
}

long inst_15_flags_var_0(long param0, long param1, long param2, long param3, long param4, long param5) {
    ((unsigned int)v0, (unsigned int)v1) = mulx(-480230665, 0x6786b014);
    return 0L;
}

long inst_15_values_var_0(long param0, long param1, long param2, long param3, long param4, long param5) {
    long v0;
    ((unsigned int)v1, (unsigned int)v2) = mulx(0x8d224a4e, 1650137760);
    return param0 + v0 - 5048743695L;
}

long inst_16_flags_var_0(long param0, long param1, long param2, long param3, long param4, long param5) {
    (long v0, long v1) = mulx(4497058590684198564L, -4307868293220861095L);
    return 0L;
}

long inst_16_values_var_0(long param0, long param1, long param2, long param3, long param4, long param5) {
    long v0;
    long v1;
    (long v0, long v1) = mulx(-2723357884104904694L, 6556702819765705747L);
    return v1 + v0 - 8573731540165473404L;
}

long inst_17_flags_var_0(long param0, long param1, long param2, long param3, long param4, long param5) {
    (unsigned int)v0 = pdep(0x9595bc42, 1427246226);
    return 0L;
}

long inst_17_values_var_0(long param0, long param1, long param2, long param3, long param4, long param5) {
    long v0;
    (unsigned int)v1 = pdep(-1992891564, 0x8225828);
    return v0 - 2115584L;
}

long inst_18_flags_var_0(long param0, long param1, long param2, long param3, long param4, long param5) {
    long v0 = pdep(0x450437897833fc15L, 1834563382777405374L);
    return 0L;
}

long inst_18_values_var_0(long param0, long param1, long param2, long param3, long param4, long param5) {
    long v0;
    long v0 = pdep(-1166322700620947828L, 4622161162189748655L);
    return v0 - 0x251000068d280cL;
}

long inst_19_flags_var_0(long param0, long param1, long param2, long param3, long param4, long param5) {
    int v0 = pext(-175952537, 2126854747);
    return 0L;
}

long inst_19_values_var_0(long param0, long param1, long param2, long param3, long param4, long param5) {
    long v0;
    (unsigned int)v1 = pext(-940118146, 478042916);
    return v0 - 0x3ddfL;
}

unsigned long inst_1_flags_var_0(long param0, long param1, long param2, long param3, long param4, long param5) {
    char v0;
    (unsigned int)v1 = tzcnt(-2070216649);
    return v0 ? 1L: 0L;
}

long inst_1_values_var_0(long param0, long param1, long param2, long param3, long param4, long param5) {
    (unsigned int)v0 = tzcnt(167755401);
    return param5;
}

long inst_20_flags_var_0(long param0, long param1, long param2, long param3, long param4, long param5) {
    long v0 = pext(7896754100362288110L, 4703504620528936883L);
    return 0L;
}

long inst_20_values_var_0(long param0, long param1, long param2, long param3, long param4, long param5) {
    long v0;
    long v0 = pext(2856120984033545071L, 5077184082415587923L);
    return v0 - 220144219L;
}

long inst_21_flags_var_0(long param0, long param1, long param2, long param3, long param4, long param5) {
    (unsigned int)v0 = rorx(0xc944012e, 207);
    return 0L;
}

long inst_21_values_var_0(long param0, long param1, long param2, long param3, long param4, long param5) {
    long v0;
    int v1 = rorx(1014434738, 74);
    return v0 - 3968802242L;
}

long inst_22_flags_var_0(long param0, long param1, long param2, long param3, long param4, long param5) {
    long v0 = rorx(-8154824121149182200L, 247);
    return 0L;
}

long inst_22_values_var_0(long param0, long param1, long param2, long param3, long param4, long param5) {
    long v0;
    long v0 = rorx(317413137324962340L, 113);
    return v0 + 0x2937775a06edfdcdL;
}

long inst_23_flags_var_0(long param0, long param1, long param2, long param3, long param4, long param5) {
    (unsigned int)v0 = sarx(974413938, 2014857664);
    return 0L;
}

long inst_23_values_var_0(long param0, long param1, long param2, long param3, long param4, long param5) {
    long v0;
    (unsigned int)v1 = sarx(-1313810261, 1828851212);
    return v0 - 0xfffb1b0dL;
}

long inst_24_flags_var_0(long param0, long param1, long param2, long param3, long param4, long param5) {
    long v0 = sarx(2419490408684805712L, -9745804569585319L);
    return 0L;
}

long inst_24_values_var_0(long param0, long param1, long param2, long param3, long param4, long param5) {
    long v0;
    long v0 = sarx(-1320227379160198733L, 5431029638131324206L);
    return v0 + 18762L;
}

long inst_25_flags_var_0(long param0, long param1, long param2, long param3, long param4, long param5) {
    (unsigned int)v0 = shlx(-374122533, -623710075);
    return 0L;
}

long inst_25_values_var_0(long param0, long param1, long param2, long param3, long param4, long param5) {
    (unsigned int)v0 = shlx(-1725303626, -1725303626);
    return param0 - 0x2d800000L;
}

long inst_26_flags_var_0(long param0, long param1, long param2, long param3, long param4, long param5) {
    long v0 = shlx(5297523544098838851L, -7029397181050977391L);
    return 0L;
}

long inst_26_values_var_0(long param0, long param1, long param2, long param3, long param4, long param5) {
    long v0;
    long v0 = shlx(2760748735360716793L, 3167837634228497849L);
    return v0 + 0xe00000000000000L;
}

long inst_27_flags_var_0(long param0, long param1, long param2, long param3, long param4, long param5) {
    (unsigned int)v0 = shrx(-1837437245, 227949272);
    return 0L;
}

long inst_27_values_var_0(long param0, long param1, long param2, long param3, long param4, long param5) {
    (unsigned int)v0 = shrx(0x1ae0819f, 1811290242);
    return param0 - 112730215L;
}

long inst_28_flags_var_0(long param0, long param1, long param2, long param3, long param4, long param5) {
    long v0 = shrx(0x8b1f928319d2ff3eL, 4499868075876245114L);
    return 0L;
}

long inst_28_values_var_0(long param0, long param1, long param2, long param3, long param4, long param5) {
    long v0;
    long v0 = shrx(0x2dacc80866774071L, 0xe89127449bbbf529L);
    return v0 - 1496676L;
}

long inst_29_flags_var_0(long param0, long param1, long param2, long param3, long param4, long param5) {
    adox(1462789309, 0x337875f);
    return 0L;
}

long inst_29_values_var_0(long param0, long param1, long param2, long param3, long param4, long param5) {
    adox(1501179794, 2132981877);
    return -9076621871295936629L;
}

unsigned long inst_2_flags_var_0(long param0, long param1, long param2, long param3, long param4, long param5) {
    char v0;
    long v1 = tzcnt(-5516321153366431621L);
    return v0 ? 1L: 0L;
}

long inst_2_values_var_0(long param0, long param1, long param2, long param3, long param4, long param5) {
    long result;
    long result = tzcnt(2046868747581727999L);
    return result;
}

long inst_30_flags_var_0(long param0, long param1, long param2, long param3, long param4, long param5) {
    adox(-7979740788994210370L, -7979740788994210370L);
    return -2L;
}

long inst_30_values_var_0(long param0, long param1, long param2, long param3, long param4, long param5) {
    adox(-8540209264635164419L, -5401955713585627611L);
    return 5401955713585627611L;
}

long inst_31_flags_var_0(long param0, long param1, long param2, long param3, long param4, long param5) {
    adcx(0x39a9e33f, 0x83310089);
    return 1L;
}

long inst_31_values_var_0(long param0, long param1, long param2, long param3, long param4, long param5) {
    adcx(-1619385100, -934403311);
    return -5451680319491941138L;
}

long inst_32_flags_var_0(long param0, long param1, long param2, long param3, long param4, long param5) {
    adcx(4939976837417212309L, 7479651943682500978L);
    return 1L;
}

long inst_32_values_var_0(long param0, long param1, long param2, long param3, long param4, long param5) {
    adcx(1119762303456978703L, 0x4b0a39603fef23d2L);
    return 0xb4f5c69fc010dc2dL;
}

long inst_33_flags_var_0(long param0, long param1, long param2, long param3, long param4, long param5) {
    crc32(0x92e9fa80, 92);
    return 0L;
}

long inst_33_values_var_0(long param0, long param1, long param2, long param3, long param4, long param5) {
    crc32(199407313, 203);
    return 1382339650452695280L;
}

long inst_34_flags_var_0(long param0, long param1, long param2, long param3, long param4, long param5) {
    crc32(-1505531621, 68);
    return 0L;
}

long inst_34_values_var_0(long param0, long param1, long param2, long param3, long param4, long param5) {
    crc32(934842348, 54);
    return 5804434576523796176L;
}

long inst_35_flags_var_0(long param0, long param1, long param2, long param3, long param4, long param5) {
    crc32(0x13fa3f2f, 0x92f9);
    return 0L;
}

long inst_35_values_var_0(long param0, long param1, long param2, long param3, long param4, long param5) {
    crc32(0x4a88678f, 18738);
    return 4943810029730119287L;
}

long inst_36_flags_var_0(long param0, long param1, long param2, long param3, long param4, long param5) {
    crc32(-76624534, 0x8516674);
    return 0L;
}

long inst_36_values_var_0(long param0, long param1, long param2, long param3, long param4, long param5) {
    crc32(558899402, 1990169027);
    return 3752259197808213509L;
}

long inst_37_flags_var_0(long param0, long param1, long param2, long param3, long param4, long param5) {
    crc32(-278969966, 146);
    return 0L;
}

long inst_37_values_var_0(long param0, long param1, long param2, long param3, long param4, long param5) {
    crc32(580811098, 239);
    return 0xaab5b5e89ad780aeL;
}

long inst_38_flags_var_0(long param0, long param1, long param2, long param3, long param4, long param5) {
    crc32(-1173608981, -1344226680769175815L);
    return 0L;
}

long inst_38_values_var_0(long param0, long param1, long param2, long param3, long param4, long param5) {
    crc32(0xfd1893ea, -5770895646794585377L);
    return 8940696413843491884L;
}

long inst_39_flags_var_0(long param0, long param1, long param2, long param3, long param4, long param5) {
    short v0 = lzcnt(24091);
    return 0L;
}

long inst_39_values_var_0(long param0, long param1, long param2, long param3, long param4, long param5) {
    long v0;
    short v1 = lzcnt(41125);
    return v0 + 0x1920eff4b8600000L;
}

unsigned long inst_3_flags_var_0(long param0, long param1, long param2, long param3, long param4, long param5) {
    char v0;
    char v1;
    char v2;
    (unsigned int)v3 = andn(0xd222a31b, 823932537);
    return (unsigned long)((v2 ? 1L: 0L) + (v0 ? 8L: 0L) + (v1 ? 2L: 0L));
}

long inst_3_values_var_0(long param0, long param1, long param2, long param3, long param4, long param5) {
    (unsigned int)v0 = andn(545603680, -1292176842);
    return param0 - 2457514518L;
}

long inst_40_flags_var_0(long param0, long param1, long param2, long param3, long param4, long param5) {
    (unsigned int)v0 = lzcnt(940771059);
    return 0L;
}

long inst_40_values_var_0(long param0, long param1, long param2, long param3, long param4, long param5) {
    (unsigned int)v0 = lzcnt(1777028060);
    return param3 - 1L;
}

long inst_41_flags_var_0(long param0, long param1, long param2, long param3, long param4, long param5) {
    long v0 = lzcnt(5191784629106162119L);
    return 0L;
}

long inst_41_values_var_0(long param0, long param1, long param2, long param3, long param4, long param5) {
    long v0;
    long v0 = lzcnt(6651292065199621522L);
    return v0 - 1L;
}

unsigned long inst_4_flags_var_0(long param0, long param1, long param2, long param3, long param4, long param5) {
    char v0;
    char v1;
    char v2;
    long v3 = andn(-6297421850762214352L, -3287147707474482033L);
    return (unsigned long)((v2 ? 1L: 0L) + (v0 ? 8L: 0L) + (v1 ? 2L: 0L));
}

long inst_4_values_var_0(long param0, long param1, long param2, long param3, long param4, long param5) {
    long v0;
    long v0 = andn(0xbbd9a9b6b933980aL, 3733446890718724004L);
    return v0 - 1783442287126436L;
}

long inst_5_flags_var_0(long param0, long param1, long param2, long param3, long param4, long param5) {
    char v0;
    char v1;
    char v2;
    (unsigned int)v3 = blsi(0xcb550e07);
    return (unsigned long)((v2 ? 1L: 0L) + (v0 ? 8L: 0L) + (v1 ? 2L: 0L)) - 1L;
}

long inst_5_values_var_0(long param0, long param1, long param2, long param3, long param4, long param5) {
    long v0;
    (unsigned int)v1 = blsi(2056781606);
    return v0 - 2L;
}

long inst_6_flags_var_0(long param0, long param1, long param2, long param3, long param4, long param5) {
    char v0;
    char v1;
    char v2;
    long v3 = blsi(4680032883993358041L);
    return (unsigned long)((v2 ? 1L: 0L) + (v0 ? 8L: 0L) + (v1 ? 2L: 0L)) - 1L;
}

long inst_6_values_var_0(long param0, long param1, long param2, long param3, long param4, long param5) {
    long v0;
    long v0 = blsi(2594698656256217671L);
    return v0 - 1L;
}

unsigned long inst_7_flags_var_0(long param0, long param1, long param2, long param3, long param4, long param5) {
    char v0;
    char v1;
    char v2;
    (unsigned int)v3 = blsmsk(440292650);
    return (unsigned long)((v2 ? 1L: 0L) + (v0 ? 8L: 0L) + (v1 ? 2L: 0L));
}

long inst_7_values_var_0(long param0, long param1, long param2, long param3, long param4, long param5) {
    long v0;
    (unsigned int)v1 = blsmsk(0xeb4d044b);
    return v0 - 1L;
}

unsigned long inst_8_flags_var_0(long param0, long param1, long param2, long param3, long param4, long param5) {
    char v0;
    char v1;
    char v2;
    long v3 = blsmsk(6444168133486643694L);
    return (unsigned long)((v2 ? 1L: 0L) + (v0 ? 8L: 0L) + (v1 ? 2L: 0L));
}

long inst_8_values_var_0(long param0, long param1, long param2, long param3, long param4, long param5) {
    long v0;
    long v0 = blsmsk(7180053812736635289L);
    return v0 - 1L;
}

unsigned long inst_9_flags_var_0(long param0, long param1, long param2, long param3, long param4, long param5) {
    char v0;
    char v1;
    char v2;
    (unsigned int)v3 = blsr(2126829873);
    return (unsigned long)((v2 ? 1L: 0L) + (v0 ? 8L: 0L) + (v1 ? 2L: 0L));
}

long inst_9_values_var_0(long param0, long param1, long param2, long param3, long param4, long param5) {
    long v0;
    (unsigned int)v1 = blsr(0xecfc2fbf);
    return v0 - 3975950270L;
}

void main() {
    // Decompilation error
}

long register_tm_clones() {
    return 0L;
}

long sub_40134D() {
    return 0L;
}

long sub_40138F() {
    return 0L;
}

long sub_4013BD() {
    long result = deregister_tm_clones();
    completed.7287 = 1;
    return result;
}

void sub_4013D0() {
}

long →__assert_fail(char* __assertion, char* __file, long param2, char* __function) {
    /*NO_RETURN*/ __assert_fail(__assertion, __file, (unsigned int)param2, __function);
    unsigned long* ptr0 = ptr0 - 1;
    *ptr0 = 0L;
    --ptr0;
    *ptr0 = gvar_409008;
    /*BAD_CALL!*/ gvar_409010();
}
