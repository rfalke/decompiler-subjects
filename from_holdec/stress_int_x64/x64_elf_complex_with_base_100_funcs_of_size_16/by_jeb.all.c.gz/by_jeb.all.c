
void __libc_csu_fini() {
}

void* __libc_csu_init(long param0, long param1, long param2) {
    void* result;
    initializer_0();
    unsigned long v0 = 0L;
    do {
        result = (void*)*(long*)(v0 * 8L + (long)&__frame_dummy_init_array_entry){initializer_1}();
        ++v0;
    }
    while(v0 != 1L);
    return result;
}

void _dl_relocate_static_pie() {
}

long _start(long param0, long param1) {
    long v0;
    long v1;
    long v2;
    long v3;
    char v4;
    long v5 = 0L;
    char v6 = 1;
    char v7 = 0;
    char v8 = 1;
    char v9 = 0;
    char v10 = 0;
    long v11 = param1;
    long v12 = v0;
    long* ptr0 = &v4;
    char v13 = &v0 ? 0: 1;
    char v14 = (long)&v0 < 0L;
    char v15 = __parity__((unsigned char)&v0);
    char v16 = 0;
    char v17 = 0;
    long* ptr1 = &v1;
    long v18 = &__libc_csu_fini;
    long v19 = &__libc_csu_init;
    long v20 = &main;
    long* ptr2 = &v2;
    long v21 = __libc_start_main(&main, v12, (long)&v4, &__libc_csu_init, &__libc_csu_fini, v11, (long)&v1, v3);
    hlt();
}

long deregister_tm_clones() {
    return &__TMC_END__;
}

void finalizer_0() {
}

void finalizer_1() {
    char v0 = completed.7287 ? 0: 1;
    char v1 = completed.7287 >= 128;
    char v2 = __parity__(completed.7287);
    char v3 = completed.7287 < 0;
    char v4 = 0;
    char v5 = 0;
    jump v0 ? &sub_40143D: &sub_401450;
}

void* initializer_0() {
    void* result = __gmon_start__;
    if(result) {
        result = (void*)result();
    }
    return result;
}

long initializer_1() {
    return register_tm_clones();
}

long log_size_4_var_000(long param0, long param1, long param2, long param3, long param4, long param5) {
    return 0xb9b7d6c700000000L;
}

long log_size_4_var_001(long param0, long param1, long param2, long param3, long param4, long param5) {
    return 0L;
}

long log_size_4_var_002(long param0, long param1, long param2, long param3, long param4, long param5) {
    short i;
    for(i = 0; !((27164 >>> i) & 0x1); ++i) {
    }
    return ((unsigned long)i | ((unsigned long)5229139688775L << 16)) - 342696898643558053L;
}

long log_size_4_var_003(long param0, long param1, long param2, long param3, long param4, long param5) {
    return 0L;
}

long log_size_4_var_004(long param0, long param1, long param2, long param3, long param4, long param5) {
    return 0L;
}

long log_size_4_var_005(long param0, long param1, long param2, long param3, long param4, long param5) {
    return 0L;
}

long log_size_4_var_006(long param0, long param1, long param2, long param3, long param4, long param5) {
    return 0L;
}

long log_size_4_var_007(long param0, long param1, long param2, long param3, long param4, long param5) {
    return 257366495L;
}

long log_size_4_var_008(long param0, long param1, long param2, long param3, long param4, long param5) {
    return 0L;
}

long log_size_4_var_009(long param0, long param1, long param2, long param3, long param4, long param5) {
    short i;
    for(i = 15; !(27729 >>> i); --i) {
    }
    return ((unsigned long)i | ((unsigned long)0x889bc94aa4a4L << 16)) + 0x776436b55b5bfff2L;
}

long log_size_4_var_010(long param0, long param1, long param2, long param3, long param4, long param5) {
    return 0L;
}

long log_size_4_var_011(long param0, long param1, long param2, long param3, long param4, long param5) {
    return 0L;
}

long log_size_4_var_012(long param0, long param1, long param2, long param3, long param4, long param5) {
    return 0x4f29f57700000000L;
}

long log_size_4_var_013(long param0, long param1, long param2, long param3, long param4, long param5) {
    return 0L;
}

long log_size_4_var_014(long param0, long param1, long param2, long param3, long param4, long param5) {
    return 0L;
}

long log_size_4_var_015(long param0, long param1, long param2, long param3, long param4, long param5) {
    return 0L;
}

long log_size_4_var_016(long param0, long param1, long param2, long param3, long param4, long param5) {
    return 0L;
}

long log_size_4_var_017(long param0, long param1, long param2, long param3, long param4, long param5) {
    char v0;
    return ((unsigned long)((unsigned char)((unsigned int)1674 | ((unsigned int)v0 << 12) | ((unsigned int)84100 << 13)) % 194 - ((unsigned char)(((unsigned long)((unsigned short)((unsigned int)1674 | ((unsigned int)v0 << 12) | ((unsigned int)84100 << 13)) % 61890) | ((unsigned long)0x4359c73122e6L << 16)) >= 10858635620719660606L) + 167)) | ((unsigned long)(((unsigned long)(unsigned short)((((unsigned short)((unsigned int)1674 | ((unsigned int)v0 << 12) | ((unsigned int)84100 << 13)) % 61890) >>> 8) & 0xFF) | ((unsigned long)0x4359c73122e6L << 8)) & 0xffffffffffffffL) << 8)) + ((unsigned long)((unsigned short)((unsigned int)1674 | ((unsigned int)v0 << 12) | ((unsigned int)84100 << 13)) / 61890) | ((unsigned long)(((unsigned long)((((unsigned int)((unsigned long)1674 | ((unsigned long)v0 << 12) | ((unsigned long)650975468360660L << 13)) & 0xff7fffff) >>> 16) & 0xFFFF) | ((unsigned long)1241637169L << 16)) & 0xffffffffffffL) << 16)) + (((unsigned long)(unsigned char)__ror__((unsigned short)((unsigned char)((unsigned long)((unsigned short)((unsigned int)1674 | ((unsigned int)v0 << 12) | ((unsigned int)84100 << 13)) % 61890) | ((unsigned long)0x4359c73122e6L << 16)) + 194) | ((unsigned short)1 << 8), 1) | ((unsigned long)(((((unsigned long)((unsigned short)((unsigned int)1674 | ((unsigned int)v0 << 12) | ((unsigned int)84100 << 13)) % 61890) | ((unsigned long)0x4359c73122e6L << 16)) + 7588108452989891010L) >>> 8L) & 0xffffffffffffffL) << 8)) - 6827556616149210861L) + 7979934059768801338L;
}

long log_size_4_var_018(long param0, long param1, long param2, long param3, long param4, long param5) {
    return 0L;
}

long log_size_4_var_019(long param0, long param1, long param2, long param3, long param4, long param5) {
    return 0L;
}

long log_size_4_var_020(long param0, long param1, long param2, long param3, long param4, long param5) {
    return 0L;
}

long log_size_4_var_021(long param0, long param1, long param2, long param3, long param4, long param5) {
    return 0L;
}

long log_size_4_var_022(long param0, long param1, long param2, long param3, long param4, long param5) {
    return 0xbf64b35600000000L;
}

long log_size_4_var_023(long param0, long param1, long param2, long param3, long param4, long param5) {
    short i;
    for(i = 15; !(19291 >>> i); --i) {
    }
    return ((unsigned long)i | ((unsigned long)0xffffffffff8fL << 16)) - 3438183507272073230L;
}

long log_size_4_var_024(long param0, long param1, long param2, long param3, long param4, long param5) {
    return (0xafb89212c4a3c039L | ((unsigned long)-1L << -39L)) + 3872834529309507527L;
}

long log_size_4_var_025(long param0, long param1, long param2, long param3, long param4, long param5) {
    return 0L;
}

long log_size_4_var_026(long param0, long param1, long param2, long param3, long param4, long param5) {
    return 0L;
}

long log_size_4_var_027(long param0, long param1, long param2, long param3, long param4, long param5) {
    return 0L;
}

long log_size_4_var_028(long param0, long param1, long param2, long param3, long param4, long param5) {
    int i;
    for(i = 0; !((0x5c9219a6 >>> i) & 0x1); ++i) {
    }
    return ((unsigned long)i | ((unsigned long)777477981 << 32)) + 0x1f702ed7ffffffffL;
}

long log_size_4_var_029(long param0, long param1, long param2, long param3, long param4, long param5) {
    return 0x1bcc92c400000000L;
}

long log_size_4_var_030(long param0, long param1, long param2, long param3, long param4, long param5) {
    return 0L;
}

long log_size_4_var_031(long param0, long param1, long param2, long param3, long param4, long param5) {
    return 0L;
}

long log_size_4_var_032(long param0, long param1, long param2, long param3, long param4, long param5) {
    return 0x6ccbc5f380000000L;
}

long log_size_4_var_033(long param0, long param1, long param2, long param3, long param4, long param5) {
    return 0L;
}

long log_size_4_var_034(long param0, long param1, long param2, long param3, long param4, long param5) {
    return 0L;
}

long log_size_4_var_035(long param0, long param1, long param2, long param3, long param4, long param5) {
    return 0L;
}

long log_size_4_var_036(long param0, long param1, long param2, long param3, long param4, long param5) {
    return 0L;
}

long log_size_4_var_037(long param0, long param1, long param2, long param3, long param4, long param5) {
    char v0;
    return ((unsigned long)1793 | ((unsigned long)v0 << 12) | ((unsigned long)1373309826063244L << 13)) + 1996859019646363903L;
}

long log_size_4_var_038(long param0, long param1, long param2, long param3, long param4, long param5) {
    return 0L;
}

long log_size_4_var_039(long param0, long param1, long param2, long param3, long param4, long param5) {
    return 0x4600000000000000L;
}

long log_size_4_var_040(long param0, long param1, long param2, long param3, long param4, long param5) {
    return 0L;
}

long log_size_4_var_041(long param0, long param1, long param2, long param3, long param4, long param5) {
    return 0L;
}

long log_size_4_var_042(long param0, long param1, long param2, long param3, long param4, long param5) {
    return 0L;
}

long log_size_4_var_043(long param0, long param1, long param2, long param3, long param4, long param5) {
    return 0L;
}

long log_size_4_var_044(long param0, long param1, long param2, long param3, long param4, long param5) {
    return 0x2f0243db00000000L;
}

long log_size_4_var_045(long param0, long param1, long param2, long param3, long param4, long param5) {
    return 0L;
}

long log_size_4_var_046(long param0, long param1, long param2, long param3, long param4, long param5) {
    return 0xace7506200000000L;
}

long log_size_4_var_047(long param0, long param1, long param2, long param3, long param4, long param5) {
    return 0xa70a5be900000000L;
}

long log_size_4_var_048(long param0, long param1, long param2, long param3, long param4, long param5) {
    return 0L;
}

long log_size_4_var_049(long param0, long param1, long param2, long param3, long param4, long param5) {
    return 0L;
}

long log_size_4_var_050(long param0, long param1, long param2, long param3, long param4, long param5) {
    short i;
    for(i = 15; !(0x2bba >>> i); --i) {
    }
    return ((unsigned long)i | ((unsigned long)148689216123548L << 16)) + 8702247605836709875L;
}

long log_size_4_var_051(long param0, long param1, long param2, long param3, long param4, long param5) {
    long i;
    for(i = 63L; !(4000880563840086069L >>> i); --i) {
    }
    return i - 61L;
}

long log_size_4_var_052(long param0, long param1, long param2, long param3, long param4, long param5) {
    return 0L;
}

long log_size_4_var_053(long param0, long param1, long param2, long param3, long param4, long param5) {
    return 0L;
}

long log_size_4_var_054(long param0, long param1, long param2, long param3, long param4, long param5) {
    return 0L;
}

long log_size_4_var_055(long param0, long param1, long param2, long param3, long param4, long param5) {
    return 0x23ce874100000000L;
}

long log_size_4_var_056(long param0, long param1, long param2, long param3, long param4, long param5) {
    return 0L;
}

long log_size_4_var_057(long param0, long param1, long param2, long param3, long param4, long param5) {
    return 0L;
}

long log_size_4_var_058(long param0, long param1, long param2, long param3, long param4, long param5) {
    return 0L;
}

long log_size_4_var_059(long param0, long param1, long param2, long param3, long param4, long param5) {
    return 0L;
}

long log_size_4_var_060(long param0, long param1, long param2, long param3, long param4, long param5) {
    int i;
    for(i = 0; !((1572347272 >>> i) & 0x1); ++i) {
    }
    return ((unsigned long)i | ((unsigned long)1573851652 << 32)) + 0x7fdc9d9fffffffdL;
}

long log_size_4_var_061(long param0, long param1, long param2, long param3, long param4, long param5) {
    return 0xf020d09200000000L;
}

long log_size_4_var_062(long param0, long param1, long param2, long param3, long param4, long param5) {
    return 0L;
}

long log_size_4_var_063(long param0, long param1, long param2, long param3, long param4, long param5) {
    return 0L;
}

long log_size_4_var_064(long param0, long param1, long param2, long param3, long param4, long param5) {
    return 0L;
}

long log_size_4_var_065(long param0, long param1, long param2, long param3, long param4, long param5) {
    return 0L;
}

long log_size_4_var_066(long param0, long param1, long param2, long param3, long param4, long param5) {
    return 0L;
}

long log_size_4_var_067(long param0, long param1, long param2, long param3, long param4, long param5) {
    return 0L;
}

long log_size_4_var_068(long param0, long param1, long param2, long param3, long param4, long param5) {
    long i;
    for(i = 0L; !((-4936733106579664310L >>> i) & 0x1L); ++i) {
    }
    return i + 0x226a0bc7ffffffadL;
}

long log_size_4_var_069(long param0, long param1, long param2, long param3, long param4, long param5) {
    return 0x5b6d4d400000000L;
}

long log_size_4_var_070(long param0, long param1, long param2, long param3, long param4, long param5) {
    return 0L;
}

long log_size_4_var_071(long param0, long param1, long param2, long param3, long param4, long param5) {
    return 0L;
}

long log_size_4_var_072(long param0, long param1, long param2, long param3, long param4, long param5) {
    return 0L;
}

long log_size_4_var_073(long param0, long param1, long param2, long param3, long param4, long param5) {
    return 0L;
}

long log_size_4_var_074(long param0, long param1, long param2, long param3, long param4, long param5) {
    return 0L;
}

long log_size_4_var_075(long param0, long param1, long param2, long param3, long param4, long param5) {
    return 0L;
}

long log_size_4_var_076(long param0, long param1, long param2, long param3, long param4, long param5) {
    return 0L;
}

long log_size_4_var_077(long param0, long param1, long param2, long param3, long param4, long param5) {
    long i;
    for(i = 0L; !((0x51bfb40000000000L >>> i) & 0x1L); ++i) {
    }
    return i - 42L;
}

long log_size_4_var_078(long param0, long param1, long param2, long param3, long param4, long param5) {
    return 0L;
}

long log_size_4_var_079(long param0, long param1, long param2, long param3, long param4, long param5) {
    for(short i = 15; !(2874 >>> i); --i) {
    }
    return 0L;
}

long log_size_4_var_080(long param0, long param1, long param2, long param3, long param4, long param5) {
    return 0L;
}

long log_size_4_var_081(long param0, long param1, long param2, long param3, long param4, long param5) {
    long i;
    for(i = 63L; !(8952551725395654137L >>> i); --i) {
    }
    return ((unsigned long)((unsigned char)i + 47) | ((unsigned long)((i >>> 8L) & 0xffffffffffffffL) << 8)) - 109L;
}

long log_size_4_var_082(long param0, long param1, long param2, long param3, long param4, long param5) {
    return 0xa721672100000000L;
}

long log_size_4_var_083(long param0, long param1, long param2, long param3, long param4, long param5) {
    return 0L;
}

long log_size_4_var_084(long param0, long param1, long param2, long param3, long param4, long param5) {
    return 0L;
}

long log_size_4_var_085(long param0, long param1, long param2, long param3, long param4, long param5) {
    return 0L;
}

long log_size_4_var_086(long param0, long param1, long param2, long param3, long param4, long param5) {
    return 1669167418L;
}

long log_size_4_var_087(long param0, long param1, long param2, long param3, long param4, long param5) {
    return 0xf8792f8300000000L;
}

long log_size_4_var_088(long param0, long param1, long param2, long param3, long param4, long param5) {
    return 0L;
}

long log_size_4_var_089(long param0, long param1, long param2, long param3, long param4, long param5) {
    return 0x60cd3f6600000000L;
}

long log_size_4_var_090(long param0, long param1, long param2, long param3, long param4, long param5) {
    return 0L;
}

long log_size_4_var_091(long param0, long param1, long param2, long param3, long param4, long param5) {
    return 0L;
}

long log_size_4_var_092(long param0, long param1, long param2, long param3, long param4, long param5) {
    return 0x1e744bd00L;
}

long log_size_4_var_093(long param0, long param1, long param2, long param3, long param4, long param5) {
    return 0L;
}

long log_size_4_var_094(long param0, long param1, long param2, long param3, long param4, long param5) {
    return -900407670681413876L;
}

long log_size_4_var_095(long param0, long param1, long param2, long param3, long param4, long param5) {
    return 0L;
}

long log_size_4_var_096(long param0, long param1, long param2, long param3, long param4, long param5) {
    return 0L;
}

long log_size_4_var_097(long param0, long param1, long param2, long param3, long param4, long param5) {
    return 0L;
}

long log_size_4_var_098(long param0, long param1, long param2, long param3, long param4, long param5) {
    return 0L;
}

long log_size_4_var_099(long param0, long param1, long param2, long param3, long param4, long param5) {
    return 0L;
}

long main(long param0, long param1, long param2, long param3, long param4, long param5) {
    void* ptr0;
    long v0;
    long v1 = v0;
    long v2 = log_size_4_var_000(param0, param1, param2, param3, param4, param5);
    long v3 = v2;
    long v4 = log_size_4_var_001(param0, param1, param2, param3, param4, param5);
    long v5 = v4 + v3;
    long v6 = log_size_4_var_002(param0, param1, param2, param3, param4, param5);
    long v7 = v6 + v5;
    long v8 = log_size_4_var_003(param0, param1, param2, param3, param4, param5);
    long v9 = v8 + v7;
    long v10 = log_size_4_var_004(param0, param1, param2, param3, param4, param5);
    long v11 = v10 + v9;
    long v12 = log_size_4_var_005(param0, param1, param2, param3, param4, param5);
    long v13 = v12 + v11;
    long v14 = log_size_4_var_006(param0, param1, param2, param3, param4, param5);
    long v15 = v14 + v13;
    long v16 = log_size_4_var_007(param0, param1, param2, param3, param4, param5);
    long v17 = v16 + v15;
    long v18 = log_size_4_var_008(param0, param1, param2, param3, param4, param5);
    long v19 = v18 + v17;
    long v20 = log_size_4_var_009(param0, param1, param2, param3, param4, param5);
    long v21 = v20 + v19;
    long v22 = log_size_4_var_010(param0, param1, param2, param3, param4, param5);
    long v23 = v22 + v21;
    long v24 = log_size_4_var_011(param0, param1, param2, param3, param4, param5);
    long v25 = v24 + v23;
    long v26 = log_size_4_var_012(param0, param1, param2, param3, param4, param5);
    long v27 = v26 + v25;
    long v28 = log_size_4_var_013(param0, param1, param2, param3, param4, param5);
    long v29 = v28 + v27;
    long v30 = log_size_4_var_014(param0, param1, param2, param3, param4, param5);
    long v31 = v30 + v29;
    long v32 = log_size_4_var_015(param0, param1, param2, param3, param4, param5);
    long v33 = v32 + v31;
    long v34 = log_size_4_var_016(param0, param1, param2, param3, param4, param5);
    long v35 = v34 + v33;
    long v36 = log_size_4_var_017(param0, param1, param2, param3, param4, param5);
    long v37 = v36 + v35;
    long v38 = log_size_4_var_018(param0, param1, param2, param3, param4, param5);
    long v39 = v38 + v37;
    long v40 = log_size_4_var_019(param0, param1, param2, param3, param4, param5);
    long v41 = v40 + v39;
    long v42 = log_size_4_var_020(param0, param1, param2, param3, param4, param5);
    long v43 = v42 + v41;
    long v44 = log_size_4_var_021(param0, param1, param2, param3, param4, param5);
    long v45 = v44 + v43;
    long v46 = log_size_4_var_022(param0, param1, param2, param3, param4, param5);
    long v47 = v46 + v45;
    long v48 = log_size_4_var_023(param0, param1, param2, param3, param4, param5);
    long v49 = v48 + v47;
    long v50 = log_size_4_var_024(param0, param1, param2, param3, param4, param5);
    long v51 = v50 + v49;
    long v52 = log_size_4_var_025(param0, param1, param2, param3, param4, param5);
    long v53 = v52 + v51;
    long v54 = log_size_4_var_026(param0, param1, param2, param3, param4, param5);
    long v55 = v54 + v53;
    long v56 = log_size_4_var_027(param0, param1, param2, param3, param4, param5);
    long v57 = v56 + v55;
    long v58 = log_size_4_var_028(param0, param1, param2, param3, param4, param5);
    long v59 = v58 + v57;
    long v60 = log_size_4_var_029(param0, param1, param2, param3, param4, param5);
    long v61 = v60 + v59;
    long v62 = log_size_4_var_030(param0, param1, param2, param3, param4, param5);
    long v63 = v62 + v61;
    long v64 = log_size_4_var_031(param0, param1, param2, param3, param4, param5);
    long v65 = v64 + v63;
    long v66 = log_size_4_var_032(param0, param1, param2, param3, param4, param5);
    long v67 = v66 + v65;
    long v68 = log_size_4_var_033(param0, param1, param2, param3, param4, param5);
    long v69 = v68 + v67;
    long v70 = log_size_4_var_034(param0, param1, param2, param3, param4, param5);
    long v71 = v70 + v69;
    long v72 = log_size_4_var_035(param0, param1, param2, param3, param4, param5);
    long v73 = v72 + v71;
    long v74 = log_size_4_var_036(param0, param1, param2, param3, param4, param5);
    long v75 = v74 + v73;
    long v76 = log_size_4_var_037(param0, param1, param2, param3, param4, param5);
    long v77 = v76 + v75;
    long v78 = log_size_4_var_038(param0, param1, param2, param3, param4, param5);
    long v79 = v78 + v77;
    long v80 = log_size_4_var_039(param0, param1, param2, param3, param4, param5);
    long v81 = v80 + v79;
    long v82 = log_size_4_var_040(param0, param1, param2, param3, param4, param5);
    long v83 = v82 + v81;
    long v84 = log_size_4_var_041(param0, param1, param2, param3, param4, param5);
    long v85 = v84 + v83;
    long v86 = log_size_4_var_042(param0, param1, param2, param3, param4, param5);
    long v87 = v86 + v85;
    long v88 = log_size_4_var_043(param0, param1, param2, param3, param4, param5);
    long v89 = v88 + v87;
    long v90 = log_size_4_var_044(param0, param1, param2, param3, param4, param5);
    long v91 = v90 + v89;
    long v92 = log_size_4_var_045(param0, param1, param2, param3, param4, param5);
    long v93 = v92 + v91;
    long v94 = log_size_4_var_046(param0, param1, param2, param3, param4, param5);
    long v95 = v94 + v93;
    long v96 = log_size_4_var_047(param0, param1, param2, param3, param4, param5);
    long v97 = v96 + v95;
    long v98 = log_size_4_var_048(param0, param1, param2, param3, param4, param5);
    long v99 = v98 + v97;
    long v100 = log_size_4_var_049(param0, param1, param2, param3, param4, param5);
    long v101 = v100 + v99;
    long v102 = log_size_4_var_050(param0, param1, param2, param3, param4, param5);
    long v103 = v102 + v101;
    long v104 = log_size_4_var_051(param0, param1, param2, param3, param4, param5);
    long v105 = v104 + v103;
    long v106 = log_size_4_var_052(param0, param1, param2, param3, param4, param5);
    long v107 = v106 + v105;
    long v108 = log_size_4_var_053(param0, param1, param2, param3, param4, param5);
    long v109 = v108 + v107;
    long v110 = log_size_4_var_054(param0, param1, param2, param3, param4, param5);
    long v111 = v110 + v109;
    long v112 = log_size_4_var_055(param0, param1, param2, param3, param4, param5);
    long v113 = v112 + v111;
    long v114 = log_size_4_var_056(param0, param1, param2, param3, param4, param5);
    long v115 = v114 + v113;
    long v116 = log_size_4_var_057(param0, param1, param2, param3, param4, param5);
    long v117 = v116 + v115;
    long v118 = log_size_4_var_058(param0, param1, param2, param3, param4, param5);
    long v119 = v118 + v117;
    long v120 = log_size_4_var_059(param0, param1, param2, param3, param4, param5);
    long v121 = v120 + v119;
    long v122 = log_size_4_var_060(param0, param1, param2, param3, param4, param5);
    long v123 = v122 + v121;
    long v124 = log_size_4_var_061(param0, param1, param2, param3, param4, param5);
    long v125 = v124 + v123;
    long v126 = log_size_4_var_062(param0, param1, param2, param3, param4, param5);
    long v127 = v126 + v125;
    long v128 = log_size_4_var_063(param0, param1, param2, param3, param4, param5);
    long v129 = v128 + v127;
    long v130 = log_size_4_var_064(param0, param1, param2, param3, param4, param5);
    long v131 = v130 + v129;
    long v132 = log_size_4_var_065(param0, param1, param2, param3, param4, param5);
    long v133 = v132 + v131;
    long v134 = log_size_4_var_066(param0, param1, param2, param3, param4, param5);
    long v135 = v134 + v133;
    long v136 = log_size_4_var_067(param0, param1, param2, param3, param4, param5);
    long v137 = v136 + v135;
    long v138 = log_size_4_var_068(param0, param1, param2, param3, param4, param5);
    long v139 = v138 + v137;
    long v140 = log_size_4_var_069(param0, param1, param2, param3, param4, param5);
    long v141 = v140 + v139;
    long v142 = log_size_4_var_070(param0, param1, param2, param3, param4, param5);
    long v143 = v142 + v141;
    long v144 = log_size_4_var_071(param0, param1, param2, param3, param4, param5);
    long v145 = v144 + v143;
    long v146 = log_size_4_var_072(param0, param1, param2, param3, param4, param5);
    long v147 = v146 + v145;
    long v148 = log_size_4_var_073(param0, param1, param2, param3, param4, param5);
    long v149 = v148 + v147;
    long v150 = log_size_4_var_074(param0, param1, param2, param3, param4, param5);
    long v151 = v150 + v149;
    long v152 = log_size_4_var_075(param0, param1, param2, param3, param4, param5);
    long v153 = v152 + v151;
    long v154 = log_size_4_var_076(param0, param1, param2, param3, param4, param5);
    long v155 = v154 + v153;
    long v156 = log_size_4_var_077(param0, param1, param2, param3, param4, param5);
    long v157 = v156 + v155;
    long v158 = log_size_4_var_078(param0, param1, param2, param3, param4, param5);
    long v159 = v158 + v157;
    long v160 = log_size_4_var_079(param0, param1, param2, param3, param4, param5);
    long v161 = v160 + v159;
    long v162 = log_size_4_var_080(param0, param1, param2, param3, param4, param5);
    long v163 = v162 + v161;
    long v164 = log_size_4_var_081(param0, param1, param2, param3, param4, param5);
    long v165 = v164 + v163;
    long v166 = log_size_4_var_082(param0, param1, param2, param3, param4, param5);
    long v167 = v166 + v165;
    long v168 = log_size_4_var_083(param0, param1, param2, param3, param4, param5);
    long v169 = v168 + v167;
    long v170 = log_size_4_var_084(param0, param1, param2, param3, param4, param5);
    long v171 = v170 + v169;
    long v172 = log_size_4_var_085(param0, param1, param2, param3, param4, param5);
    long v173 = v172 + v171;
    long v174 = log_size_4_var_086(param0, param1, param2, param3, param4, param5);
    long v175 = v174 + v173;
    long v176 = log_size_4_var_087(param0, param1, param2, param3, param4, param5);
    long v177 = v176 + v175;
    long v178 = log_size_4_var_088(param0, param1, param2, param3, param4, param5);
    long v179 = v178 + v177;
    long v180 = log_size_4_var_089(param0, param1, param2, param3, param4, param5);
    long v181 = v180 + v179;
    long v182 = log_size_4_var_090(param0, param1, param2, param3, param4, param5);
    long v183 = v182 + v181;
    long v184 = log_size_4_var_091(param0, param1, param2, param3, param4, param5);
    long v185 = v184 + v183;
    long v186 = log_size_4_var_092(param0, param1, param2, param3, param4, param5);
    long v187 = v186 + v185;
    long v188 = log_size_4_var_093(param0, param1, param2, param3, param4, param5);
    long v189 = v188 + v187;
    long v190 = log_size_4_var_094(param0, param1, param2, param3, param4, param5);
    long v191 = v190 + v189;
    long v192 = log_size_4_var_095(param0, param1, param2, param3, param4, param5);
    long v193 = v192 + v191;
    long v194 = log_size_4_var_096(param0, param1, param2, param3, param4, param5);
    long v195 = v194 + v193;
    long v196 = log_size_4_var_097(param0, param1, param2, param3, param4, param5);
    long v197 = v196 + v195;
    long v198 = log_size_4_var_098(param0, param1, param2, param3, param4, param5);
    long v199 = v198 + v197;
    long v200 = log_size_4_var_099(param0, param1, param2, param3, param4, param5);
    long v201 = v200 + v199;
    char v202 = v201 ? 0: 1;
    if(v202) {
        return 0L;
    }
    long v203 = &__PRETTY_FUNCTION__.2713;
    long v204 = 211L;
    long v205 = "source_complex_with_base_100_funcs_of_size_16.c";
    long v206 = "sum==0";
    long* ptr1 = &ptr0;
    long v207 = /*NO_RETURN*/ →__assert_fail("sum==0", "source_complex_with_base_100_funcs_of_size_16.c", 211L, (char*)&__PRETTY_FUNCTION__.2713);
}

long register_tm_clones() {
    return 0L;
}

long sub_4013CD() {
    return 0L;
}

long sub_40140F() {
    return 0L;
}

long sub_40143D() {
    long result = deregister_tm_clones();
    completed.7287 = 1;
    return result;
}

void sub_401450() {
}

long →__assert_fail(char* __assertion, char* __file, long param2, char* __function) {
    /*NO_RETURN*/ __assert_fail(__assertion, __file, (unsigned int)param2, __function);
    unsigned long* ptr0 = ptr0 - 1;
    *ptr0 = 0L;
    --ptr0;
    *ptr0 = gvar_40B008;
    /*BAD_CALL!*/ gvar_40B010();
}
