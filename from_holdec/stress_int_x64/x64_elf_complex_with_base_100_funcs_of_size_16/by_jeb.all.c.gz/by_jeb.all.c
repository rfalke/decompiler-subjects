
void __libc_csu_fini() {
}

void* __libc_csu_init(long param0, long param1) {
    void* result;
    initializer_0();
    long v0 = 0L;
    do {
        result = (void*)*(long*)(v0 * 8L + (long)&__frame_dummy_init_array_entry){initializer_1}();
        ++v0;
    }
    while(v0 != 1L);
    return result;
}

void _dl_relocate_static_pie() {
}

long _start(long param0, long param1) {
    long v0;
    long v1;
    long v2;
    char v3;
    __libc_start_main(&main, v0, (long)&v3, &__libc_csu_init, &__libc_csu_fini, param1, (long)&v1, v2);
    hlt();
}

// Stale decompilation - Refresh this view to re-decompile this code
long deregister_tm_clones() {
    return &__TMC_END__;
}

void finalizer_0() {
}

void finalizer_1() {
    if(!completed.7287) {
        deregister_tm_clones();
        completed.7287 = 1;
    }
}

void* initializer_0() {
    void* result = __gmon_start__;
    if(result) {
        result = (void*)result();
    }
    return result;
}

long initializer_1() {
    return register_tm_clones();
}

long log_size_4_var_000(long param0, long param1, long param2, long param3, long param4, long param5) {
    return 0xb9b7d6c700000000L;
}

long log_size_4_var_001(long param0, long param1, long param2, long param3, long param4, long param5) {
    return 0L;
}

long log_size_4_var_002(long param0, long param1, long param2, long param3, long param4, long param5) {
    short i;
    for(i = 0; !((27164 >>> i) & 0x1); ++i) {
    }
    return ((unsigned long)i | ((unsigned long)5229139688775L << 16)) - 342696898643558053L;
}

long log_size_4_var_003(long param0, long param1, long param2, long param3, long param4, long param5) {
    return 0L;
}

long log_size_4_var_004(long param0, long param1, long param2, long param3, long param4, long param5) {
    return 0L;
}

long log_size_4_var_005(long param0, long param1, long param2, long param3, long param4, long param5) {
    return 0L;
}

long log_size_4_var_006(long param0, long param1, long param2, long param3, long param4, long param5) {
    return 0L;
}

long log_size_4_var_007(long param0, long param1, long param2, long param3, long param4, long param5) {
    return 257366495L;
}

long log_size_4_var_008(long param0, long param1, long param2, long param3, long param4, long param5) {
    return 0L;
}

long log_size_4_var_009(long param0, long param1, long param2, long param3, long param4, long param5) {
    short i;
    for(i = 15; !(27729 >>> i); --i) {
    }
    return ((unsigned long)i | ((unsigned long)0x889bc94aa4a4L << 16)) + 0x776436b55b5bfff2L;
}

long log_size_4_var_010(long param0, long param1, long param2, long param3, long param4, long param5) {
    return 0L;
}

long log_size_4_var_011(long param0, long param1, long param2, long param3, long param4, long param5) {
    return 0L;
}

long log_size_4_var_012(long param0, long param1, long param2, long param3, long param4, long param5) {
    return 0x4f29f57700000000L;
}

long log_size_4_var_013(long param0, long param1, long param2, long param3, long param4, long param5) {
    return 0L;
}

long log_size_4_var_014(long param0, long param1, long param2, long param3, long param4, long param5) {
    return 0L;
}

long log_size_4_var_015(long param0, long param1, long param2, long param3, long param4, long param5) {
    return 0L;
}

long log_size_4_var_016(long param0, long param1, long param2, long param3, long param4, long param5) {
    return 0L;
}

long log_size_4_var_017(long param0, long param1, long param2, long param3, long param4, long param5) {
    char v0;
    return ((unsigned long)((unsigned char)((unsigned int)1674 | ((unsigned int)v0 << 12) | ((unsigned int)84100 << 13)) % 194 - ((unsigned char)(((unsigned long)((unsigned short)((unsigned int)1674 | ((unsigned int)v0 << 12) | ((unsigned int)84100 << 13)) % 61890) | ((unsigned long)0x4359c73122e6L << 16)) >= 10858635620719660606L) + 167)) | ((unsigned long)(((unsigned long)(unsigned short)((((unsigned short)((unsigned int)1674 | ((unsigned int)v0 << 12) | ((unsigned int)84100 << 13)) % 61890) >>> 8) & 0xFF) | ((unsigned long)0x4359c73122e6L << 8)) & 0xffffffffffffffL) << 8)) + ((unsigned long)((unsigned short)((unsigned int)1674 | ((unsigned int)v0 << 12) | ((unsigned int)84100 << 13)) / 61890) | ((unsigned long)(((unsigned long)((((unsigned int)((unsigned long)1674 | ((unsigned long)v0 << 12) | ((unsigned long)650975468360660L << 13)) & 0xff7fffff) >>> 16) & 0xFFFF) | ((unsigned long)1241637169L << 16)) & 0xffffffffffffL) << 16)) + (((unsigned long)(unsigned char)__ror__((unsigned short)(unsigned char)(((unsigned long)((unsigned short)((unsigned int)1674 | ((unsigned int)v0 << 12) | ((unsigned int)84100 << 13)) % 61890) | ((unsigned long)0x4359c73122e6L << 16)) + 7588108452989891010L) | ((unsigned short)1 << 8), 1) | ((unsigned long)(((((unsigned long)((unsigned short)((unsigned int)1674 | ((unsigned int)v0 << 12) | ((unsigned int)84100 << 13)) % 61890) | ((unsigned long)0x4359c73122e6L << 16)) + 7588108452989891010L) >>> 8L) & 0xffffffffffffffL) << 8)) - 6827556616149210861L) + 7979934059768801338L;
}

long log_size_4_var_018(long param0, long param1, long param2, long param3, long param4, long param5) {
    return 0L;
}

long log_size_4_var_019(long param0, long param1, long param2, long param3, long param4, long param5) {
    return 0L;
}

long log_size_4_var_020(long param0, long param1, long param2, long param3, long param4, long param5) {
    return 0L;
}

long log_size_4_var_021(long param0, long param1, long param2, long param3, long param4, long param5) {
    return 0L;
}

long log_size_4_var_022(long param0, long param1, long param2, long param3, long param4, long param5) {
    return 0xbf64b35600000000L;
}

long log_size_4_var_023(long param0, long param1, long param2, long param3, long param4, long param5) {
    short i;
    for(i = 15; !(19291 >>> i); --i) {
    }
    return ((unsigned long)i | ((unsigned long)0xffffffffff8fL << 16)) - 3438183507272073230L;
}

long log_size_4_var_024(long param0, long param1, long param2, long param3, long param4, long param5) {
    return (0xafb89212c4a3c039L | ((unsigned long)-1L << -39L)) + 3872834529309507527L;
}

long log_size_4_var_025(long param0, long param1, long param2, long param3, long param4, long param5) {
    return 0L;
}

long log_size_4_var_026(long param0, long param1, long param2, long param3, long param4, long param5) {
    return 0L;
}

long log_size_4_var_027(long param0, long param1, long param2, long param3, long param4, long param5) {
    return 0L;
}

long log_size_4_var_028(long param0, long param1, long param2, long param3, long param4, long param5) {
    int i;
    for(i = 0; !((0x5c9219a6 >>> i) & 0x1); ++i) {
    }
    return ((unsigned long)i | ((unsigned long)777477981 << 32)) + 0x1f702ed7ffffffffL;
}

long log_size_4_var_029(long param0, long param1, long param2, long param3, long param4, long param5) {
    return 0x1bcc92c400000000L;
}

long log_size_4_var_030(long param0, long param1, long param2, long param3, long param4, long param5) {
    return 0L;
}

long log_size_4_var_031(long param0, long param1, long param2, long param3, long param4, long param5) {
    int i;
    for(i = 31; !(-1403362929 >>> i); --i) {
    }
    return (unsigned long)((unsigned int)((unsigned long)__ror__((unsigned char)i, 10) | ((unsigned long)(((unsigned long)((i >>> 8) & 0xFFFFFF) | ((unsigned long)3384286013L << 24)) & 0xffffffffffffffL) << 8)) * 0x20000) - 0x18e0000L;
}

long log_size_4_var_032(long param0, long param1, long param2, long param3, long param4, long param5) {
    return 0x6ccbc5f380000000L;
}

long log_size_4_var_033(long param0, long param1, long param2, long param3, long param4, long param5) {
    return 0L;
}

long log_size_4_var_034(long param0, long param1, long param2, long param3, long param4, long param5) {
    return 0L;
}

long log_size_4_var_035(long param0, long param1, long param2, long param3, long param4, long param5) {
    return 0L;
}

long log_size_4_var_036(long param0, long param1, long param2, long param3, long param4, long param5) {
    return 0L;
}

long log_size_4_var_037(long param0, long param1, long param2, long param3, long param4, long param5) {
    char v0;
    int i;
    for(i = 0; !((0xc99bee1b >>> i) & 0x1); ++i) {
    }
    return ((unsigned long)i | ((unsigned long)-1210656706 << 32)) + ((unsigned long)1793 | ((unsigned long)v0 << 12) | ((unsigned long)1373309826063244L << 13)) + 7196589978599450879L;
}

long log_size_4_var_038(long param0, long param1, long param2, long param3, long param4, long param5) {
    return 0L;
}

long log_size_4_var_039(long param0, long param1, long param2, long param3, long param4, long param5) {
    return 0x4600000000000000L;
}

long log_size_4_var_040(long param0, long param1, long param2, long param3, long param4, long param5) {
    return 0L;
}

long log_size_4_var_041(long param0, long param1, long param2, long param3, long param4, long param5) {
    return 0L;
}

long log_size_4_var_042(long param0, long param1, long param2, long param3, long param4, long param5) {
    return 0L;
}

long log_size_4_var_043(long param0, long param1, long param2, long param3, long param4, long param5) {
    return 0L;
}

long log_size_4_var_044(long param0, long param1, long param2, long param3, long param4, long param5) {
    return 0x2f0243db00000000L;
}

long log_size_4_var_045(long param0, long param1, long param2, long param3, long param4, long param5) {
    return 0L;
}

long log_size_4_var_046(long param0, long param1, long param2, long param3, long param4, long param5) {
    return 0xace7506200000000L;
}

long log_size_4_var_047(long param0, long param1, long param2, long param3, long param4, long param5) {
    return 0xa70a5be900000000L;
}

long log_size_4_var_048(long param0, long param1, long param2, long param3, long param4, long param5) {
    return 0L;
}

long log_size_4_var_049(long param0, long param1, long param2, long param3, long param4, long param5) {
    return 0L;
}

long log_size_4_var_050(long param0, long param1, long param2, long param3, long param4, long param5) {
    short i;
    for(i = 15; !(0x2bba >>> i); --i) {
    }
    return ((unsigned long)i | ((unsigned long)148689216123548L << 16)) + 8702247605836709875L;
}

long log_size_4_var_051(long param0, long param1, long param2, long param3, long param4, long param5) {
    long i;
    for(i = 63L; !(4000880563840086069L >>> i); --i) {
    }
    return i - 61L;
}

long log_size_4_var_052(long param0, long param1, long param2, long param3, long param4, long param5) {
    return 0L;
}

long log_size_4_var_053(long param0, long param1, long param2, long param3, long param4, long param5) {
    return 0L;
}

long log_size_4_var_054(long param0, long param1, long param2, long param3, long param4, long param5) {
    return 0L;
}

long log_size_4_var_055(long param0, long param1, long param2, long param3, long param4, long param5) {
    for(short i = 0; !((35531 >>> i) & 0x1); ++i) {
    }
    return 0x23ce874100000000L;
}

long log_size_4_var_056(long param0, long param1, long param2, long param3, long param4, long param5) {
    long i;
    for(i = 63L; !(0xa2d4359878b42eddL >>> i); --i) {
    }
    long v0 = i;
    long v1 = v0 + 950530794036985724L;
    long v2 = -5847722535804563732L;
    if((unsigned short)v0 == 0x8eec) {
        v0 = (unsigned long)17710 | ((unsigned long)((v0 >>> 16L) & 0xffffffffffffL) << 16);
    }
    else {
        v2 = (unsigned long)(unsigned short)v0 | ((unsigned long)192245812040786L << 16);
    }
    return (unsigned long)(int)(unsigned short)v1 + ((unsigned long)((unsigned char)v2 + (unsigned char)v1 + 1) | ((unsigned long)((v1 >>> 8L) & 0xffffffffffffffL) << 8)) + (v2 + v0) + 4897191737472647116L;
}

long log_size_4_var_057(long param0, long param1, long param2, long param3, long param4, long param5) {
    return 0L;
}

long log_size_4_var_058(long param0, long param1, long param2, long param3, long param4, long param5) {
    short i;
    for(i = 0; !((4553 >>> i) & 0x1); ++i) {
    }
    return ((unsigned long)i | ((unsigned long)0xfffffc43b6fbcc31L << 16)) - 307290393722588744L;
}

long log_size_4_var_059(long param0, long param1, long param2, long param3, long param4, long param5) {
    return 0L;
}

long log_size_4_var_060(long param0, long param1, long param2, long param3, long param4, long param5) {
    int i;
    for(i = 0; !((1572347272 >>> i) & 0x1); ++i) {
    }
    long j;
    for(j = 63L; !(0x8693efc637eea000L >>> j); --j) {
    }
    return ((unsigned long)i | ((unsigned long)1573851652 << 32)) + j + 0x7fdc9d9ffffffbeL;
}

long log_size_4_var_061(long param0, long param1, long param2, long param3, long param4, long param5) {
    return 0xf020d09200000000L;
}

long log_size_4_var_062(long param0, long param1, long param2, long param3, long param4, long param5) {
    return 0L;
}

long log_size_4_var_063(long param0, long param1, long param2, long param3, long param4, long param5) {
    return 0L;
}

long log_size_4_var_064(long param0, long param1, long param2, long param3, long param4, long param5) {
    return 0L;
}

long log_size_4_var_065(long param0, long param1, long param2, long param3, long param4, long param5) {
    return 0L;
}

long log_size_4_var_066(long param0, long param1, long param2, long param3, long param4, long param5) {
    return 0L;
}

long log_size_4_var_067(long param0, long param1, long param2, long param3, long param4, long param5) {
    return 0L;
}

long log_size_4_var_068(long param0, long param1, long param2, long param3, long param4, long param5) {
    long i;
    for(i = 0L; !((-4936733106579664310L >>> i) & 0x1L); ++i) {
    }
    return i + 0x226a0bc7ffffffadL;
}

long log_size_4_var_069(long param0, long param1, long param2, long param3, long param4, long param5) {
    return 0x5b6d4d400000000L;
}

long log_size_4_var_070(long param0, long param1, long param2, long param3, long param4, long param5) {
    return 1251325720L;
}

long log_size_4_var_071(long param0, long param1, long param2, long param3, long param4, long param5) {
    return 0L;
}

long log_size_4_var_072(long param0, long param1, long param2, long param3, long param4, long param5) {
    return 0L;
}

long log_size_4_var_073(long param0, long param1, long param2, long param3, long param4, long param5) {
    return 0L;
}

long log_size_4_var_074(long param0, long param1, long param2, long param3, long param4, long param5) {
    return 0L;
}

long log_size_4_var_075(long param0, long param1, long param2, long param3, long param4, long param5) {
    return 0L;
}

long log_size_4_var_076(long param0, long param1, long param2, long param3, long param4, long param5) {
    return 0L;
}

long log_size_4_var_077(long param0, long param1, long param2, long param3, long param4, long param5) {
    long i;
    for(i = 0L; !((0x51bfb40000000000L >>> i) & 0x1L); ++i) {
    }
    return i - 42L;
}

long log_size_4_var_078(long param0, long param1, long param2, long param3, long param4, long param5) {
    return 0L;
}

long log_size_4_var_079(long param0, long param1, long param2, long param3, long param4, long param5) {
    for(short i = 15; !(2874 >>> i); --i) {
    }
    return 0L;
}

long log_size_4_var_080(long param0, long param1, long param2, long param3, long param4, long param5) {
    return 0L;
}

long log_size_4_var_081(long param0, long param1, long param2, long param3, long param4, long param5) {
    long i;
    for(i = 63L; !(8952551725395654137L >>> i); --i) {
    }
    return ((unsigned long)((unsigned char)i + 47) | ((unsigned long)((i >>> 8L) & 0xffffffffffffffL) << 8)) - 109L;
}

long log_size_4_var_082(long param0, long param1, long param2, long param3, long param4, long param5) {
    return 0xa721672100000000L;
}

long log_size_4_var_083(long param0, long param1, long param2, long param3, long param4, long param5) {
    return 0L;
}

long log_size_4_var_084(long param0, long param1, long param2, long param3, long param4, long param5) {
    return 0L;
}

long log_size_4_var_085(long param0, long param1, long param2, long param3, long param4, long param5) {
    return 0L;
}

long log_size_4_var_086(long param0, long param1, long param2, long param3, long param4, long param5) {
    return 1669167418L;
}

long log_size_4_var_087(long param0, long param1, long param2, long param3, long param4, long param5) {
    return 0xf8792f8300000000L;
}

long log_size_4_var_088(long param0, long param1, long param2, long param3, long param4, long param5) {
    return 0L;
}

long log_size_4_var_089(long param0, long param1, long param2, long param3, long param4, long param5) {
    return 0x60cd3f6600000000L;
}

long log_size_4_var_090(long param0, long param1, long param2, long param3, long param4, long param5) {
    return 0L;
}

long log_size_4_var_091(long param0, long param1, long param2, long param3, long param4, long param5) {
    return 0L;
}

long log_size_4_var_092(long param0, long param1, long param2, long param3, long param4, long param5) {
    short i;
    for(i = 0; !((52929 >>> i) & 0x1); ++i) {
    }
    return (unsigned long)((unsigned int)__rol__(0x57d0e76eL, ((unsigned long)i | ((unsigned long)237387613893907L << 16)) & 0x1fL) & 0xd20f8e8d) + ((unsigned long)i | ((unsigned long)237387613893907L << 16)) + 2889309416357705460L;
}

long log_size_4_var_093(long param0, long param1, long param2, long param3, long param4, long param5) {
    return 0L;
}

long log_size_4_var_094(long param0, long param1, long param2, long param3, long param4, long param5) {
    int i;
    for(i = 0; !((-748926967 >>> i) & 0x1); ++i) {
    }
    long j;
    for(j = 63L; !(((unsigned long)i | ((unsigned long)-209642498 << 32)) >>> j); --j) {
    }
    return (unsigned long)(unsigned int)__rol__((unsigned long)(unsigned int)j, 25) + ((unsigned long)i | ((unsigned long)-209642498 << 32)) - 0x200a8f4L;
}

long log_size_4_var_095(long param0, long param1, long param2, long param3, long param4, long param5) {
    return 0L;
}

long log_size_4_var_096(long param0, long param1, long param2, long param3, long param4, long param5) {
    return 0L;
}

long log_size_4_var_097(long param0, long param1, long param2, long param3, long param4, long param5) {
    return 711846441L;
}

long log_size_4_var_098(long param0, long param1, long param2, long param3, long param4, long param5) {
    return 0L;
}

long log_size_4_var_099(long param0, long param1, long param2, long param3, long param4, long param5) {
    return 0L;
}

long main(long param0, long param1, long param2, long param3, long param4, long param5) {
    long v0 = log_size_4_var_000(param0, param1, param2, param3, param4, param5);
    long v1 = /*BAD_CALL!*/ log_size_4_var_001(param0, param1, param2, param3, param4, param5);
    long v2 = /*BAD_CALL!*/ log_size_4_var_002(param0, param1, param2, param3, param4, param5);
    long v3 = /*BAD_CALL!*/ log_size_4_var_003(param0, param1, param2, param3, param4, param5);
    long v4 = /*BAD_CALL!*/ log_size_4_var_004(param0, param1, param2, param3, param4, param5);
    long v5 = /*BAD_CALL!*/ log_size_4_var_005(param0, param1, param2, param3, param4, param5);
    long v6 = /*BAD_CALL!*/ log_size_4_var_006(param0, param1, param2, param3, param4, param5);
    long v7 = /*BAD_CALL!*/ log_size_4_var_007(param0, param1, param2, param3, param4, param5);
    long v8 = /*BAD_CALL!*/ log_size_4_var_008(param0, param1, param2, param3, param4, param5);
    long v9 = /*BAD_CALL!*/ log_size_4_var_009(param0, param1, param2, param3, param4, param5);
    long v10 = /*BAD_CALL!*/ log_size_4_var_010(param0, param1, param2, param3, param4, param5);
    long v11 = /*BAD_CALL!*/ log_size_4_var_011(param0, param1, param2, param3, param4, param5);
    long v12 = /*BAD_CALL!*/ log_size_4_var_012(param0, param1, param2, param3, param4, param5);
    long v13 = /*BAD_CALL!*/ log_size_4_var_013(param0, param1, param2, param3, param4, param5);
    long v14 = /*BAD_CALL!*/ log_size_4_var_014(param0, param1, param2, param3, param4, param5);
    long v15 = /*BAD_CALL!*/ log_size_4_var_015(param0, param1, param2, param3, param4, param5);
    long v16 = /*BAD_CALL!*/ log_size_4_var_016(param0, param1, param2, param3, param4, param5);
    long v17 = /*BAD_CALL!*/ log_size_4_var_017(param0, param1, param2, param3, param4, param5);
    long v18 = /*BAD_CALL!*/ log_size_4_var_018(param0, param1, param2, param3, param4, param5);
    long v19 = /*BAD_CALL!*/ log_size_4_var_019(param0, param1, param2, param3, param4, param5);
    long v20 = /*BAD_CALL!*/ log_size_4_var_020(param0, param1, param2, param3, param4, param5);
    long v21 = /*BAD_CALL!*/ log_size_4_var_021(param0, param1, param2, param3, param4, param5);
    long v22 = /*BAD_CALL!*/ log_size_4_var_022(param0, param1, param2, param3, param4, param5);
    long v23 = /*BAD_CALL!*/ log_size_4_var_023(param0, param1, param2, param3, param4, param5);
    long v24 = /*BAD_CALL!*/ log_size_4_var_024(param0, param1, param2, param3, param4, param5);
    long v25 = /*BAD_CALL!*/ log_size_4_var_025(param0, param1, param2, param3, param4, param5);
    long v26 = /*BAD_CALL!*/ log_size_4_var_026(param0, param1, param2, param3, param4, param5);
    long v27 = /*BAD_CALL!*/ log_size_4_var_027(param0, param1, param2, param3, param4, param5);
    long v28 = /*BAD_CALL!*/ log_size_4_var_028(param0, param1, param2, param3, param4, param5);
    long v29 = /*BAD_CALL!*/ log_size_4_var_029(param0, param1, param2, param3, param4, param5);
    long v30 = /*BAD_CALL!*/ log_size_4_var_030(param0, param1, param2, param3, param4, param5);
    long v31 = /*BAD_CALL!*/ log_size_4_var_031(param0, param1, param2, param3, param4, param5);
    long v32 = /*BAD_CALL!*/ log_size_4_var_032(param0, param1, param2, param3, param4, param5);
    long v33 = /*BAD_CALL!*/ log_size_4_var_033(param0, param1, param2, param3, param4, param5);
    long v34 = /*BAD_CALL!*/ log_size_4_var_034(param0, param1, param2, param3, param4, param5);
    long v35 = /*BAD_CALL!*/ log_size_4_var_035(param0, param1, param2, param3, param4, param5);
    long v36 = /*BAD_CALL!*/ log_size_4_var_036(param0, param1, param2, param3, param4, param5);
    long v37 = /*BAD_CALL!*/ log_size_4_var_037(param0, param1, param2, param3, param4, param5);
    long v38 = /*BAD_CALL!*/ log_size_4_var_038(param0, param1, param2, param3, param4, param5);
    long v39 = /*BAD_CALL!*/ log_size_4_var_039(param0, param1, param2, param3, param4, param5);
    long v40 = /*BAD_CALL!*/ log_size_4_var_040(param0, param1, param2, param3, param4, param5);
    long v41 = /*BAD_CALL!*/ log_size_4_var_041(param0, param1, param2, param3, param4, param5);
    long v42 = /*BAD_CALL!*/ log_size_4_var_042(param0, param1, param2, param3, param4, param5);
    long v43 = /*BAD_CALL!*/ log_size_4_var_043(param0, param1, param2, param3, param4, param5);
    long v44 = /*BAD_CALL!*/ log_size_4_var_044(param0, param1, param2, param3, param4, param5);
    long v45 = /*BAD_CALL!*/ log_size_4_var_045(param0, param1, param2, param3, param4, param5);
    long v46 = /*BAD_CALL!*/ log_size_4_var_046(param0, param1, param2, param3, param4, param5);
    long v47 = /*BAD_CALL!*/ log_size_4_var_047(param0, param1, param2, param3, param4, param5);
    long v48 = /*BAD_CALL!*/ log_size_4_var_048(param0, param1, param2, param3, param4, param5);
    long v49 = /*BAD_CALL!*/ log_size_4_var_049(param0, param1, param2, param3, param4, param5);
    long v50 = /*BAD_CALL!*/ log_size_4_var_050(param0, param1, param2, param3, param4, param5);
    long v51 = /*BAD_CALL!*/ log_size_4_var_051(param0, param1, param2, param3, param4, param5);
    long v52 = /*BAD_CALL!*/ log_size_4_var_052(param0, param1, param2, param3, param4, param5);
    long v53 = /*BAD_CALL!*/ log_size_4_var_053(param0, param1, param2, param3, param4, param5);
    long v54 = /*BAD_CALL!*/ log_size_4_var_054(param0, param1, param2, param3, param4, param5);
    long v55 = /*BAD_CALL!*/ log_size_4_var_055(param0, param1, param2, param3, param4, param5);
    long v56 = /*BAD_CALL!*/ log_size_4_var_056(param0, param1, param2, param3, param4, param5);
    long v57 = /*BAD_CALL!*/ log_size_4_var_057(param0, param1, param2, param3, param4, param5);
    long v58 = /*BAD_CALL!*/ log_size_4_var_058(param0, param1, param2, param3, param4, param5);
    long v59 = /*BAD_CALL!*/ log_size_4_var_059(param0, param1, param2, param3, param4, param5);
    long v60 = /*BAD_CALL!*/ log_size_4_var_060(param0, param1, param2, param3, param4, param5);
    long v61 = /*BAD_CALL!*/ log_size_4_var_061(param0, param1, param2, param3, param4, param5);
    long v62 = /*BAD_CALL!*/ log_size_4_var_062(param0, param1, param2, param3, param4, param5);
    long v63 = /*BAD_CALL!*/ log_size_4_var_063(param0, param1, param2, param3, param4, param5);
    long v64 = /*BAD_CALL!*/ log_size_4_var_064(param0, param1, param2, param3, param4, param5);
    long v65 = /*BAD_CALL!*/ log_size_4_var_065(param0, param1, param2, param3, param4, param5);
    long v66 = /*BAD_CALL!*/ log_size_4_var_066(param0, param1, param2, param3, param4, param5);
    long v67 = /*BAD_CALL!*/ log_size_4_var_067(param0, param1, param2, param3, param4, param5);
    long v68 = /*BAD_CALL!*/ log_size_4_var_068(param0, param1, param2, param3, param4, param5);
    long v69 = /*BAD_CALL!*/ log_size_4_var_069(param0, param1, param2, param3, param4, param5);
    long v70 = /*BAD_CALL!*/ log_size_4_var_070(param0, param1, param2, param3, param4, param5);
    long v71 = /*BAD_CALL!*/ log_size_4_var_071(param0, param1, param2, param3, param4, param5);
    long v72 = /*BAD_CALL!*/ log_size_4_var_072(param0, param1, param2, param3, param4, param5);
    long v73 = /*BAD_CALL!*/ log_size_4_var_073(param0, param1, param2, param3, param4, param5);
    long v74 = /*BAD_CALL!*/ log_size_4_var_074(param0, param1, param2, param3, param4, param5);
    long v75 = /*BAD_CALL!*/ log_size_4_var_075(param0, param1, param2, param3, param4, param5);
    long v76 = /*BAD_CALL!*/ log_size_4_var_076(param0, param1, param2, param3, param4, param5);
    long v77 = /*BAD_CALL!*/ log_size_4_var_077(param0, param1, param2, param3, param4, param5);
    long v78 = /*BAD_CALL!*/ log_size_4_var_078(param0, param1, param2, param3, param4, param5);
    long v79 = /*BAD_CALL!*/ log_size_4_var_079(param0, param1, param2, param3, param4, param5);
    long v80 = /*BAD_CALL!*/ log_size_4_var_080(param0, param1, param2, param3, param4, param5);
    long v81 = /*BAD_CALL!*/ log_size_4_var_081(param0, param1, param2, param3, param4, param5);
    long v82 = /*BAD_CALL!*/ log_size_4_var_082(param0, param1, param2, param3, param4, param5);
    long v83 = /*BAD_CALL!*/ log_size_4_var_083(param0, param1, param2, param3, param4, param5);
    long v84 = /*BAD_CALL!*/ log_size_4_var_084(param0, param1, param2, param3, param4, param5);
    long v85 = /*BAD_CALL!*/ log_size_4_var_085(param0, param1, param2, param3, param4, param5);
    long v86 = /*BAD_CALL!*/ log_size_4_var_086(param0, param1, param2, param3, param4, param5);
    long v87 = /*BAD_CALL!*/ log_size_4_var_087(param0, param1, param2, param3, param4, param5);
    long v88 = /*BAD_CALL!*/ log_size_4_var_088(param0, param1, param2, param3, param4, param5);
    long v89 = /*BAD_CALL!*/ log_size_4_var_089(param0, param1, param2, param3, param4, param5);
    long v90 = /*BAD_CALL!*/ log_size_4_var_090(param0, param1, param2, param3, param4, param5);
    long v91 = /*BAD_CALL!*/ log_size_4_var_091(param0, param1, param2, param3, param4, param5);
    long v92 = /*BAD_CALL!*/ log_size_4_var_092(param0, param1, param2, param3, param4, param5);
    long v93 = /*BAD_CALL!*/ log_size_4_var_093(param0, param1, param2, param3, param4, param5);
    long v94 = /*BAD_CALL!*/ log_size_4_var_094(param0, param1, param2, param3, param4, param5);
    long v95 = /*BAD_CALL!*/ log_size_4_var_095(param0, param1, param2, param3, param4, param5);
    long v96 = /*BAD_CALL!*/ log_size_4_var_096(param0, param1, param2, param3, param4, param5);
    long v97 = /*BAD_CALL!*/ log_size_4_var_097(param0, param1, param2, param3, param4, param5);
    long v98 = /*BAD_CALL!*/ log_size_4_var_098(param0, param1, param2, param3, param4, param5);
    long v99 = log_size_4_var_099(param0, param1, param2, param3, param4, param5);
    if((v1 + v10 + (v11 + v12) + (v13 + v14 + (v15 + v16)) + (v17 + v18 + (v19 + v2) + (v20 + v21 + (v22 + v23))) + (v24 + v25 + (v26 + v27) + (v28 + v29 + (v3 + v30)) + (v31 + v32 + (v33 + v34) + (v35 + v36 + (v37 + v38)))) + (v39 + v4 + (v40 + v41) + (v42 + v43 + (v44 + v45)) + (v46 + v47 + (v48 + v49) + (v5 + v50 + (v51 + v52))) + (v53 + v54 + (v55 + v56) + (v57 + v58 + (v59 + v6)) + (v60 + v61 + (v62 + v63) + (v64 + v65 + (v66 + v67))))) + (v68 + v69 + (v7 + v70) + (v71 + v72 + (v73 + v74)) + (v75 + v76 + (v77 + v78) + (v79 + v8 + (v80 + v81))) + (v82 + v83 + (v84 + v85) + (v86 + v87 + (v88 + v89)) + (v9 + v90 + (v91 + v92) + (v93 + v94 + (v95 + v96)))) + (v97 + v98 + (v99 + v0))))) {
        /*NO_RETURN*/ →__assert_fail("sum==0", "source_complex_with_base_100_funcs_of_size_16.c", 211, (char*)&__PRETTY_FUNCTION__.2713);
    }
    return 0L;
}

long register_tm_clones() {
    return 0L;
}

void r→__assert_fail(char* __assertion, char* __file, unsigned int __line, char* __function) {
    jump gvar_40B010;
}

void →__assert_fail(char* __assertion, char* __file, unsigned int __line, char* __function) {
    ptr___assert_fail[0]{r→__assert_fail}(__assertion, __file, (unsigned int)__line, __function);
}
