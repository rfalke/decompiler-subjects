
int __do_global_ctors_aux(int param0, int param1) {
    unsigned char v0 = *(int*)&__CTOR_LIST__;
    if(v0 != -1) {
        int v1 = &__CTOR_LIST__;
        do {
            v0();
            v0 = *(unsigned char*)(v1 - 4);
            v1 -= 4;
        }
        while(v0 != -1);
    }
    return param1;
}

int* __do_global_dtors_aux() {
    int* result;
    if(!completed.4583) {
        while(1) {
            result = *(int*)&p.4582;
            int v0 = *result;
            if(!v0) {
                break;
            }
            else {
                *(int*)&p.4582 = result + 1;
                v0{__DTOR_END__}();
            }
        }
        completed.4583 = 1;
    }
    return result;
}

void __libc_csu_fini() {
}

int* __libc_csu_init(int param0) {
    initializer_0(param0);
    return NULL;
}

int _start(int param0, int param1) {
    →__libc_start_main();
    hlt();
}

int call_gmon_start(int param0) {
    if(__gmon_start__) {
        →__gmon_start__();
    }
    return param0;
}

int cparam(int param0, int param1) {
    if(param0 < 0) {
        param1 = 0;
    }
    return param0 + param1;
}

int finalizer_0() {
    int result;
    __do_global_dtors_aux();
    return result;
}

unsigned char frame_dummy() {
    return 0;
}

// Stale decompilation - Refresh this view to re-decompile this code
int initializer_0(int param0) {
    int v0;
    call_gmon_start(param0);
    frame_dummy();
    return __do_global_ctors_aux(param0, v0);
}

int main(int param0) {
    int v0 = cparam(param0 - 3, 2);
    →printf("Result is %d\n", v0);
    return 0;
}

int r→__gmon_start__() {
    /*BAD_CALL!*/ sub_8048298();
}

int r→__libc_start_main() {
    /*BAD_CALL!*/ sub_8048298();
}

int r→printf(char* __format, ...) {
    /*BAD_CALL!*/ sub_8048298();
}

void sub_8048298() {
    jump gvar_804957C;
}

void sub_8048352() {
}

int →__gmon_start__() {
    return ptr___gmon_start__{r→__gmon_start__}();
}

int →__libc_start_main() {
    return ptr___libc_start_main{r→__libc_start_main}();
}

int →printf(char* __format, ...) {
    return ptr_printf[0]{r→printf}(__format);
}
