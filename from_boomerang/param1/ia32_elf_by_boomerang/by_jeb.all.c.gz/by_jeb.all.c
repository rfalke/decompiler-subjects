
int __do_global_ctors_aux(int param0, int param1) {
    int v0;
    int v1 = v0;
    int v2 = param1;
    unsigned int v3 = *(int*)&__CTOR_LIST__;
    if(v3 != -1) {
        int v4 = &__CTOR_LIST__;
        do {
            v3();
            v3 = *(unsigned int*)(v4 - 4);
            v4 -= 4;
        }
        while(v3 != -1);
    }
    return param1;
}

int* __do_global_dtors_aux() {
    int* result;
    if(!completed.4583) {
        while(1) {
            result = *(int*)&p.4582;
            int v0 = *result;
            if(!v0) {
                break;
            }
            else {
                *(int*)&p.4582 = result + 1;
                v0{__DTOR_END__}();
            }
        }
        completed.4583 = 1;
    }
    return result;
}

void __libc_csu_fini() {
}

int* __libc_csu_init(int param0) {
    initializer_0(param0);
    return NULL;
}

int _start(int param0, int param1) {
    int v0;
    char v1;
    void* ptr0;
    int v2;
    int v3 = 0;
    char v4 = 1;
    char v5 = 0;
    char v6 = 1;
    char v7 = 0;
    char v8 = 0;
    int v9 = v0;
    int* ptr1 = &v1;
    char v10 = &v0 ? 0: 1;
    char v11 = (int)&v0 < 0;
    char v12 = __parity__((unsigned char)&v0);
    char v13 = 0;
    char v14 = 0;
    int v15 = v2;
    int* ptr2 = &v15;
    int* ptr3 = &v15;
    int v16 = param1;
    int v17 = &__libc_csu_fini;
    int v18 = &__libc_csu_init;
    int* ptr4 = &v1;
    int v19 = &main;
    int* ptr5 = &ptr0;
    →__libc_start_main();
    hlt();
}

int call_gmon_start(int param0) {
    if(__gmon_start__) {
        →__gmon_start__();
    }
    return param0;
}

int cparam(unsigned int param0, int param1) {
    if(param0 >= 0x80000000) {
        param1 = 0;
    }
    return param0 + param1;
}

int finalizer_0() {
    int result;
    __do_global_dtors_aux();
    return result;
}

unsigned char frame_dummy() {
    return 0;
}

// Stale decompilation - Refresh this view to re-decompile this code
int initializer_0(int param0) {
    int v0;
    call_gmon_start(param0);
    frame_dummy();
    return __do_global_ctors_aux(param0, v0);
}

int main(unsigned int param0) {
    int v0 = cparam(param0 - 3, 2);
    →printf("Result is %d\n");
    return 0;
}

int sub_804829E() {
    return gvar_804957C();
}

void →__gmon_start__() {
    while(1) {
        /*BAD_CALL!*/ __gmon_start__();
        unsigned int* ptr0 = ptr0 - 1;
        *ptr0 = 16;
        --ptr0;
        *ptr0 = gvar_8049578;
    }
}

void →__libc_start_main() {
    while(1) {
        /*BAD_CALL!*/ __libc_start_main();
        unsigned int* ptr0 = ptr0 - 1;
        *ptr0 = 0;
        --ptr0;
        *ptr0 = gvar_8049578;
    }
}

void →printf(int param0) {
    unsigned int* ptr0;
    while(1) {
        /*BAD_CALL!*/ printf(*(char**)(ptr0 + 1));
        --ptr0;
        *ptr0 = 8;
        --ptr0;
        *ptr0 = gvar_8049578;
    }
}
