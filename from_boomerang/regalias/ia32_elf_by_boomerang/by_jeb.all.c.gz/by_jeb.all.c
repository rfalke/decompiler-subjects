
int __do_global_ctors_aux() {
    int result;
    unsigned int* ptr0 = (unsigned int*)&__CTOR_LIST__;
    for(unsigned char i = *(int*)&__CTOR_LIST__; i != -1; i = *ptr0) {
        --ptr0;
        i();
    }
    return result;
}

void __do_global_dtors_aux() {
}

void __i686.get_pc_thunk.bx() {
}

int __libc_csu_fini(int param0) {
    return finalizer_0(param0, &data_start);
}

int __libc_csu_init() {
    initializer_0();
    return &data_start;
}

int _start(int param0, int param1) {
    →__libc_start_main();
    hlt();
}

void* call_gmon_start() {
    void* result = __gmon_start__;
    if(result) {
        result = (void*)result();
    }
    return result;
}

int finalizer_0(int param0, int param1) {
    int result;
    __do_global_dtors_aux();
    return result;
}

unsigned char frame_dummy() {
    return 0;
}

int initializer_0() {
    call_gmon_start();
    frame_dummy();
    return __do_global_ctors_aux();
}

int main() {
    return →printf("%08X\n", 0x87653412);
}

void sub_8048268() {
    jump gvar_80495B0;
}

int sub_804827E() {
    /*BAD_CALL!*/ sub_8048268();
}

int sub_804828E() {
    /*BAD_CALL!*/ sub_8048268();
}

void sub_804832E() {
}

void →__libc_start_main() {
    while(1) {
    }
}

int →printf(char* __format, ...) {
    while(1) {
    }
}
