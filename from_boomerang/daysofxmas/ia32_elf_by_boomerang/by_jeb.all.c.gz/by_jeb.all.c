
int __do_global_ctors_aux(int param0, int param1) {
    int v0;
    int v1 = v0;
    int v2 = param1;
    unsigned int v3 = *(int*)&__CTOR_LIST__;
    unsigned int* ptr0 = (unsigned int*)&__CTOR_LIST__;
    while(v3 != -1) {
        --ptr0;
        v3();
        v3 = *ptr0;
    }
    return param1;
}

int* __do_global_dtors_aux() {
    int* result;
    return result;
}

int _start(int param0, int param1) {
    int v0;
    char v1;
    void* ptr0;
    int v2;
    int v3 = 0;
    char v4 = 1;
    char v5 = 0;
    char v6 = 1;
    char v7 = 0;
    char v8 = 0;
    int v9 = v0;
    int* ptr1 = &v1;
    char v10 = &v0 ? 0: 1;
    char v11 = (int)&v0 < 0;
    char v12 = __parity__((unsigned char)&v0);
    char v13 = 0;
    char v14 = 0;
    int v15 = v2;
    int* ptr2 = &v15;
    int* ptr3 = &v15;
    int v16 = param1;
    int v17 = &finalizer_0;
    int v18 = &initializer_0;
    int* ptr4 = &v1;
    int v19 = &main;
    int* ptr5 = &ptr0;
    int v20 = →__libc_start_main();
    hlt();
}

void* call_gmon_start() {
    void* result = __gmon_start__;
    if(result) {
        result = (void*)result();
    }
    return result;
}

int* finalizer_0(int param0, int param1) {
    return __do_global_dtors_aux();
}

unsigned char frame_dummy() {
    return 0;
}

int initializer_0() {
    int v0;
    int v1;
    call_gmon_start();
    frame_dummy();
    return __do_global_ctors_aux(v0, v1);
}

int main(unsigned char* param0, unsigned char* param1, unsigned char* param2) {
    unsigned char* ptr0;
    int result;
    unsigned char* ptr0;
    unsigned char* ptr1;
    int* ptr2;
    int result1;
    unsigned char* ptr3;
    int v0;
    int v1;
    unsigned char* ptr4;
    unsigned char* ptr5;
    unsigned char* ptr6;
    int v2 = v1;
    if((int)param0 > 1) {
        if((int)param0 <= 2) {
            int v3 = main(-86, 0, (int)(int*)(param2 + 1), (int)ptr4);
            int v4 = main(-87, (int)(int*)(1 - (int)param1), (int)(int*)(v3 + (int)param2), (int)ptr3);
            ptr4 = (unsigned char*)main(-79, -13, (int)(int*)(v4 + (int)param2), (int)ptr3);
        }
        if((int)param0 < (int)param1) {
            ptr4 = (unsigned char*)main((int)(int*)(param0 + 1), (int)param1, (int)param2, (int)ptr4);
        }
        unsigned char* ptr7 = (unsigned char*)main(-94, (int)(int*)(param0 - 27), (int)param2, (int)ptr4);
        if(!ptr7 || param0 != 2) {
            result1 = 16;
        }
        else if((int)param1 > 12) {
            result1 = 9;
        }
        else {
            ptr3 = ptr7;
            ptr2 = "%s %d %d\n";
            ptr1 = param1 + 1;
            ptr0 = (unsigned char*)0x2;
            result = main((int)ptr0, (int)ptr1, (int)ptr2, (int)ptr3);
            return result;
        }
    }
    else {
        if((int)param0 < 0) {
            if((int)param0 < -72) {
                ptr3 = param2;
                ptr2 = "@n\'+,#\'/*{}w+/w#cdnr/+,{}r/*de}+,/*{*+,/w{%+,/w#q#n+,/#{l,+,/n{n+,/+#n+,/#;#q#n+,/+k#;*+,/\'r :\'d*\'3,}{w+K w\'K:\'+}e#\';dq#\'l q#\'+d\'K#!/+k#;q#\'r}eKK#}w\'r}eKK{nl]\'/#;#q#n\'){)#}w\'){){nl]\'/+#n\';d}rw\' i;# ){nl]!/n{n#\'; r{#w\'r nc{nl]\'/#{l,+\'K {rw\' iK{;[{nl]\'/w#q#n\'wk nw\' iwk{KK{nl]!/w{%\'l##w#\' i; :{nl]\'/*{q#\'ld;r\'}{nlwb!/*de}\'c ;;{nl\'-{}rw]\'/+,}##\'*}#nc,\',#nw]\'/+kd\'+e}+;#\'rdq#w! nr\'/ \') }+}{rl#\'{n\' \')# }\'+}##(!!/";
                ptr1 = param0;
                ptr0 = param1;
            }
            else if((int)param0 >= -50) {
                ptr3 = ptr6;
                ptr2 = (int*)(param2 + 1);
                ptr1 = param1;
                unsigned char* ptr8 = param0;
                if(*param2 == 47) {
                    ptr8 = param0 + 1;
                }
                ptr0 = ptr8;
            }
            else if((unsigned int)*param2 != param1) {
                ptr3 = param0;
                ptr2 = (int*)(param2 + 1);
                ptr1 = param1;
                ptr0 = (unsigned char*)0xFFFFFFBF;
            }
            else {
                result = →_IO_putc((int)*(char*)(param2 + 31), stdout);
                return result;
            }
            result = main((int)ptr0, (int)ptr1, (int)ptr2, (int)ptr3);
            return result;
        }
        else if((int)param0 > 0) {
            ptr3 = ptr5;
            ptr2 = (int*)&gvar_8048532;
            ptr1 = (unsigned char*)0x2;
            ptr0 = (unsigned char*)0x2;
            result = main((int)ptr0, (int)ptr1, (int)ptr2, (int)ptr3);
            return result;
        }
        ptr5 = (unsigned int)*param2 | ((unsigned int)(int*)((int)(int*)((int)ptr5 >>> 8) & 0xffffff) << 8);
        result1 = 0;
        if((unsigned char)ptr5 != 47) {
            ptr3 = ptr4;
            ptr2 = (int*)(param2 + 1);
            int v5 = main(-61, (int)(unsigned char)ptr5, "!ek;dc i@bK\'(q)-[w]*%n+r3#l,{}:\nuwloca-O;m .vpbks,fxntdCeghiry", v0);
            int v6 = main(0, v5, (int)ptr2, (int)ptr3);
            if(v6) {
                return 1;
            }
        }
        else {
            return 1;
        }
    }
    return result1;
}

int sub_8048276() {
    return gvar_8049810();
}

int →_IO_putc(int __c, _IO_FILE* __fp) {
    return →_IO_putc(__c, __fp);
}

int →__libc_start_main() {
    return →__libc_start_main();
}
