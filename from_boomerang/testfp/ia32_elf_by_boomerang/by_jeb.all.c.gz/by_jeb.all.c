
int __do_global_ctors_aux(int param0, int param1) {
    unsigned char v0 = *(int*)&__CTOR_LIST__;
    if(v0 != -1) {
        int v1 = &__CTOR_LIST__;
        do {
            v0();
            v0 = *(unsigned char*)(v1 - 4);
            v1 -= 4;
        }
        while(v0 != -1);
    }
    return param1;
}

int* __do_global_dtors_aux() {
    int* result;
    if(!completed.4583) {
        while(1) {
            result = *(int*)&p.4582;
            int v0 = *result;
            if(!v0) {
                break;
            }
            else {
                *(int*)&p.4582 = result + 1;
                v0{__DTOR_END__}();
            }
        }
        completed.4583 = 1;
    }
    return result;
}

void __libc_csu_fini() {
}

int* __libc_csu_init(int param0) {
    initializer_0(param0);
    return NULL;
}

int _start(int param0, int param1) {
    →__libc_start_main();
    hlt();
}

int call_gmon_start(int param0) {
    if(__gmon_start__) {
        →__gmon_start__();
    }
    return param0;
}

int finalizer_0() {
    int result;
    __do_global_dtors_aux();
    return result;
}

unsigned char frame_dummy() {
    return 0;
}

// Stale decompilation - Refresh this view to re-decompile this code
int initializer_0(int param0) {
    int v0;
    call_gmon_start(param0);
    frame_dummy();
    return __do_global_ctors_aux(param0, v0);
}

int main() {
    __SyntheticTypeUnknownF v0;
    __SyntheticTypeUnknownF v1;
    __SyntheticTypeUnknownF v2;
    __SyntheticTypeUnknownF v3;
    __SyntheticTypeUnknownF v4;
    __SyntheticTypeUnknownF v5;
    →printf("Hello, world\n");
    res1 = (double)5 - (double)3;
    int v6 = *(int*)((char*)&res1 + 4);
    int v7 = *(int*)&res1;
    →printf("Result is %f\n", *(double*)&v7);
    v34[v35 + 1] = fsubr((double)3, (double)5);
    res1 = v3;
    int v8 = *(int*)((char*)&res1 + 4);
    int v9 = *(int*)&res1;
    →printf("Result is %f\n", *(double*)&v9);
    v34[v35] = fsubr((double)5, (double)3);
    res1 = v2;
    int v10 = *(int*)((char*)&res1 + 4);
    int v11 = *(int*)&res1;
    →printf("Result is %f\n", *(double*)&v11);
    res1 = (double)3 - (double)5;
    int v12 = *(int*)((char*)&res1 + 4);
    int v13 = *(int*)&res1;
    →printf("Result is %f\n", *(double*)&v13);
    v34[v35 + 1] = fsubrp((double)3, (double)5);
    res1 = v5;
    int v14 = *(int*)((char*)&res1 + 4);
    int v15 = *(int*)&res1;
    →printf("Result is %f\n", *(double*)&v15);
    res1 = (double)3 - (double)5;
    int v16 = *(int*)((char*)&res1 + 4);
    int v17 = *(int*)&res1;
    →printf("Result is %f\n", *(double*)&v17);
    res1 = (double)5 / (double)3;
    int v18 = *(int*)((char*)&res1 + 4);
    int v19 = *(int*)&res1;
    →printf("Result is %f\n", *(double*)&v19);
    v34[v35 + 1] = fdivr((double)3, (double)5);
    res1 = v4;
    int v20 = *(int*)((char*)&res1 + 4);
    int v21 = *(int*)&res1;
    →printf("Result is %f\n", *(double*)&v21);
    v34[v35] = fdivr((double)5, (double)3);
    res1 = v1;
    int v22 = *(int*)((char*)&res1 + 4);
    int v23 = *(int*)&res1;
    →printf("Result is %f\n", *(double*)&v23);
    res1 = (double)3 / (double)5;
    int v24 = *(int*)((char*)&res1 + 4);
    int v25 = *(int*)&res1;
    →printf("Result is %f\n", *(double*)&v25);
    v34[v35 + 1] = fdivrp((double)3, (double)5);
    res1 = v0;
    int v26 = *(int*)((char*)&res1 + 4);
    int v27 = *(int*)&res1;
    →printf("Result is %f\n", *(double*)&v27);
    res1 = (double)3 / (double)5;
    int v28 = *(int*)((char*)&res1 + 4);
    int v29 = *(int*)&res1;
    →printf("Result is %f\n", *(double*)&v29);
    res1 = (double)3 - (double)5;
    int v30 = *(int*)((char*)&res1 + 4);
    int v31 = *(int*)&res1;
    →printf("Result is %f\n", *(double*)&v31);
    5 = fisubr(5);
    res1 = (double)3;
    int v32 = *(int*)((char*)&res1 + 4);
    int v33 = *(int*)&res1;
    int result = →printf("Result is %f\n", *(double*)&v33);
    rdtsc();
    return result;
}

int r→__gmon_start__() {
    /*BAD_CALL!*/ sub_8048298();
}

int r→__libc_start_main() {
    /*BAD_CALL!*/ sub_8048298();
}

int r→printf(char* __format, ...) {
    /*BAD_CALL!*/ sub_8048298();
}

void sub_8048298() {
    jump gvar_80497B4;
}

void sub_8048352() {
}

int →__gmon_start__() {
    return ptr___gmon_start__{r→__gmon_start__}();
}

int →__libc_start_main() {
    return ptr___libc_start_main{r→__libc_start_main}();
}

int →printf(char* __format, ...) {
    return ptr_printf[0]{r→printf}(__format);
}
