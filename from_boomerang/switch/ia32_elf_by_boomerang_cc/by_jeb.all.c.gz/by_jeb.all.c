
void __fsr(int param0, int param1) {
}

void _mcount() {
}

int _start(int param0, FUNCPTR __func) {
    int v0;
    int v1;
    char v2;
    int v3;
    char v4;
    int v5 = 0;
    int v6 = 0;
    int* ptr0 = &v6;
    int v7 = &_DYNAMIC;
    char v8 = 0;
    char v9 = 0;
    char v10 = 1;
    char v11 = 0;
    char v12 = 0;
    int v13 = →atexit(__func);
    int v14 = →atexit((void __cdecl (*_)())&finalizer_0);
    int v15 = v0;
    int* ptr1 = (int*)(v15 * 4 + (int)&v4);
    _environ = (int*)(v15 * 4 + (int)&v4);
    int* ptr2 = ptr1;
    int* ptr3 = &v2;
    ___Argv = &v2;
    int* ptr4 = &v2;
    int v16 = v15;
    int v17 = →__fpstart();
    __fsr(v3, (int)__func);
    int v18 = initializer_0();
    int __status = main(v16);
    int* ptr5 = &v16;
    char v19 = &v0 == 16;
    char v20 = (int)&v1 < 0;
    char v21 = __parity__((unsigned char)&v0 - 16);
    char v22 = (int*)((int)(int*)((int)(int*)((int)(int*)((int)&v16 ^ 0xc) ^ (int)&v1) >>> 4) & 0x1);
    char v23 = (unsigned int)&v16 >= 0xfffffff4;
    char v24 = (int)(int*)((int)(int*)((int)&v1 ^ (int)&v16) & (int*)~(int)(int*)((int)&v16 ^ 0xc)) < 0;
    int* ptr6 = &ptr4;
    /*NO_RETURN*/ →exit(__status);
}

int finalizer_0() {
    int result;
    if(_ex_deregister) {
        result = _ex_deregister(&_ex_shared0);
    }
    return result;
}

int initializer_0() {
    int result;
    if(_ex_register) {
        result = _ex_register(&_ex_shared0);
    }
    return result;
}

int main(int param0) {
    switch((unsigned int)(param0 - 2)) {
        case 0: {
            →printf("Two!\n");
            return 0;
        }
        case 1: {
            →printf("Three!\n");
            return 0;
        }
        case 2: {
            →printf("Four!\n");
            return 0;
        }
        case 3: {
            →printf("Five!\n");
            return 0;
        }
        case 4: {
            break;
        }
        case 5: {
            →printf("Seven!\n");
            return 0;
        }
        default: {
            →printf("Other!\n");
            return 0;
        }
    }
    →printf("Six!\n");
    return 0;
}

int sub_804879A() {
    return gvar_8049A08();
}

int →__fpstart() {
    return →__fpstart();
}

int →atexit(FUNCPTR __func) {
    return →atexit(__func);
}

void →exit(int __status) {
    /*NO_RETURN*/ →exit(__status);
}

int →printf(char* __format, ...) {
    return →printf(__format);
}
