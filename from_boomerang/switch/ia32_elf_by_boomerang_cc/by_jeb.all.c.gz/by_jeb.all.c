
void __fsr(int param0, int param1) {
}

void _mcount() {
}

int _start(int param0, FUNCPTR __func) {
    int v0;
    int v1;
    char v2;
    char v3;
    int v4 = 0;
    int v5 = 0;
    →atexit(__func);
    →atexit((void __cdecl (*_)())&finalizer_0);
    int* ptr0 = (int*)(v0 * 4 + (int)&v2);
    _environ = (int*)(v0 * 4 + (int)&v2);
    int* ptr1 = ptr0;
    ___Argv = &v3;
    int* ptr2 = &v3;
    int v6 = v0;
    →__fpstart();
    __fsr(v1, (int)__func);
    initializer_0();
    int __status = main(v6);
    /*NO_RETURN*/ →exit(__status);
}

int finalizer_0() {
    int result;
    if(_ex_deregister) {
        result = _ex_deregister(&_ex_shared0);
    }
    return result;
}

int initializer_0() {
    int result;
    if(_ex_register) {
        result = _ex_register(&_ex_shared0);
    }
    return result;
}

int main(int param0) {
    switch((unsigned int)(param0 - 2)) {
        case 0: {
            →printf("Two!\n");
            return 0;
        }
        case 1: {
            →printf("Three!\n");
            return 0;
        }
        case 2: {
            →printf("Four!\n");
            return 0;
        }
        case 3: {
            →printf("Five!\n");
            return 0;
        }
        case 4: {
            break;
        }
        case 5: {
            →printf("Seven!\n");
            return 0;
        }
        default: {
            →printf("Other!\n");
            return 0;
        }
    }
    →printf("Six!\n");
    return 0;
}

int sub_8048795() {
    jump gvar_8049A08;
}

int sub_8048839() {
    call();
    hlt();
}

void →__fpstart() {
    while(1) {
    }
}

int →atexit(FUNCPTR __func) {
    while(1) {
    }
}

void →exit(int __status) {
    while(1) {
    }
}

int →printf(char* __format, ...) {
    while(1) {
    }
}
