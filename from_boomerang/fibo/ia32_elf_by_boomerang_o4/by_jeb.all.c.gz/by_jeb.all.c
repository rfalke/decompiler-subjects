
int __do_global_ctors_aux() {
    int result;
    int* ptr0 = (int*)&force_to_data;
    if(*(int*)&force_to_data != -1) {
        do {
            result = *ptr0;
            result();
            --ptr0;
        }
        while(*ptr0 != -1);
    }
    return result;
}

int __do_global_dtors_aux() {
    int result;
    int* ptr0 = (int*)&__DTOR_END__;
    if(*(int*)&__DTOR_END__) {
        do {
            result = *ptr0;
            result();
            ++ptr0;
        }
        while(*ptr0);
    }
    return result;
}

void _mcount() {
}

// Stale decompilation - Refresh this view to re-decompile this code
int _start(int param0, FUNCPTR param1) {
    int v0;
    FUNCPTR __func;
    char v1;
    int v2 = 0;
    int v3 = 0;
    →atexit((void __cdecl (*_)())&→_cleanup);
    →atexit(__func);
    →atexit((void __cdecl (*_)())&finalizer_0);
    _environ = (int*)(v0 * 4 + (int)&v1);
    initializer_0();
    →__fpstart();
    int __status = main();
    /*NO_RETURN*/ →exit(__status);
}

int fib(int param0) {
    int result;
    if(param0 > 1) {
        int v0 = fib(param0 - 1);
        int v1 = fib(param0 - 2);
        result = v1 + v0;
    }
    else {
        result = param0;
    }
    return result;
}

int finalizer_0() {
    return __do_global_dtors_aux();
}

void fini_dummy() {
}

void init_dummy() {
}

int initializer_0() {
    return __do_global_ctors_aux();
}

int main() {
    int v0;
    int v1;
    int v2;
    int v3;
    int v4;
    →printf("Input number: ", v4, v3);
    →scanf((char*)&gvar_80488C7, &v1, v2);
    if(v1 > 1) {
        int v5 = fib(v1 - 1);
        int v6 = fib(v1 - 2);
        v0 = v6 + v5;
    }
    else {
        v0 = v1;
    }
    →printf("fibonacci(%d) = %d\n", v1, v0);
    return 0;
}

int sub_804866D() {
    jump gvar_80498E8;
}

int sub_804873C() {
    call();
    hlt();
}

int sub_8048812() {
    int v0;
    int* ptr0;
    int v1;
    →printf("fibonacci(%d) = %d\n", *(ptr0 - 1), v1);
    jump v0;
}

void →__fpstart() {
    while(1) {
    }
}

void →_cleanup() {
    while(1) {
    }
}

int →atexit(FUNCPTR __func) {
    while(1) {
    }
}

void →exit(int __status) {
    while(1) {
    }
}

int →printf(char* __format, ...) {
    while(1) {
    }
}

int →scanf(char* __format, ...) {
    while(1) {
    }
}
