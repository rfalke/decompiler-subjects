
int* __do_global_ctors_aux() {
    int v0;
    int v1 = v0;
    int* result = (int*)&__CTOR_END__;
    unsigned int* ptr0 = (unsigned int*)&force_to_data;
    if(*(int*)&force_to_data != -1) {
        do {
            result = (int*)*ptr0();
            --ptr0;
        }
        while(*ptr0 != -1);
    }
    return result;
}

int* __do_global_dtors_aux() {
    int v0;
    int v1 = v0;
    int* result = (int*)&__DTOR_LIST__;
    unsigned int* ptr0 = (unsigned int*)&__DTOR_END__;
    if(*(int*)&__DTOR_END__) {
        do {
            result = (int*)*ptr0();
            ++ptr0;
        }
        while(*ptr0);
    }
    return result;
}

void _mcount() {
}

// Stale decompilation - Refresh this view to re-decompile this code
int _start(int param0, FUNCPTR param1) {
    int v0;
    int v1;
    int v2;
    char v3;
    char v4;
    int v5 = 0;
    int v6 = 0;
    int* ptr0 = &v6;
    FUNCPTR __func = param1;
    int v7 = &→_cleanup;
    char v8 = 0;
    char v9 = 0;
    char v10 = 0;
    char v11 = 0;
    char v12 = 0;
    int v13 = →atexit((void __cdecl (*_)())&→_cleanup);
    int* ptr1 = &v0;
    char v14 = &v1 == 12;
    char v15 = (int)&__func < 0;
    char v16 = __parity__((unsigned char)&v1 - 12);
    char v17 = (int*)((int)(int*)((int)(int*)((int)(int*)((int)&v0 ^ 0x4) ^ (int)&__func) >>> 4) & 0x1);
    char v18 = (unsigned int)&v0 >= 0xfffffffc;
    char v19 = (int)(int*)((int)(int*)((int)&__func ^ (int)&v0) & (int*)~(int)(int*)((int)&v0 ^ 0x4)) < 0;
    int v20 = &_DYNAMIC;
    char v21 = 0;
    char v22 = 0;
    char v23 = 0;
    char v24 = 0;
    char v25 = 0;
    int v26 = →atexit(__func);
    int v27 = →atexit((void __cdecl (*_)())&finalizer_0);
    int v28 = v1;
    int* ptr2 = (int*)(v28 * 4 + (int)&v4);
    _environ = (int*)(v28 * 4 + (int)&v4);
    int* ptr3 = &v3;
    int v29 = v28;
    int* ptr4 = initializer_0();
    int v30 = →__fpstart();
    int __status = main();
    int* ptr5 = &v29;
    char v31 = &v1 == 16;
    char v32 = (int)&v0 < 0;
    char v33 = __parity__((unsigned char)&v1 - 16);
    char v34 = (int*)((int)(int*)((int)(int*)((int)(int*)((int)&v29 ^ 0xc) ^ (int)&v0) >>> 4) & 0x1);
    char v35 = (unsigned int)&v29 >= 0xfffffff4;
    char v36 = (int)(int*)((int)(int*)((int)&v0 ^ (int)&v29) & (int*)~(int)(int*)((int)&v29 ^ 0xc)) < 0;
    int* ptr6 = &v2;
    /*NO_RETURN*/ →exit(__status);
}

unsigned int fib(unsigned int param0) {
    unsigned int result;
    if((int)param0 > 1) {
        int v0 = fib(param0 - 1);
        int v1 = fib(param0 - 2);
        result = (unsigned int)(v1 + v0);
    }
    else {
        result = param0;
    }
    return result;
}

int* finalizer_0() {
    return __do_global_dtors_aux();
}

void fini_dummy() {
}

void init_dummy() {
}

int* initializer_0() {
    return __do_global_ctors_aux();
}

int main() {
    unsigned int v0;
    unsigned int v1;
    int v2;
    int v3;
    int v4;
    →printf("Input number: ", v4, v3);
    →scanf((char*)&gvar_80488C7, &v1, v2);
    if((int)v1 > 1) {
        unsigned int v5 = fib(v1 - 1);
        unsigned int v6 = fib(v1 - 2);
        v0 = v6 + v5;
    }
    else {
        v0 = v1;
    }
    →printf("fibonacci(%d) = %d\n", v1, v0);
    return 0;
}

int sub_8048672() {
    return gvar_80498E8();
}

int →__fpstart() {
    return →__fpstart();
}

int →_cleanup() {
    return →_cleanup();
}

int →atexit(FUNCPTR __func) {
    return →atexit(__func);
}

void →exit(int __status) {
    /*NO_RETURN*/ →exit(__status);
}

int →printf(char* __format, ...) {
    return →printf(__format);
}

int →scanf(char* __format, ...) {
    return →scanf(__format);
}
