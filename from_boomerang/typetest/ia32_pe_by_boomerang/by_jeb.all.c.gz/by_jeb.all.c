
void start() {
    int v0;
    char v1;
    char v2;
    int v3;
    char v4;
    char v5;
    char v6;
    int v7;
    int v8 = &gvar_402258;
    int v9 = &→MSVCRT.dll!_except_handler3;
    int v10 = *(int*)__FS_BASE;
    *(int**)__FS_BASE = &v10;
    int v11 = v7;
    int* ptr0 = &v0;
    int v12 = 0;
    _set_app_type(2);
    gvar_40312C = 0xffffffff;
    gvar_403130 = 0xffffffff;
    int* ptr1 = __p__fmode();
    ptr1[0] = gvar_403120;
    int* ptr2 = __p__commode();
    ptr2[0] = gvar_40311C;
    gvar_403128 = *(unsigned int*)0x451E;
    sub_401BE0();
    if(!gvar_403040) {
        __setusermatherr((_UserMathErrorFunctionPointer)&gvar_401BD0);
    }
    sub_401BB0();
    →MSVCRT.dll!_initterm((_PVFV*)0x403010, (_PVFV*)0x403014);
    unsigned int v13 = gvar_403118;
    MSVCRT.dll!__getmainargs((int)&v4, (int)&v5, (int)&v1, (int)gvar_403114, (int)&v13);
    →MSVCRT.dll!_initterm((_PVFV*)0x403000, (_PVFV*)0x40300C);
    char** i = __p__acmdln();
    char* ptr3 = i[0];
    if(ptr3[0] == 34) {
        do {
            ++ptr3;
            i = (unsigned int)ptr3[0] | ((unsigned int)(int*)((int)(int*)((int)i >>> 8) & 0xffffff) << 8);
        }
        while(ptr3[0] && (unsigned char)i != 34);
        if(ptr3[0] == 34) {
            ++ptr3;
        }
    }
    else {
        while((unsigned char)ptr3[0] > 32) {
            ++ptr3;
        }
    }
    for(i = (unsigned int)ptr3[0] | ((unsigned int)(int*)((int)(int*)((int)i >>> 8) & 0xffffff) << 8); ptr3[0] && (unsigned char)ptr3[0] <= 32; i = (unsigned int)ptr3[0] | ((unsigned int)(int*)((int)(int*)((int)i >>> 8) & 0xffffff) << 8)) {
        ++ptr3;
    }
    *(int*)&v6 = 0;
    /*BAD_CALL!*/ GetStartupInfoA(&v2);
    HMODULE v14 = GetModuleHandleA(NULL);
    int _Code = sub_401BFC((int)v14, 0, (int)ptr3, (int)(v6 & 0x1 ? (void*)(unsigned short)v3: (void*)0xA));
    int v15 = _Code;
    /*NO_RETURN*/ exit(_Code);
}

unsigned int sub_401BB0() {
    return →MSVCRT.dll!_controlfp(0x10000, 0x30000);
}

void sub_401BE0() {
}

int sub_401BFC(int param0, int param1, int param2, int param3) {
    int v0 = param3;
    int v1 = param3;
    int v2 = param2;
    int v3 = param2;
    int v4 = param1;
    int v5 = param1;
    int v6 = param0;
    int v7 = param0;
    int v8 = →MFC42.DLL!#1576();
    int v9 = v7;
    int* ptr0 = &param0;
    jump v9;
}

int →MFC42.DLL!#1089() {
    return MFC42.DLL!#1089();
}

int →MFC42.DLL!#1146() {
    return MFC42.DLL!#1146();
}

int →MFC42.DLL!#1168() {
    return MFC42.DLL!#1168();
}

int →MFC42.DLL!#1576() {
    return MFC42.DLL!#1576();
}

int →MFC42.DLL!#1641() {
    return MFC42.DLL!#1641();
}

int →MFC42.DLL!#1727() {
    return MFC42.DLL!#1727();
}

int →MFC42.DLL!#1775() {
    return MFC42.DLL!#1775();
}

int →MFC42.DLL!#2055() {
    return MFC42.DLL!#2055();
}

int →MFC42.DLL!#2124() {
    return MFC42.DLL!#2124();
}

int →MFC42.DLL!#2385() {
    return MFC42.DLL!#2385();
}

int →MFC42.DLL!#2396() {
    return MFC42.DLL!#2396();
}

int →MFC42.DLL!#2414() {
    return MFC42.DLL!#2414();
}

int →MFC42.DLL!#2446() {
    return MFC42.DLL!#2446();
}

int →MFC42.DLL!#2512() {
    return MFC42.DLL!#2512();
}

int →MFC42.DLL!#2514() {
    return MFC42.DLL!#2514();
}

int →MFC42.DLL!#2554() {
    return MFC42.DLL!#2554();
}

int →MFC42.DLL!#2621() {
    return MFC42.DLL!#2621();
}

int →MFC42.DLL!#2648() {
    return MFC42.DLL!#2648();
}

int →MFC42.DLL!#2725() {
    return MFC42.DLL!#2725();
}

int →MFC42.DLL!#283() {
    return MFC42.DLL!#283();
}

int →MFC42.DLL!#2976() {
    return MFC42.DLL!#2976();
}

int →MFC42.DLL!#2982() {
    return MFC42.DLL!#2982();
}

int →MFC42.DLL!#2985() {
    return MFC42.DLL!#2985();
}

int →MFC42.DLL!#3079() {
    return MFC42.DLL!#3079();
}

int →MFC42.DLL!#3081() {
    return MFC42.DLL!#3081();
}

int →MFC42.DLL!#3136() {
    return MFC42.DLL!#3136();
}

int →MFC42.DLL!#3147() {
    return MFC42.DLL!#3147();
}

int →MFC42.DLL!#324() {
    return MFC42.DLL!#324();
}

int →MFC42.DLL!#3259() {
    return MFC42.DLL!#3259();
}

int →MFC42.DLL!#3262() {
    return MFC42.DLL!#3262();
}

int →MFC42.DLL!#3346() {
    return MFC42.DLL!#3346();
}

int →MFC42.DLL!#3597() {
    return MFC42.DLL!#3597();
}

int →MFC42.DLL!#3619() {
    return MFC42.DLL!#3619();
}

int →MFC42.DLL!#3626() {
    return MFC42.DLL!#3626();
}

int →MFC42.DLL!#3663() {
    return MFC42.DLL!#3663();
}

int →MFC42.DLL!#3738() {
    return MFC42.DLL!#3738();
}

int →MFC42.DLL!#3749() {
    return MFC42.DLL!#3749();
}

int →MFC42.DLL!#3798() {
    return MFC42.DLL!#3798();
}

int →MFC42.DLL!#3825() {
    return MFC42.DLL!#3825();
}

int →MFC42.DLL!#3830() {
    return MFC42.DLL!#3830();
}

int →MFC42.DLL!#3831() {
    return MFC42.DLL!#3831();
}

int →MFC42.DLL!#3922() {
    return MFC42.DLL!#3922();
}

int →MFC42.DLL!#4078() {
    return MFC42.DLL!#4078();
}

int →MFC42.DLL!#4079() {
    return MFC42.DLL!#4079();
}

int →MFC42.DLL!#4080() {
    return MFC42.DLL!#4080();
}

int →MFC42.DLL!#4133() {
    return MFC42.DLL!#4133();
}

int →MFC42.DLL!#4297() {
    return MFC42.DLL!#4297();
}

int →MFC42.DLL!#4353() {
    return MFC42.DLL!#4353();
}

int →MFC42.DLL!#4376() {
    return MFC42.DLL!#4376();
}

int →MFC42.DLL!#4407() {
    return MFC42.DLL!#4407();
}

int →MFC42.DLL!#4424() {
    return MFC42.DLL!#4424();
}

int →MFC42.DLL!#4425() {
    return MFC42.DLL!#4425();
}

int →MFC42.DLL!#4441() {
    return MFC42.DLL!#4441();
}

int →MFC42.DLL!#4465() {
    return MFC42.DLL!#4465();
}

int →MFC42.DLL!#4486() {
    return MFC42.DLL!#4486();
}

int →MFC42.DLL!#4622() {
    return MFC42.DLL!#4622();
}

int →MFC42.DLL!#4627() {
    return MFC42.DLL!#4627();
}

int →MFC42.DLL!#4673() {
    return MFC42.DLL!#4673();
}

int →MFC42.DLL!#4698() {
    return MFC42.DLL!#4698();
}

int →MFC42.DLL!#470() {
    return MFC42.DLL!#470();
}

int →MFC42.DLL!#4710() {
    return MFC42.DLL!#4710();
}

int →MFC42.DLL!#472() {
    return MFC42.DLL!#472();
}

int →MFC42.DLL!#4837() {
    return MFC42.DLL!#4837();
}

int →MFC42.DLL!#4853() {
    return MFC42.DLL!#4853();
}

int →MFC42.DLL!#4998() {
    return MFC42.DLL!#4998();
}

int →MFC42.DLL!#5065() {
    return MFC42.DLL!#5065();
}

int →MFC42.DLL!#5163() {
    return MFC42.DLL!#5163();
}

int →MFC42.DLL!#5199() {
    return MFC42.DLL!#5199();
}

int →MFC42.DLL!#5241() {
    return MFC42.DLL!#5241();
}

int →MFC42.DLL!#5261() {
    return MFC42.DLL!#5261();
}

int →MFC42.DLL!#5265() {
    return MFC42.DLL!#5265();
}

int →MFC42.DLL!#5277() {
    return MFC42.DLL!#5277();
}

int →MFC42.DLL!#5280() {
    return MFC42.DLL!#5280();
}

int →MFC42.DLL!#5289() {
    return MFC42.DLL!#5289();
}

int →MFC42.DLL!#5300() {
    return MFC42.DLL!#5300();
}

int →MFC42.DLL!#5302() {
    return MFC42.DLL!#5302();
}

int →MFC42.DLL!#5307() {
    return MFC42.DLL!#5307();
}

int →MFC42.DLL!#561() {
    return MFC42.DLL!#561();
}

int →MFC42.DLL!#5714() {
    return MFC42.DLL!#5714();
}

int →MFC42.DLL!#5731() {
    return MFC42.DLL!#5731();
}

int →MFC42.DLL!#5788() {
    return MFC42.DLL!#5788();
}

int →MFC42.DLL!#5789() {
    return MFC42.DLL!#5789();
}

int →MFC42.DLL!#5875() {
    return MFC42.DLL!#5875();
}

int →MFC42.DLL!#6021() {
    return MFC42.DLL!#6021();
}

int →MFC42.DLL!#6052() {
    return MFC42.DLL!#6052();
}

int →MFC42.DLL!#6170() {
    return MFC42.DLL!#6170();
}

int →MFC42.DLL!#6374() {
    return MFC42.DLL!#6374();
}

int →MFC42.DLL!#6375() {
    return MFC42.DLL!#6375();
}

int →MFC42.DLL!#6376() {
    return MFC42.DLL!#6376();
}

int →MFC42.DLL!#641() {
    return MFC42.DLL!#641();
}

int →MFC42.DLL!#755() {
    return MFC42.DLL!#755();
}

int →MFC42.DLL!#815() {
    return MFC42.DLL!#815();
}

int →MFC42.DLL!#825() {
    return MFC42.DLL!#825();
}

int →MSVCRT.dll!_XcptFilter() {
    return MSVCRT.dll!_XcptFilter();
}

int →MSVCRT.dll!__CxxFrameHandler() {
    return MSVCRT.dll!__CxxFrameHandler();
}

int →MSVCRT.dll!__dllonexit() {
    return MSVCRT.dll!__dllonexit();
}

unsigned int →MSVCRT.dll!_controlfp(unsigned int _NewValue, unsigned int _Mask) {
    return _controlfp(_NewValue, _Mask);
}

int →MSVCRT.dll!_except_handler3() {
    return MSVCRT.dll!_except_handler3();
}

int →MSVCRT.dll!_ftol() {
    return MSVCRT.dll!_ftol();
}

void →MSVCRT.dll!_initterm(_PVFV* _First, _PVFV* _Last) {
    _initterm(_First, _Last);
}
