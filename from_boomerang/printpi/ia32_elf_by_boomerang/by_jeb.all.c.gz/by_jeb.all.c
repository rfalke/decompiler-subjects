
int __do_global_ctors_aux(int param0, int param1) {
    unsigned char v0 = *(int*)&__CTOR_LIST__;
    unsigned int* ptr0 = (unsigned int*)&__CTOR_LIST__;
    while(v0 != -1) {
        --ptr0;
        v0();
        v0 = *ptr0;
    }
    return param1;
}

void __do_global_dtors_aux() {
}

void __libc_csu_fini() {
    // Decompilation error
}

int __libc_csu_init() {
    initializer_0();
    return 0;
}

int _start(int param0, int param1) {
    →__libc_start_main();
    hlt();
}

void* call_gmon_start() {
    void* result = __gmon_start__;
    if(result) {
        result = (void*)result();
    }
    return result;
}

int finalizer_0(int param0, int param1) {
    int result;
    __do_global_dtors_aux();
    return result;
}

unsigned char frame_dummy() {
    return 0;
}

int initializer_0() {
    int v0;
    int v1;
    call_gmon_start();
    frame_dummy();
    return __do_global_ctors_aux(v0, v1);
}

int main() {
    →printf("Pi is about %.5f\n", 3.141592502593994);
    return 0;
}

void sub_8048248() {
    jump gvar_8049514;
}

int sub_804825E() {
    /*BAD_CALL!*/ sub_8048248();
}

int sub_804826E() {
    /*BAD_CALL!*/ sub_8048248();
}

void sub_80482FA() {
}

int sub_80483B2() {
    int result;
    int v0;
    int v1;
    int v2;
    do {
        *(int*)(v1 * 4 + (int)&data_start)();
        v0 = v1;
        --v1;
    }
    while(v0);
    finalizer_0(v2, 0);
    return result;
}

void →__libc_start_main() {
    while(1) {
    }
}

int →printf(char* __format, ...) {
    while(1) {
    }
}
