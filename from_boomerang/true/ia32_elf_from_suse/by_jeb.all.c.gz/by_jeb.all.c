
int __do_global_ctors_aux(int param0, int param1) {
    unsigned int* ptr0 = (unsigned int*)&__CTOR_LIST__;
    for(unsigned char i = *(int*)&__CTOR_LIST__; i != -1; i = *ptr0) {
        --ptr0;
        i();
    }
    return param1;
}

int __do_global_dtors_aux() {
    int result;
    return result;
}

void __i686.get_pc_thunk.bx() {
}

int __libc_csu_fini() {
    return finalizer_0();
}

int __libc_csu_init(int param0, int param1) {
    initializer_0(param0, param1);
    return &__CTOR_LIST__;
}

int _start(int param0, int param1) {
    →__libc_start_main();
    hlt();
}

int atexit(FUNCPTR __func) {
    return →__cxa_atexit();
}

int call_gmon_start(int param0, int param1) {
    void* ptr0 = __gmon_start__;
    if(ptr0) {
        ptr0();
    }
    return param1;
}

void* clone_quoting_options(int* param0) {
    int* ptr0 = →__errno_location();
    int v0 = ptr0[0];
    void* result = xmalloc(36);
    int* ptr1 = param0;
    if(!ptr1) {
        ptr1 = (int*)&default_quoting_options;
    }
    *(int*)result = *ptr1;
    *(int*)((int)result + 4) = *(ptr1 + 1);
    *(int*)((int)result + 8) = *(ptr1 + 2);
    *(int*)((int)result + 12) = *(ptr1 + 3);
    *(int*)((int)result + 16) = *(ptr1 + 4);
    *(int*)((int)result + 20) = *(ptr1 + 5);
    *(int*)((int)result + 24) = *(ptr1 + 6);
    *(int*)((int)result + 28) = *(ptr1 + 7);
    *(int*)((int)result + 32) = *(ptr1 + 8);
    ptr0[0] = v0;
    return result;
}

size_t close_stdout() {
    size_t result1;
    int v0;
    int v1;
    int v2;
    int v3;
    int result;
    FILE* __fp = stdout;
    int __errnum = (unsigned int)((__fp->_flags >>> 5) & 0x1) < 1 ? -1: 0;
    if(__errnum) {
        result1 = →__fpending(__fp);
        if(result1) {
            __fp = stdout;
            goto loc_8048CB4;
        }
    }
    else {
    loc_8048CB4:
        result1 = (size_t)→fclose(__fp);
        if(result1) {
            result1 = (size_t)→__errno_location();
            __errnum = *(int*)result1;
        }
        if(__errnum >= 0) {
            char* ptr0 = →dcgettext(NULL, "write error", 5);
            int v4 = file_name;
            if(v4) {
                int v5 = quotearg_colon(v4);
                →error(exit_failure, __errnum, (char*)&gvar_804A0B8, v5, ptr0);
            }
            else {
                →error(exit_failure, __errnum, (char*)&gvar_804A0BC, ptr0, v0, v1, v2, v3);
                return result;
            }
        }
    }
    return result1;
}

unsigned int close_stdout_set_file_name(unsigned int param0) {
    file_name = param0;
    return param0;
}

int finalizer_0() {
    return __do_global_dtors_aux();
}

int frame_dummy(int param0) {
    int result;
    if(*(int*)&__JCR_LIST__) {
        result = 0;
    }
    return result;
}

unsigned char get_quoting_style(unsigned int* param0) {
    if(param0) {
        return *param0;
    }
    return *(int*)&default_quoting_options;
}

char* gettext_quote(int param0, int param1) {
    int v0;
    char* __msgid;
    char* ptr0 = →dcgettext(NULL, __msgid, 5);
    char* result = ptr0;
    if(((unsigned char)(((unsigned int)(ptr0 == __msgid ? 1: 0) | ((unsigned int)((param1 >>> 8) & 0xffffff) << 8)) & ((unsigned int)(v0 == 6 ? 1: 0) | ((unsigned int)(int*)((int)(int*)((int)ptr0 >>> 8) & 0xffffff) << 8))) & 0x1)) {
        result = (char*)&gvar_804A3BC;
    }
    return result;
}

int initializer_0(int param0, int param1) {
    call_gmon_start(param0, param1);
    frame_dummy(param0);
    return __do_global_ctors_aux(param0, param1);
}

int main(int param0, unsigned int* param1) {
    int v0;
    int v1 = v0;
    unsigned int* ptr0 = param1;
    unsigned int v2 = *ptr0;
    int v3 = 6;
    program_name = v2;
    →setlocale(6, (char*)0x804A03C);
    →bindtextdomain("coreutils", "/usr/share/locale");
    →textdomain("coreutils");
    atexit((void __cdecl (*_)())&close_stdout);
    if(param0 != 2) {
    loc_8048BCE:
        /*NO_RETURN*/ →exit(0);
    }
    char* ptr1 = →getenv("POSIXLY_CORRECT");
    char v4 = ptr1 ? 0: 1;
    if(v4) {
        char* ptr2 = "--help";
        char* ptr3 = *(ptr0 + 1);
        char* ptr4 = *(ptr0 + 1);
        int v5 = 7;
        while(v5 != 0) {
            v4 = *ptr4 == *ptr2;
            ++ptr4;
            ++ptr2;
            --v5;
            if(!v4) {
                break;
            }
        }
        if(v4) {
            /*NO_RETURN*/ usage(0);
        }
        char* ptr5 = ptr3;
        char* ptr6 = "--version";
        int v6 = 10;
        while(v6 != 0) {
            v4 = *ptr5 == *ptr6;
            ++ptr5;
            ++ptr6;
            --v6;
            if(!v4) {
                break;
            }
        }
        if(v4) {
            int v7 = 0;
            FILE* ptr7 = stdout;
            ptr0 = (unsigned int*)&gvar_804A099;
            int v8 = "Jim Meyering";
            version_etc(ptr7, "true", &gvar_804A099, "5.2.1");
        }
    }
    goto loc_8048BCE;
}

int quotearg(int param0) {
    return quotearg_n(0);
}

// Stale decompilation - Refresh this view to re-decompile this code
int quotearg_buffer(int param0, int param1, int param2, int param3, int* param4) {
    int v0;
    int* ptr0 = param4;
    int v1 = v0;
    if(!ptr0) {
        ptr0 = (int*)&default_quoting_options;
    }
    int* ptr1 = →__errno_location();
    int v2 = ptr1[0];
    int result = quotearg_buffer_restyled(param3, *ptr0, (int)ptr0);
    ptr1[0] = v2;
    return result;
}

size_t quotearg_buffer_restyled(size_t param0, int param1, int param2) {
    unsigned int v0;
    char v1;
    size_t v2;
    size_t v3;
    size_t v4;
    unsigned int v5;
    size_t v6;
    size_t v7;
    wint_t __wc;
    size_t v8;
    size_t v9;
    int v10;
    char v11;
    size_t v12 = v8;
    size_t v13 = v9;
    char* __s1 = (char*)v10;
    size_t result = 0;
    size_t v14 = 0;
    size_t v15 = 0;
    int v16 = 0;
    size_t v17 = /*BAD_CALL!*/ →__ctype_get_mb_cur_max();
    int v18 = v17 - 1 ? 0: 1;
    if((unsigned int)param1 <= 6) {
        switch(param1) {
            case 0: 
            case 1: {
                size_t v19 = 0;
                goto loc_8048FA4;
            }
            case 2: {
                if(v13 > 0) {
                    v6 = v12;
                    *(char*)v6 = 39;
                }
                result = 1;
                v14 = &gvar_804A3C0;
                v15 = 1;
                size_t v19 = 0;
                goto loc_8048FA4;
            }
            case 3: {
                break;
            }
            case 4: {
                v16 = 1;
                size_t v19 = 0;
                goto loc_8048FA4;
            }
            case 5: 
            case 6: {
                v7 = (size_t)gettext_quote(v10, param1);
                char* __s = gettext_quote(v10, param1);
                v14 = v7;
                if(*(char*)v7) {
                    do {
                        if(result < v13) {
                            *(char*)(result + v12) = *(char*)v14;
                        }
                        ++v14;
                        ++result;
                    }
                    while(*(char*)v14);
                }
                v16 = 1;
                v14 = (size_t)__s;
                v15 = →strlen(__s);
                size_t v19 = 0;
                goto loc_8048FA4;
            }
            case 8: 
            case 9: 
            case 10: 
            case 11: 
            case 12: 
            case 13: {
                goto loc_8049025;
            }
            default: {
                throw 0;
            }
        }
        v6 = v13;
        if(v6 > 0) {
            *(char*)v12 = 34;
        }
        result = 1;
        v16 = 1;
        v14 = &gvar_804A3BC;
        v15 = 1;
        size_t v19 = 0;
        goto loc_8048FA4;
    }
    else {
        size_t v19 = 0;
        goto loc_8048FA4;
    loc_8049025:
        if(v18) {
            v5 = 1;
            unsigned short** ptr0 = →__ctype_b_loc();
            v4 = (size_t)((unsigned int)ptr0[0][(unsigned int)v11] & 0x4000);
            v3 = (size_t)((unsigned int)ptr0[0][(unsigned int)v11] & 0x4000);
        }
        else {
            int v20 = 0;
            int v21 = 0;
            v5 = 0;
            v3 = 1;
            if(param0 == -1) {
                param0 = →strlen(__s1);
            }
            do {
                mbstate_t* __p = &v20;
                unsigned int v22 = v5 + v19;
                size_t __n = param0 - v22;
                char* __s2 = &__s1[v22];
                char* ptr1 = &__s1[v22];
                v4 = /*BAD_CALL!*/ →mbrtowc(&__wc, __s2, __n, __p);
                if(!v4) {
                    break;
                }
                else if(v4 == -2) {
                    char v23 = v22 < param0;
                    v3 = 0;
                    if(v23 && ptr1[0]) {
                        do {
                            ++v5;
                            v4 = (size_t)(v5 + v19);
                        }
                        while(v4 < param0 && __s1[v4]);
                    }
                    break;
                }
                else if(v4 == -1) {
                    v3 = 0;
                    break;
                }
                else {
                    int v24 = →iswprint(__wc);
                    v5 = (unsigned int)(v4 + v5);
                    v3 = (size_t)((0 - (v24 ? 1: 0)) & v3);
                    v4 = (size_t)→mbsinit(&v20);
                }
            }
            while(!v4);
            if(v5 > 1) {
                goto loc_8049066;
            }
        }
        v6 = (unsigned int)(v3 ? 0: 1) | ((unsigned int)((v3 >>> 8) & 0xffffff) << 8);
        if(((unsigned char)(((unsigned int)(v16 ? 1: 0) | ((unsigned int)((v4 >>> 8) & 0xffffff) << 8)) & v6) & 0x1)) {
        loc_8049066:
            unsigned int v25 = v5;
            unsigned int v26 = v25 + v19;
            while(1) {
                if(((unsigned char)(((unsigned int)(v3 ? 0: 1) | ((unsigned int)((v6 >>> 8) & 0xffffff) << 8)) & ((unsigned int)(v16 ? 1: 0) | ((unsigned int)((v25 >>> 8) & 0xffffff) << 8))) & 0x1)) {
                    if(result < v13) {
                        *(char*)(result + v12) = 92;
                    }
                    ++result;
                    if(result < v13) {
                        *(char*)(result + v12) = (v11 >>> 6) + 48;
                    }
                    ++result;
                    if(result < v13) {
                        *(char*)(result + v12) = ((v11 >>> 3) & 0x7) + 48;
                    }
                    v11 &= 7;
                    ++result;
                    v11 += 48;
                }
                v6 = v19 + 1;
                if(v26 <= v6) {
                    goto loc_8049296;
                }
                else {
                    if(result < v13) {
                        *(char*)(result + v12) = v11;
                    }
                    ++result;
                    v19 = v6;
                    v25 = (unsigned int)__s1[v6];
                    v11 = __s1[v6];
                }
            }
        loc_8048FA4:
            if(param0 != -1) {
                v6 = param0;
                if(v6 != v19) {
                loc_8048FBB:
                    if(v16 && v15 && (unsigned int)(v15 + v19) <= param0) {
                        size_t v27 = v15;
                        v7 = v14;
                        char* ptr2 = &__s1[v19];
                        char v28 = 1;
                        while(v27 != 0) {
                            v28 = *ptr2 == *(char*)v7;
                            ++ptr2;
                            ++v7;
                            --v27;
                            if(!v28) {
                                break;
                            }
                        }
                        if(v28) {
                            if(result < v13) {
                                *(char*)(result + v12) = 92;
                            }
                            ++result;
                        }
                    }
                    char v29 = __s1[v19];
                    v11 = __s1[v19];
                    switch((unsigned int)v29) {
                        case 0: {
                            goto loc_80493E4;
                        }
                        case 7: {
                            v0 = (unsigned int)97 | ((unsigned int)(((unsigned int)v29 >>> 8) & 0xffffff) << 8);
                            goto loc_80492C6;
                        }
                        case 8: {
                            v0 = (unsigned int)98 | ((unsigned int)(((unsigned int)v29 >>> 8) & 0xffffff) << 8);
                            goto loc_80492C6;
                        }
                        case 9: {
                            v0 = (unsigned int)116 | ((unsigned int)(((unsigned int)v29 >>> 8) & 0xffffff) << 8);
                        loc_80492B8:
                            if(param1 == 1) {
                                return (size_t)quotearg_buffer_restyled((int)param0, 2, param2);
                            }
                        loc_80492C6:
                            v6 = v19 + 1;
                            if(!v16) {
                                goto loc_8049296;
                            }
                            else {
                                v11 = (char)v0;
                                goto loc_8049271;
                            }
                        }
                        case 10: {
                            v0 = (unsigned int)110 | ((unsigned int)(((unsigned int)v29 >>> 8) & 0xffffff) << 8);
                            goto loc_80492B8;
                        }
                        case 11: {
                            v0 = (unsigned int)118 | ((unsigned int)(((unsigned int)v29 >>> 8) & 0xffffff) << 8);
                            goto loc_80492C6;
                        }
                        case 12: {
                            v0 = (unsigned int)102 | ((unsigned int)(((unsigned int)v29 >>> 8) & 0xffffff) << 8);
                            goto loc_80492C6;
                        }
                        case 13: {
                            v0 = (unsigned int)114 | ((unsigned int)(((unsigned int)v29 >>> 8) & 0xffffff) << 8);
                            if(param1 != 1) {
                                goto loc_80492C6;
                            }
                            else {
                                return (size_t)quotearg_buffer_restyled((int)param0, 2, param2);
                            loc_80493E4:
                                v6 = v19 + 1;
                                if(!v16) {
                                    goto loc_8049296;
                                }
                                else {
                                    if(result < v13) {
                                        *(char*)(result + v12) = 92;
                                    }
                                    ++result;
                                    if(result < v13) {
                                        *(char*)(result + v12) = 48;
                                    }
                                    ++result;
                                    if(result < v13) {
                                        *(char*)(result + v12) = 48;
                                    }
                                    ++result;
                                    v11 = '0';
                                    goto loc_8049248;
                                loc_804950D:
                                    v11 = v1;
                                    char v30 = result < v13;
                                    v19 = v2;
                                    if(v30) {
                                        *(char*)(result + v12) = 63;
                                    }
                                    ++result;
                                    if(result < v13) {
                                        *(char*)(result + v12) = 92;
                                    }
                                    ++result;
                                }
                            }
                            if(result < v13) {
                                *(char*)(result + v12) = 63;
                            }
                            ++result;
                            goto loc_8049248;
                        }
                        case 32: 
                        case 33: 
                        case 34: 
                        case 36: 
                        case 38: 
                        case 40: 
                        case 41: 
                        case 42: 
                        case 59: 
                        case 60: 
                        case 62: 
                        case 91: 
                        case 94: 
                        case 96: 
                        case 124: {
                            goto loc_8049238;
                        }
                        case 35: 
                        case 126: {
                            goto loc_8049232;
                        }
                        case 37: 
                        case 43: 
                        case 44: 
                        case 45: 
                        case 46: 
                        case 47: 
                        case 48: 
                        case 49: 
                        case 50: 
                        case 51: 
                        case 52: 
                        case 53: 
                        case 54: 
                        case 55: 
                        case 56: 
                        case 57: 
                        case 58: 
                        case 61: 
                        case 65: 
                        case 66: 
                        case 67: 
                        case 68: 
                        case 69: 
                        case 70: 
                        case 71: 
                        case 72: 
                        case 73: 
                        case 74: 
                        case 75: 
                        case 76: 
                        case 77: 
                        case 78: 
                        case 79: 
                        case 80: 
                        case 81: 
                        case 82: 
                        case 83: 
                        case 84: 
                        case 85: 
                        case 86: 
                        case 87: 
                        case 88: 
                        case 89: 
                        case 90: 
                        case 93: 
                        case 95: 
                        case 97: 
                        case 98: 
                        case 99: 
                        case 100: 
                        case 101: 
                        case 102: 
                        case 103: 
                        case 104: 
                        case 105: 
                        case 106: 
                        case 107: 
                        case 108: 
                        case 109: 
                        case 110: 
                        case 111: 
                        case 112: 
                        case 113: 
                        case 114: 
                        case 115: 
                        case 116: 
                        case 117: 
                        case 118: 
                        case 119: 
                        case 120: 
                        case 121: 
                        case 122: 
                        case 123: 
                        case 125: {
                            goto loc_8049248;
                        }
                        case 39: {
                            goto loc_8049325;
                        }
                        case 63: {
                            if(param1 != 1) {
                                if(param1 == 3) {
                                    v2 = v19 + 2;
                                    if(v2 < param0) {
                                        size_t v31 = v19;
                                        if(__s1[v31 + 1] == 63) {
                                            v1 = __s1[v31 + 2];
                                            switch((unsigned int)((int)v1 - 33)) {
                                                case 0: 
                                                case 6: 
                                                case 7: 
                                                case 8: 
                                                case 12: 
                                                case 14: 
                                                case 27: 
                                                case 28: 
                                                case 29: {
                                                    goto loc_804950D;
                                                }
                                                default: {
                                                    goto loc_8049248;
                                                }
                                            }
                                        loc_8049325:
                                            if(param1 == 1) {
                                                return (size_t)quotearg_buffer_restyled((int)param0, 2, param2);
                                            }
                                            else if(param1 == 2) {
                                                if(result < v13) {
                                                    *(char*)(result + v12) = 39;
                                                }
                                                ++result;
                                                if(result < v13) {
                                                    *(char*)(result + v12) = 92;
                                                }
                                                ++result;
                                                if(result < v13) {
                                                    *(char*)(result + v12) = 39;
                                                }
                                                ++result;
                                            }
                                        }
                                    }
                                }
                                goto loc_8049248;
                            }
                            else {
                                return (size_t)quotearg_buffer_restyled((int)param0, 2, param2);
                            }
                        }
                        case 92: {
                            v0 = (unsigned int)v11;
                            goto loc_80492B8;
                        }
                        default: {
                            goto loc_8049025;
                        }
                    }
                }
            }
            else if(__s1[v19]) {
                goto loc_8048FBB;
            }
            if(v14) {
                char v32 = *(char*)v14;
                if(v32) {
                    goto loc_804913C;
                loc_8049232:
                    if(v19) {
                        goto loc_8049248;
                    }
                    else {
                    loc_8049238:
                        if(param1 != 1) {
                            goto loc_8049248;
                        }
                        else {
                            return (size_t)quotearg_buffer_restyled((int)param0, 2, param2);
                        loc_804913C:
                            do {
                                if(result < v13) {
                                    *(char*)(result + v12) = v32;
                                }
                                ++v14;
                                ++result;
                                v32 = *(char*)v14;
                            }
                            while(v32);
                        }
                    }
                }
            }
            if(result < v13) {
                *(char*)(result + v12) = 0;
            }
            return result;
        }
    loc_8049248:
        v6 = v19 + 1;
        if((!v16 || !((unsigned char)(*(int*)((unsigned int)(v11 >>> 5) * 4 + param2 + 4) >> ((unsigned int)v11 & 0x1f)) & 0x1))) {
        loc_8049296:
            if(result < v13) {
                *(char*)(result + v12) = v11;
            }
            ++result;
            v19 = v6;
            goto loc_8048FA4;
        }
        else {
        loc_8049271:
            if(result < v13) {
                *(char*)(result + v12) = 92;
            }
            ++result;
            v6 = v19 + 1;
            goto loc_8049296;
        }
    }
}

int quotearg_char(int param0, char param1) {
    unsigned char v0;
    set_char_quoting(&v0, param1, 1);
    return quotearg_n_options((int*)&v0);
}

int quotearg_colon(int param0) {
    return quotearg_char(param0, ':');
}

int quotearg_n(int param0) {
    return quotearg_n_options((int*)&default_quoting_options);
}

int quotearg_n_options(int* param0) {
    int v0;
    unsigned int v1;
    int v2;
    int v3;
    int v4 = v2;
    unsigned int v5 = v1;
    int v6 = v3;
    int v7 = v0;
    int* ptr0 = →__errno_location();
    int v8 = ptr0[0];
    if(v5 >= 0x80000000) {
        /*NO_RETURN*/ →abort();
    }
    if(nslots.1 <= v5) {
        unsigned int v9 = v5 + 1;
        if(v9 > 0x1fffffff) {
            /*NO_RETURN*/ xalloc_die();
        }
        void* __ptr = slotvec.3;
        if(__ptr == &slotvec0.2) {
            void* ptr1 = xmalloc(8);
            slotvec.3 = ptr1;
            __ptr = ptr1;
            int v10 = *(int*)&slotvec0.2;
            *(int*)((int)__ptr + 4) = *(int*)((char*)&slotvec0.2 + 4);
            *(int*)__ptr = v10;
        }
        void* ptr2 = xrealloc(__ptr, (size_t)(v9 * 8));
        slotvec.3 = ptr2;
        unsigned int v11 = nslots.1;
        int* ptr3 = (int*)(v11 * 8 + (int)ptr2);
        unsigned int v12 = (v9 - v11) * 8;
        if(v12 > 7 && (int*)((int)ptr3 & 0x4)) {
            *ptr3 = 0;
            v12 -= 4;
            ++ptr3;
        }
        for(int i = v12 >>> 2; i != 0; --i) {
            *ptr3 = 0;
            ++ptr3;
        }
        nslots.1 = v9;
    }
    unsigned int v13 = slotvec.3;
    int v14 = *(int*)(v5 * 8 + v13);
    int result = *(int*)(v5 * 8 + v13 + 4);
    int v15 = quotearg_buffer(result, v14, v6, v7, param0);
    if((unsigned int)v15 >= (unsigned int)v14) {
        unsigned int v16 = slotvec.3;
        *(size_t*)(v5 * 8 + v16) = (size_t)(v15 + 1);
        if(result != &slot0.0) {
            →free((void*)result);
            v16 = slotvec.3;
        }
        result = (int)xmalloc((size_t)(v15 + 1));
        *(int*)(v5 * 8 + v16 + 4) = result;
        quotearg_buffer(result, (int)(size_t)(v15 + 1), v6, v7, param0);
    }
    int* ptr4 = →__errno_location();
    ptr4[0] = v8;
    return result;
}

int quotearg_n_style(int param0, int param1) {
    char v0;
    int v1;
    quoting_options_from_style(v1, param1);
    return quotearg_n_options(&v0);
}

int quotearg_n_style_mem(int param0, int param1) {
    char v0;
    int v1;
    quoting_options_from_style(v1, param1);
    return quotearg_n_options(&v0);
}

int quotearg_style(int param0, int param1) {
    return quotearg_n_style(0, param0);
}

int* quoting_options_from_style(int param0, int param1) {
    int v0;
    int v1;
    int v2;
    int v3;
    int v4;
    int v5;
    int v6;
    int v7;
    int* result;
    int v8 = 8;
    int v9 = param1;
    int* ptr0 = &v0;
    while(v8 != 0) {
        *ptr0 = 0;
        ++ptr0;
        --v8;
    }
    *result = v9;
    *(result + 1) = v0;
    *(result + 2) = v4;
    *(result + 3) = v1;
    *(result + 4) = v5;
    *(result + 5) = v2;
    *(result + 6) = v6;
    *(result + 7) = v3;
    *(result + 8) = v7;
    return result;
}

unsigned short** r→__ctype_b_loc() {
    /*BAD_CALL!*/ sub_80487C8();
}

size_t r→__ctype_get_mb_cur_max() {
    /*BAD_CALL!*/ sub_80487C8();
}

int r→__cxa_atexit() {
    /*BAD_CALL!*/ sub_80487C8();
}

int* r→__errno_location() {
    /*BAD_CALL!*/ sub_80487C8();
}

size_t r→__fpending(FILE* __fp) {
    /*BAD_CALL!*/ sub_80487C8();
}

int r→__libc_start_main() {
    /*BAD_CALL!*/ sub_80487C8();
}

int r→__overflow(_IO_FILE* param1, int param2) {
    /*BAD_CALL!*/ sub_80487C8();
}

void r→abort() {
    /*BAD_CALL!*/ sub_80487C8();
}

char* r→bindtextdomain(char* __domainname, char* __dirname) {
    /*BAD_CALL!*/ sub_80487C8();
}

void* r→calloc(size_t __nmemb, size_t __size) {
    /*BAD_CALL!*/ sub_80487C8();
}

char* r→dcgettext(char* __domainname, char* __msgid, int __category) {
    /*BAD_CALL!*/ sub_80487C8();
}

void r→error(int __status, int __errnum, char* __format, ...) {
    /*BAD_CALL!*/ sub_80487C8();
}

void r→exit(int __status) {
    /*BAD_CALL!*/ sub_80487C8();
}

int r→fclose(FILE* __stream) {
    /*BAD_CALL!*/ sub_80487C8();
}

int r→fprintf(FILE* __stream, char* __format, ...) {
    /*BAD_CALL!*/ sub_80487C8();
}

int r→fputs_unlocked(char* __s, FILE* __stream) {
    /*BAD_CALL!*/ sub_80487C8();
}

void r→free(void* __ptr) {
    /*BAD_CALL!*/ sub_80487C8();
}

char* r→getenv(char* __name) {
    /*BAD_CALL!*/ sub_80487C8();
}

int r→iswprint(wint_t __wc) {
    /*BAD_CALL!*/ sub_80487C8();
}

void* r→malloc(size_t __size) {
    /*BAD_CALL!*/ sub_80487C8();
}

size_t r→mbrtowc(wchar_t* __pwc, char* __s, size_t __n, mbstate_t* __p) {
    /*BAD_CALL!*/ sub_80487C8();
}

int r→mbsinit(mbstate_t* __ps) {
    /*BAD_CALL!*/ sub_80487C8();
}

void* r→memcpy(void* __dest, void* __src, size_t __n) {
    /*BAD_CALL!*/ sub_80487C8();
}

void* r→memset(void* __s, int __c, size_t __n) {
    /*BAD_CALL!*/ sub_80487C8();
}

int r→printf(char* __format, ...) {
    /*BAD_CALL!*/ sub_80487C8();
}

void* r→realloc(void* __ptr, size_t __size) {
    /*BAD_CALL!*/ sub_80487C8();
}

char* r→setlocale(int __category, char* __locale) {
    /*BAD_CALL!*/ sub_80487C8();
}

size_t r→strlen(char* __s) {
    /*BAD_CALL!*/ sub_80487C8();
}

char* r→textdomain(char* __domainname) {
    /*BAD_CALL!*/ sub_80487C8();
}

int r→vfprintf(FILE* __s, char* __format, __gnuc_va_list __arg) {
    /*BAD_CALL!*/ sub_80487C8();
}

int set_char_quoting(int param0, char param1, int param2) {
    int result;
    int* ptr0 = (int*)((unsigned int)(param1 >>> 5) * 4 + param0 + 4);
    if(param0) {
        int v0 = *ptr0;
        result = (v0 >> ((unsigned int)param1 & 0x1f)) & 0x1;
        *ptr0 = (((param2 & 0x1) ^ result) << ((unsigned int)param1 & 0x1f)) ^ v0;
    }
    else {
        int v1 = *(int*)((unsigned int)(param1 >>> 5) * 4 + &gvar_804B924);
        result = (v1 >> ((unsigned int)param1 & 0x1f)) & 0x1;
        *(int*)((unsigned int)(param1 >>> 5) * 4 + &gvar_804B924) = (((param2 & 0x1) ^ result) << ((unsigned int)param1 & 0x1f)) ^ v1;
    }
    return result;
}

unsigned char set_quoting_style(unsigned int* param0, unsigned char param1) {
    if(param0) {
        unsigned char result = param1;
        *param0 = param1;
        return result;
    }
    *(int*)&default_quoting_options = param1;
    return param1;
}

void sub_80487C8() {
    jump gvar_804B74C;
}

void sub_8048A4E() {
}

void sub_8048C59(int param0, int param1, int param2, int param3, int param4) {
    char v0;
    int v1;
    int v2;
    *(int*)(v1 - 16) = *(int*)(v2 + 4);
    while(1) {
        char* ptr0 = *(unsigned int*)(v1 - 16);
        char* ptr1 = "--version";
        int v3 = 10;
        while(v3 != 0) {
            v0 = *ptr0 == *ptr1;
            ++ptr0;
            ++ptr1;
            --v3;
            if(!v0) {
                break;
            }
        }
        if(v0) {
            v0 = 1;
            param4 = 0;
            FILE* ptr2 = stdout;
            param3 = "Jim Meyering";
            version_etc(ptr2, "true", &gvar_804A099, "5.2.1");
        }
        /*NO_RETURN*/ →exit(0);
    }
}

int sub_8048D5E(int param0) {
    jump param0;
}

int sub_8049BDE() {
    /*NO_RETURN*/ xalloc_die();
}

int usage(int __status) {
    char* __format = →dcgettext(NULL, "Usage: %s [ignored command line arguments]\n  or:  %s OPTION\nExit with a status code indicating success.\n\nThese option names may not be abbreviated.\n\n", 5);
    unsigned int v0 = program_name;
    →printf(__format, v0, v0);
    char* __s = →dcgettext(NULL, "      --help     display this help and exit\n", 5);
    →fputs_unlocked(__s, stdout);
    char* __s1 = →dcgettext(NULL, "      --version  output version information and exit\n", 5);
    →fputs_unlocked(__s1, stdout);
    char* __format1 = →dcgettext(NULL, "\nReport bugs to <%s>.\n", 5);
    →printf(__format1, "bug-coreutils@gnu.org");
    /*NO_RETURN*/ →exit(__status);
}

int version_etc(FILE* param0, FILE* param1, int param2, int param3) {
    char v0;
    return version_etc_va(param0, param1, param2, param3, &v0);
}

int version_etc_va(FILE* param0, FILE* param1, int param2, int param3, __gnuc_va_list __arg) {
    char* ptr0;
    char* __msgid;
    int v0;
    unsigned int v1 = 0;
    FILE* __stream = param0;
    int v2 = param2;
    int* ptr1 = (int*)(__arg + 4);
    int v3 = param3;
    if(*(int*)__arg) {
        do {
            ++v1;
            v0 = *ptr1;
            ++ptr1;
        }
        while(v0);
    }
    if(param1) {
        →fprintf(__stream, "%s (%s) %s\n", param1, v2, v3);
    loc_804993C:
        switch(v1) {
            case 0: {
                /*NO_RETURN*/ →abort();
                →fprintf(__stream, "%s %s\n", v2, v3);
                goto loc_804993C;
            }
            case 1: {
                ptr0 = "Written by %s.\n";
            loc_8049951:
                __msgid = ptr0;
            loc_804995C:
                char* __format = →dcgettext(NULL, __msgid, 5);
                →vfprintf(__stream, __format, __arg);
                char* ptr2 = __stream->_IO_write_ptr;
                if(__stream->_IO_write_end > ptr2) {
                    ptr2[0] = 10;
                    ++__stream->_IO_write_ptr;
                }
                else {
                    →__overflow((_IO_FILE*)__stream, 10);
                }
                int result = →fputs_unlocked(version_etc_copyright, __stream);
                char* ptr3 = __stream->_IO_write_ptr;
                if(__stream->_IO_write_end > ptr3) {
                    ptr3[0] = 10;
                    ++__stream->_IO_write_ptr;
                }
                else {
                    →__overflow((_IO_FILE*)__stream, 10);
                }
                char* __s = →dcgettext(NULL, "This is free software; see the source for copying conditions.  There is NO\nwarranty; not even for MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.\n", 5);
                →fputs_unlocked(__s, __stream);
                return result;
            }
            case 2: {
                __msgid = "Written by %s and %s.\n";
                goto loc_804995C;
            }
            case 3: {
                ptr0 = "Written by %s, %s, and %s.\n";
                goto loc_8049951;
            }
            case 4: {
                ptr0 = "Written by %s, %s, %s,\nand %s.\n";
                goto loc_8049951;
            }
            case 5: {
                ptr0 = "Written by %s, %s, %s,\n%s, and %s.\n";
                goto loc_8049951;
            }
            case 6: {
                __msgid = "Written by %s, %s, %s,\n%s, %s, and %s.\n";
                goto loc_804995C;
            }
            case 7: {
                __msgid = "Written by %s, %s, %s,\n%s, %s, %s, and %s.\n";
                goto loc_804995C;
            }
            case 8: {
                ptr0 = "Written by %s, %s, %s,\n%s, %s, %s, %s,\nand %s.\n";
                goto loc_8049951;
            }
            case 9: {
                ptr0 = "Written by %s, %s, %s,\n%s, %s, %s, %s,\n%s, and %s.\n";
                goto loc_8049951;
            }
        }
        ptr0 = "Written by %s, %s, %s,\n%s, %s, %s, %s,\n%s, %s, and others.\n";
        goto loc_8049951;
    }
    else {
        →fprintf(__stream, "%s %s\n", v2, v3);
        goto loc_804993C;
    }
}

unsigned int x2nrealloc(void* param0, unsigned int* param1, unsigned int param2) {
    unsigned int result;
    unsigned int v0;
    void* __ptr = param0;
    unsigned int v1 = v0;
    unsigned int v2 = *param1;
    unsigned int v3 = param2;
    if(__ptr) {
        if(0x7fffffff / v3 < v2) {
            /*NO_RETURN*/ xalloc_die();
        }
        v2 *= 2;
    }
    else if(!v2) {
        result = 64 / v3;
        v2 = (unsigned int)((result ? 0: 1) + result);
    }
    *param1 = v2;
    xrealloc(__ptr, (size_t)(v2 * v3));
    return result;
}

size_t x2realloc(void* param0, unsigned int* param1) {
    void* __ptr = param0;
    size_t __size = *param1;
    if(__ptr) {
        if(__size >= 0x80000000) {
            /*NO_RETURN*/ xalloc_die();
        }
        __size *= 2;
    }
    else if(!__size) {
        __size = 64;
    }
    *param1 = __size;
    xrealloc(__ptr, __size);
    return __size;
}

void xalloc_die() {
    unsigned int v0 = xalloc_fail_func;
    if(!v0) {
    loc_8049B48:
        char* ptr0 = →dcgettext(NULL, (char*)&xalloc_msg_memory_exhausted, 5);
        →error(exit_failure, 0, (char*)&gvar_804A0BC, ptr0);
        /*NO_RETURN*/ →abort();
    }
    v0();
    goto loc_8049B48;
}

void* xcalloc(size_t __nmemb, size_t __size) {
    if(0xffffffff / __size >= __nmemb) {
        void* result = →calloc(__nmemb, __size);
        if(result) {
            return result;
        }
    }
    /*NO_RETURN*/ xalloc_die();
}

int xclone(FUNCPTR __fn, void* __child_stack, int __flags, void* __arg, ...) {
    void* __dest = xmalloc((size_t)__child_stack);
    return (int)→memcpy(__dest, __fn, (size_t)__child_stack);
}

void* xmalloc(size_t __size) {
    void* result = →malloc(__size);
    if(!result) {
        /*NO_RETURN*/ xalloc_die();
    }
    return result;
}

void* xnmalloc(unsigned int param0, unsigned int param1) {
    if(0xffffffff / param1 >= param0) {
        void* result = →malloc((size_t)(param0 * param1));
        if(result) {
            return result;
        }
    }
    /*NO_RETURN*/ xalloc_die();
}

void* xnrealloc(void* __ptr, unsigned int param1, unsigned int param2) {
    void* ptr0;
    void* ptr1 = ptr0;
    if(0xffffffff / param2 >= param1) {
        void* result = →realloc(__ptr, (size_t)(param1 * param2));
        if(result) {
            return result;
        }
    }
    /*NO_RETURN*/ xalloc_die();
}

void* xrealloc(void* __ptr, size_t __size) {
    void* result = →realloc(__ptr, __size);
    if(!result) {
        /*NO_RETURN*/ xalloc_die();
    }
    return result;
}

void* xzalloc(size_t __size) {
    void* __s = xmalloc(__size);
    return →memset(__s, 0, __size);
}

unsigned short** →__ctype_b_loc() {
    return ptr___ctype_b_loc[0]{r→__ctype_b_loc}();
}

size_t →__ctype_get_mb_cur_max() {
    return ptr___ctype_get_mb_cur_max[0]{r→__ctype_get_mb_cur_max}();
}

int →__cxa_atexit() {
    return ptr___cxa_atexit{r→__cxa_atexit}();
}

int* →__errno_location() {
    return ptr___errno_location[0]{r→__errno_location}();
}

size_t →__fpending(FILE* __fp) {
    return ptr___fpending[0]{r→__fpending}(__fp);
}

int →__libc_start_main() {
    return ptr___libc_start_main{r→__libc_start_main}();
}

int →__overflow(_IO_FILE* param1, int param2) {
    return ptr___overflow[0]{r→__overflow}(param1, param2);
}

void →abort() {
    ptr_abort[0]{r→abort}();
}

char* →bindtextdomain(char* __domainname, char* __dirname) {
    return ptr_bindtextdomain[0]{r→bindtextdomain}(__domainname, __dirname);
}

void* →calloc(size_t __nmemb, size_t __size) {
    return ptr_calloc[0]{r→calloc}(__nmemb, __size);
}

char* →dcgettext(char* __domainname, char* __msgid, int __category) {
    return ptr_dcgettext[0]{r→dcgettext}(__domainname, __msgid, __category);
}

void →error(int __status, int __errnum, char* __format, ...) {
    ptr_error[0]{r→error}(__status, __errnum, __format);
}

void →exit(int __status) {
    ptr_exit[0]{r→exit}(__status);
}

int →fclose(FILE* __stream) {
    return ptr_fclose[0]{r→fclose}(__stream);
}

int →fprintf(FILE* __stream, char* __format, ...) {
    return ptr_fprintf[0]{r→fprintf}(__stream, __format);
}

int →fputs_unlocked(char* __s, FILE* __stream) {
    return ptr_fputs_unlocked[0]{r→fputs_unlocked}(__s, __stream);
}

void →free(void* __ptr) {
    ptr_free[0]{r→free}(__ptr);
}

char* →getenv(char* __name) {
    return ptr_getenv[0]{r→getenv}(__name);
}

int →iswprint(wint_t __wc) {
    return ptr_iswprint[0]{r→iswprint}(__wc);
}

void* →malloc(size_t __size) {
    return ptr_malloc[0]{r→malloc}(__size);
}

size_t →mbrtowc(wchar_t* __pwc, char* __s, size_t __n, mbstate_t* __p) {
    return ptr_mbrtowc[0]{r→mbrtowc}(__pwc, __s, __n, __p);
}

int →mbsinit(mbstate_t* __ps) {
    return ptr_mbsinit[0]{r→mbsinit}(__ps);
}

void* →memcpy(void* __dest, void* __src, size_t __n) {
    return ptr_memcpy[0]{r→memcpy}(__dest, __src, __n);
}

void* →memset(void* __s, int __c, size_t __n) {
    return ptr_memset[0]{r→memset}(__s, __c, __n);
}

int →printf(char* __format, ...) {
    return ptr_printf[0]{r→printf}(__format);
}

void* →realloc(void* __ptr, size_t __size) {
    return ptr_realloc[0]{r→realloc}(__ptr, __size);
}

char* →setlocale(int __category, char* __locale) {
    return ptr_setlocale[0]{r→setlocale}(__category, __locale);
}

size_t →strlen(char* __s) {
    return ptr_strlen[0]{r→strlen}(__s);
}

char* →textdomain(char* __domainname) {
    return ptr_textdomain[0]{r→textdomain}(__domainname);
}

int →vfprintf(FILE* __s, char* __format, __gnuc_va_list __arg) {
    return ptr_vfprintf[0]{r→vfprintf}(__s, __format, __arg);
}
