
int __do_global_ctors_aux(int param0, int param1) {
    unsigned char v0 = *(int*)&__CTOR_LIST__;
    if(v0 != -1) {
        int v1 = &__CTOR_LIST__;
        do {
            v0();
            v0 = *(unsigned char*)(v1 - 4);
            v1 -= 4;
        }
        while(v0 != -1);
    }
    return param1;
}

int* __do_global_dtors_aux() {
    int* result;
    if(!completed.4583) {
        while(1) {
            result = *(int*)&p.4582;
            int v0 = *result;
            if(!v0) {
                break;
            }
            else {
                *(int*)&p.4582 = result + 1;
                v0{__DTOR_END__}();
            }
        }
        completed.4583 = 1;
    }
    return result;
}

void __libc_csu_fini() {
}

int* __libc_csu_init(int param0) {
    initializer_0(param0);
    return NULL;
}

int _start(int param0, int param1) {
    →__libc_start_main();
    hlt();
}

int call_gmon_start(int param0) {
    if(__gmon_start__) {
        →__gmon_start__();
    }
    return param0;
}

int finalizer_0() {
    int result;
    __do_global_dtors_aux();
    return result;
}

unsigned char frame_dummy() {
    return 0;
}

unsigned int g() {
    --g_f;
    if(g_f < 0x80000000) {
        f();
    }
    unsigned int result = res + 13;
    res += 13;
    return result;
}

unsigned int h() {
    --h_i;
    if(h_i < 0x80000000) {
        i();
    }
    unsigned int result = res + 17;
    res += 17;
    return result;
}

// Stale decompilation - Refresh this view to re-decompile this code
unsigned int i() {
    unsigned int result = res + 19;
    res += 19;
    return result;
}

// Stale decompilation - Refresh this view to re-decompile this code
int initializer_0(int param0) {
    int v0;
    call_gmon_start(param0);
    frame_dummy();
    return __do_global_ctors_aux(param0, v0);
}

unsigned int j(int param0, int param1) {
    --j_k;
    if(j_k < 0x80000000) {
        k(param1, param0);
    }
    unsigned int result = res + 23;
    res += 23;
    return result;
}

unsigned int k(int param0, int param1) {
    --k_e;
    if(k_e < 0x80000000) {
        e(param1, param0);
    }
    unsigned int result = res + 27;
    res += 27;
    return result;
}

unsigned int l(int param0, int param1) {
    --l_b;
    if(l_b < 0x80000000) {
        b(param1, param0);
    }
    unsigned int result = res + 29;
    res += 29;
    return result;
}

int main() {
    int v0;
    int v1;
    b(55, 99);
    →printf("ecx is %d, edx is %d\n", v0, v1);
    →printf("res is %d\n", res);
    return 0;
}

int r→__gmon_start__() {
    /*BAD_CALL!*/ sub_8048298();
}

int r→__libc_start_main() {
    /*BAD_CALL!*/ sub_8048298();
}

int r→printf(char* __format, ...) {
    /*BAD_CALL!*/ sub_8048298();
}

void sub_8048298() {
    jump gvar_80497F4;
}

void sub_8048352() {
}

int →__gmon_start__() {
    return ptr___gmon_start__{r→__gmon_start__}();
}

int →__libc_start_main() {
    return ptr___libc_start_main{r→__libc_start_main}();
}

int →printf(char* __format, ...) {
    return ptr_printf[0]{r→printf}(__format);
}
