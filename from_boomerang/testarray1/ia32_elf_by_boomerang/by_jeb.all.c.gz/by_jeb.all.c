
int __do_global_ctors_aux(int param0, int param1) {
    unsigned int* ptr0 = (unsigned int*)&__CTOR_LIST__;
    for(unsigned char i = *(int*)&__CTOR_LIST__; i != -1; i = *ptr0) {
        --ptr0;
        i();
    }
    return param1;
}

int* __do_global_dtors_aux() {
    int* result;
    if(!completed.1) {
        while(1) {
            result = *(int*)&p.0;
            int v0 = *result;
            if(!v0) {
                break;
            }
            else {
                *(int*)&p.0 = result + 1;
                v0{__DTOR_END__}();
            }
        }
        completed.1 = 1;
    }
    return result;
}

int* __libc_csu_fini() {
    for(int i = -1; i != -1; --i) {
        *(int*)(i * 4 + (int)&__CTOR_LIST__)();
    }
    return finalizer_0();
}

unsigned int __libc_csu_init(int param0, int param1) {
    initializer_0(param0, param1);
    return 0;
}

int _start(int param0, int param1) {
    →__libc_start_main();
    hlt();
}

int call_gmon_start(int param0, int param1) {
    void* ptr0 = __gmon_start__;
    if(ptr0) {
        ptr0();
    }
    return param1;
}

int* finalizer_0() {
    return __do_global_dtors_aux();
}

unsigned char frame_dummy() {
    return 0;
}

int initializer_0(int param0, int param1) {
    call_gmon_start(param0, param1);
    frame_dummy();
    return __do_global_ctors_aux(param0, param1);
}

int main() {
    int v0 = 0;
    for(int i = 0; i <= 4; ++i) {
        v0 += (int)*(unsigned char*)((int)&gca + i);
    }
    →printf("Sum is %d\n", v0);
    return 0;
}

int r→__libc_start_main() {
    /*BAD_CALL!*/ sub_8048290();
}

int r→printf(char* __format, ...) {
    /*BAD_CALL!*/ sub_8048290();
}

void sub_8048290() {
    jump gvar_80495A4;
}

void sub_804833A() {
}

void sub_804841E() {
}

int →__libc_start_main() {
    return ptr___libc_start_main{r→__libc_start_main}();
}

int →printf(char* __format, ...) {
    return ptr_printf[0]{r→printf}(__format);
}
