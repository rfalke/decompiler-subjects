
int __do_global_ctors_aux() {
    int result;
    unsigned int* ptr0 = (unsigned int*)&__CTOR_LIST__;
    for(unsigned char i = *(int*)&__CTOR_LIST__; i != -1; i = *ptr0) {
        --ptr0;
        i();
    }
    return result;
}

void __do_global_dtors_aux() {
}

void __i686.get_pc_thunk.bx() {
}

int __libc_csu_fini(int param0) {
    return finalizer_0(param0, &data_start);
}

int __libc_csu_init() {
    initializer_0();
    return &data_start;
}

int _start(int param0, int param1) {
    →__libc_start_main();
    hlt();
}

void* call_gmon_start() {
    void* result = __gmon_start__;
    if(result) {
        result = (void*)result();
    }
    return result;
}

char* chomp(char* __s, int __n, FILE* __stream) {
    char* __s1 = →fgets(__s, __n, __stream);
    if(__s1) {
        char* ptr0 = →strchr(__s1, 10);
        if(ptr0) {
            ptr0[0] = 0;
        }
    }
    return __s1;
}

int finalizer_0(int param0, int param1) {
    int result;
    __do_global_dtors_aux();
    return result;
}

unsigned char frame_dummy() {
    return 0;
}

int initializer_0() {
    call_gmon_start();
    frame_dummy();
    return __do_global_ctors_aux();
}

int main(int param0, int param1) {
    int result;
    char v0;
    if(param0 <= 1) {
        result = 1;
    }
    else {
        FILE* __stream = →fopen(*(char**)(param1 + 4), (char*)&gvar_8048654);
        if(!__stream) {
            result = 1;
        }
        else {
            char* ptr0 = chomp(&v0, 0x400, __stream);
            if(ptr0) {
                →printf((char*)&gvar_8048656, &v0);
            }
            →fclose(__stream);
        }
    }
    return result;
}

void sub_8048314() {
    jump gvar_8049750;
}

int sub_804832A() {
    /*BAD_CALL!*/ sub_8048314();
}

int sub_804833A() {
    /*BAD_CALL!*/ sub_8048314();
}

int sub_804834A() {
    /*BAD_CALL!*/ sub_8048314();
}

int sub_804835A() {
    /*BAD_CALL!*/ sub_8048314();
}

int sub_804836A() {
    /*BAD_CALL!*/ sub_8048314();
}

int sub_804837A() {
    /*BAD_CALL!*/ sub_8048314();
}

void sub_804841E() {
}

void →__libc_start_main() {
    while(1) {
    }
}

int →fclose(FILE* __stream) {
    while(1) {
    }
}

char* →fgets(char* __s, int __n, FILE* __stream) {
    while(1) {
    }
}

FILE* →fopen(char* __filename, char* __modes) {
    while(1) {
    }
}

int →printf(char* __format, ...) {
    while(1) {
    }
}

char* →strchr(char* __s, int __c) {
    while(1) {
    }
}
