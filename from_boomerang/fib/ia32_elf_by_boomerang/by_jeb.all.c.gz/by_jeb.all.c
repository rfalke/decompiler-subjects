
int __do_global_ctors_aux() {
    int result;
    unsigned char v0 = *(int*)&__CTOR_LIST__;
    unsigned int* ptr0 = (unsigned int*)&__CTOR_LIST__;
    while(v0 != -1) {
        --ptr0;
        v0();
        v0 = *ptr0;
    }
    return result;
}

void __do_global_dtors_aux() {
}

void* call_gmon_start() {
    void* result = __gmon_start__;
    if(result) {
        result = (void*)result();
    }
    return result;
}

int fib(int param0) {
    int result;
    if(param0 > 1) {
        int v0 = fib(param0 - 1);
        int v1 = fib(param0 - 2);
        result = v1 + v0;
    }
    else {
        result = param0;
    }
    return result;
}

int finalizer_0(int param0, int param1) {
    int result;
    __do_global_dtors_aux();
    return result;
}

unsigned char frame_dummy() {
    int v0;
    if(v0) {
        0(&__EH_FRAME_BEGIN__, &object.2, 0, &_GLOBAL_OFFSET_TABLE_);
    }
    return 0;
}

// Stale decompilation - Refresh this view to re-decompile this code
int initializer_0() {
    call_gmon_start();
    frame_dummy();
    return __do_global_ctors_aux();
}

// Stale decompilation - Refresh this view to re-decompile this code
int main() {
    int v0 = fib(10);
    →printf((char*)&gvar_8048468, v0);
    return 0;
}

int start(int param0, int param1) {
    →__libc_start_main();
    hlt();
}

void sub_8048248() {
    jump gvar_8049560;
}

int sub_804825E() {
    /*BAD_CALL!*/ sub_8048248();
}

int sub_804826E() {
    /*BAD_CALL!*/ sub_8048248();
}

void sub_80482A2() {
}

void sub_80482C6() {
}

void →__libc_start_main() {
    while(1) {
    }
}

int →printf(char* __format, ...) {
    while(1) {
    }
}
