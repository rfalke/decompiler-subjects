
int __do_global_ctors_aux(int param0, int param1) {
    unsigned char v0 = *(int*)&__CTOR_LIST__;
    unsigned int* ptr0 = (unsigned int*)&__CTOR_LIST__;
    while(v0 != -1) {
        --ptr0;
        v0();
        v0 = *ptr0;
    }
    return param1;
}

void __do_global_dtors_aux() {
}

int __libc_csu_fini(int param0, int param1) {
    return finalizer_0(0, param1);
}

int __libc_csu_init() {
    return initializer_0();
}

int _start(int param0, int param1) {
    →__libc_start_main();
    hlt();
}

void* call_gmon_start() {
    void* result = __gmon_start__;
    if(result) {
        result = (void*)result();
    }
    return result;
}

int finalizer_0(int param0, int param1) {
    int result;
    __do_global_dtors_aux();
    return result;
}

unsigned char frame_dummy() {
    return 0;
}

int initializer_0() {
    int v0;
    int v1;
    call_gmon_start();
    frame_dummy();
    return __do_global_ctors_aux(v0, v1);
}

int main() {
    return →printf("%08X\n", 0x87653412);
}

int r→__libc_start_main() {
    /*BAD_CALL!*/ sub_8048290();
}

int r→printf(char* __format, ...) {
    /*BAD_CALL!*/ sub_8048290();
}

void sub_8048290() {
    jump gvar_804956C;
}

void sub_8048342() {
}

int sub_804841E(int param0) {
    int v0;
    int v1;
    int v2;
    int v3;
    int v4 = v0;
    do {
        *(int*)(v4 * 4 + v2 - 224)();
        v1 = v4;
        --v4;
    }
    while(v1);
    return finalizer_0(v3, 0);
}

int →__libc_start_main() {
    return ptr___libc_start_main{r→__libc_start_main}();
}

int →printf(char* __format, ...) {
    return ptr_printf[0]{r→printf}(__format);
}
