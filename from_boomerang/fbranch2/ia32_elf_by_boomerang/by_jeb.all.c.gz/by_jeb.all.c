
int __do_global_ctors_aux(int param0, int param1) {
    unsigned char v0 = *(int*)&__CTOR_LIST__;
    if(v0 != -1) {
        int v1 = &__CTOR_LIST__;
        do {
            v0();
            v0 = *(unsigned char*)(v1 - 4);
            v1 -= 4;
        }
        while(v0 != -1);
    }
    return param1;
}

int* __do_global_dtors_aux() {
    int* result;
    if(!completed.4577) {
        while(1) {
            result = *(int*)&p.4576;
            int v0 = *result;
            if(!v0) {
                break;
            }
            else {
                *(int*)&p.4576 = result + 1;
                v0{__DTOR_END__}();
            }
        }
        completed.4577 = 1;
    }
    return result;
}

void __libc_csu_fini() {
}

int* __libc_csu_init(int param0) {
    initializer_0(param0);
    return NULL;
}

int _start(int param0, int param1) {
    →__libc_start_main();
    hlt();
}

int call_gmon_start(int param0) {
    if(__gmon_start__) {
        →__gmon_start__();
    }
    return param0;
}

int finalizer_0() {
    int result;
    __do_global_dtors_aux();
    return result;
}

unsigned char frame_dummy() {
    return 0;
}

// Stale decompilation - Refresh this view to re-decompile this code
int initializer_0(int param0) {
    int v0;
    call_gmon_start(param0);
    frame_dummy();
    return __do_global_ctors_aux(param0, v0);
}

int main() {
    float v0;
    int v1;
    int v2;
    int v3;
    int v4;
    int v5;
    int v6;
    int v7;
    int v8;
    int v9;
    float v10 = (float)5.0;
    →scanf((char*)&gvar_80485C0, &v0, v1, v2);
    __SyntheticTypeUnknownF v11 = v0;
    *(long long*)&v3 = 0x4014000000000000L;
    int v12 = →printf("a is %f, b is %f\n", v11, *(double*)&v3);
    fucompp();
    short v20 = fnstsw((unsigned short)v12);
    int v13 = (unsigned int)(unsigned char)v7 | ((unsigned int)((unsigned char)(v7 >>> 8) & 0x45) << 8) | ((unsigned int)(unsigned short)(v7 >>> 16) << 16);
    if((unsigned char)(v13 >>> 8) == 64) {
        v13 = →puts("Equal");
    }
    fucompp();
    short v15 = fnstsw((unsigned short)v13);
    int v14 = (unsigned int)(unsigned char)v8 | ((unsigned int)(((unsigned char)(v8 >>> 8) & 0x45) ^ 0x40) << 8) | ((unsigned int)(unsigned short)(v8 >>> 16) << 16);
    if((unsigned char)(v14 >>> 8)) {
        v14 = →puts("Not Equal");
    }
    fucompp();
    short v16 = fnstsw((unsigned short)v14);
    if(!((unsigned char)(v5 >>> 8) & 0x45)) {
        v5 = →puts("Greater");
    }
    fucompp();
    short v17 = fnstsw((unsigned short)v5);
    if(!((unsigned char)(v6 >>> 8) & 0x5)) {
        v6 = →puts("Less or Equal");
    }
    fucompp();
    short v18 = fnstsw((unsigned short)v6);
    if(!((unsigned char)(v9 >>> 8) & 0x5)) {
        v9 = →puts("Greater or Equal");
    }
    fucompp();
    short v19 = fnstsw((unsigned short)v9);
    if(!((unsigned char)(v4 >>> 8) & 0x45)) {
        →puts("Less");
    }
    return 0;
}

int r→__gmon_start__() {
    /*BAD_CALL!*/ sub_80482E0();
}

int r→__libc_start_main() {
    /*BAD_CALL!*/ sub_80482E0();
}

int r→printf(char* __format, ...) {
    /*BAD_CALL!*/ sub_80482E0();
}

int r→puts(char* __s) {
    /*BAD_CALL!*/ sub_80482E0();
}

int r→scanf(char* __format, ...) {
    /*BAD_CALL!*/ sub_80482E0();
}

void sub_80482E0() {
    jump gvar_8049700;
}

void sub_80483BA() {
}

int →__gmon_start__() {
    return ptr___gmon_start__{r→__gmon_start__}();
}

int →__libc_start_main() {
    return ptr___libc_start_main{r→__libc_start_main}();
}

int →printf(char* __format, ...) {
    return ptr_printf[0]{r→printf}(__format);
}

int →puts(char* __s) {
    return ptr_puts[0]{r→puts}(__s);
}

int →scanf(char* __format, ...) {
    return ptr_scanf[0]{r→scanf}(__format);
}
