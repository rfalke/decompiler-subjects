
int __do_global_ctors_aux() {
    int result;
    unsigned char v0 = *(int*)&__CTOR_LIST__;
    if(v0 != -1) {
        int v1 = &__CTOR_LIST__;
        do {
            v0();
            v0 = *(unsigned char*)(v1 - 4);
            v1 -= 4;
        }
        while(v0 != -1);
    }
    return result;
}

int* __do_global_dtors_aux() {
    int* result;
    if(!completed.4463) {
        while(1) {
            result = *(int*)&p.4462;
            int v0 = *result;
            if(!v0) {
                break;
            }
            else {
                *(int*)&p.4462 = result + 1;
                v0{__DTOR_END__}();
            }
        }
        completed.4463 = 1;
    }
    return result;
}

int __libc_csu_fini() {
    return finalizer_0();
}

int* __libc_csu_init(int param0) {
    initializer_0(param0);
    return NULL;
}

int _start(int param0, int param1) {
    →__libc_start_main();
    hlt();
}

int call_gmon_start(int param0) {
    if(__gmon_start__) {
        →__gmon_start__();
    }
    return param0;
}

int finalizer_0() {
    int result;
    __do_global_dtors_aux();
    return result;
}

unsigned char frame_dummy() {
    return 0;
}

int getDevice(int param0) {
    return *(int*)(param0 + 24);
}

// Stale decompilation - Refresh this view to re-decompile this code
int initializer_0(int param0) {
    call_gmon_start(param0);
    frame_dummy();
    return __do_global_ctors_aux();
}

int main() {
    int v0 = →xf86GetPciVideoInfo();
    int v1 = getDevice(*(int*)v0);
    →printf((char*)&gvar_80485F8, v1);
    return 0;
}

int r→__gmon_start__() {
    /*BAD_CALL!*/ sub_8048374();
}

int r→__libc_start_main() {
    /*BAD_CALL!*/ sub_8048374();
}

int r→printf(char* __format, ...) {
    /*BAD_CALL!*/ sub_8048374();
}

int r→xf86GetPciVideoInfo() {
    /*BAD_CALL!*/ sub_8048374();
}

void sub_8048374() {
    jump gvar_80496F0;
}

int →__gmon_start__() {
    return ptr___gmon_start__{r→__gmon_start__}();
}

int →__libc_start_main() {
    return ptr___libc_start_main{r→__libc_start_main}();
}

int →printf(char* __format, ...) {
    return ptr_printf[0]{r→printf}(__format);
}

int →xf86GetPciVideoInfo() {
    return ptr_xf86GetPciVideoInfo{r→xf86GetPciVideoInfo}();
}
