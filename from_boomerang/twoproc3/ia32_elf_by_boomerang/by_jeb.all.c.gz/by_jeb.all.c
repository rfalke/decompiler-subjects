
int __do_global_ctors_aux() {
    int result;
    int v0;
    int v1 = v0;
    unsigned int v2 = *(int*)&__CTOR_LIST__;
    if(v2 != -1) {
        int v3 = &__CTOR_LIST__;
        do {
            v2();
            v2 = *(unsigned int*)(v3 - 4);
            v3 -= 4;
        }
        while(v2 != -1);
    }
    return result;
}

int* __do_global_dtors_aux() {
    int* result;
    if(!completed.4463) {
        while(1) {
            result = *(int*)&p.4462;
            int v0 = *result;
            if(!v0) {
                break;
            }
            else {
                *(int*)&p.4462 = result + 1;
                v0{__DTOR_END__}();
            }
        }
        completed.4463 = 1;
    }
    return result;
}

int __libc_csu_fini() {
    return finalizer_0();
}

int* __libc_csu_init(int param0) {
    initializer_0(param0);
    return NULL;
}

int _start(int param0, int param1) {
    int v0;
    char v1;
    void* ptr0;
    int v2;
    int v3 = 0;
    char v4 = 1;
    char v5 = 0;
    char v6 = 1;
    char v7 = 0;
    char v8 = 0;
    int v9 = v0;
    int* ptr1 = &v1;
    char v10 = &v0 ? 0: 1;
    char v11 = (int)&v0 < 0;
    char v12 = __parity__((unsigned char)&v0);
    char v13 = 0;
    char v14 = 0;
    int v15 = v2;
    int* ptr2 = &v15;
    int* ptr3 = &v15;
    int v16 = param1;
    int v17 = &__libc_csu_fini;
    int v18 = &__libc_csu_init;
    int* ptr4 = &v1;
    int v19 = &main;
    int* ptr5 = &ptr0;
    →__libc_start_main();
    hlt();
}

int call_gmon_start(int param0) {
    if(__gmon_start__) {
        →__gmon_start__();
    }
    return param0;
}

int finalizer_0() {
    int result;
    __do_global_dtors_aux();
    return result;
}

unsigned char frame_dummy() {
    return 0;
}

int getDevice(int param0) {
    return *(int*)(param0 + 24);
}

// Stale decompilation - Refresh this view to re-decompile this code
int initializer_0(int param0) {
    call_gmon_start(param0);
    frame_dummy();
    return __do_global_ctors_aux();
}

int main() {
    int* ptr0;
    →xf86GetPciVideoInfo();
    int* ptr1 = ptr0;
    int v0 = getDevice(*ptr0);
    →printf(&gvar_80485F8);
    return 0;
}

int sub_804837A() {
    return gvar_80496F0();
}

void →__gmon_start__() {
    while(1) {
        /*BAD_CALL!*/ __gmon_start__();
        unsigned int* ptr0 = ptr0 - 1;
        *ptr0 = 24;
        --ptr0;
        *ptr0 = gvar_80496EC;
    }
}

void →__libc_start_main() {
    while(1) {
        /*BAD_CALL!*/ __libc_start_main();
        unsigned int* ptr0 = ptr0 - 1;
        *ptr0 = 8;
        --ptr0;
        *ptr0 = gvar_80496EC;
    }
}

void →printf(int param0) {
    unsigned int* ptr0;
    while(1) {
        /*BAD_CALL!*/ printf(*(char**)(ptr0 + 1));
        --ptr0;
        *ptr0 = 16;
        --ptr0;
        *ptr0 = gvar_80496EC;
    }
}

void →xf86GetPciVideoInfo() {
    while(1) {
        /*BAD_CALL!*/ xf86GetPciVideoInfo();
        unsigned int* ptr0 = ptr0 - 1;
        *ptr0 = 0;
        --ptr0;
        *ptr0 = gvar_80496EC;
    }
}
