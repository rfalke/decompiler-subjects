
int __do_global_ctors_aux(int param0, int param1) {
    int v0;
    int v1 = v0;
    int v2 = param1;
    unsigned int v3 = *(int*)&__CTOR_LIST__;
    unsigned int* ptr0 = (unsigned int*)&__CTOR_LIST__;
    while(v3 != -1) {
        --ptr0;
        v3();
        v3 = *ptr0;
    }
    return param1;
}

int* __do_global_dtors_aux() {
    int* result;
    return result;
}

int* __libc_csu_fini(int param0, int param1) {
    return finalizer_0(param0, param1);
}

int __libc_csu_init() {
    initializer_0();
    return 0;
}

int _start(int param0, int param1) {
    int v0;
    char v1;
    void* ptr0;
    int v2;
    int v3 = 0;
    char v4 = 1;
    char v5 = 0;
    char v6 = 1;
    char v7 = 0;
    char v8 = 0;
    int v9 = v0;
    int* ptr1 = &v1;
    char v10 = &v0 ? 0: 1;
    char v11 = (int)&v0 < 0;
    char v12 = __parity__((unsigned char)&v0);
    char v13 = 0;
    char v14 = 0;
    int v15 = v2;
    int* ptr2 = &v15;
    int* ptr3 = &v15;
    int v16 = param1;
    int v17 = &__libc_csu_fini;
    int v18 = &__libc_csu_init;
    int* ptr4 = &v1;
    int v19 = &main;
    int* ptr5 = &ptr0;
    int v20 = →__libc_start_main();
    hlt();
}

void* call_gmon_start() {
    void* result = __gmon_start__;
    if(result) {
        result = (void*)result();
    }
    return result;
}

int* finalizer_0(int param0, int param1) {
    return __do_global_dtors_aux();
}

unsigned char frame_dummy() {
    return 0;
}

int initializer_0() {
    int v0;
    int v1;
    call_gmon_start();
    frame_dummy();
    return __do_global_ctors_aux(v0, v1);
}

int main(int param0, int param1, int param2, int param3, int param4, int param5, int param6, int param7, int param8, int param9, int param10, int param11, int param12, int param13, int param14, int param15, int param16, int param17, int param18, int param19, int param20, int param21, int param22, int param23, int param24, int param25, int param26, int param27, int param28, int param29, int param30, int param31, int param32, int param33, int param34, int param35, int param36, int param37, int param38, int param39) {
    char v0;
    char v1;
    char v2;
    void* ptr0 = →malloc(12);
    *(int*)((int)ptr0 + 4) = "HelloWorld";
    unsigned int v3 = 2;
    ptr0 = (void*)((int)ptr0 + 4);
    --v3;
    while(v3) {
        size_t v4 = →strlen(*(char**)ptr0);
        if((int)v4 > 10) {
            v4 = 10;
        }
        unsigned int v5 = 0;
        do {
            unsigned int i;
            for(i = 0; (int)v4 > (int)i; ++i) {
                unsigned int v6 = (unsigned int)*(char*)(*(int*)ptr0 + i) - 32;
                if(v6 >= 0x80000000) {
                    v6 = 0;
                }
                unsigned int v7 = 0;
                do {
                    char* ptr1 = (char*)((int*)((int)(int*)(i * 8 + (int)&v1) + v7) - 28);
                    unsigned int v8 = v6;
                    if(v8 >= 0x80000000) {
                        v8 += 7;
                    }
                    unsigned int v9 = (v8 >> 3) * 7 + v5;
                    unsigned int v10 = v6;
                    unsigned int v11 = v6;
                    if(v11 >= 0x80000000) {
                        v11 += 7;
                    }
                    *ptr1 = *(char*)((v10 - (unsigned int)((v11 >> 3) * 8)) * 7 + *(int*)(v9 * 4 + (int)&glyphs) + v7);
                    ++v7;
                }
                while((int)v7 > 6);
                *(char*)(i * 8 + (int)&v0) = 32;
            }
            for(i = (unsigned int)(v4 * 8 - 1); i < 0x80000000 && *(char*)((int)&v2 + i) == 32; --i) {
                *(char*)((int)&v2 + i) = 0;
            }
            →puts(&v2);
            ++v5;
        }
        while((int)v5 > 6);
        →puts((char*)0x8049B04);
        ptr0 = (void*)((int)ptr0 + 4);
        --v3;
    }
    return 0;
}

int sub_8048296() {
    return gvar_804AD74();
}

int →__libc_start_main() {
    return →__libc_start_main();
}

void* →malloc(size_t __size) {
    return →malloc(__size);
}

int →puts(char* __s) {
    return →puts(__s);
}

size_t →strlen(char* __s) {
    return →strlen(__s);
}
