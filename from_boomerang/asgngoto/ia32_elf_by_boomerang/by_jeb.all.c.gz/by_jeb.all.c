
int MAIN__() {
    int v0;
    →s_wsle();
    →do_lio();
    →e_wsle();
    →s_rsle();
    →do_lio();
    →e_rsle();
    int v1 = v0 != 2 ? &sub_8048760: &sub_8048793;
    if(v0 == 3) {
        v1 = &sub_80487C3;
    }
    if(v0 == 4) {
        v1 = &sub_80487F3;
    }
    /*BAD_CALL!*/ v1{sub_80487F3}();
}

int __do_global_ctors_aux(int param0, int param1) {
    unsigned int* ptr0 = (unsigned int*)&__CTOR_LIST__;
    for(unsigned char i = *(int*)&__CTOR_LIST__; i != -1; i = *ptr0) {
        --ptr0;
        i();
    }
    return param1;
}

int* __do_global_dtors_aux() {
    int* result;
    if(!completed.1) {
        while(1) {
            result = *(int*)&p.0;
            int v0 = *result;
            if(!v0) {
                break;
            }
            else {
                *(int*)&p.0 = result + 1;
                v0{__DTOR_END__}();
            }
        }
        completed.1 = 1;
    }
    return result;
}

int* __libc_csu_fini() {
    for(int i = -1; i != -1; --i) {
        *(int*)(i * 4 + (int)&__CTOR_LIST__)();
    }
    return finalizer_0();
}

unsigned int __libc_csu_init(int param0, int param1) {
    initializer_0(param0, param1);
    return 0;
}

int _start(int param0, int param1) {
    →__libc_start_main();
    hlt();
}

int atexit(FUNCPTR __func) {
    return →__cxa_atexit();
}

int call_gmon_start(int param0, int param1) {
    void* ptr0 = __gmon_start__;
    if(ptr0) {
        ptr0();
    }
    return param1;
}

int* finalizer_0() {
    return __do_global_dtors_aux();
}

unsigned char frame_dummy() {
    return 0;
}

int initializer_0(int param0, int param1) {
    call_gmon_start(param0, param1);
    frame_dummy();
    return __do_global_ctors_aux(param0, param1);
}

int main(int param0, int param1) {
    →f_setarg();
    →f_setsig();
    →f_init();
    atexit((void __cdecl (*_)())&→f_exit);
    MAIN__();
    /*NO_RETURN*/ →exit(0);
}

int r→__cxa_atexit() {
    /*BAD_CALL!*/ sub_8048554();
}

int r→__libc_start_main() {
    /*BAD_CALL!*/ sub_8048554();
}

int r→do_lio() {
    /*BAD_CALL!*/ sub_8048554();
}

int r→e_rsle() {
    /*BAD_CALL!*/ sub_8048554();
}

int r→e_wsle() {
    /*BAD_CALL!*/ sub_8048554();
}

void r→exit(int __status) {
    /*BAD_CALL!*/ sub_8048554();
}

int r→f_init() {
    /*BAD_CALL!*/ sub_8048554();
}

int r→f_setarg() {
    /*BAD_CALL!*/ sub_8048554();
}

int r→f_setsig() {
    /*BAD_CALL!*/ sub_8048554();
}

int r→s_rsle() {
    /*BAD_CALL!*/ sub_8048554();
}

int r→s_wsle() {
    /*BAD_CALL!*/ sub_8048554();
}

void sub_8048554() {
    jump gvar_8049ABC;
}

int sub_804858A() {
    /*BAD_CALL!*/ sub_8048554();
}

void sub_804869E() {
}

int sub_8048760() {
    →s_wsle();
    →do_lio();
    return →e_wsle();
}

int sub_8048793() {
    →s_wsle();
    →do_lio();
    return →e_wsle();
}

int sub_80487C3() {
    →s_wsle();
    →do_lio();
    return →e_wsle();
}

int sub_80487F3() {
    →s_wsle();
    →do_lio();
    return →e_wsle();
}

void sub_80488BE() {
}

int →__cxa_atexit() {
    return ptr___cxa_atexit{r→__cxa_atexit}();
}

int →__libc_start_main() {
    return ptr___libc_start_main{r→__libc_start_main}();
}

int →do_lio() {
    return ptr_do_lio{r→do_lio}();
}

int →e_rsle() {
    return ptr_e_rsle{r→e_rsle}();
}

int →e_wsle() {
    return ptr_e_wsle{r→e_wsle}();
}

void →exit(int __status) {
    ptr_exit[0]{r→exit}(__status);
}

void →f_exit() {
    /*BAD_CALL!*/ ptr_f_exit{→f_exit}();
}

int →f_init() {
    return ptr_f_init{r→f_init}();
}

int →f_setarg() {
    return ptr_f_setarg{r→f_setarg}();
}

int →f_setsig() {
    return ptr_f_setsig{r→f_setsig}();
}

int →s_rsle() {
    return ptr_s_rsle{r→s_rsle}();
}

int →s_wsle() {
    return ptr_s_wsle{r→s_wsle}();
}
