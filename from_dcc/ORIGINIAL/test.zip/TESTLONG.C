#include <stdio.h>

main()
{ long a, d;

	scanf ("%d", &d);
	scanf ("%d", &a);
	scanf ("%d %d", &a, &d);
	printf ("%ld %ld", a, d);
}