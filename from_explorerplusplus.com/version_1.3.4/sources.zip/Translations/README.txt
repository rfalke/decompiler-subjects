This directory contains the translation projects for Explorer++.

Each project should be built as a DLL with no entry point (Project Properties->Linker->Advanced->No Entry Point) and should have Whole Program Optimization turned off (Project Properties->General->Whole Program Optimization).