#include <shlobj.h>

HRESULT	CreateDataObject(FORMATETC *,STGMEDIUM *,IDataObject **,int);