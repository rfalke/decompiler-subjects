The projects within this solution make use of the Boost C++ libraries (http://www.boost.org). The following environment variable must be defined in order to build:

- BOOST
  Installation directory of Boost (e.g. C:\Program Files (x86)\boost\boost_1_46_1).

- BOOST_LIB
  Library directory within Boost (e.g. C:\Program Files (x86)\boost\boost_1_46_1\stage\lib).