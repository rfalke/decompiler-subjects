/* Defines how close the text can get to the bottom
of the display window before it is moved into the
next column. */
#define TEXT_VERTICAL_THRESHOLD	10

/* Defines the horizontal spacing between text columns. */
#define TEXT_COLUMN_SPACING	50