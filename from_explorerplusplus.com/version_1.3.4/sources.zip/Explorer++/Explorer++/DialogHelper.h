#ifndef DIALOGHELPER_INCLUDED
#define DIALOGHELPER_INCLUDED

namespace NDialogHelper
{
	const int DEFAULT_HISTORY_SIZE = 20;
}

#endif