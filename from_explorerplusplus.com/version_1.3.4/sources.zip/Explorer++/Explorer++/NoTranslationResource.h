//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by Explorer++_NoTranslation.rc
//
#define IDB_FOLDERLOCKED                101
#define IDB_TABTOOLBAR_CLOSE            102
#define IDB_FILTERINGAPPLIED            104
#define IDI_MAIN                        105
#define IDI_DISPLAYWINDOW               106
#define IDB_FOLDEREMPTY                 149
#define IDR_MAINACCELERATORS            152
#define IDB_SHELL_GO                    194
#define IDB_SHELLIMAGES                 205
#define IDI_MAIN_SMALL                  206
#define IDB_ABOUT                       231
#define IDR_WAVE_NAVIGATIONSTART        235
#define IDB_NOPREVIEWAVAILABLE          236
#define IDB_SHELLIMAGES_LARGE           237
#define IDM_FILE_NEWTAB                 40056
#define IDM_FILE_CLOSETAB               40057
#define IDM_FILE_COPYFOLDERPATH         40060
#define IDM_FILE_PROPERTIES             40065
#define IDM_EDIT_PASTESHORTCUT          40071
#define IDM_EDIT_COPYTOFOLDER           40072
#define IDM_EDIT_MOVETOFOLDER           40073
#define IDM_EDIT_SELECTNONE             40076
#define IDM_GO_BACK                     40093
#define IDM_GO_FORWARD                  40094
#define IDM_GO_UPONELEVEL               40095
#define IDM_VIEW_SHOWHIDDENFILES        40104
#define IDM_VIEW_REFRESH                40105
#define IDA_NEXTTAB                     40123
#define IDA_PREVIOUSTAB                 40125
#define IDM_FILE_DELETEPERMANENTLY      40145
#define IDM_BOOKMARKS_BOOKMARKTHISTAB   40174
#define IDM_EDIT_WILDCARDSELECTION      40195
#define IDM_BOOKMARKS_ORGANIZEBOOKMARKS 40197
#define IDM_EDIT_WILDCARDDESELECT       40204
#define IDM_FILTER_APPLYFILTER          40229
#define IDM_FILTER_FILTERRESULTS        40230
#define IDA_TAB_DUPLICATETAB            40247
#define IDM_ACTIONS_NEWFOLDER           40263
#define IDA_ADDRESSBAR                  40286
#define IDA_COMBODROPDOWN               40287
#define IDA_NEXTWINDOW                  40289
#define IDM_EDIT_UNDO                   40325
#define IDA_PREVIOUSWINDOW              40350
#define IDA_RCLICK                      40352
#define IDA_FILE_RENAME                 40377
#define IDM_TOOLS_SEARCH                40417
#define IDA_HOME                        40420
#define IDA_TAB1                        40423
#define IDA_TAB2                        40424
#define IDA_TAB3                        40425
#define IDA_TAB4                        40426
#define IDA_TAB5                        40427
#define IDA_TAB6                        40428
#define IDA_TAB7                        40429
#define IDA_TAB8                        40430
#define IDA_LASTTAB                     40431

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        241
#define _APS_NEXT_COMMAND_VALUE         40433
#define _APS_NEXT_CONTROL_VALUE         1255
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
