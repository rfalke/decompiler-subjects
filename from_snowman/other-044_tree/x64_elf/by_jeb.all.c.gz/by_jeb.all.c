
void __libc_csu_fini() {
}

void* __libc_csu_init(long param0, long param1, long param2) {
    void* result;
    unsigned long v0 = 0L;
    initializer_0();
    do {
        *(long*)(v0 * 8L + (long)&__frame_dummy_init_array_entry){initializer_1}();
        ++v0;
    }
    while(v0 != 1L);
    return result;
}

long _start(long param0, long param1) {
    long v0;
    void* ptr0;
    char v1;
    long v2;
    long v3 = 0L;
    char v4 = 1;
    char v5 = 0;
    char v6 = 1;
    char v7 = 0;
    char v8 = 0;
    long v9 = param1;
    long v10 = v0;
    long* ptr1 = &v1;
    char v11 = &v0 ? 0: 1;
    char v12 = (long)&v0 < 0L;
    char v13 = __parity__((unsigned char)&v0);
    char v14 = 0;
    char v15 = 0;
    long v16 = v2;
    long* ptr2 = &v16;
    long* ptr3 = &v16;
    long v17 = &__libc_csu_fini;
    long v18 = &__libc_csu_init;
    long v19 = &main;
    long* ptr4 = &ptr0;
    →__libc_start_main();
    hlt();
}

long deregister_tm_clones() {
    return 7L;
}

void finalizer_0() {
}

void finalizer_1() {
    char v0 = completed.6391 ? 0: 1;
    char v1 = completed.6391 >= 128;
    char v2 = __parity__(completed.6391);
    char v3 = completed.6391 < 0;
    char v4 = 0;
    char v5 = 0;
    jump v0 ? &sub_400549: &sub_40055A;
}

void* initializer_0() {
    void* result = __gmon_start__;
    if(result) {
        →__gmon_start__();
    }
    return result;
}

void initializer_1() {
    char v0 = *(long*)&__JCR_LIST__ ? 0: 1;
    char v1 = *(long*)&__JCR_LIST__ >= 0x8000000000000000L;
    char v2 = __parity__((unsigned char)*(long*)&__JCR_LIST__);
    char v3 = *(long*)&__JCR_LIST__ < 0L;
    char v4 = 0;
    char v5 = 0;
    jump v0 ? &→register_tm_clones: &sub_40056A;
}

unsigned long* insert(unsigned long* param0, unsigned int* param1) {
    unsigned long* result;
    if(!*param0) {
        result = param0;
        *result = param1;
    }
    else if((int)**param0 > (int)*param1) {
        long v0 = *param0 + 16L;
        result = (unsigned long*)insert(v0, (long)param1, v0);
    }
    else {
        int* ptr0 = *param0;
        result = (unsigned long*)*ptr0;
        if(*ptr0 < *param1) {
            long v1 = *param0 + 8L;
            result = (unsigned long*)insert(v1, (long)param1, v1);
        }
    }
    return result;
}

// Stale decompilation - Refresh this view to re-decompile this code
long main() {
    unsigned int v0;
    unsigned int* ptr0;
    long v1 = 0L;
    unsigned int v2 = 1;
    do {
        →malloc(24L);
        unsigned int* ptr1 = ptr0;
        *(long*)&ptr1[2] = 0L;
        *(long*)&ptr1[4] = 0L;
        →rand();
        ptr1[0] = v0;
        insert(&v1, ptr1);
        ++v2;
    }
    while((int)v2 <= 10);
    return printout(v1);
}

long printout(int* param0) {
    int* ptr0 = param0;
    if(*(long*)(ptr0 + 4)) {
        printout(*(long*)(ptr0 + 4));
    }
    →printf((char*)&gvar_400794);
    long result = *(long*)(ptr0 + 2);
    if(result) {
        result = printout(*(long*)(ptr0 + 2));
    }
    return result;
}

long sub_400446() {
    return gvar_600AF8();
}

long sub_400549() {
    long v0;
    long v1 = v0;
    deregister_tm_clones();
    completed.6391 = 1;
}

void sub_40055A() {
}

long sub_40056A() {
    return register_tm_clones();
}

void →__gmon_start__() {
    while(1) {
        /*BAD_CALL!*/ __gmon_start__();
        unsigned long* ptr0 = ptr0 - 1;
        *ptr0 = 2L;
        --ptr0;
        *ptr0 = gvar_600AF0;
    }
}

void →__libc_start_main() {
    while(1) {
        /*BAD_CALL!*/ __libc_start_main();
        unsigned long* ptr0 = ptr0 - 1;
        *ptr0 = 1L;
        --ptr0;
        *ptr0 = gvar_600AF0;
    }
}

void →malloc(size_t __size) {
    while(1) {
        /*BAD_CALL!*/ malloc(__size);
        unsigned long* ptr0 = ptr0 - 1;
        *ptr0 = 3L;
        --ptr0;
        *ptr0 = gvar_600AF0;
    }
}

void →printf(char* __format) {
    while(1) {
        /*BAD_CALL!*/ printf(__format);
        unsigned long* ptr0 = ptr0 - 1;
        *ptr0 = 0L;
        --ptr0;
        *ptr0 = gvar_600AF0;
    }
}

void →rand() {
    while(1) {
        /*BAD_CALL!*/ rand();
        unsigned long* ptr0 = ptr0 - 1;
        *ptr0 = 4L;
        --ptr0;
        *ptr0 = gvar_600AF0;
    }
}
