
void __libc_csu_fini() {
}

int __libc_csu_init(int param0, int param1, int param2) {
    int result;
    unsigned int v0 = 0;
    initializer_0();
    do {
        result = *(int*)(v0 * 4 + (int)&__frame_dummy_init_array_entry){initializer_1}();
        ++v0;
    }
    while(v0 != 1);
    return result;
}

void __x86.get_pc_thunk.bx() {
}

int _start(int param0, int param1) {
    int v0;
    char v1;
    void* ptr0;
    int v2;
    int v3 = 0;
    char v4 = 1;
    char v5 = 0;
    char v6 = 1;
    char v7 = 0;
    char v8 = 0;
    int v9 = v0;
    int* ptr1 = &v1;
    char v10 = &v0 ? 0: 1;
    char v11 = (int)&v0 < 0;
    char v12 = __parity__((unsigned char)&v0);
    char v13 = 0;
    char v14 = 0;
    int v15 = v2;
    int* ptr2 = &v15;
    int* ptr3 = &v15;
    int v16 = param1;
    int v17 = &__libc_csu_fini;
    int v18 = &__libc_csu_init;
    int* ptr4 = &v1;
    int v19 = &main;
    int* ptr5 = &ptr0;
    →__libc_start_main();
    hlt();
}

int deregister_tm_clones() {
    return 3;
}

void finalizer_0() {
}

void finalizer_1() {
    char v0 = completed.6007 ? 0: 1;
    char v1 = completed.6007 >= 128;
    char v2 = __parity__(completed.6007);
    char v3 = completed.6007 < 0;
    char v4 = 0;
    char v5 = 0;
    jump v0 ? &sub_8048419: &sub_804842C;
}

void* initializer_0() {
    void* result = __gmon_start__;
    if(result) {
        →__gmon_start__();
    }
    return result;
}

int initializer_1() {
    unsigned char v0 = *(int*)&__JCR_LIST__;
    char v1 = v0 ? 0: 1;
    char v2 = v0 >= 0x80000000;
    char v3 = __parity__((unsigned char)v0);
    char v4 = 0;
    char v5 = 0;
    jump v1 ? &→register_tm_clones: &sub_8048439;
}

unsigned int* insert(unsigned int* param0, unsigned int* param1) {
    unsigned int* result;
    if(!*param0) {
        result = param0;
        *result = param1;
    }
    else if((int)**param0 > (int)*param1) {
        result = (unsigned int*)insert(*param0 + 8, (int)param1);
    }
    else {
        result = **param0;
        if((int)*param1 > (int)result) {
            result = (unsigned int*)insert(*param0 + 4, (int)param1);
        }
    }
    return result;
}

// Stale decompilation - Refresh this view to re-decompile this code
int main() {
    unsigned int* ptr0;
    int v0 = 0;
    unsigned int v1 = 1;
    do {
        →malloc(12);
        unsigned int* ptr1 = ptr0;
        ptr1[1] = 0;
        ptr1[2] = 0;
        →rand();
        ptr1[0] = (unsigned int)ptr0;
        insert(&v0, ptr1);
        ++v1;
    }
    while((int)v1 <= 10);
    return printout(v0);
}

int printout(int* param0) {
    if(*(param0 + 2)) {
        printout(*(param0 + 2));
    }
    int v0 = *param0;
    →printf(&gvar_8048630);
    int result = *(param0 + 1);
    if(result) {
        result = printout(*(param0 + 1));
    }
    return result;
}

int sub_8048306() {
    return gvar_8049860();
}

int deregister_tm_clones() {
    return 3;
}

int sub_80483B0() {
    return 0;
}

void sub_80483E9() {
}

int sub_8048419() {
    int v0;
    int v1 = v0;
    deregister_tm_clones();
    completed.6007 = 1;
}

void sub_804842C() {
}

int sub_8048439() {
    return register_tm_clones();
}

void →__gmon_start__() {
    while(1) {
        /*BAD_CALL!*/ __gmon_start__();
        unsigned int* ptr0 = ptr0 - 1;
        *ptr0 = 16;
        --ptr0;
        *ptr0 = gvar_804985C;
    }
}

void →__libc_start_main() {
    while(1) {
        /*BAD_CALL!*/ __libc_start_main();
        unsigned int* ptr0 = ptr0 - 1;
        *ptr0 = 24;
        --ptr0;
        *ptr0 = gvar_804985C;
    }
}

void →malloc(int param0) {
    unsigned int* ptr0;
    while(1) {
        /*BAD_CALL!*/ malloc(*(size_t*)(ptr0 + 1));
        --ptr0;
        *ptr0 = 8;
        --ptr0;
        *ptr0 = gvar_804985C;
    }
}

void →printf(int param0) {
    unsigned int* ptr0;
    while(1) {
        /*BAD_CALL!*/ printf(*(char**)(ptr0 + 1));
        --ptr0;
        *ptr0 = 0;
        --ptr0;
        *ptr0 = gvar_804985C;
    }
}

void →rand() {
    while(1) {
        /*BAD_CALL!*/ rand();
        unsigned int* ptr0 = ptr0 - 1;
        *ptr0 = 32;
        --ptr0;
        *ptr0 = gvar_804985C;
    }
}
