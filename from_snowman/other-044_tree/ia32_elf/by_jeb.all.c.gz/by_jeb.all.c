
void __libc_csu_fini() {
}

int __libc_csu_init(int param0, int param1, int param2) {
    int result;
    int v0 = 0;
    initializer_0();
    do {
        result = *(int*)(v0 * 4 + (int)&__frame_dummy_init_array_entry){initializer_1}();
        ++v0;
    }
    while(v0 != 1);
    return result;
}

void __x86.get_pc_thunk.bx() {
}

int _start(int param0, int param1) {
    →__libc_start_main();
    hlt();
}

// Stale decompilation - Refresh this view to re-decompile this code
int deregister_tm_clones() {
    return 3;
}

void finalizer_0() {
}

int finalizer_1() {
    int result;
    return result;
}

int initializer_0() {
    int result = __gmon_start__;
    if(result) {
        result = →__gmon_start__();
    }
    return result;
}

int initializer_1() {
    return register_tm_clones();
}

unsigned int* insert(unsigned int* param0, int* param1) {
    unsigned int* result;
    if(!*param0) {
        result = param0;
        *result = param1;
    }
    else if(**param0 > *param1) {
        result = (unsigned int*)insert(*param0 + 8, (int)param1);
    }
    else {
        result = **param0;
        if((int)*param1 > (int)result) {
            result = (unsigned int*)insert(*param0 + 4, (int)param1);
        }
    }
    return result;
}

// Stale decompilation - Refresh this view to re-decompile this code
int main() {
    int v0 = 0;
    for(int i = 1; i <= 10; ++i) {
        int* ptr0 = (int*)→malloc(12);
        ptr0[1] = 0;
        ptr0[2] = ptr0[1];
        int v1 = →rand();
        ptr0[0] = v1;
        insert(&v0, ptr0);
    }
    return printout(v0);
}

int printout(int* param0) {
    int result;
    if(*(param0 + 2)) {
        printout(*(param0 + 2));
    }
    →printf((char*)&gvar_8048630, *param0);
    if(*(param0 + 1)) {
        result = printout(*(param0 + 1));
    }
    return result;
}

int register_tm_clones() {
    return 0;
}

int r→__gmon_start__() {
    /*BAD_CALL!*/ sub_8048300();
}

int r→__libc_start_main() {
    /*BAD_CALL!*/ sub_8048300();
}

void* r→malloc(size_t __size) {
    /*BAD_CALL!*/ sub_8048300();
}

int r→printf(char* __format, ...) {
    /*BAD_CALL!*/ sub_8048300();
}

int r→rand() {
    /*BAD_CALL!*/ sub_8048300();
}

void sub_8048300() {
    jump gvar_8049860;
}

int →__gmon_start__() {
    return ptr___gmon_start__{r→__gmon_start__}();
}

int →__libc_start_main() {
    return ptr___libc_start_main{r→__libc_start_main}();
}

void* →malloc(size_t __size) {
    return ptr_malloc[0]{r→malloc}(__size);
}

int →printf(char* __format, ...) {
    return ptr_printf[0]{r→printf}(__format);
}

int →rand() {
    return ptr_rand[0]{r→rand}();
}
