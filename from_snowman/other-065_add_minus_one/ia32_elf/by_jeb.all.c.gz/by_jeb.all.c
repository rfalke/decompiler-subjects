
int start() {
    unsigned int* ptr0;
    *ptr0 = *ptr0 - 1;
    *ptr0 = *ptr0 + 1;
}
