
int start() {
    int* ptr0;
    *ptr0 = 0x11220066;
}
