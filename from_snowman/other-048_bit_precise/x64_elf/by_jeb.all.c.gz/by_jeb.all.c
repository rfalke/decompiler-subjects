
long start() {
    *(short*)0x64 = 258;
}
