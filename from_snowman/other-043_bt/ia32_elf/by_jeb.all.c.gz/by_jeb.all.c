
int start() {
    int v0;
    char v1 = (v0 >>> 3) & 0x1;
    if(v1) {
        *(int*)0x1F4 = 10;
    }
}
