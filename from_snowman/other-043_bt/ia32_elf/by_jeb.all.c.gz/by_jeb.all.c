
int start() {
    int v0;
    if(((v0 >>> 3) & 0x1)) {
        *(int*)0x1F4 = 10;
    }
}
