
void g(long param0) {
}

long main() {
    long result;
    g(&f);
    return result;
}
