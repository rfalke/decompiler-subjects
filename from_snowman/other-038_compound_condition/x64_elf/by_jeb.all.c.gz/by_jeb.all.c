
void g() {
}

void h() {
}
