
char start(unsigned char* param0) {
    unsigned char v0;
    char v1 = *param0 == v0;
    unsigned char* ptr0 = param0 + 1L;
    if(v1) {
        char v2 = 1;
        v1 = *ptr0 == v0;
        v5 = *ptr0 > (char)v0;
        v3 = __parity__(v0 - *ptr0);
        v7 = *ptr0 > v0;
        v6 = (((v0 - *ptr0) ^ v0) & (*ptr0 ^ v0)) < 0;
        v4 = (((v0 - *ptr0) ^ (*ptr0 ^ v0)) >>> 4) & 0x1;
        --ptr0;
    }
}
