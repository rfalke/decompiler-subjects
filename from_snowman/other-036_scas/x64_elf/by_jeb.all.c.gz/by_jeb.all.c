
char start(long param0) {
}
