
void finalizer_0() {
}

void finalizer_1() {
}

void initializer_0() {
}

void initializer_1() {
}

void start() {
}

void sub_400710() {
    jump 0L;
}

void sub_400720() {
    jump 0L;
}

void sub_400730() {
    jump 0L;
}

void sub_400740() {
    jump 0L;
}

void sub_400750() {
    jump 0L;
}

void sub_400760() {
    jump 0L;
}

void sub_400770() {
    jump 0L;
}

void sub_400780() {
    jump 0L;
}

void sub_400790() {
    jump 0L;
}

void sub_4007A0() {
    jump 0L;
}

void sub_4007C0() {
    jump 0L;
}

void sub_4007D0() {
    jump 0L;
}

void sub_4007E0() {
    jump 0L;
}

void sub_4007F0() {
    jump 0L;
}
