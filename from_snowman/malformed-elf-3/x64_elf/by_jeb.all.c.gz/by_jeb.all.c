
void finalizer_0() {
}

void finalizer_1() {
}

long initializer_0() {
    return 0L;
}

void initializer_1() {
}

void start() {
}
