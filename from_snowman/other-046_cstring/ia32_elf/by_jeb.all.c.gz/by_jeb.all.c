
void __libc_csu_fini() {
}

int __libc_csu_init(int param0, int param1, int param2) {
    int result;
    int v0 = 0;
    initializer_0();
    do {
        result = *(int*)(v0 * 4 + (int)&__frame_dummy_init_array_entry){initializer_1}();
        ++v0;
    }
    while(v0 != 1);
    return result;
}

void __x86.get_pc_thunk.bx() {
}

int _start(int param0, int param1) {
    →__libc_start_main();
    hlt();
}

// Stale decompilation - Refresh this view to re-decompile this code
int deregister_tm_clones() {
    return 3;
}

void finalizer_0() {
}

int finalizer_1() {
    int result;
    return result;
}

int initializer_0() {
    int result = __gmon_start__;
    if(result) {
        result = →__gmon_start__();
    }
    return result;
}

int initializer_1() {
    return register_tm_clones();
}

int main() {
    size_t max = →strlen("Hello, World!");
    for(unsigned int i = 0; i < max; ++i) {
        →putchar((int)aHello__World_[i]);
    }
    →putchar(10);
    return 0;
}

int register_tm_clones() {
    return 0;
}

int r→__gmon_start__() {
    /*BAD_CALL!*/ sub_80482E0();
}

int r→__libc_start_main() {
    /*BAD_CALL!*/ sub_80482E0();
}

int r→putchar(int __c) {
    /*BAD_CALL!*/ sub_80482E0();
}

size_t r→strlen(char* __s) {
    /*BAD_CALL!*/ sub_80482E0();
}

void sub_80482E0() {
    jump gvar_804971C;
}

int →__gmon_start__() {
    return ptr___gmon_start__{r→__gmon_start__}();
}

int →__libc_start_main() {
    return ptr___libc_start_main{r→__libc_start_main}();
}

int →putchar(int __c) {
    return ptr_putchar[0]{r→putchar}(__c);
}

size_t →strlen(char* __s) {
    return ptr_strlen[0]{r→strlen}(__s);
}
