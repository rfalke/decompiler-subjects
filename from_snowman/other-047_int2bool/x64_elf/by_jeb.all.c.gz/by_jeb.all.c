
void __libc_csu_fini() {
}

long __libc_csu_init(long param0, long param1) {
    long result;
    long v0 = 0L;
    initializer_0();
    do {
        result = *(long*)(v0 * 8L + (long)&__frame_dummy_init_array_entry){initializer_1}();
        ++v0;
    }
    while(v0 != 1L);
    return result;
}

long _start() {
    →__libc_start_main();
    hlt();
}

// Stale decompilation - Refresh this view to re-decompile this code
long deregister_tm_clones() {
    return 7L;
}

long f() {
    return 10L;
}

void finalizer_0() {
}

long finalizer_1() {
    long result;
    return result;
}

long g(int param0) {
    return (unsigned long)param0;
}

long initializer_0() {
    long result = __gmon_start__;
    if(result) {
        result = →__gmon_start__();
    }
    return result;
}

long initializer_1() {
    return register_tm_clones();
}

long main() {
    long v0 = f();
    g((unsigned int)v0 ? 1L: 0L);
    return 0L;
}

long register_tm_clones() {
    return 0L;
}

long r→__gmon_start__() {
    /*BAD_CALL!*/ sub_400450();
}

long r→__libc_start_main() {
    /*BAD_CALL!*/ sub_400450();
}

void sub_400450() {
    jump gvar_6009E0;
}

long →__gmon_start__() {
    return ptr___gmon_start__{r→__gmon_start__}();
}

long →__libc_start_main() {
    return ptr___libc_start_main{r→__libc_start_main}();
}
