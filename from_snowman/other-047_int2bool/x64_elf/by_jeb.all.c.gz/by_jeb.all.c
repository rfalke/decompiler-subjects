
void __libc_csu_fini() {
}

void* __libc_csu_init(long param0, long param1, long param2) {
    void* result;
    unsigned long v0 = 0L;
    initializer_0();
    do {
        *(long*)(v0 * 8L + (long)&__frame_dummy_init_array_entry){initializer_1}();
        ++v0;
    }
    while(v0 != 1L);
    return result;
}

long _start(long param0, long param1) {
    long v0;
    void* ptr0;
    char v1;
    long v2;
    long v3 = 0L;
    char v4 = 1;
    char v5 = 0;
    char v6 = 1;
    char v7 = 0;
    char v8 = 0;
    long v9 = param1;
    long v10 = v0;
    long* ptr1 = &v1;
    char v11 = &v0 ? 0: 1;
    char v12 = (long)&v0 < 0L;
    char v13 = __parity__((unsigned char)&v0);
    char v14 = 0;
    char v15 = 0;
    long v16 = v2;
    long* ptr2 = &v16;
    long* ptr3 = &v16;
    long v17 = &__libc_csu_fini;
    long v18 = &__libc_csu_init;
    long v19 = &main;
    long* ptr4 = &ptr0;
    →__libc_start_main();
    hlt();
}

long deregister_tm_clones() {
    return 7L;
}

long f() {
    return 10L;
}

void finalizer_0() {
}

void finalizer_1() {
    char v0 = completed.6392 ? 0: 1;
    char v1 = completed.6392 >= 128;
    char v2 = __parity__(completed.6392);
    char v3 = completed.6392 < 0;
    char v4 = 0;
    char v5 = 0;
    jump v0 ? &sub_400529: &sub_40053A;
}

long g(int param0) {
    return (unsigned long)param0;
}

void* initializer_0() {
    void* result = __gmon_start__;
    if(result) {
        →__gmon_start__();
    }
    return result;
}

void initializer_1() {
    char v0 = *(long*)&__JCR_LIST__ ? 0: 1;
    char v1 = *(long*)&__JCR_LIST__ >= 0x8000000000000000L;
    char v2 = __parity__((unsigned char)*(long*)&__JCR_LIST__);
    char v3 = *(long*)&__JCR_LIST__ < 0L;
    char v4 = 0;
    char v5 = 0;
    jump v0 ? &→register_tm_clones: &sub_40054A;
}

long main() {
    long v0 = f();
    g((unsigned int)v0 ? 1L: 0L);
    return 0L;
}

long sub_400456() {
    return gvar_6009E0();
}

long sub_400529() {
    long v0;
    long v1 = v0;
    deregister_tm_clones();
    completed.6392 = 1;
}

void sub_40053A() {
}

long sub_40054A() {
    return register_tm_clones();
}

void →__gmon_start__() {
    while(1) {
        /*BAD_CALL!*/ __gmon_start__();
        unsigned long* ptr0 = ptr0 - 1;
        *ptr0 = 0L;
        --ptr0;
        *ptr0 = gvar_6009D8;
    }
}

void →__libc_start_main() {
    while(1) {
        /*BAD_CALL!*/ __libc_start_main();
        unsigned long* ptr0 = ptr0 - 1;
        *ptr0 = 1L;
        --ptr0;
        *ptr0 = gvar_6009D8;
    }
}
