
int do_switch(unsigned int param0) {
    int result;
    switch(param0) {
        case 1: {
            return &gvar_804A82B;
        }
        case 2: {
            return &gvar_804A82D;
        }
        case 3: {
            return &gvar_804A82F;
        }
        case 4: {
            return &gvar_804A831;
        }
        case 5: {
            return &gvar_804A833;
        }
        case 6: {
            return &gvar_804A835;
        }
        case 7: {
            return &gvar_804A837;
        }
        case 8: {
            return &gvar_804A839;
        }
        case 9: {
            return &gvar_804A83B;
        }
        case 10: {
            return &gvar_804A83D;
        }
        case 11: {
            return &gvar_804A840;
        }
        case 12: {
            return &gvar_804A843;
        }
        case 13: {
            return &gvar_804A846;
        }
        case 14: {
            return &gvar_804A849;
        }
        case 15: {
            return &gvar_804A84C;
        }
        case 16: {
            return &gvar_804A84F;
        }
        case 17: {
            return &gvar_804A852;
        }
        case 18: {
            return &gvar_804A855;
        }
        case 19: {
            return &gvar_804A858;
        }
        case 20: {
            return &gvar_804A85B;
        }
        case 21: {
            return &gvar_804A85E;
        }
        case 22: {
            return &gvar_804A861;
        }
        case 23: {
            return &gvar_804A864;
        }
        case 24: {
            return &gvar_804A867;
        }
        case 25: {
            return &gvar_804A86A;
        }
        case 26: {
            return &gvar_804A86D;
        }
        case 27: {
            return &gvar_804A870;
        }
        case 28: {
            return &gvar_804A873;
        }
        case 29: {
            return &gvar_804A876;
        }
        case 30: {
            return &gvar_804A879;
        }
        case 31: {
            return &gvar_804A87C;
        }
        case 32: {
            return &gvar_804A87F;
        }
        case 34: {
            return &gvar_804A882;
        }
        case 35: {
            return &gvar_804A885;
        }
        case 36: {
            return &gvar_804A888;
        }
        case 37: {
            return &gvar_804A88B;
        }
        case 38: {
            return &gvar_804A88E;
        }
        case 39: {
            return &gvar_804A891;
        }
        case 40: {
            return &gvar_804A894;
        }
        case 41: {
            return &gvar_804A897;
        }
        case 42: {
            return &gvar_804A89A;
        }
        case 43: {
            return &gvar_804A89D;
        }
        case 44: {
            return &gvar_804A8A0;
        }
        case 45: {
            return &gvar_804A8A3;
        }
        case 46: {
            return &gvar_804A8A6;
        }
        case 47: {
            return &gvar_804A8A9;
        }
        case 48: {
            return &gvar_804A8AC;
        }
        case 49: {
            return &gvar_804A8AF;
        }
        case 50: {
            return &gvar_804A8B2;
        }
        case 51: {
            return &gvar_804A8B5;
        }
        case 52: {
            return &gvar_804A8B8;
        }
        case 53: {
            return &gvar_804A8BB;
        }
        case 54: {
            return &gvar_804A8BE;
        }
        case 55: {
            return &gvar_804A8C1;
        }
        case 56: {
            return &gvar_804A8C4;
        }
        case 57: {
            return &gvar_804A8C7;
        }
        case 58: {
            return &gvar_804A8CA;
        }
        case 59: {
            return &gvar_804A8CD;
        }
        case 60: {
            return &gvar_804A8D0;
        }
        case 61: {
            return &gvar_804A8D3;
        }
        case 62: {
            return &gvar_804A8D6;
        }
        case 63: {
            return &gvar_804A8D9;
        }
        case 64: {
            return &gvar_804A8DC;
        }
        case 65: {
            return &gvar_804A8DF;
        }
        case 67: {
            return &gvar_804A8E2;
        }
        case 68: {
            return &gvar_804A8E5;
        }
        case 69: {
            return &gvar_804A8E8;
        }
        case 70: {
            return &gvar_804A8EB;
        }
        case 71: {
            return &gvar_804A8EE;
        }
        case 72: {
            return &gvar_804A8F1;
        }
        case 73: {
            return &gvar_804A8F4;
        }
        case 74: {
            return &gvar_804A8F7;
        }
        case 75: {
            return &gvar_804A8FA;
        }
        case 76: {
            return &gvar_804A8FD;
        }
        case 77: {
            return &gvar_804A900;
        }
        case 78: {
            return &gvar_804A903;
        }
        case 79: {
            return &gvar_804A906;
        }
        case 80: {
            return &gvar_804A909;
        }
        case 81: {
            return &gvar_804A90C;
        }
        case 82: {
            return &gvar_804A90F;
        }
        case 83: {
            return &gvar_804A912;
        }
        case 84: {
            return &gvar_804A915;
        }
        case 85: {
            return &gvar_804A918;
        }
        case 86: {
            return &gvar_804A91B;
        }
        case 87: {
            return &gvar_804A91E;
        }
        case 88: {
            return &gvar_804A921;
        }
        case 89: {
            return &gvar_804A924;
        }
        case 90: {
            return &gvar_804A927;
        }
        case 91: {
            return &gvar_804A92A;
        }
        case 92: {
            return &gvar_804A92D;
        }
        case 93: {
            return &gvar_804A930;
        }
        case 94: {
            return &gvar_804A933;
        }
        case 95: {
            return &gvar_804A936;
        }
        case 96: {
            return &gvar_804A939;
        }
        case 97: {
            return &gvar_804A93C;
        }
        case 98: {
            return &gvar_804A93F;
        }
        case 100: {
            return &gvar_804A942;
        }
        case 101: {
            return &gvar_804A946;
        }
        case 102: {
            return &gvar_804A94A;
        }
        case 103: {
            return &gvar_804A94E;
        }
        case 104: {
            return &gvar_804A952;
        }
        case 105: {
            return &gvar_804A956;
        }
        case 106: {
            return &gvar_804A95A;
        }
        case 107: {
            return &gvar_804A95E;
        }
        case 108: {
            return &gvar_804A962;
        }
        case 109: {
            return &gvar_804A966;
        }
        case 110: {
            return &gvar_804A96A;
        }
        case 111: {
            return &gvar_804A96E;
        }
        case 112: {
            return &gvar_804A972;
        }
        case 113: {
            return &gvar_804A976;
        }
        case 114: {
            return &gvar_804A97A;
        }
        case 115: {
            return &gvar_804A97E;
        }
        case 116: {
            return &gvar_804A982;
        }
        case 117: {
            return &gvar_804A986;
        }
        case 118: {
            return &gvar_804A98A;
        }
        case 119: {
            return &gvar_804A98E;
        }
        case 120: {
            return &gvar_804A992;
        }
        case 121: {
            return &gvar_804A996;
        }
        case 122: {
            return &gvar_804A99A;
        }
        case 123: {
            return &gvar_804A99E;
        }
        case 124: {
            return &gvar_804A9A2;
        }
        case 125: {
            return &gvar_804A9A6;
        }
        case 126: {
            return &gvar_804A9AA;
        }
        case 127: {
            return &gvar_804A9AE;
        }
        case 128: {
            return &gvar_804A9B2;
        }
        case 129: {
            return &gvar_804A9B6;
        }
        case 130: {
            return &gvar_804A9BA;
        }
        case 131: {
            return &gvar_804A9BE;
        }
        case 133: {
            return &gvar_804A9C2;
        }
        case 134: {
            return &gvar_804A9C6;
        }
        case 135: {
            return &gvar_804A9CA;
        }
        case 136: {
            return &gvar_804A9CE;
        }
        case 137: {
            return &gvar_804A9D2;
        }
        case 138: {
            return &gvar_804A9D6;
        }
        case 139: {
            return &gvar_804A9DA;
        }
        case 140: {
            return &gvar_804A9DE;
        }
        case 141: {
            return &gvar_804A9E2;
        }
        case 142: {
            return &gvar_804A9E6;
        }
        case 143: {
            return &gvar_804A9EA;
        }
        case 144: {
            return &gvar_804A9EE;
        }
        case 145: {
            return &gvar_804A9F2;
        }
        case 146: {
            return &gvar_804A9F6;
        }
        case 147: {
            return &gvar_804A9FA;
        }
        case 148: {
            return &gvar_804A9FE;
        }
        case 149: {
            return &gvar_804AA02;
        }
        case 150: {
            return &gvar_804AA06;
        }
        case 151: {
            return &gvar_804AA0A;
        }
        case 152: {
            return &gvar_804AA0E;
        }
        case 153: {
            return &gvar_804AA12;
        }
        case 154: {
            return &gvar_804AA16;
        }
        case 155: {
            return &gvar_804AA1A;
        }
        case 156: {
            return &gvar_804AA1E;
        }
        case 157: {
            return &gvar_804AA22;
        }
        case 158: {
            return &gvar_804AA26;
        }
        case 159: {
            return &gvar_804AA2A;
        }
        case 160: {
            return &gvar_804AA2E;
        }
        case 161: {
            return &gvar_804AA32;
        }
        case 162: {
            return &gvar_804AA36;
        }
        case 163: {
            return &gvar_804AA3A;
        }
        case 164: {
            return &gvar_804AA3E;
        }
        case 166: {
            return &gvar_804AA42;
        }
        case 167: {
            return &gvar_804AA46;
        }
        case 168: {
            return &gvar_804AA4A;
        }
        case 169: {
            return &gvar_804AA4E;
        }
        case 170: {
            return &gvar_804AA52;
        }
        case 171: {
            return &gvar_804AA56;
        }
        case 172: {
            return &gvar_804AA5A;
        }
        case 173: {
            return &gvar_804AA5E;
        }
        case 174: {
            return &gvar_804AA62;
        }
        case 175: {
            return &gvar_804AA66;
        }
        case 176: {
            return &gvar_804AA6A;
        }
        case 177: {
            return &gvar_804AA6E;
        }
        case 178: {
            return &gvar_804AA72;
        }
        case 179: {
            return &gvar_804AA76;
        }
        case 180: {
            return &gvar_804AA7A;
        }
        case 181: {
            return &gvar_804AA7E;
        }
        case 182: {
            return &gvar_804AA82;
        }
        case 183: {
            return &gvar_804AA86;
        }
        case 184: {
            return &gvar_804AA8A;
        }
        case 185: {
            return &gvar_804AA8E;
        }
        case 186: {
            return &gvar_804AA92;
        }
        case 187: {
            return &gvar_804AA96;
        }
        case 188: {
            return &gvar_804AA9A;
        }
        case 189: {
            return &gvar_804AA9E;
        }
        case 190: {
            return &gvar_804AAA2;
        }
        case 191: {
            return &gvar_804AAA6;
        }
        case 192: {
            return &gvar_804AAAA;
        }
        case 193: {
            return &gvar_804AAAE;
        }
        case 194: {
            return &gvar_804AAB2;
        }
        case 195: {
            return &gvar_804AAB6;
        }
        case 196: {
            return &gvar_804AABA;
        }
        case 197: {
            return &gvar_804AABE;
        }
        case 199: {
            return &gvar_804AAC2;
        }
        case 200: {
            return &gvar_804AAC6;
        }
        case 201: {
            return &gvar_804AACA;
        }
        case 202: {
            return &gvar_804AACE;
        }
        case 203: {
            return &gvar_804AAD2;
        }
        case 204: {
            return &gvar_804AAD6;
        }
        case 205: {
            return &gvar_804AADA;
        }
        case 206: {
            return &gvar_804AADE;
        }
        case 207: {
            return &gvar_804AAE2;
        }
        case 208: {
            return &gvar_804AAE6;
        }
        case 209: {
            return &gvar_804AAEA;
        }
        case 210: {
            return &gvar_804AAEE;
        }
        case 211: {
            return &gvar_804AAF2;
        }
        case 212: {
            return &gvar_804AAF6;
        }
        case 213: {
            return &gvar_804AAFA;
        }
        case 214: {
            return &gvar_804AAFE;
        }
        case 215: {
            return &gvar_804AB02;
        }
        case 216: {
            return &gvar_804AB06;
        }
        case 217: {
            return &gvar_804AB0A;
        }
        case 218: {
            return &gvar_804AB0E;
        }
        case 219: {
            return &gvar_804AB12;
        }
        case 220: {
            return &gvar_804AB16;
        }
        case 221: {
            return &gvar_804AB1A;
        }
        case 222: {
            return &gvar_804AB1E;
        }
        case 223: {
            return &gvar_804AB22;
        }
        case 224: {
            return &gvar_804AB26;
        }
        case 225: {
            return &gvar_804AB2A;
        }
        case 226: {
            return &gvar_804AB2E;
        }
        case 227: {
            return &gvar_804AB32;
        }
        case 228: {
            return &gvar_804AB36;
        }
        case 229: {
            return &gvar_804AB3A;
        }
        case 230: {
            return &gvar_804AB3E;
        }
        case 232: {
            return &gvar_804AB42;
        }
        case 233: {
            return &gvar_804AB46;
        }
        case 234: {
            return &gvar_804AB4A;
        }
        case 235: {
            return &gvar_804AB4E;
        }
        case 236: {
            return &gvar_804AB52;
        }
        case 237: {
            return &gvar_804AB56;
        }
        case 238: {
            return &gvar_804AB5A;
        }
        case 239: {
            return &gvar_804AB5E;
        }
        case 240: {
            return &gvar_804AB62;
        }
        case 241: {
            return &gvar_804AB66;
        }
        case 242: {
            return &gvar_804AB6A;
        }
        case 243: {
            return &gvar_804AB6E;
        }
        case 244: {
            return &gvar_804AB72;
        }
        case 245: {
            return &gvar_804AB76;
        }
        case 246: {
            return &gvar_804AB7A;
        }
        case 247: {
            return &gvar_804AB7E;
        }
        case 248: {
            return &gvar_804AB82;
        }
        case 249: {
            return &gvar_804AB86;
        }
        case 250: {
            return &gvar_804AB8A;
        }
        case 251: {
            return &gvar_804AB8E;
        }
        case 252: {
            return &gvar_804AB92;
        }
        case 253: {
            return &gvar_804AB96;
        }
        case 254: {
            return &gvar_804AB9A;
        }
        case 255: {
            return &gvar_804AB9E;
        }
        case 256: {
            return &gvar_804ABA2;
        }
        case 257: {
            return &gvar_804ABA6;
        }
        case 258: {
            return &gvar_804ABAA;
        }
        case 259: {
            return &gvar_804ABAE;
        }
        case 260: {
            return &gvar_804ABB2;
        }
        case 261: {
            return &gvar_804ABB6;
        }
        case 262: {
            return &gvar_804ABBA;
        }
        case 263: {
            return &gvar_804ABBE;
        }
        case 265: {
            return &gvar_804ABC2;
        }
        case 266: {
            return &gvar_804ABC6;
        }
        case 267: {
            return &gvar_804ABCA;
        }
        case 268: {
            return &gvar_804ABCE;
        }
        case 269: {
            return &gvar_804ABD2;
        }
        case 270: {
            return &gvar_804ABD6;
        }
        case 271: {
            return &gvar_804ABDA;
        }
        case 272: {
            return &gvar_804ABDE;
        }
        case 273: {
            return &gvar_804ABE2;
        }
        case 274: {
            return &gvar_804ABE6;
        }
        case 275: {
            return &gvar_804ABEA;
        }
        case 276: {
            return &gvar_804ABEE;
        }
        case 277: {
            return &gvar_804ABF2;
        }
        case 278: {
            return &gvar_804ABF6;
        }
        case 279: {
            return &gvar_804ABFA;
        }
        case 280: {
            return &gvar_804ABFE;
        }
        case 281: {
            return &gvar_804AC02;
        }
        case 282: {
            return &gvar_804AC06;
        }
        case 283: {
            return &gvar_804AC0A;
        }
        case 284: {
            return &gvar_804AC0E;
        }
        case 285: {
            return &gvar_804AC12;
        }
        case 286: {
            return &gvar_804AC16;
        }
        case 287: {
            return &gvar_804AC1A;
        }
        case 288: {
            return &gvar_804AC1E;
        }
        case 289: {
            return &gvar_804AC22;
        }
        case 290: {
            return &gvar_804AC26;
        }
        case 291: {
            return &gvar_804AC2A;
        }
        case 292: {
            return &gvar_804AC2E;
        }
        case 293: {
            return &gvar_804AC32;
        }
        case 294: {
            return &gvar_804AC36;
        }
        case 295: {
            return &gvar_804AC3A;
        }
        case 296: {
            return &gvar_804AC3E;
        }
        case 298: {
            return &gvar_804AC42;
        }
        case 299: {
            return &gvar_804AC46;
        }
        case 300: {
            return &gvar_804AC4A;
        }
        case 301: {
            return &gvar_804AC4E;
        }
        case 302: {
            return &gvar_804AC52;
        }
        case 303: {
            return &gvar_804AC56;
        }
        case 304: {
            return &gvar_804AC5A;
        }
        case 305: {
            return &gvar_804AC5E;
        }
        case 306: {
            return &gvar_804AC62;
        }
        case 307: {
            return &gvar_804AC66;
        }
        case 308: {
            return &gvar_804AC6A;
        }
        case 309: {
            return &gvar_804AC6E;
        }
        case 310: {
            return &gvar_804AC72;
        }
        case 311: {
            return &gvar_804AC76;
        }
        case 312: {
            return &gvar_804AC7A;
        }
        case 313: {
            return &gvar_804AC7E;
        }
        case 314: {
            return &gvar_804AC82;
        }
        case 315: {
            return &gvar_804AC86;
        }
        case 316: {
            return &gvar_804AC8A;
        }
        case 317: {
            return &gvar_804AC8E;
        }
        case 318: {
            return &gvar_804AC92;
        }
        case 319: {
            return &gvar_804AC96;
        }
        case 320: {
            return &gvar_804AC9A;
        }
        case 321: {
            return &gvar_804AC9E;
        }
        case 322: {
            return &gvar_804ACA2;
        }
        case 323: {
            return &gvar_804ACA6;
        }
        case 324: {
            return &gvar_804ACAA;
        }
        case 325: {
            return &gvar_804ACAE;
        }
        case 326: {
            return &gvar_804ACB2;
        }
        case 327: {
            return &gvar_804ACB6;
        }
        case 328: {
            return &gvar_804ACBA;
        }
        case 329: {
            return &gvar_804ACBE;
        }
        case 331: {
            return &gvar_804ACC2;
        }
        case 332: {
            return &gvar_804ACC6;
        }
        case 333: {
            return &gvar_804ACCA;
        }
        case 334: {
            return &gvar_804ACCE;
        }
        case 335: {
            return &gvar_804ACD2;
        }
        case 336: {
            return &gvar_804ACD6;
        }
        case 337: {
            return &gvar_804ACDA;
        }
        case 338: {
            return &gvar_804ACDE;
        }
        case 339: {
            return &gvar_804ACE2;
        }
        case 340: {
            return &gvar_804ACE6;
        }
        case 341: {
            return &gvar_804ACEA;
        }
        case 342: {
            return &gvar_804ACEE;
        }
        case 343: {
            return &gvar_804ACF2;
        }
        case 344: {
            return &gvar_804ACF6;
        }
        case 345: {
            return &gvar_804ACFA;
        }
        case 346: {
            return &gvar_804ACFE;
        }
        case 347: {
            return &gvar_804AD02;
        }
        case 348: {
            return &gvar_804AD06;
        }
        case 349: {
            return &gvar_804AD0A;
        }
        case 350: {
            return &gvar_804AD0E;
        }
        case 351: {
            return &gvar_804AD12;
        }
        case 352: {
            return &gvar_804AD16;
        }
        case 353: {
            return &gvar_804AD1A;
        }
        case 354: {
            return &gvar_804AD1E;
        }
        case 355: {
            return &gvar_804AD22;
        }
        case 356: {
            return &gvar_804AD26;
        }
        case 357: {
            return &gvar_804AD2A;
        }
        case 358: {
            return &gvar_804AD2E;
        }
        case 359: {
            return &gvar_804AD32;
        }
        case 360: {
            return &gvar_804AD36;
        }
        case 361: {
            return &gvar_804AD3A;
        }
        case 362: {
            return &gvar_804AD3E;
        }
        case 364: {
            return &gvar_804AD42;
        }
        case 365: {
            return &gvar_804AD46;
        }
        case 366: {
            return &gvar_804AD4A;
        }
        case 367: {
            return &gvar_804AD4E;
        }
        case 368: {
            return &gvar_804AD52;
        }
        case 369: {
            return &gvar_804AD56;
        }
        case 370: {
            return &gvar_804AD5A;
        }
        case 371: {
            return &gvar_804AD5E;
        }
        case 372: {
            return &gvar_804AD62;
        }
        case 373: {
            return &gvar_804AD66;
        }
        case 374: {
            return &gvar_804AD6A;
        }
        case 375: {
            return &gvar_804AD6E;
        }
        case 376: {
            return &gvar_804AD72;
        }
        case 377: {
            return &gvar_804AD76;
        }
        case 378: {
            return &gvar_804AD7A;
        }
        case 379: {
            return &gvar_804AD7E;
        }
        case 380: {
            return &gvar_804AD82;
        }
        case 381: {
            return &gvar_804AD86;
        }
        case 382: {
            return &gvar_804AD8A;
        }
        case 383: {
            return &gvar_804AD8E;
        }
        case 384: {
            return &gvar_804AD92;
        }
        case 385: {
            return &gvar_804AD96;
        }
        case 386: {
            return &gvar_804AD9A;
        }
        case 387: {
            return &gvar_804AD9E;
        }
        case 388: {
            return &gvar_804ADA2;
        }
        case 389: {
            return &gvar_804ADA6;
        }
        case 390: {
            return &gvar_804ADAA;
        }
        case 391: {
            return &gvar_804ADAE;
        }
        case 392: {
            return &gvar_804ADB2;
        }
        case 393: {
            return &gvar_804ADB6;
        }
        case 394: {
            return &gvar_804ADBA;
        }
        case 395: {
            return &gvar_804ADBE;
        }
        case 397: {
            return &gvar_804ADC2;
        }
        case 398: {
            return &gvar_804ADC6;
        }
        case 399: {
            return &gvar_804ADCA;
        }
        case 400: {
            return &gvar_804ADCE;
        }
        case 401: {
            return &gvar_804ADD2;
        }
        case 402: {
            return &gvar_804ADD6;
        }
        case 403: {
            return &gvar_804ADDA;
        }
        case 404: {
            return &gvar_804ADDE;
        }
        case 405: {
            return &gvar_804ADE2;
        }
        case 406: {
            return &gvar_804ADE6;
        }
        case 407: {
            return &gvar_804ADEA;
        }
        case 408: {
            return &gvar_804ADEE;
        }
        case 409: {
            return &gvar_804ADF2;
        }
        case 410: {
            return &gvar_804ADF6;
        }
        case 411: {
            return &gvar_804ADFA;
        }
        case 412: {
            return &gvar_804ADFE;
        }
        case 413: {
            return &gvar_804AE02;
        }
        case 414: {
            return &gvar_804AE06;
        }
        case 415: {
            return &gvar_804AE0A;
        }
        case 416: {
            return &gvar_804AE0E;
        }
        case 417: {
            return &gvar_804AE12;
        }
        case 418: {
            return &gvar_804AE16;
        }
        case 419: {
            return &gvar_804AE1A;
        }
        case 420: {
            return &gvar_804AE1E;
        }
        case 421: {
            return &gvar_804AE22;
        }
        case 422: {
            return &gvar_804AE26;
        }
        case 423: {
            return &gvar_804AE2A;
        }
        case 424: {
            return &gvar_804AE2E;
        }
        case 425: {
            return &gvar_804AE32;
        }
        case 426: {
            return &gvar_804AE36;
        }
        case 427: {
            return &gvar_804AE3A;
        }
        case 428: {
            return &gvar_804AE3E;
        }
        case 430: {
            return &gvar_804AE42;
        }
        case 431: {
            return &gvar_804AE46;
        }
        case 432: {
            return &gvar_804AE4A;
        }
        case 433: {
            return &gvar_804AE4E;
        }
        case 434: {
            return &gvar_804AE52;
        }
        case 435: {
            return &gvar_804AE56;
        }
        case 436: {
            return &gvar_804AE5A;
        }
        case 437: {
            return &gvar_804AE5E;
        }
        case 438: {
            return &gvar_804AE62;
        }
        case 439: {
            return &gvar_804AE66;
        }
        case 440: {
            return &gvar_804AE6A;
        }
        case 441: {
            return &gvar_804AE6E;
        }
        case 442: {
            return &gvar_804AE72;
        }
        case 443: {
            return &gvar_804AE76;
        }
        case 444: {
            return &gvar_804AE7A;
        }
        case 445: {
            return &gvar_804AE7E;
        }
        case 446: {
            return &gvar_804AE82;
        }
        case 447: {
            return &gvar_804AE86;
        }
        case 448: {
            return &gvar_804AE8A;
        }
        case 449: {
            return &gvar_804AE8E;
        }
        case 450: {
            return &gvar_804AE92;
        }
        case 451: {
            return &gvar_804AE96;
        }
        case 452: {
            return &gvar_804AE9A;
        }
        case 453: {
            return &gvar_804AE9E;
        }
        case 454: {
            return &gvar_804AEA2;
        }
        case 455: {
            return &gvar_804AEA6;
        }
        case 456: {
            return &gvar_804AEAA;
        }
        case 457: {
            return &gvar_804AEAE;
        }
        case 458: {
            return &gvar_804AEB2;
        }
        case 459: {
            return &gvar_804AEB6;
        }
        case 460: {
            return &gvar_804AEBA;
        }
        case 461: {
            return &gvar_804AEBE;
        }
        case 463: {
            return &gvar_804AEC2;
        }
        case 464: {
            return &gvar_804AEC6;
        }
        case 465: {
            return &gvar_804AECA;
        }
        case 466: {
            return &gvar_804AECE;
        }
        case 467: {
            return &gvar_804AED2;
        }
        case 468: {
            return &gvar_804AED6;
        }
        case 469: {
            return &gvar_804AEDA;
        }
        case 470: {
            return &gvar_804AEDE;
        }
        case 471: {
            return &gvar_804AEE2;
        }
        case 472: {
            return &gvar_804AEE6;
        }
        case 473: {
            return &gvar_804AEEA;
        }
        case 474: {
            return &gvar_804AEEE;
        }
        case 475: {
            return &gvar_804AEF2;
        }
        case 476: {
            return &gvar_804AEF6;
        }
        case 477: {
            return &gvar_804AEFA;
        }
        case 478: {
            return &gvar_804AEFE;
        }
        case 479: {
            return &gvar_804AF02;
        }
        case 480: {
            return &gvar_804AF06;
        }
        case 481: {
            return &gvar_804AF0A;
        }
        case 482: {
            return &gvar_804AF0E;
        }
        case 483: {
            return &gvar_804AF12;
        }
        case 484: {
            return &gvar_804AF16;
        }
        case 485: {
            return &gvar_804AF1A;
        }
        case 486: {
            return &gvar_804AF1E;
        }
        case 487: {
            return &gvar_804AF22;
        }
        case 488: {
            return &gvar_804AF26;
        }
        case 489: {
            return &gvar_804AF2A;
        }
        case 490: {
            return &gvar_804AF2E;
        }
        case 491: {
            return &gvar_804AF32;
        }
        case 492: {
            return &gvar_804AF36;
        }
        case 493: {
            return &gvar_804AF3A;
        }
        case 494: {
            return &gvar_804AF3E;
        }
        case 496: {
            return &gvar_804AF42;
        }
        case 497: {
            return &gvar_804AF46;
        }
        case 498: {
            return &gvar_804AF4A;
        }
        case 499: {
            return &gvar_804AF4E;
        }
        case 500: {
            return &gvar_804AF52;
        }
        case 501: {
            return &gvar_804AF56;
        }
        case 502: {
            return &gvar_804AF5A;
        }
        case 503: {
            return &gvar_804AF5E;
        }
        case 504: {
            return &gvar_804AF62;
        }
        case 505: {
            return &gvar_804AF66;
        }
        case 506: {
            return &gvar_804AF6A;
        }
        case 507: {
            return &gvar_804AF6E;
        }
        case 508: {
            return &gvar_804AF72;
        }
        case 509: {
            return &gvar_804AF76;
        }
        case 510: {
            return &gvar_804AF7A;
        }
        case 511: {
            return &gvar_804AF7E;
        }
        case 512: {
            return &gvar_804AF82;
        }
        case 513: {
            return &gvar_804AF86;
        }
        case 514: {
            return &gvar_804AF8A;
        }
        case 515: {
            return &gvar_804AF8E;
        }
        case 516: {
            return &gvar_804AF92;
        }
        case 517: {
            return &gvar_804AF96;
        }
        case 518: {
            return &gvar_804AF9A;
        }
        case 519: {
            return &gvar_804AF9E;
        }
        case 520: {
            return &gvar_804AFA2;
        }
        case 521: {
            return &gvar_804AFA6;
        }
        case 522: {
            return &gvar_804AFAA;
        }
        case 523: {
            return &gvar_804AFAE;
        }
        case 524: {
            return &gvar_804AFB2;
        }
        case 525: {
            return &gvar_804AFB6;
        }
        case 526: {
            return &gvar_804AFBA;
        }
        case 527: {
            return &gvar_804AFBE;
        }
        case 529: {
            return &gvar_804AFC2;
        }
        case 530: {
            return &gvar_804AFC6;
        }
        case 531: {
            return &gvar_804AFCA;
        }
        case 532: {
            return &gvar_804AFCE;
        }
        case 533: {
            return &gvar_804AFD2;
        }
        case 534: {
            return &gvar_804AFD6;
        }
        case 535: {
            return &gvar_804AFDA;
        }
        case 536: {
            return &gvar_804AFDE;
        }
        case 537: {
            return &gvar_804AFE2;
        }
        case 538: {
            return &gvar_804AFE6;
        }
        case 539: {
            return &gvar_804AFEA;
        }
        case 540: {
            return &gvar_804AFEE;
        }
        case 541: {
            return &gvar_804AFF2;
        }
        case 542: {
            return &gvar_804AFF6;
        }
        case 543: {
            return &gvar_804AFFA;
        }
        case 544: {
            return &gvar_804AFFE;
        }
        case 545: {
            return &gvar_804B002;
        }
        case 546: {
            return &gvar_804B006;
        }
        case 547: {
            return &gvar_804B00A;
        }
        case 548: {
            return &gvar_804B00E;
        }
        case 549: {
            return &gvar_804B012;
        }
        case 550: {
            return &gvar_804B016;
        }
        case 551: {
            return &gvar_804B01A;
        }
        case 552: {
            return &gvar_804B01E;
        }
        case 553: {
            return &gvar_804B022;
        }
        case 554: {
            return &gvar_804B026;
        }
        case 555: {
            return &gvar_804B02A;
        }
        case 556: {
            return &gvar_804B02E;
        }
        case 557: {
            return &gvar_804B032;
        }
        case 558: {
            return &gvar_804B036;
        }
        case 559: {
            return &gvar_804B03A;
        }
        case 560: {
            return &gvar_804B03E;
        }
        case 562: {
            return &gvar_804B042;
        }
        case 563: {
            return &gvar_804B046;
        }
        case 564: {
            return &gvar_804B04A;
        }
        case 565: {
            return &gvar_804B04E;
        }
        case 566: {
            return &gvar_804B052;
        }
        case 567: {
            return &gvar_804B056;
        }
        case 568: {
            return &gvar_804B05A;
        }
        case 569: {
            return &gvar_804B05E;
        }
        case 570: {
            return &gvar_804B062;
        }
        case 571: {
            return &gvar_804B066;
        }
        case 572: {
            return &gvar_804B06A;
        }
        case 573: {
            return &gvar_804B06E;
        }
        case 574: {
            return &gvar_804B072;
        }
        case 575: {
            return &gvar_804B076;
        }
        case 576: {
            return &gvar_804B07A;
        }
        case 577: {
            return &gvar_804B07E;
        }
        case 578: {
            return &gvar_804B082;
        }
        case 579: {
            return &gvar_804B086;
        }
        case 580: {
            return &gvar_804B08A;
        }
        case 581: {
            return &gvar_804B08E;
        }
        case 582: {
            return &gvar_804B092;
        }
        case 583: {
            return &gvar_804B096;
        }
        case 584: {
            return &gvar_804B09A;
        }
        case 585: {
            return &gvar_804B09E;
        }
        case 586: {
            return &gvar_804B0A2;
        }
        case 587: {
            return &gvar_804B0A6;
        }
        case 588: {
            return &gvar_804B0AA;
        }
        case 589: {
            return &gvar_804B0AE;
        }
        case 590: {
            return &gvar_804B0B2;
        }
        case 591: {
            return &gvar_804B0B6;
        }
        case 592: {
            return &gvar_804B0BA;
        }
        case 593: {
            return &gvar_804B0BE;
        }
        case 595: {
            return &gvar_804B0C2;
        }
        case 596: {
            return &gvar_804B0C6;
        }
        case 597: {
            return &gvar_804B0CA;
        }
        case 598: {
            return &gvar_804B0CE;
        }
        case 599: {
            return &gvar_804B0D2;
        }
        case 600: {
            return &gvar_804B0D6;
        }
        case 601: {
            return &gvar_804B0DA;
        }
        case 602: {
            return &gvar_804B0DE;
        }
        case 603: {
            return &gvar_804B0E2;
        }
        case 604: {
            return &gvar_804B0E6;
        }
        case 605: {
            return &gvar_804B0EA;
        }
        case 606: {
            return &gvar_804B0EE;
        }
        case 607: {
            return &gvar_804B0F2;
        }
        case 608: {
            return &gvar_804B0F6;
        }
        case 609: {
            return &gvar_804B0FA;
        }
        case 610: {
            return &gvar_804B0FE;
        }
        case 611: {
            return &gvar_804B102;
        }
        case 612: {
            return &gvar_804B106;
        }
        case 613: {
            return &gvar_804B10A;
        }
        case 614: {
            return &gvar_804B10E;
        }
        case 615: {
            return &gvar_804B112;
        }
        case 616: {
            return &gvar_804B116;
        }
        case 617: {
            return &gvar_804B11A;
        }
        case 618: {
            return &gvar_804B11E;
        }
        case 619: {
            return &gvar_804B122;
        }
        case 620: {
            return &gvar_804B126;
        }
        case 621: {
            return &gvar_804B12A;
        }
        case 622: {
            return &gvar_804B12E;
        }
        case 623: {
            return &gvar_804B132;
        }
        case 624: {
            return &gvar_804B136;
        }
        case 625: {
            return &gvar_804B13A;
        }
        case 626: {
            return &gvar_804B13E;
        }
        case 628: {
            return &gvar_804B142;
        }
        case 629: {
            return &gvar_804B146;
        }
        case 630: {
            return &gvar_804B14A;
        }
        case 631: {
            return &gvar_804B14E;
        }
        case 632: {
            return &gvar_804B152;
        }
        case 633: {
            return &gvar_804B156;
        }
        case 634: {
            return &gvar_804B15A;
        }
        case 635: {
            return &gvar_804B15E;
        }
        case 636: {
            return &gvar_804B162;
        }
        case 637: {
            return &gvar_804B166;
        }
        case 638: {
            return &gvar_804B16A;
        }
        case 639: {
            return &gvar_804B16E;
        }
        case 640: {
            return &gvar_804B172;
        }
        case 641: {
            return &gvar_804B176;
        }
        case 642: {
            return &gvar_804B17A;
        }
        case 643: {
            return &gvar_804B17E;
        }
        case 644: {
            return &gvar_804B182;
        }
        case 645: {
            return &gvar_804B186;
        }
        case 646: {
            return &gvar_804B18A;
        }
        case 647: {
            return &gvar_804B18E;
        }
        case 648: {
            return &gvar_804B192;
        }
        case 649: {
            return &gvar_804B196;
        }
        case 650: {
            return &gvar_804B19A;
        }
        case 651: {
            return &gvar_804B19E;
        }
        case 652: {
            return &gvar_804B1A2;
        }
        case 653: {
            return &gvar_804B1A6;
        }
        case 654: {
            return &gvar_804B1AA;
        }
        case 655: {
            return &gvar_804B1AE;
        }
        case 656: {
            return &gvar_804B1B2;
        }
        case 657: {
            return &gvar_804B1B6;
        }
        case 658: {
            return &gvar_804B1BA;
        }
        case 659: {
            return &gvar_804B1BE;
        }
        case 661: {
            return &gvar_804B1C2;
        }
        case 662: {
            return &gvar_804B1C6;
        }
        case 663: {
            return &gvar_804B1CA;
        }
        case 664: {
            return &gvar_804B1CE;
        }
        case 665: {
            return &gvar_804B1D2;
        }
        case 666: {
            return &gvar_804B1D6;
        }
        case 667: {
            return &gvar_804B1DA;
        }
        case 668: {
            return &gvar_804B1DE;
        }
        case 669: {
            return &gvar_804B1E2;
        }
        case 670: {
            return &gvar_804B1E6;
        }
        case 671: {
            return &gvar_804B1EA;
        }
        case 672: {
            return &gvar_804B1EE;
        }
        case 673: {
            return &gvar_804B1F2;
        }
        case 674: {
            return &gvar_804B1F6;
        }
        case 675: {
            return &gvar_804B1FA;
        }
        case 676: {
            return &gvar_804B1FE;
        }
        case 677: {
            return &gvar_804B202;
        }
        case 678: {
            return &gvar_804B206;
        }
        case 679: {
            return &gvar_804B20A;
        }
        case 680: {
            return &gvar_804B20E;
        }
        case 681: {
            return &gvar_804B212;
        }
        case 682: {
            return &gvar_804B216;
        }
        case 683: {
            return &gvar_804B21A;
        }
        case 684: {
            return &gvar_804B21E;
        }
        case 685: {
            return &gvar_804B222;
        }
        case 686: {
            return &gvar_804B226;
        }
        case 687: {
            return &gvar_804B22A;
        }
        case 688: {
            return &gvar_804B22E;
        }
        case 689: {
            return &gvar_804B232;
        }
        case 690: {
            return &gvar_804B236;
        }
        case 691: {
            return &gvar_804B23A;
        }
        case 692: {
            return &gvar_804B23E;
        }
        case 694: {
            return &gvar_804B242;
        }
        case 695: {
            return &gvar_804B246;
        }
        case 696: {
            return &gvar_804B24A;
        }
        case 697: {
            return &gvar_804B24E;
        }
        case 698: {
            return &gvar_804B252;
        }
        case 699: {
            return &gvar_804B256;
        }
        case 700: {
            return &gvar_804B25A;
        }
        case 701: {
            return &gvar_804B25E;
        }
        case 702: {
            return &gvar_804B262;
        }
        case 703: {
            return &gvar_804B266;
        }
        case 704: {
            return &gvar_804B26A;
        }
        case 705: {
            return &gvar_804B26E;
        }
        case 706: {
            return &gvar_804B272;
        }
        case 707: {
            return &gvar_804B276;
        }
        case 708: {
            return &gvar_804B27A;
        }
        case 709: {
            return &gvar_804B27E;
        }
        case 710: {
            return &gvar_804B282;
        }
        case 711: {
            return &gvar_804B286;
        }
        case 712: {
            return &gvar_804B28A;
        }
        case 713: {
            return &gvar_804B28E;
        }
        case 714: {
            return &gvar_804B292;
        }
        case 715: {
            return &gvar_804B296;
        }
        case 716: {
            return &gvar_804B29A;
        }
        case 717: {
            return &gvar_804B29E;
        }
        case 718: {
            return &gvar_804B2A2;
        }
        case 719: {
            return &gvar_804B2A6;
        }
        case 720: {
            return &gvar_804B2AA;
        }
        case 721: {
            return &gvar_804B2AE;
        }
        case 722: {
            return &gvar_804B2B2;
        }
        case 723: {
            return &gvar_804B2B6;
        }
        case 724: {
            return &gvar_804B2BA;
        }
        case 725: {
            return &gvar_804B2BE;
        }
        case 727: {
            return &gvar_804B2C2;
        }
        case 728: {
            return &gvar_804B2C6;
        }
        case 729: {
            return &gvar_804B2CA;
        }
        case 730: {
            return &gvar_804B2CE;
        }
        case 731: {
            return &gvar_804B2D2;
        }
        case 732: {
            return &gvar_804B2D6;
        }
        case 733: {
            return &gvar_804B2DA;
        }
        case 734: {
            return &gvar_804B2DE;
        }
        case 735: {
            return &gvar_804B2E2;
        }
        case 736: {
            return &gvar_804B2E6;
        }
        case 737: {
            return &gvar_804B2EA;
        }
        case 738: {
            return &gvar_804B2EE;
        }
        case 739: {
            return &gvar_804B2F2;
        }
        case 740: {
            return &gvar_804B2F6;
        }
        case 741: {
            return &gvar_804B2FA;
        }
        case 742: {
            return &gvar_804B2FE;
        }
        case 743: {
            return &gvar_804B302;
        }
        case 744: {
            return &gvar_804B306;
        }
        case 745: {
            return &gvar_804B30A;
        }
        case 746: {
            return &gvar_804B30E;
        }
        case 747: {
            return &gvar_804B312;
        }
        case 748: {
            return &gvar_804B316;
        }
        case 749: {
            return &gvar_804B31A;
        }
        case 750: {
            return &gvar_804B31E;
        }
        case 751: {
            return &gvar_804B322;
        }
        case 752: {
            return &gvar_804B326;
        }
        case 753: {
            return &gvar_804B32A;
        }
        case 754: {
            return &gvar_804B32E;
        }
        case 755: {
            return &gvar_804B332;
        }
        case 756: {
            return &gvar_804B336;
        }
        case 757: {
            return &gvar_804B33A;
        }
        case 758: {
            return &gvar_804B33E;
        }
        case 760: {
            return &gvar_804B342;
        }
        case 761: {
            return &gvar_804B346;
        }
        case 762: {
            return &gvar_804B34A;
        }
        case 763: {
            return &gvar_804B34E;
        }
        case 764: {
            return &gvar_804B352;
        }
        case 765: {
            return &gvar_804B356;
        }
        case 766: {
            return &gvar_804B35A;
        }
        case 767: {
            return &gvar_804B35E;
        }
        case 768: {
            return &gvar_804B362;
        }
        case 769: {
            return &gvar_804B366;
        }
        case 770: {
            return &gvar_804B36A;
        }
        case 771: {
            return &gvar_804B36E;
        }
        case 772: {
            return &gvar_804B372;
        }
        case 773: {
            return &gvar_804B376;
        }
        case 774: {
            return &gvar_804B37A;
        }
        case 775: {
            return &gvar_804B37E;
        }
        case 776: {
            return &gvar_804B382;
        }
        case 777: {
            return &gvar_804B386;
        }
        case 778: {
            return &gvar_804B38A;
        }
        case 779: {
            return &gvar_804B38E;
        }
        case 780: {
            return &gvar_804B392;
        }
        case 781: {
            return &gvar_804B396;
        }
        case 782: {
            return &gvar_804B39A;
        }
        case 783: {
            return &gvar_804B39E;
        }
        case 784: {
            return &gvar_804B3A2;
        }
        case 785: {
            return &gvar_804B3A6;
        }
        case 786: {
            return &gvar_804B3AA;
        }
        case 787: {
            return &gvar_804B3AE;
        }
        case 788: {
            return &gvar_804B3B2;
        }
        case 789: {
            return &gvar_804B3B6;
        }
        case 790: {
            return &gvar_804B3BA;
        }
        case 791: {
            return &gvar_804B3BE;
        }
        case 793: {
            return &gvar_804B3C2;
        }
        case 794: {
            return &gvar_804B3C6;
        }
        case 795: {
            return &gvar_804B3CA;
        }
        case 796: {
            return &gvar_804B3CE;
        }
        case 797: {
            return &gvar_804B3D2;
        }
        case 798: {
            return &gvar_804B3D6;
        }
        case 799: {
            return &gvar_804B3DA;
        }
        case 800: {
            return &gvar_804B3DE;
        }
        case 801: {
            return &gvar_804B3E2;
        }
        case 802: {
            return &gvar_804B3E6;
        }
        case 803: {
            return &gvar_804B3EA;
        }
        case 804: {
            return &gvar_804B3EE;
        }
        case 805: {
            return &gvar_804B3F2;
        }
        case 806: {
            return &gvar_804B3F6;
        }
        case 807: {
            return &gvar_804B3FA;
        }
        case 808: {
            return &gvar_804B3FE;
        }
        case 809: {
            return &gvar_804B402;
        }
        case 810: {
            return &gvar_804B406;
        }
        case 811: {
            return &gvar_804B40A;
        }
        case 812: {
            return &gvar_804B40E;
        }
        case 813: {
            return &gvar_804B412;
        }
        case 814: {
            return &gvar_804B416;
        }
        case 815: {
            return &gvar_804B41A;
        }
        case 816: {
            return &gvar_804B41E;
        }
        case 817: {
            return &gvar_804B422;
        }
        case 818: {
            return &gvar_804B426;
        }
        case 819: {
            return &gvar_804B42A;
        }
        case 820: {
            return &gvar_804B42E;
        }
        case 821: {
            return &gvar_804B432;
        }
        case 822: {
            return &gvar_804B436;
        }
        case 823: {
            return &gvar_804B43A;
        }
        case 824: {
            return &gvar_804B43E;
        }
        case 826: {
            return &gvar_804B442;
        }
        case 827: {
            return &gvar_804B446;
        }
        case 828: {
            return &gvar_804B44A;
        }
        case 829: {
            return &gvar_804B44E;
        }
        case 830: {
            return &gvar_804B452;
        }
        case 831: {
            return &gvar_804B456;
        }
        case 832: {
            return &gvar_804B45A;
        }
        case 833: {
            return &gvar_804B45E;
        }
        case 834: {
            return &gvar_804B462;
        }
        case 835: {
            return &gvar_804B466;
        }
        case 836: {
            return &gvar_804B46A;
        }
        case 837: {
            return &gvar_804B46E;
        }
        case 838: {
            return &gvar_804B472;
        }
        case 839: {
            return &gvar_804B476;
        }
        case 840: {
            return &gvar_804B47A;
        }
        case 841: {
            return &gvar_804B47E;
        }
        case 842: {
            return &gvar_804B482;
        }
        case 843: {
            return &gvar_804B486;
        }
        case 844: {
            return &gvar_804B48A;
        }
        case 845: {
            return &gvar_804B48E;
        }
        case 846: {
            return &gvar_804B492;
        }
        case 847: {
            return &gvar_804B496;
        }
        case 848: {
            return &gvar_804B49A;
        }
        case 849: {
            return &gvar_804B49E;
        }
        case 850: {
            return &gvar_804B4A2;
        }
        case 851: {
            return &gvar_804B4A6;
        }
        case 852: {
            return &gvar_804B4AA;
        }
        case 853: {
            return &gvar_804B4AE;
        }
        case 854: {
            return &gvar_804B4B2;
        }
        case 855: {
            return &gvar_804B4B6;
        }
        case 856: {
            return &gvar_804B4BA;
        }
        case 857: {
            return &gvar_804B4BE;
        }
        case 859: {
            return &gvar_804B4C2;
        }
        case 860: {
            return &gvar_804B4C6;
        }
        case 861: {
            return &gvar_804B4CA;
        }
        case 862: {
            return &gvar_804B4CE;
        }
        case 863: {
            return &gvar_804B4D2;
        }
        case 864: {
            return &gvar_804B4D6;
        }
        case 865: {
            return &gvar_804B4DA;
        }
        case 866: {
            return &gvar_804B4DE;
        }
        case 867: {
            return &gvar_804B4E2;
        }
        case 868: {
            return &gvar_804B4E6;
        }
        case 869: {
            return &gvar_804B4EA;
        }
        case 870: {
            return &gvar_804B4EE;
        }
        case 871: {
            return &gvar_804B4F2;
        }
        case 872: {
            return &gvar_804B4F6;
        }
        case 873: {
            return &gvar_804B4FA;
        }
        case 874: {
            return &gvar_804B4FE;
        }
        case 875: {
            return &gvar_804B502;
        }
        case 876: {
            return &gvar_804B506;
        }
        case 877: {
            return &gvar_804B50A;
        }
        case 878: {
            return &gvar_804B50E;
        }
        case 879: {
            return &gvar_804B512;
        }
        case 880: {
            return &gvar_804B516;
        }
        case 881: {
            return &gvar_804B51A;
        }
        case 882: {
            return &gvar_804B51E;
        }
        case 883: {
            return &gvar_804B522;
        }
        case 884: {
            return &gvar_804B526;
        }
        case 885: {
            return &gvar_804B52A;
        }
        case 886: {
            return &gvar_804B52E;
        }
        case 887: {
            return &gvar_804B532;
        }
        case 888: {
            return &gvar_804B536;
        }
        case 889: {
            return &gvar_804B53A;
        }
        case 890: {
            return &gvar_804B53E;
        }
        case 892: {
            return &gvar_804B542;
        }
        case 893: {
            return &gvar_804B546;
        }
        case 894: {
            return &gvar_804B54A;
        }
        case 895: {
            return &gvar_804B54E;
        }
        case 896: {
            return &gvar_804B552;
        }
        case 897: {
            return &gvar_804B556;
        }
        case 898: {
            return &gvar_804B55A;
        }
        case 899: {
            return &gvar_804B55E;
        }
        case 900: {
            return &gvar_804B562;
        }
        case 901: {
            return &gvar_804B566;
        }
        case 902: {
            return &gvar_804B56A;
        }
        case 903: {
            return &gvar_804B56E;
        }
        case 904: {
            return &gvar_804B572;
        }
        case 905: {
            return &gvar_804B576;
        }
        case 906: {
            return &gvar_804B57A;
        }
        case 907: {
            return &gvar_804B57E;
        }
        case 908: {
            return &gvar_804B582;
        }
        case 909: {
            return &gvar_804B586;
        }
        case 910: {
            return &gvar_804B58A;
        }
        case 911: {
            return &gvar_804B58E;
        }
        case 912: {
            return &gvar_804B592;
        }
        case 913: {
            return &gvar_804B596;
        }
        case 914: {
            return &gvar_804B59A;
        }
        case 915: {
            return &gvar_804B59E;
        }
        case 916: {
            return &gvar_804B5A2;
        }
        case 917: {
            return &gvar_804B5A6;
        }
        case 918: {
            return &gvar_804B5AA;
        }
        case 919: {
            return &gvar_804B5AE;
        }
        case 920: {
            return &gvar_804B5B2;
        }
        case 921: {
            return &gvar_804B5B6;
        }
        case 922: {
            return &gvar_804B5BA;
        }
        case 923: {
            return &gvar_804B5BE;
        }
        case 925: {
            return &gvar_804B5C2;
        }
        case 926: {
            return &gvar_804B5C6;
        }
        case 927: {
            return &gvar_804B5CA;
        }
        case 928: {
            return &gvar_804B5CE;
        }
        case 929: {
            return &gvar_804B5D2;
        }
        case 930: {
            return &gvar_804B5D6;
        }
        case 931: {
            return &gvar_804B5DA;
        }
        case 932: {
            return &gvar_804B5DE;
        }
        case 933: {
            return &gvar_804B5E2;
        }
        case 934: {
            return &gvar_804B5E6;
        }
        case 935: {
            return &gvar_804B5EA;
        }
        case 936: {
            return &gvar_804B5EE;
        }
        case 937: {
            return &gvar_804B5F2;
        }
        case 938: {
            return &gvar_804B5F6;
        }
        case 939: {
            return &gvar_804B5FA;
        }
        case 940: {
            return &gvar_804B5FE;
        }
        case 941: {
            return &gvar_804B602;
        }
        case 942: {
            return &gvar_804B606;
        }
        case 943: {
            return &gvar_804B60A;
        }
        case 944: {
            return &gvar_804B60E;
        }
        case 945: {
            return &gvar_804B612;
        }
        case 946: {
            return &gvar_804B616;
        }
        case 947: {
            return &gvar_804B61A;
        }
        case 948: {
            return &gvar_804B61E;
        }
        case 949: {
            return &gvar_804B622;
        }
        case 950: {
            return &gvar_804B626;
        }
        case 951: {
            return &gvar_804B62A;
        }
        case 952: {
            return &gvar_804B62E;
        }
        case 953: {
            return &gvar_804B632;
        }
        case 954: {
            return &gvar_804B636;
        }
        case 955: {
            return &gvar_804B63A;
        }
        case 956: {
            return &gvar_804B63E;
        }
        case 958: {
            return &gvar_804B642;
        }
        case 959: {
            return &gvar_804B646;
        }
        case 960: {
            return &gvar_804B64A;
        }
        case 961: {
            return &gvar_804B64E;
        }
        case 962: {
            return &gvar_804B652;
        }
        case 963: {
            return &gvar_804B656;
        }
        case 964: {
            return &gvar_804B65A;
        }
        case 965: {
            return &gvar_804B65E;
        }
        case 966: {
            return &gvar_804B662;
        }
        case 967: {
            return &gvar_804B666;
        }
        case 968: {
            return &gvar_804B66A;
        }
        case 969: {
            return &gvar_804B66E;
        }
        case 970: {
            return &gvar_804B672;
        }
        case 971: {
            return &gvar_804B676;
        }
        case 972: {
            return &gvar_804B67A;
        }
        case 973: {
            return &gvar_804B67E;
        }
        case 974: {
            return &gvar_804B682;
        }
        case 975: {
            return &gvar_804B686;
        }
        case 976: {
            return &gvar_804B68A;
        }
        case 977: {
            return &gvar_804B68E;
        }
        case 978: {
            return &gvar_804B692;
        }
        case 979: {
            return &gvar_804B696;
        }
        case 980: {
            return &gvar_804B69A;
        }
        case 981: {
            return &gvar_804B69E;
        }
        case 982: {
            return &gvar_804B6A2;
        }
        case 983: {
            return &gvar_804B6A6;
        }
        case 984: {
            return &gvar_804B6AA;
        }
        case 985: {
            return &gvar_804B6AE;
        }
        case 986: {
            return &gvar_804B6B2;
        }
        case 987: {
            return &gvar_804B6B6;
        }
        case 988: {
            return &gvar_804B6BA;
        }
        case 989: {
            return &gvar_804B6BE;
        }
        case 0: 
        case 33: 
        case 66: 
        case 99: 
        case 132: 
        case 165: 
        case 198: 
        case 231: 
        case 264: 
        case 297: 
        case 330: 
        case 363: 
        case 396: 
        case 429: 
        case 462: 
        case 495: 
        case 528: 
        case 561: 
        case 594: 
        case 627: 
        case 660: 
        case 693: 
        case 726: 
        case 759: 
        case 792: 
        case 825: 
        case 858: 
        case 891: 
        case 924: 
        case 957: 
        case 990: {
            printf("Hmm...");
            return result;
        }
        case 991: {
            return &gvar_804B6C2;
        }
        case 992: {
            return &gvar_804B6C6;
        }
        case 993: {
            return &gvar_804B6CA;
        }
        case 994: {
            return &gvar_804B6CE;
        }
        case 995: {
            return &gvar_804B6D2;
        }
        case 996: {
            return &gvar_804B6D6;
        }
        case 997: {
            return &gvar_804B6DA;
        }
        case 998: {
            return &gvar_804B6DE;
        }
        case 999: {
            return &gvar_804B6E2;
        }
        default: {
            return "many";
        }
    }
}

int printf(char* __format, ...) {
    int result;
    return result;
}
