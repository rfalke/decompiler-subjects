
void @124() {
}

long @19() {
    return 7L;
}

long @29e(long param0, long param1, long param2) {
    long result;
    unsigned long v0 = 0L;
    initializer_0();
    do {
        *(long*)(v0 * 8L + (long)&@99){initializer_1}();
        ++v0;
    }
    while(v0 != 1L);
    return result;
}

long @2c7(long param0, long param1) {
    long v0;
    void* ptr0;
    char v1;
    long v2;
    long v3 = 0L;
    char v4 = 1;
    char v5 = 0;
    char v6 = 1;
    char v7 = 0;
    char v8 = 0;
    long v9 = param1;
    long v10 = v0;
    long* ptr1 = &v1;
    char v11 = &v0 ? 0: 1;
    char v12 = (long)&v0 < 0L;
    char v13 = __parity__((unsigned char)&v0);
    char v14 = 0;
    char v15 = 0;
    long v16 = v2;
    long* ptr2 = &v16;
    long* ptr3 = &v16;
    long v17 = &@124;
    long v18 = &@29e;
    long v19 = &@2da;
    long* ptr4 = &ptr0;
    →@64();
    hlt();
}

long @2da() {
    int v0;
    long* ptr0;
    →@55();
    *ptr0 = 4981102551306676041L;
    *(int*)(ptr0 + 1) = 975193676;
    *(short*)((char*)ptr0 + 12L) = 0x292d;
    *(char*)((char*)ptr0 + 14L) = 0;
    →@34();
    →@50();
    →@1e();
    →@10();
    →@11();
    if((v0 & 0x1)) {
        →@50();
        →@b();
    }
    @2f3();
    →@49();
    return 0L;
}

long @2f3() {
    long v0 = *(long*)(__FS_BASE + (long)(long*)0x28);
    →@3b();
    →@3b();
    →@16();
    →@5c();
    →@4f();
    long result = *(long*)(__FS_BASE + (long)(long*)0x28) ^ v0;
    if(result) {
        →@23();
    }
    return result;
}

void finalizer_0() {
}

void finalizer_1() {
    char v0 = @57 ? 0: 1;
    char v1 = @57 >= 128;
    char v2 = __parity__(@57);
    char v3 = @57 < 0;
    char v4 = 0;
    char v5 = 0;
    jump v0 ? &sub_4008A9: &sub_4008BA;
}

long initializer_0() {
    return 0L;
}

void initializer_1() {
    char v0 = *(long*)&@c ? 0: 1;
    char v1 = *(long*)&@c >= 0x8000000000000000L;
    char v2 = __parity__((unsigned char)*(long*)&@c);
    char v3 = *(long*)&@c < 0L;
    char v4 = 0;
    char v5 = 0;
    jump v0 ? &→@2e: &sub_4008CA;
}

long sub_400706() {
    return gvar_601010();
}

long sub_4008A9() {
    long v0;
    long v1 = v0;
    @19();
    @57 = 1;
}

void sub_4008BA() {
}

long sub_4008CA() {
    return @2e();
}

void →@10() {
    while(1) {
        /*BAD_CALL!*/ @10();
        unsigned long* ptr0 = ptr0 - 1;
        *ptr0 = 9L;
        --ptr0;
        *ptr0 = gvar_601008;
    }
}

void →@11() {
    while(1) {
        /*BAD_CALL!*/ @11();
        unsigned long* ptr0 = ptr0 - 1;
        *ptr0 = 14L;
        --ptr0;
        *ptr0 = gvar_601008;
    }
}

void →@16() {
    while(1) {
        /*BAD_CALL!*/ @16();
        unsigned long* ptr0 = ptr0 - 1;
        *ptr0 = 0L;
        --ptr0;
        *ptr0 = gvar_601008;
    }
}

void →@1e() {
    while(1) {
        /*BAD_CALL!*/ @1e();
        unsigned long* ptr0 = ptr0 - 1;
        *ptr0 = 11L;
        --ptr0;
        *ptr0 = gvar_601008;
    }
}

void →@23() {
    while(1) {
        /*BAD_CALL!*/ @23();
        unsigned long* ptr0 = ptr0 - 1;
        *ptr0 = 3L;
        --ptr0;
        *ptr0 = gvar_601008;
    }
}

void →@34() {
    while(1) {
        /*BAD_CALL!*/ @34();
        unsigned long* ptr0 = ptr0 - 1;
        *ptr0 = 4L;
        --ptr0;
        *ptr0 = gvar_601008;
    }
}

void →@3b() {
    while(1) {
        /*BAD_CALL!*/ @3b();
        unsigned long* ptr0 = ptr0 - 1;
        *ptr0 = 2L;
        --ptr0;
        *ptr0 = gvar_601008;
    }
}

void →@49() {
    while(1) {
        /*BAD_CALL!*/ @49();
        unsigned long* ptr0 = ptr0 - 1;
        *ptr0 = 7L;
        --ptr0;
        *ptr0 = gvar_601008;
    }
}

void →@4f() {
    while(1) {
        /*BAD_CALL!*/ @4f();
        unsigned long* ptr0 = ptr0 - 1;
        *ptr0 = 5L;
        --ptr0;
        *ptr0 = gvar_601008;
    }
}

void →@50() {
    while(1) {
        /*BAD_CALL!*/ @50();
        unsigned long* ptr0 = ptr0 - 1;
        *ptr0 = 1L;
        --ptr0;
        *ptr0 = gvar_601008;
    }
}

void →@55() {
    while(1) {
        /*BAD_CALL!*/ @55();
        unsigned long* ptr0 = ptr0 - 1;
        *ptr0 = 12L;
        --ptr0;
        *ptr0 = gvar_601008;
    }
}

void →@5c() {
    while(1) {
        /*BAD_CALL!*/ @5c();
        unsigned long* ptr0 = ptr0 - 1;
        *ptr0 = 6L;
        --ptr0;
        *ptr0 = gvar_601008;
    }
}

void →@64() {
    while(1) {
        /*BAD_CALL!*/ @64();
        unsigned long* ptr0 = ptr0 - 1;
        *ptr0 = 8L;
        --ptr0;
        *ptr0 = gvar_601008;
    }
}

void →@76() {
    while(1) {
        /*BAD_CALL!*/ @76();
        unsigned long* ptr0 = ptr0 - 1;
        *ptr0 = 10L;
        --ptr0;
        *ptr0 = gvar_601008;
    }
}

void →@b() {
    while(1) {
        /*BAD_CALL!*/ @b();
        unsigned long* ptr0 = ptr0 - 1;
        *ptr0 = 13L;
        --ptr0;
        *ptr0 = gvar_601008;
    }
}
