
long g(int param0, int param1, int param2, int param3) {
    return (unsigned long)(param3 + param2 + (param1 + param0));
}

long h() {
    return 1L;
}
