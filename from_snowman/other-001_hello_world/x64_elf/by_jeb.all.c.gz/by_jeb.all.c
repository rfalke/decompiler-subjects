
void __do_global_ctors_aux() {
    // Decompilation error
}

void __do_global_dtors_aux() {
}

void __libc_csu_fini() {
}

long __libc_csu_init() {
    return initializer_0();
}

long _start() {
    →__libc_start_main();
    hlt();
}

void* call_gmon_start() {
    void* result = __gmon_start__;
    if(result) {
        result = (void*)result();
    }
    return result;
}

long finalizer_0() {
    long result;
    __do_global_dtors_aux();
    return result;
}

long frame_dummy() {
    long result;
    if(*(long*)&__JCR_LIST__) {
        result = 0L;
    }
    return result;
}

long initializer_0() {
    call_gmon_start();
    frame_dummy();
    return __do_global_ctors_aux();
}

long main() {
    →puts("Hello, World!");
    return 0L;
}

long r→__libc_start_main() {
    /*BAD_CALL!*/ sub_4003D0();
}

int r→puts(char* __s) {
    /*BAD_CALL!*/ sub_4003D0();
}

void sub_4003D0() {
    jump gvar_600880;
}

long →__libc_start_main() {
    return ptr___libc_start_main{r→__libc_start_main}();
}

int →puts(char* __s) {
    return ptr_puts[0]{r→puts}(__s);
}
