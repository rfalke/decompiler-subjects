
void __do_global_ctors_aux() {
    // Decompilation error
}

unsigned long __do_global_dtors_aux() {
    unsigned long result;
    return result;
}

void __libc_csu_fini() {
}

long __libc_csu_init(long param0, long param1, long param2) {
    return initializer_0();
}

long _start(long param0, long param1) {
    long v0;
    void* ptr0;
    char v1;
    long v2;
    long v3 = 0L;
    char v4 = 1;
    char v5 = 0;
    char v6 = 1;
    char v7 = 0;
    char v8 = 0;
    long v9 = param1;
    long v10 = v0;
    long* ptr1 = &v1;
    char v11 = &v0 ? 0: 1;
    char v12 = (long)&v0 < 0L;
    char v13 = __parity__((unsigned char)&v0);
    char v14 = 0;
    char v15 = 0;
    long v16 = v2;
    long* ptr2 = &v16;
    long* ptr3 = &v16;
    long v17 = &__libc_csu_fini;
    long v18 = &__libc_csu_init;
    long v19 = &main;
    long* ptr4 = &ptr0;
    →__libc_start_main();
    hlt();
}

void* call_gmon_start() {
    void* result = __gmon_start__;
    if(result) {
        result = (void*)result();
    }
    return result;
}

unsigned long finalizer_0() {
    return __do_global_dtors_aux();
}

long frame_dummy() {
    long result;
    if(*(long*)&__JCR_LIST__) {
        result = 0L;
    }
    return result;
}

long initializer_0() {
    call_gmon_start();
    frame_dummy();
    return __do_global_ctors_aux();
}

long main() {
    →puts("Hello, World!");
    return 0L;
}

long sub_4003D6() {
    return gvar_600880();
}

void →__libc_start_main() {
    while(1) {
        /*BAD_CALL!*/ __libc_start_main();
        unsigned long* ptr0 = ptr0 - 1;
        *ptr0 = 1L;
        --ptr0;
        *ptr0 = gvar_600878;
    }
}

void →puts(char* __s) {
    while(1) {
        /*BAD_CALL!*/ puts(__s);
        unsigned long* ptr0 = ptr0 - 1;
        *ptr0 = 0L;
        --ptr0;
        *ptr0 = gvar_600878;
    }
}
