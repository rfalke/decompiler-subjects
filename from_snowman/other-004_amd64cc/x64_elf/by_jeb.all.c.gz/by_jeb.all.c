
long main() {
    int v0 = 9;
    int v1 = 8;
    int v2 = 7;
    f(1L, 2L, 3L, 4L, 5L, 6L, *(long*)&v2, *(long*)&v1, *(long*)&v0);
    return 0L;
}
