
long main() {
    long v0;
    long v1 = (unsigned long)9 | ((unsigned long)(unsigned int)(v1 >>> 32L) << 32);
    long v2 = (unsigned long)8 | ((unsigned long)(unsigned int)(v2 >>> 32L) << 32);
    v0 & 0xFFFFFFFFL = 7;
    f(1L, 2L, 3L, 4L, 5L, 6L, v0, v2, v1);
    return 0L;
}
