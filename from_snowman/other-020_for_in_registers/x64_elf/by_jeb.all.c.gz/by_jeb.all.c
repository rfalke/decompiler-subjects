
long main(int param0) {
    for(long i = 0L; (unsigned int)i <= 9; i = (unsigned long)(param0 + 1)) {
        start();
    }
    return 0L;
}

void start() {
}
