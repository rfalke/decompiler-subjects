
long main(int param0) {
    do {
        start();
    }
    while((int)(unsigned int)(param0 + 1) <= 9);
    return 0L;
}

void start() {
}
