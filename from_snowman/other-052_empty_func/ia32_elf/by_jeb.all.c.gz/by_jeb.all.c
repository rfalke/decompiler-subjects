
int start() {
    /*BAD_CALL!*/ 123456(3);
}
