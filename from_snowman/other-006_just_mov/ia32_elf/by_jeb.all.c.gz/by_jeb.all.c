
int start() {
    int v0;
    *(int*)(v0 + 4) = 1000;
}
