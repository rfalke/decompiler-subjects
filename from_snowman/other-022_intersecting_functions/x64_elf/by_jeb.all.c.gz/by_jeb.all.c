
void g() {
}

long main() {
    long result;
    start();
    g();
    return result;
}

void start() {
}
