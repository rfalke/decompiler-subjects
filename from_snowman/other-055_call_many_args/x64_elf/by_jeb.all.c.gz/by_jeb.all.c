
long g() {
    long result;
    f(1L, 2L, 3L, 4L, 5L, 6L);
    return result;
}
