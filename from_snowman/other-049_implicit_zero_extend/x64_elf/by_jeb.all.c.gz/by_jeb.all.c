
long start() {
    *(long*)0x64 = 2L;
}
