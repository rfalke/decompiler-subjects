
long start() {
    for(int i = 0; i <= 9; ++i) {
        *(char*)i = 7;
    }
    return 0L;
}
