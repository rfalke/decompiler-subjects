
long start() {
    unsigned int v0 = 0;
    do {
        *(char*)v0 = 7;
        ++v0;
    }
    while((int)v0 <= 9);
    return 0L;
}
