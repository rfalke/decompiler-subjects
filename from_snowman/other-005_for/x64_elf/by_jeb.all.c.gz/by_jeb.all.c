
long main() {
    for(int i = 0; i <= 9; ++i) {
        puts("Hello!\n");
    }
    return 0L;
}

int puts(char* __s) {
    int result;
    return result;
}
