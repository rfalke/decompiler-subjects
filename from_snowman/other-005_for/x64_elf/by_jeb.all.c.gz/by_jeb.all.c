
long main() {
    unsigned int v0 = 0;
    do {
        puts("Hello!\n");
        ++v0;
    }
    while((int)v0 <= 9);
    return 0L;
}

int puts(char* __s) {
    long result;
    return result;
}
