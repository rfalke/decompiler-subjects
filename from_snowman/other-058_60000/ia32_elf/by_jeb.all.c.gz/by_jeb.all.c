
void start() {
    // Decompilation error
}
